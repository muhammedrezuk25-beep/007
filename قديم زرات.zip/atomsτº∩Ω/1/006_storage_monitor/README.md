# 6 — Storage Monitor (مراقب مساحة التخزين)

**id=6 — النسخة الأصلية يلي اعتمدتها فعليًا بمشروعك.**

## المسؤولية

فحص دوري لمساحة القرص المتاحة، تنبيه عند اقتراب الامتلاء.

## المدخلات

لا يوجد (`subscribes: []`).

## المخرجات

- `tools.storage.low` — عند أول دخول لحالة غير HEALTHY (DEGRADED أو UNHEALTHY).
- `tools.storage.recovered` — عند العودة لـHEALTHY من أي حالة سيئة.

كلاهما edge-triggered: لا يتكرر النشر طالما البقاء بنفس نوع الحالة
(سيئة أو سليمة)، ولا عند الانتقال بين DEGRADED وUNHEALTHY (لسا "سيئة").
Payload: `{path, used_pct, used_bytes, total_bytes}`.

## لماذا لا توجد حلقة داخلية؟

`health.interval_ms` بالعقد أصلًا يعني Health Manager ينادي
`health_check()` دوريًا — استخدام مباشر لحقل موجود، بلا حاجة لحلقة
asyncio منفصلة. `start()`/`stop()` شبه فارغتين عمدًا.

## الحالات — نسبة استخدام (used%) لا تفرّغ (free%)

| الحالة | الشرط (افتراضي 80/90) |
|---|---|
| `HEALTHY` | `used_pct < 80` |
| `DEGRADED` | `80 <= used_pct < 90` |
| `UNHEALTHY` | `used_pct >= 90` |
| `UNKNOWN` | تعذّر قراءة المسار |

## snapshot()/restore()

يحفظان آخر حالة منشورة (`healthy`/`degraded`/`unhealthy`). بدونهما، أي
Restart يصفّر التتبّع فيُطلق `tools.storage.low` مكررًا كاذبًا فور أول
فحص تالٍ رغم عدم حدوث انتقال حقيقي. مُختبَر فعليًا بمحاكاة Restart كامل.

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

4 اختبارات: الحالات الثلاث بعتبات 80/90، سلوك `low`/`recovered`
عبر 6 فحوصات متتالية (بما فيها انتقال بين حالتين سيئتين بلا نشر إضافي)،
منع تنبيه مكرر كاذب بعد Restart محاكى، وحالة `UNKNOWN`. **نتيجة آخر
تشغيل: 4/4.**
