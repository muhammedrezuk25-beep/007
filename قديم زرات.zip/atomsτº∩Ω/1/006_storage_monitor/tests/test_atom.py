import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
from collections import namedtuple
from unittest.mock import patch

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom6"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
Usage = namedtuple("Usage", ["total", "used", "free"])


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(
        atom_id=6, config=config or {}, logger=_NullLogger(),
        publish=publish, subscribe=lambda n, h: None,
    ), published


async def test_three_tiers_used_pct_semantics():
    print("\n--- test_three_tiers_used_pct_semantics ---")
    context, published = make_context({"path": "/fake", "warn_threshold_pct": 80.0, "critical_threshold_pct": 90.0})
    atom = Atom()
    await atom.initialize(context)
    await atom.start()

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=50, free=50)):
        h = await atom.health_check()
        assert h.state.value == "healthy", h.message

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=85, free=15)):
        h = await atom.health_check()
        assert h.state.value == "degraded", h.message

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=95, free=5)):
        h = await atom.health_check()
        assert h.state.value == "unhealthy", h.message

    await atom.stop()
    print(f"OK — used=50→healthy, used=85→degraded, used=95→unhealthy (عتبات 80/90)")


async def test_low_and_recovered_edge_triggered():
    print("\n--- test_low_and_recovered_edge_triggered ---")
    context, published = make_context({"path": "/fake"})
    atom = Atom()
    await atom.initialize(context)
    await atom.start()

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=50, free=50)):
        await atom.health_check()
    assert len(published) == 0

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=85, free=15)):
        await atom.health_check()
    assert len(published) == 1 and published[0][0] == "tools.storage.low"

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=95, free=5)):
        await atom.health_check()  # DEGRADED -> UNHEALTHY، لسا "غير صحي" — لا نشر إضافي
    assert len(published) == 1, "الانتقال بين حالتين سيئتين لا يعيد نشر low"

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=88, free=12)):
        await atom.health_check()  # UNHEALTHY -> DEGRADED، لسا "غير صحي" — لا recovered بعد
    assert len(published) == 1, "لسا مش HEALTHY كليًا، ما لازم ينشر recovered"

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=50, free=50)):
        await atom.health_check()
    assert len(published) == 2 and published[1][0] == "tools.storage.recovered"

    with patch("shutil.disk_usage", return_value=Usage(total=100, used=82, free=18)):
        await atom.health_check()
    assert len(published) == 3 and published[2][0] == "tools.storage.low", "انتقال جديد لمنخفض بعد تعافٍ يجب أن ينشر"

    await atom.stop()
    print(f"OK — 6 فحوصات، 3 أحداث (low, [لا شيء بين الحالتين السيئتين], recovered, low جديد)")


async def test_snapshot_restore_prevents_duplicate_after_restart():
    print("\n--- test_snapshot_restore_prevents_duplicate_after_restart ---")
    context, published = make_context({"path": "/fake"})
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    with patch("shutil.disk_usage", return_value=Usage(total=100, used=85, free=15)):
        await atom.health_check()
    assert len(published) == 1
    snap = await atom.snapshot()
    await atom.stop()

    atom2 = Atom()
    context2, published2 = make_context({"path": "/fake"})
    await atom2.initialize(context2)
    await atom2.restore(snap)
    await atom2.start()
    with patch("shutil.disk_usage", return_value=Usage(total=100, used=87, free=13)):
        h = await atom2.health_check()
        assert h.state.value == "degraded"
        assert len(published2) == 0, "لا انتقال حقيقي — restore منع تنبيهًا مكررًا كاذبًا"
    await atom2.stop()
    print("OK — restore() منع إعادة نشر low بلا انتقال فعلي")


async def test_unknown_on_bad_path():
    print("\n--- test_unknown_on_bad_path ---")
    context, published = make_context({"path": "/definitely/does/not/exist/xyz"})
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    h = await atom.health_check()
    assert h.state.value == "unknown", h.message
    await atom.stop()
    print(f"OK — مسار غير موجود → UNKNOWN")


async def main():
    tests = [
        test_three_tiers_used_pct_semantics,
        test_low_and_recovered_edge_triggered,
        test_snapshot_restore_prevents_duplicate_after_restart,
        test_unknown_on_bad_path,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
