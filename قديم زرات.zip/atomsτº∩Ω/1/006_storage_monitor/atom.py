"""
id=804 — مراقب مساحة التخزين (Storage Monitor)

المسؤولية: فحص دوري لمساحة القرص المتاحة، تنبيه عند اقتراب الامتلاء.

لا حلقة داخلية إطلاقًا: Health Manager أصلًا ينادي health_check() كل
health.interval_ms. start()/stop() شبه فارغتين عمدًا.

النشر edge-triggered باتجاهين: tools.storage.low عند أول دخول لحالة
غير HEALTHY (مرة وحدة، لا يتكرر بالبقاء بنفس الحالة أو الانتقال بين
DEGRADED/UNHEALTHY)، وtools.storage.recovered عند العودة لـHEALTHY.
الحالة الأخيرة المنشورة محفوظة عبر snapshot/restore لمنع نشر مكرر
كاذب بعد أي Restart.

العتبات نسبة استخدام (used%) لا نسبة تفرّغ (free%) — افتراضي 80/90،
اصطلاح شائع بأدوات المراقبة (warn عند 80% استخدام، critical عند 90%).
"""

from __future__ import annotations

import shutil

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._path = "."
        self._warn_threshold_pct = 80.0
        self._critical_threshold_pct = 90.0
        self._last_published_state = "healthy"  # healthy | degraded | unhealthy

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._path = context.config.get("path", ".")
        self._warn_threshold_pct = float(context.config.get("warn_threshold_pct", 80.0))
        self._critical_threshold_pct = float(context.config.get("critical_threshold_pct", 90.0))
        context.logger.info(
            "StorageMonitor تمت تهيئته (path=%s, warn=%.1f%%, critical=%.1f%%)",
            self._path, self._warn_threshold_pct, self._critical_threshold_pct,
        )

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("StorageMonitor جاهز — health_check() هي آلية الفحص الوحيدة")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        try:
            usage = shutil.disk_usage(self._path)
        except OSError as exc:
            return HealthStatus(state=HealthState.UNKNOWN, message=f"تعذّرت قراءة المسار {self._path}: {exc}")

        used_pct = (usage.used / usage.total) * 100 if usage.total > 0 else 0.0

        if used_pct >= self._critical_threshold_pct:
            new_state, health = "unhealthy", HealthState.UNHEALTHY
        elif used_pct >= self._warn_threshold_pct:
            new_state, health = "degraded", HealthState.DEGRADED
        else:
            new_state, health = "healthy", HealthState.HEALTHY

        if self._context is not None:
            payload = {
                "path": self._path, "used_pct": round(used_pct, 2),
                "used_bytes": usage.used, "total_bytes": usage.total,
            }
            if new_state != "healthy" and self._last_published_state == "healthy":
                await self._context.publish("tools.storage.low", payload)
            elif new_state == "healthy" and self._last_published_state != "healthy":
                await self._context.publish("tools.storage.recovered", payload)

        self._last_published_state = new_state
        return HealthStatus(state=health, message=f"استخدام القرص: {used_pct:.1f}%")

    async def snapshot(self) -> dict:
        return {"last_published_state": self._last_published_state}

    async def restore(self, state: dict) -> None:
        self._last_published_state = state.get("last_published_state", "healthy")
