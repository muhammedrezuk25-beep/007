"""
ATOM_003 — CLOCK (الساعة المركزية)

الهدف الهندسي: توليد الزمن الرسمي الوحيد للنظام.

سبب وجود الذرة: منع استخدام sleep() المتفرّق داخل الذرات الأخرى.
CLOCK هي الاستثناء الوحيد المقصود لهذه القاعدة — هي المكان الرسمي
الوحيد الذي يُسمح فيه باستخدام بدائية توقيت خام (loop.time /
asyncio.sleep)، بالضبط عشان يمنع أي ذرة تانية من الحاجة لفعل ذلك:
أي ذرة تحتاج توقيتًا تشترك بأحداثها (subscribe) بدل ما تدير حلقة
sleep() خاصة فيها.

التواصل مع بقية الذرات عبر الأحداث المنشورة فقط (Event Bus) — CLOCK
لا تعرف من يشترك بأحداثها ولا تستدعي أي ذرة مباشرة، بما يطابق قاعدة
"التواصل فقط عبر Event Bus" بالدستور.

المخرجات:
  - kernel.clock.sys_tick       نبضة عالية التردد (افتراضي كل 0.1s)
  - kernel.clock.heartbeat      نبضة أبطأ لمراقبة الحيوية (افتراضي كل 1s)
  - kernel.clock.minute_elapsed تُطلَق عند كل حد دقيقة حقيقية (wall-clock)،
                                 غير قابلة للتهيئة عمدًا — "دقيقة" تعني
                                 دقيقة فعلية دائمًا، لا فترة قابلة للتعديل.

كل حدث يحمل official_time (time.time، متزامن مع الساعة الحقيقية) —
هذا هو القناة الوحيدة المتاحة لتوفير "الوقت الرسمي" لذرات أخرى، بما
أن الذرات ممنوعة من استدعاء دوال بعضها مباشرة. أي ذرة تحتاج الوقت
الرسمي تشترك بـ kernel.clock.sys_tick وتقرأ آخر official_time وصلها.

ملاحظة تصميم مهمّة: الجدولة الداخلية تستخدم loop.time() (رتيبة/
monotonic، محصّنة من قفزات NTP) لحساب مواعيد الإطلاق، بينما القيمة
المنشورة بالحدث تستخدم time.time() (زمن الحائط الحقيقي) — لأن
المستهلك يريد "كم الساعة فعليًا" لا "كم مضى منذ بدء العملية".
"""

from __future__ import annotations

import asyncio
import time
from typing import Awaitable, Callable

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SYNCED = "time.utc.synced"

SOURCE_LOCAL = "LOCAL_CLOCK"
SOURCE_NTP = "NTP_SYNCED"


# دقيقة حقيقية دائمًا — عمدًا غير موجودة داخل config_schema/config، حتى
# لا يقدر أحد يغيّرها بالغلط ويخلّي "MINUTE_ELAPSED" تعني شي غير دقيقة.
_MINUTE_S = 60.0

# حد الانحراف الذي يحوّل health_check من HEALTHY إلى DEGRADED.
_DRIFT_WARNING_THRESHOLD_S = 1.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None

        self._sys_tick_task: asyncio.Task | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._minute_task: asyncio.Task | None = None

        self._sys_tick_interval_s = 0.1
        self._heartbeat_interval_s = 1.0

        self.sys_tick_count = 0

        self._offset_s = 0.0

        self._time_source = SOURCE_LOCAL
        self.heartbeat_count = 0
        self.minute_count = 0
        self._max_observed_drift_s = 0.0

    # ------------------------------------------------------------------
    # دورة الحياة (AtomBase)
    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        context.subscribe(EVENT_SYNCED, self._on_synced)
        self._context = context
        self._sys_tick_interval_s = float(context.config.get("sys_tick_interval_s", 0.1))
        self._heartbeat_interval_s = float(context.config.get("heartbeat_interval_s", 1.0))
        context.logger.info(
            "CLOCK تمت تهيئته (sys_tick=%.3fs, heartbeat=%.1fs, minute=%.0fs ثابتة)",
            self._sys_tick_interval_s, self._heartbeat_interval_s, _MINUTE_S,
        )

    async def start(self) -> None:
        self._sys_tick_task = asyncio.create_task(
            self._scheduled_loop(self._sys_tick_interval_s, self._on_sys_tick)
        )
        self._heartbeat_task = asyncio.create_task(
            self._scheduled_loop(self._heartbeat_interval_s, self._on_heartbeat)
        )
        self._minute_task = asyncio.create_task(
            self._scheduled_loop(_MINUTE_S, self._on_minute_elapsed, align_to_wall_clock=True)
        )
        self._context.logger.info("CLOCK بدأ إصدار SYS_TICK/HEARTBEAT/MINUTE_ELAPSED")

    async def _on_synced(self, payload: dict) -> None:
        """608 يقيس فرق ساعة الجهاز عن NTP. بلا تبنّيه يبقى official_time
        اسمًا رسميًا لقراءة محلية غير مزامَنة."""
        offset = payload.get("offset_s")
        if isinstance(offset, (int, float)):
            self._offset_s = float(offset)
            self._time_source = SOURCE_NTP

    def official_now(self) -> float:
        return time.time() + self._offset_s

    async def stop(self) -> None:
        """قابلة للعكس — توقف الحلقات الثلاث فقط. Health Manager قد يستدعي
        start() مباشرة بعدها أثناء Restart، فلا نُغلق أي شيء نهائي هنا."""
        tasks = (self._sys_tick_task, self._heartbeat_task, self._minute_task)
        for task in tasks:
            if task is not None:
                task.cancel()
        for task in tasks:
            if task is not None:
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._sys_tick_task = self._heartbeat_task = self._minute_task = None
        if self._context is not None:
            self._context.logger.info(
                "CLOCK توقف (sys_tick=%d, heartbeat=%d, minute=%d)",
                self.sys_tick_count, self.heartbeat_count, self.minute_count,
            )

    async def shutdown(self) -> None:
        """نهائية، غير قابلة للعكس — تُستدعى مرة واحدة فقط عند إغلاق Core
        بالكامل، وليس أثناء أي Restart."""
        if self._context is not None:
            self._context.logger.info(
                "CLOCK إغلاق نهائي — لن تصدر أي أحداث توقيت بعد هذه النقطة"
            )

    async def health_check(self) -> HealthStatus:
        if self._sys_tick_task is None or self._sys_tick_task.done():
            return HealthStatus(state=HealthState.UNHEALTHY, message="حلقة sys_tick متوقفة")
        if self._max_observed_drift_s > _DRIFT_WARNING_THRESHOLD_S:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"انحراف زمني ملحوظ: {self._max_observed_drift_s:.3f}s",
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=(
                f"sys_tick={self.sys_tick_count} heartbeat={self.heartbeat_count} "
                f"minute={self.minute_count} max_drift={self._max_observed_drift_s:.4f}s"
            ),
        )

    async def snapshot(self) -> dict:
        return {
            "sys_tick_count": self.sys_tick_count,
            "heartbeat_count": self.heartbeat_count,
            "minute_count": self.minute_count,
        }

    async def restore(self, state: dict) -> None:
        self.sys_tick_count = state.get("sys_tick_count", 0)
        self.heartbeat_count = state.get("heartbeat_count", 0)
        self.minute_count = state.get("minute_count", 0)

    # ------------------------------------------------------------------
    # آلية الجدولة الداخلية — المكان الوحيد المسموح فيه استخدام sleep
    # ------------------------------------------------------------------

    async def _scheduled_loop(
        self,
        interval_s: float,
        on_tick: Callable[[], Awaitable[None]],
        align_to_wall_clock: bool = False,
    ) -> None:
        """حلقة بجدول زمني مطلق تراكمي — تنفّذ "تصحيح الانحراف الزمني"
        المطلوبة من CLOCK. لا نستخدم `while True: sleep(interval)` بسيط،
        لأن ذلك يجعل الفترة الفعلية = interval + زمن المعالجة في كل دورة،
        فيتراكم الانحراف مع الوقت. بدل ذلك: نحسب موعد الإطلاق القادم
        كقيمة مطلقة تراكمية (`next_deadline += interval_s` وليس
        `sleep(interval_s)` بعد كل تنفيذ)، فأي تأخير عرضي بدورة واحدة
        يُمتَص تلقائيًا بدون أن ينتقل للدورة التالية.

        فشل on_tick (مثلاً خطأ عابر بـ publish) يُسجَّل ولا يوقف الحلقة —
        نفس مبدأ عزل الأخطاء داخل الذرة."""
        loop = asyncio.get_running_loop()

        if align_to_wall_clock:
            seconds_into_period = time.time() % interval_s
            first_wait = interval_s - seconds_into_period
            next_deadline = loop.time() + first_wait
        else:
            next_deadline = loop.time() + interval_s

        try:
            while True:
                sleep_for = next_deadline - loop.time()
                if sleep_for > 0:
                    await asyncio.sleep(sleep_for)
                else:
                    drift = -sleep_for
                    self._max_observed_drift_s = max(self._max_observed_drift_s, drift)
                    next_deadline = loop.time()  # فاتنا الموعد — أعد المزامنة، لا تراكم Burst
                try:
                    await on_tick()
                except Exception as exc:  # noqa: BLE001 — عزل متعمّد، غير مسموح بانهيار الحلقة
                    if self._context is not None:
                        self._context.logger.error("CLOCK: فشل تنفيذ tick: %s", exc)
                next_deadline += interval_s
                # الجدولة تراكمية عمدًا: الموعد التالي يُبنى على السابق لا
                # على الآن، فيُعوَّض الـ jitter بدل أن يتراكم.
                #
                # لكن لو استغرق on_tick أكثر من الفاصل كاملًا، يصير الموعد
                # الجديد ماضيًا فورًا وتدور الحلقة بلا نوم — نواة كاملة
                # مأكولة والوقت مقطوع عن بقية المهام. مقيس: نامت دورة واحدة
                # من عشرين حين كان التنفيذ ضعف الفاصل.
                #
                # فالمزامنة تُعاد هنا وحدها: حين يكون الموعد قد فات فعلًا،
                # لا في كل دورة — وإلا ضاع التعويض التراكمي نفسه.
                if next_deadline <= loop.time():
                    next_deadline = loop.time() + interval_s
        except asyncio.CancelledError:
            pass

    async def _on_sys_tick(self) -> None:
        self.sys_tick_count += 1
        await self._context.publish(
            "kernel.clock.sys_tick",
            {"tick": self.sys_tick_count, "official_time": self.official_now(),
             "time_source": self._time_source},
        )

    async def _on_heartbeat(self) -> None:
        self.heartbeat_count += 1
        await self._context.publish(
            "kernel.clock.heartbeat",
            {"beat": self.heartbeat_count, "official_time": self.official_now(),
             "time_source": self._time_source},
        )

    async def _on_minute_elapsed(self) -> None:
        self.minute_count += 1
        await self._context.publish(
            "kernel.clock.minute_elapsed",
            {"minute": self.minute_count, "official_time": self.official_now(),
             "time_source": self._time_source},
        )
