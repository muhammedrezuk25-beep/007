"""
اختبارات ATOM_003 (CLOCK) — منفصلة تمامًا عن اختبارات Core، تُشغَّل
مستقلة عن أي ذرة أخرى (المادة ٢٠ / م١٤ بالتعليمات الصارمة).

يفترض وجود core/contracts/atom.py على sys.path (تزوّده بيئة Core
الحقيقية وقت التشغيل الفعلي؛ هنا نضيفها يدويًا فقط للاختبار المعزول).
"""
import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
import time

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))  # يوفّر حزمة core.contracts من جذر المشروع الفعلي
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# ملاحظة: atom_audit تحتوي أيضًا على atom.py خاص بـ hello_atom (اسم وحدة
# متطابق) — الإدراج بهذا الترتيب يضمن أن `import atom` هنا يلتقط CLOCK
# المحلي أولًا، لا hello_atom القديمة، بينما `core.contracts.atom` ما زالت
# تُحل عبر atom_audit لأن هذا المجلد لا يحتوي حزمة core خاصة به.

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom3"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class FakeLogger:
    def __init__(self):
        self.lines = []

    def _rec(self, level, msg, *args):
        self.lines.append(f"[{level}] " + (msg % args if args else msg))

    def debug(self, msg, *args): self._rec("DEBUG", msg, *args)
    def info(self, msg, *args): self._rec("INFO", msg, *args)
    def warning(self, msg, *args): self._rec("WARNING", msg, *args)
    def error(self, msg, *args): self._rec("ERROR", msg, *args)
    def critical(self, msg, *args): self._rec("CRITICAL", msg, *args)


def make_context(config=None, publish=None):
    published = []

    async def default_publish(name, payload):
        published.append((name, payload))

    return AtomContext(
        atom_id=3,
        config=config or {},
        logger=FakeLogger(),
        publish=publish or default_publish,
        subscribe=lambda name, handler: None,
    ), published


async def test_full_lifecycle():
    print("\n--- test_full_lifecycle ---")
    context, published = make_context({"sys_tick_interval_s": 0.05, "heartbeat_interval_s": 0.2})
    atom = Atom()

    await atom.initialize(context)
    await atom.start()
    await asyncio.sleep(0.53)  # يكفي لعدة sys_tick وعدة heartbeat

    # health_check() أثناء التشغيل الفعلي — قبل stop()، لأن بعد stop()
    # الحلقات متوقفة عمدًا وHEALTHY لن تكون صحيحة عندها (تُختبر بشكل
    # منفصل بـ test_unhealthy_when_loop_not_running)
    health = await atom.health_check()
    assert health.state.value == "healthy", health.message

    await atom.stop()

    assert atom._sys_tick_task is None and atom._heartbeat_task is None and atom._minute_task is None
    assert atom.sys_tick_count >= 8, f"المتوقع >=8 نبضة sys_tick خلال 0.53s@0.05s، لقيت {atom.sys_tick_count}"
    assert atom.heartbeat_count >= 2, f"المتوقع >=2 heartbeat خلال 0.53s@0.2s، لقيت {atom.heartbeat_count}"

    sys_ticks = [p for n, p in published if n == "kernel.clock.sys_tick"]
    heartbeats = [p for n, p in published if n == "kernel.clock.heartbeat"]
    assert len(sys_ticks) == atom.sys_tick_count
    assert len(heartbeats) == atom.heartbeat_count
    # Superset: time_source names where official_time came from;
    # an exact match would forbid every legitimate addition.
    assert {"tick", "official_time"} <= set(sys_ticks[0].keys())
    assert abs(sys_ticks[0]["official_time"] - time.time()) < 2.0

    snap = await atom.snapshot()
    assert snap["sys_tick_count"] == atom.sys_tick_count

    await atom.restore({"sys_tick_count": 999, "heartbeat_count": 1, "minute_count": 0})
    assert atom.sys_tick_count == 999

    await atom.shutdown()
    print(f"OK — sys_tick={len(sys_ticks)} heartbeat={len(heartbeats)} أول حدث: {sys_ticks[0]}")


async def test_drift_correction_under_jitter():
    """يثبت أن الجدول التراكمي (next_deadline += interval) لا يتراكم
    انحرافًا حتى لو on_tick أخذ وقتًا متغيرًا كل مرة — بعكس
    `while True: sleep(interval)` الساذجة التي كانت ستتراكم انحرافًا
    مساويًا لمجموع كل التأخيرات."""
    print("\n--- test_drift_correction_under_jitter ---")
    jitter_pattern = [0.02, 0.0, 0.03, 0.01, 0.0, 0.025, 0.0, 0.015]
    call_index = {"i": 0}

    async def jittery_publish(name, payload):
        i = call_index["i"] % len(jitter_pattern)
        call_index["i"] += 1
        await asyncio.sleep(jitter_pattern[i])  # يحاكي زمن معالجة/نشر متغير

    context, _ = make_context({"sys_tick_interval_s": 0.05}, publish=jittery_publish)
    atom = Atom()
    await atom.initialize(context)

    loop = asyncio.get_running_loop()
    start = loop.time()
    atom._sys_tick_task = asyncio.create_task(
        atom._scheduled_loop(0.05, atom._on_sys_tick)
    )
    n_target = 12
    while atom.sys_tick_count < n_target:
        await asyncio.sleep(0.005)
    elapsed = loop.time() - start
    atom._sys_tick_task.cancel()
    try:
        await atom._sys_tick_task
    except asyncio.CancelledError:
        pass

    expected = n_target * 0.05
    deviation = elapsed - expected
    print(f"المتوقع (بلا انحراف): {expected:.3f}s — الفعلي: {elapsed:.3f}s — الفرق: {deviation:+.3f}s")
    # التسامح صغير عمدًا: لو الجدولة ساذجة (sleep بعد كل tick) لكان
    # الانحراف التراكمي ~= مجموع الـ jitter (~0.11s لثماني قيم)، لا أجزاء
    # من الثانية الواحدة كما هنا.
    assert abs(deviation) < 0.05, "انحراف أكبر من المتوقع — الجدولة التراكمية لم تعوّض الـ jitter"
    print("OK — الجدولة عوّضت التأخيرات المتغيرة ولم تتراكم انحرافًا")


async def test_wall_clock_alignment_math():
    """يتحقق من حساب أول انتظار لمحاذاة MINUTE_ELAPSED على حدود الدقيقة
    الحقيقية، بمحاكاة فترة قصيرة (2s) بدل انتظار 60s فعلية — يختبر نفس
    معادلة المحاذاة (`interval - (time.time() % interval)`) المستخدمة
    فعليًا داخل _scheduled_loop لـ MINUTE_ELAPSED (interval=60 بالإنتاج)."""
    print("\n--- test_wall_clock_alignment_math ---")
    interval_s = 2.0
    now = time.time()
    seconds_into_period = now % interval_s
    first_wait = interval_s - seconds_into_period
    assert 0 <= first_wait <= interval_s
    # المحاذاة الفعلية: بعد الانتظار المحسوب، لازم نكون بالضبط عند حد
    # الفترة (خطأ مسموح فقط بسبب دقّة القياس نفسها، لا بسبب منطق خاطئ)
    target = now + first_wait
    assert abs(target % interval_s) < 0.001 or abs((target % interval_s) - interval_s) < 0.001
    print(f"OK — الانتظار الأول المحسوب={first_wait:.3f}s يحاذي فعليًا حد فترة {interval_s}s")


async def test_error_in_publish_does_not_kill_loop():
    """ينشر أول tick بنجاح، يفشل الثاني، وينجح الثالث — يثبت أن استثناء
    عابر داخل on_tick لا يوقف الحلقة نهائيًا (عزل الأخطاء داخل الذرة)."""
    print("\n--- test_error_in_publish_does_not_kill_loop ---")
    calls = {"n": 0}

    async def flaky_publish(name, payload):
        calls["n"] += 1
        if calls["n"] == 2:
            raise RuntimeError("فشل عابر محاكى بالـ Event Bus")

    context, _ = make_context({"sys_tick_interval_s": 0.03}, publish=flaky_publish)
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    await asyncio.sleep(0.16)
    await atom.stop()

    assert atom.sys_tick_count >= 4, f"الحلقة لازم تستمر بعد الفشل، لقيت count={atom.sys_tick_count}"
    error_logs = [l for l in context.logger.lines if "فشل تنفيذ tick" in l]
    assert len(error_logs) >= 1, "لازم يُسجَّل خطأ واحد على الأقل عند فشل publish"
    print(f"OK — استمرت الحلقة لـ {atom.sys_tick_count} نبضة رغم فشل واحدة، وسُجِّل الخطأ: {error_logs[0]}")


async def test_unhealthy_when_loop_not_running():
    print("\n--- test_unhealthy_when_loop_not_running ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    health = await atom.health_check()
    assert health.state.value == "unhealthy", health.message
    print(f"OK — health_check قبل start(): {health.state.value} / {health.message}")


async def main():
    tests = [
        test_full_lifecycle,
        test_drift_correction_under_jitter,
        test_wall_clock_alignment_math,
        test_error_in_publish_does_not_kill_loop,
        test_unhealthy_when_loop_not_running,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")

    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}:")
        for name, err in failed:
            print(f"  - {name}: {err}")
        sys.exit(1)
    else:
        print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
