"""
id=7 — مراقب سلامة الملفات (File Integrity Monitor) — مرجعي: 807

v2: أربعة مؤشرات مجتمعة لكل عنصر مراقَب، لا checksum فقط:
  - ملفات فردية (watched_files): size + mtime + checksum لكل ملف
  - مجلدات (watched_dirs): عدد الملفات + بصمة بنية (hash لقائمة مرتَّبة
    من كل المسارات النسبية جوا المجلد) — يكشف إضافة/حذف/نقل ملف حتى
    بدون فحص محتوى كل ملف بالمجلد

نفس نمط id=6: بلا حلقة داخلية، health_check() فقط.

أول استخدام جدّي لـ snapshot()/restore(): الأساس (ملفات + مجلدات)
يعيش بالذاكرة فقط، وبفضل restore() بعد أي Restart تُقارَن الحالة
الحالية على القرص مقابل آخر أساس معروف قبل التوقف — فيُكتشف أي تغيير
حصل أثناء التوقف، لا فقط أثناء التشغيل.

قرار تصميم متعمّد: لا "نسيان" تلقائي للتنبيه. مرة يُكتشف فرق، الأساس
المخزَّن لا يتحدَّث تلقائيًا — تحديث صامت = نفس ثغرة "تجاهل التلاعب"
التي الأداة مصمَّمة لكشفها. اعتماد أساس جديد يحتاج فعلًا بشريًا صريحًا
(حاليًا: حذف الـsnapshot المحفوظ يدويًا وإعادة تشغيل الذرة؛ لاحقًا
ربما حدث tools.integrity.rebaseline مخصَّص — غير مبني هنا عمدًا).

فرق متعمّد عن id=6 بسلوك النشر: id=6 (Storage Monitor) نشرها
edge-triggered (فقط عند الانتقال لحالة منخفضة، ليس بكل فحص). هون
العكس مقصود: tools.integrity.violation يُنشر بكل دورة فحص طالما فيها
فرق واحد على الأقل — تحذير أمني نشط يجب أن يستمر بالتنبيه لا أن يصمت
بعد أول إشارة (صمت بعد أول تنبيه قد يُفهَم خطأً كأن المشكلة انحلّت).
كل الفروقات المكتشَفة بدورة واحدة تُجمَع بحدث واحد، لا حدث لكل فرق.
"""

from __future__ import annotations

import hashlib
import os

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _file_baseline(path: str) -> dict:
    st = os.stat(path)
    return {"size": st.st_size, "mtime": st.st_mtime, "checksum": _sha256_of_file(path)}


def _dir_structure_fingerprint(dir_path: str) -> str:
    rel_paths = []
    for root, _dirs, files in os.walk(dir_path):
        for name in files:
            rel_paths.append(os.path.relpath(os.path.join(root, name), dir_path))
    rel_paths.sort()
    h = hashlib.sha256()
    for p in rel_paths:
        h.update(p.encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()


def _dir_baseline(dir_path: str) -> dict:
    file_count = sum(len(files) for _root, _dirs, files in os.walk(dir_path))
    return {"file_count": file_count, "structure_fingerprint": _dir_structure_fingerprint(dir_path)}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._watched_files: list[str] = []
        self._watched_dirs: list[str] = []
        self._file_baselines: dict[str, dict] = {}
        self._dir_baselines: dict[str, dict] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._watched_files = list(context.config.get("watched_files", []))
        self._watched_dirs = list(context.config.get("watched_dirs", []))
        context.logger.info(
            "FileIntegrityMonitor تمت تهيئته (%d ملف، %d مجلد، أساس مُستعاد: %d/%d)",
            len(self._watched_files), len(self._watched_dirs),
            len(self._file_baselines), len(self._dir_baselines),
        )

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("FileIntegrityMonitor جاهز — health_check() هي آلية الفحص الوحيدة")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        if not self._watched_files and not self._watched_dirs:
            return HealthStatus(state=HealthState.UNKNOWN, message="لا ملفات ولا مجلدات مراقَبة بالإعدادات")

        violations: list[dict] = []
        newly_baselined = 0

        for path in self._watched_files:
            try:
                current = _file_baseline(path)
            except FileNotFoundError:
                violations.append({"path": path, "diff_type": "missing", "old": "موجود", "new": "غير موجود"})
                continue
            except OSError as exc:
                violations.append({"path": path, "diff_type": "read_error", "old": None, "new": str(exc)})
                continue

            baseline = self._file_baselines.get(path)
            if baseline is None:
                self._file_baselines[path] = current
                newly_baselined += 1
                continue

            for field in ("size", "mtime", "checksum"):
                if current[field] != baseline[field]:
                    violations.append({"path": path, "diff_type": field, "old": baseline[field], "new": current[field]})

        for path in self._watched_dirs:
            try:
                current = _dir_baseline(path)
            except OSError as exc:
                violations.append({"path": path, "diff_type": "read_error", "old": None, "new": str(exc)})
                continue

            baseline = self._dir_baselines.get(path)
            if baseline is None:
                self._dir_baselines[path] = current
                newly_baselined += 1
                continue

            if current["file_count"] != baseline["file_count"]:
                violations.append({
                    "path": path, "diff_type": "dir_file_count",
                    "old": baseline["file_count"], "new": current["file_count"],
                })
            if current["structure_fingerprint"] != baseline["structure_fingerprint"]:
                violations.append({
                    "path": path, "diff_type": "dir_structure",
                    "old": baseline["structure_fingerprint"][:12] + "…",
                    "new": current["structure_fingerprint"][:12] + "…",
                })

        if violations:
            if self._context is not None:
                await self._context.publish("tools.integrity.violation", {"violations": violations})
            summary = "؛ ".join(
                f"{v['path']}: اختفى" if v["diff_type"] == "missing" else f"{v['path']}: {v['diff_type']} تغيّر"
                for v in violations
            )
            return HealthStatus(state=HealthState.UNHEALTHY, message=summary)

        total = len(self._watched_files) + len(self._watched_dirs)
        suffix = f" ({newly_baselined} أُسِّس أساسها الآن)" if newly_baselined else ""
        return HealthStatus(state=HealthState.HEALTHY, message=f"{total} عنصر مراقَب مطابق للأساس المحفوظ{suffix}")

    async def snapshot(self) -> dict:
        return {"file_baselines": dict(self._file_baselines), "dir_baselines": dict(self._dir_baselines)}

    async def restore(self, state: dict) -> None:
        self._file_baselines = dict(state.get("file_baselines", {}))
        self._dir_baselines = dict(state.get("dir_baselines", {}))
