import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
import tempfile
import time

import contextlib
import shutil


@contextlib.contextmanager
def _robust_temp_dir():
    """إصلاح حقيقي (v2): ignore_cleanup_errors=True لا يغطي
    RecursionError (ليست OSError، الآلية مصمَّمة لأخطاء OS فقط). هنا
    نتحكم بالتنظيف يدويًا، نبلع أي نوع استثناء أثناءه. كمان نرجع
    لمجلد العمل الأصلي **قبل** محاولة الحذف — حذف المجلد الحالي
    (CWD) فعليًا مرفوض على أنظمة كثيرة (ويندوز خصوصًا)، قد يكون هذا
    جزءًا حقيقيًا من سبب الانهيار الأصلي، لا افتراض نظري بس."""
    original_cwd = os.getcwd()
    d = tempfile.mkdtemp()
    try:
        yield d
    finally:
        try:
            os.chdir(original_cwd)
        except Exception:
            pass
        try:
            shutil.rmtree(d)
        except Exception:
            pass


from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom7"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(watched_files=None, watched_dirs=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    ctx = AtomContext(
        atom_id=7,
        config={"watched_files": watched_files or [], "watched_dirs": watched_dirs or []},
        logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None,
    )
    return ctx, published


async def test_file_size_mtime_checksum_all_detected():
    print("\n--- test_file_size_mtime_checksum_all_detected ---")
    with _robust_temp_dir() as d:
        f1 = os.path.join(d, "core.yaml")
        with open(f1, "w") as fh:
            fh.write("original")

        context, published = make_context(watched_files=[f1])
        atom = Atom()
        await atom.initialize(context)
        h1 = await atom.health_check()
        assert h1.state.value == "healthy" and "أُسِّس" in h1.message, h1.message
        assert len(published) == 0, "لا نشر عند التأسيس الأول"

        time.sleep(0.01)
        with open(f1, "w") as fh:
            fh.write("MODIFIED content, different length")
        h2 = await atom.health_check()
        assert h2.state.value == "unhealthy", h2.message
        assert len(published) == 1, "يجب نشر tools.integrity.violation عند وجود فرق"
        assert published[0][0] == "tools.integrity.violation"
        diff_types = {v["diff_type"] for v in published[0][1]["violations"]}
        assert diff_types & {"size", "mtime", "checksum"}, diff_types

        h3 = await atom.health_check()
        assert h3.state.value == "unhealthy", h3.message
        assert len(published) == 2, "يجب أن يستمر التنبيه كل دورة طالما الفرق قائم — لا صفح تلقائي"
        print(f"OK — {len(diff_types)} نوع فرق مكتشَف بدفعة واحدة: {diff_types}، وأعاد التنبيه بالدورة التالية ({len(published)} نشر إجمالي)")


async def test_missing_file_labeled_distinctly():
    print("\n--- test_missing_file_labeled_distinctly ---")
    with _robust_temp_dir() as d:
        f1 = os.path.join(d, "will_vanish.yaml")
        with open(f1, "w") as fh:
            fh.write("x")
        context, published = make_context(watched_files=[f1])
        atom = Atom()
        await atom.initialize(context)
        await atom.health_check()
        os.remove(f1)
        h = await atom.health_check()
        assert h.state.value == "unhealthy"
        assert "اختفى" in h.message, h.message
        assert published[-1][1]["violations"][0]["diff_type"] == "missing"
        print(f"OK — اختفاء ملف مُصنَّف بوضوح: {h.message}")


async def test_directory_structure_fingerprint_detects_add_and_remove():
    print("\n--- test_directory_structure_fingerprint_detects_add_and_remove ---")
    with _robust_temp_dir() as d:
        atoms_dir = os.path.join(d, "atoms")
        os.makedirs(os.path.join(atoms_dir, "hello_atom"))
        with open(os.path.join(atoms_dir, "hello_atom", "atom.py"), "w") as fh:
            fh.write("x")

        context, published = make_context(watched_dirs=[atoms_dir])
        atom = Atom()
        await atom.initialize(context)
        h1 = await atom.health_check()
        assert h1.state.value == "healthy", h1.message

        h2 = await atom.health_check()
        assert h2.state.value == "healthy", h2.message

        os.makedirs(os.path.join(atoms_dir, "sneaky_new_atom"))
        with open(os.path.join(atoms_dir, "sneaky_new_atom", "atom.py"), "w") as fh:
            fh.write("y")
        h3 = await atom.health_check()
        assert h3.state.value == "unhealthy", h3.message
        diff_types = {v["diff_type"] for v in published[-1][1]["violations"]}
        assert "dir_file_count" in diff_types and "dir_structure" in diff_types, diff_types
        print(f"OK — ظهور ملف جديد بمجلد مراقَب اكتُشف عبر {diff_types}")


async def test_snapshot_restore_covers_both_files_and_dirs():
    print("\n--- test_snapshot_restore_covers_both_files_and_dirs ---")
    with _robust_temp_dir() as d:
        f1 = os.path.join(d, "registry.yaml")
        with open(f1, "w") as fh:
            fh.write("id: 1\n")
        dir1 = os.path.join(d, "atoms")
        os.makedirs(dir1)
        with open(os.path.join(dir1, "a.py"), "w") as fh:
            fh.write("x")

        context, _ = make_context(watched_files=[f1], watched_dirs=[dir1])
        atom = Atom()
        await atom.initialize(context)
        await atom.health_check()
        snap = await atom.snapshot()
        assert set(snap["file_baselines"].keys()) == {f1}
        assert set(snap["dir_baselines"].keys()) == {dir1}

        with open(os.path.join(dir1, "b.py"), "w") as fh:
            fh.write("y")

        atom2 = Atom()
        context2, published2 = make_context(watched_files=[f1], watched_dirs=[dir1])
        await atom2.initialize(context2)
        await atom2.restore(snap)
        h = await atom2.health_check()
        assert h.state.value == "unhealthy", "لازم يُكتشف التغيير بالمجلد رغم أنه حصل بالكامل أثناء التوقف"
        print(f"OK — snapshot/restore غطّى الملفات والمجلدات معًا واكتشف تغييرًا حصل أثناء التوقف: {h.message}")


async def test_unknown_when_nothing_configured():
    print("\n--- test_unknown_when_nothing_configured ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    h = await atom.health_check()
    assert h.state.value == "unknown", h.message
    print("OK — لا ملفات ولا مجلدات مُعدَّة → UNKNOWN")


async def main():
    tests = [
        test_file_size_mtime_checksum_all_detected,
        test_missing_file_labeled_distinctly,
        test_directory_structure_fingerprint_detects_add_and_remove,
        test_snapshot_restore_covers_both_files_and_dirs,
        test_unknown_when_nothing_configured,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
