from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom700"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 700

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 700


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_it_keeps_the_latest_report_of_each_store():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 5, "total": 5, "timestamp": TS})
    await ctx.handlers["storage.analysis_saved"]({"rows": 3, "total": 3, "timestamp": TS})
    view = out(ctx, MODULE.EVENT_OUT)[-1]
    assert set(view["sections"]) == {"storage.orders_saved", "storage.analysis_saved"}


@pytest.mark.asyncio
async def test_the_row_total_sums_across_stores():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 5, "total": 12})
    await ctx.handlers["storage.analysis_saved"]({"rows": 3, "total": 8})
    assert out(ctx, MODULE.EVENT_OUT)[-1]["rows_total"] == 20


@pytest.mark.asyncio
async def test_a_repeated_report_overwrites_rather_than_adds():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 5, "total": 5})
    await ctx.handlers["storage.orders_saved"]({"rows": 2, "total": 7})
    view = out(ctx, MODULE.EVENT_OUT)[-1]
    assert view["rows_total"] == 7
    assert view["counts"]["storage.orders_saved"] == 2


@pytest.mark.asyncio
async def test_it_publishes_nothing_of_its_own():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 1, "total": 1})
    assert {n for n, _ in ctx.published} == {MODULE.EVENT_OUT}


@pytest.mark.asyncio
async def test_health_names_the_silent_stores():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 1, "total": 1})
    details = (await atom.health_check()).details
    assert "storage.trades_saved" in details["silent"]
    assert details["seen"] == 1


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 1, "total": 1, "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_OUT)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_carries_the_sections():
    atom, ctx = await _ready()
    await ctx.handlers["storage.orders_saved"]({"rows": 5, "total": 5})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._sections["storage.orders_saved"]["total"] == 5
