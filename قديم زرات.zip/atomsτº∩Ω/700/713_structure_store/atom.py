from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

_DB_TIMEOUT_S = 5.0

EVENT_IN = "market.structure.updated"
EVENT_OUT = "storage.structure_saved"
EVENT_DAY = "SYS_DAY"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_STORE = "STORE_UNAVAILABLE"
REASON_NOTHING_STORED = "NOTHING_STORED_YET"

_TABLE = "structure"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS structure (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol       TEXT,
    source       TEXT,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_structure_symbol ON structure(symbol, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_structure_time ON structure(occurred_at)",
)


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._flush_size = 0
        self._retention_days = 0
        self._buffer: list[tuple] = []
        self._store_ready = False
        self._last_error = ""
        self.stored_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._flush_size = int(cfg["flush_size"])
        self._retention_days = int(cfg["retention_days"])
        context.subscribe(EVENT_IN, self._on_event)
        context.subscribe(EVENT_DAY, self._on_day)
        self._store_ready = self._ensure_store()
        self._initialized = True
        context.logger.info("713 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("713 started")

    async def stop(self) -> None:
        self._running = False
        if self._buffer:
            await asyncio.to_thread(self._flush)
        if self._context is not None:
            self._context.logger.info("713 stopped (stored=%d)", self.stored_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            if self._context is not None:
                self._context.logger.error("713 cannot open store: %s", exc)
            return False

    def _flush(self) -> int:
        if not self._buffer:
            return 0
        rows, self._buffer = self._buffer, []
        try:
            connection = self._connect()
            try:
                connection.executemany(
                    "INSERT INTO structure (symbol, source, occurred_at, payload_json)"
                    " VALUES (?,?,?,?)", rows)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return len(rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            self.dropped_count += len(rows)
            if self._context is not None:
                self._context.logger.error("713 lost %d rows: %s", len(rows), exc)
            return 0

    def _prune(self, now: float) -> int:
        if self._retention_days <= 0:
            return 0
        cutoff = now - self._retention_days * 86400.0
        try:
            connection = self._connect()
            try:
                cursor = connection.execute(
                    "DELETE FROM structure WHERE occurred_at IS NOT NULL"
                    " AND occurred_at < ?", (cutoff,))
                connection.commit()
                return cursor.rowcount or 0
            finally:
                connection.close()
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return 0

    async def _on_event(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
            if not self._store_ready:
                self.dropped_count += 1
                return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        occurred = _to_float(inner.get("timestamp", payload.get("timestamp")))
        self._buffer.append((
            str(inner.get("symbol")) if inner.get("symbol") else None,
            str(payload.get("source")) if payload.get("source") else None,
            occurred,
            json.dumps(inner, ensure_ascii=False, default=str),
        ))

        if len(self._buffer) >= self._flush_size:
            written = await asyncio.to_thread(self._flush)
            self.stored_count += written
            if written:
                body: dict[str, Any] = {"rows": written, "total": self.stored_count}
                if occurred is not None:
                    body["timestamp"] = occurred
                await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        written = await asyncio.to_thread(self._flush)
        self.stored_count += written
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        removed = 0
        if now is not None:
            removed = await asyncio.to_thread(self._prune, now)
        body: dict[str, Any] = {"rows": written, "total": self.stored_count,
                                "pruned": removed}
        if now is not None:
            body["timestamp"] = now
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"stored": self.stored_count, "dropped": self.dropped_count,
                   "buffered": len(self._buffer), "db_path": self._db_path,
                   "last_error": self._last_error}
        if not self._store_ready:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_NO_STORE,
                                details=details)
        if self.stored_count == 0 and not self._buffer:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NOTHING_STORED, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="stored=%d buffered=%d" % (
                                self.stored_count, len(self._buffer)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "stored": self.stored_count,
                "dropped": self.dropped_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self.stored_count = int(state.get("stored", 0))
        self.dropped_count = int(state.get("dropped", 0))
