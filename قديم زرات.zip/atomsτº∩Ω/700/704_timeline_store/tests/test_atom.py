from __future__ import annotations

import ast
import importlib.util
import json
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom704"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 704

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "timeline.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, tmp


def _rows(ctx, sql="SELECT * FROM timeline ORDER BY id"):
    connection = sqlite3.connect(ctx.config["db_path"])
    connection.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in connection.execute(sql)]
    finally:
        connection.close()


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_no_arabic_and_no_module_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_subscribes_match_watch_events():
    assert MANIFEST["id"] == 704
    declared = set(MANIFEST["subscribes"]) - {"SYS_DAY"}
    assert declared == set(CONFIG["watch_events"])


@pytest.mark.asyncio
async def test_buffered_until_flush_size():
    atom, ctx, tmp = await _ready(flush_size=3)
    try:
        for i in range(2):
            await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS + i})
        assert _rows(ctx) == []
        assert atom.recorded_count == 2
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS + 9})
        assert len(_rows(ctx)) == 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_day_roll_flushes_what_is_buffered():
    atom, ctx, tmp = await _ready(flush_size=100)
    try:
        await ctx.handlers["tools.alert.raised"]({"source_event": "x", "timestamp": TS})
        assert _rows(ctx) == []
        await ctx.handlers["SYS_DAY"]({"count": 1, "official_time": TS + 10})
        assert len(_rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_flushes_the_buffer():
    atom, ctx, tmp = await _ready(flush_size=100)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
        await atom.stop()
        assert len(_rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_event_name_and_payload_are_kept():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers["risk.unified"]({
            "daily_loss_pct": 3.06, "kill_switch_state": True, "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["event_name"] == "risk.unified"
        assert row["occurred_at"] == TS
        assert json.loads(row["payload_json"])["daily_loss_pct"] == 3.06
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_symbol_is_extracted_when_present():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers["market_data.quality_alert"]({
            "payload": {"symbol": "USTEC", "kind": "duplicate"}, "timestamp": TS})
        assert _rows(ctx)[0]["symbol"] == "USTEC"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_retention_prunes_old_rows_on_day_roll():
    atom, ctx, tmp = await _ready(flush_size=1, retention_days=1.0)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "old", "timestamp": TS})
        await ctx.handlers["emergency.halt"]({"reason": "new", "timestamp": TS + 200000})
        await ctx.handlers["SYS_DAY"]({"count": 1, "official_time": TS + 200000})
        remaining = [json.loads(r["payload_json"])["reason"] for r in _rows(ctx)]
        assert remaining == ["new"]
        assert atom.pruned_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_retention_off_when_zero():
    atom, ctx, tmp = await _ready(flush_size=1, retention_days=0.0)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "old", "timestamp": TS})
        await ctx.handlers["SYS_DAY"]({"count": 1, "official_time": TS + 1e9})
        assert len(_rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unwatched_event_is_not_subscribed():
    atom, ctx, tmp = await _ready()
    try:
        assert "market.tick" not in ctx.handlers
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unreachable_store_does_not_raise():
    atom, ctx, tmp = await _ready(flush_size=1, db_path="/proc/nonexistent/t.db")
    try:
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
        assert atom.failure_count >= 1
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "t.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_no_events_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_healthy_after_recording():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_counts_per_event():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
        await ctx.handlers["emergency.halt"]({"reason": "Y", "timestamp": TS})
        await ctx.handlers["tools.alert.raised"]({"source_event": "z", "timestamp": TS})
        details = (await atom.health_check()).details or {}
        assert details["per_event"]["emergency.halt"] == 2
        assert details["per_event"]["tools.alert.raised"] == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.recorded_count == atom.recorded_count
        assert fresh._per_event == atom._per_event
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
