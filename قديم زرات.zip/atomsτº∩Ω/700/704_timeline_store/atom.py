from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DB_TIMEOUT_S = 5.0

ATOM_VERSION = "1.0.0"

EVENT_STATS = "storage.timeline_saved"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NO_ACTIVITY = "NO_EVENTS_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS timeline (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name   TEXT NOT NULL,
    source       TEXT,
    symbol       TEXT,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_timeline_event ON timeline(event_name, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_timeline_time ON timeline(occurred_at)",
)


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._db_path = ""
        self._watch_events: list[str] = []
        self._flush_size = 0
        self._retention_days = 0.0
        self._store_ready = False
        self._last_error = ""

        self._buffer: list[tuple] = []
        self._last_prune_day: float | None = None

        self.recorded_count = 0
        self.flushed_count = 0
        self.pruned_count = 0
        self.failure_count = 0
        self._per_event: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._watch_events = list(cfg["watch_events"])
        self._flush_size = int(cfg["flush_size"])
        self._retention_days = float(cfg["retention_days"])

        for event_name in self._watch_events:
            context.subscribe(event_name, self._make_recorder(event_name))
        context.subscribe("SYS_DAY", self._on_day)

        self._store_ready = self._ensure_store()
        self._initialized = True
        context.logger.info(
            "704 initialised on %s watching %d events",
            self._db_path, len(self._watch_events),
        )

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        self._context.logger.info("704 started")

    async def stop(self) -> None:
        self._running = False
        if self._buffer:
            await self._flush()
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "704 stopped (recorded=%d, flushed=%d)",
                self.recorded_count, self.flushed_count,
            )

    async def shutdown(self) -> None:
        await self.stop()

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = "%s: %s" % (REASON_STORE_UNAVAILABLE, exc)
            return False

    def _write(self, rows: list[tuple]) -> int:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        try:
            connection.executemany(
                "INSERT INTO timeline (event_name, source, symbol, occurred_at,"
                " payload_json) VALUES (?, ?, ?, ?, ?)",
                rows,
            )
            connection.commit()
            return len(rows)
        finally:
            connection.close()

    def _prune(self, cutoff: float) -> int:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        try:
            cursor = connection.execute(
                "DELETE FROM timeline WHERE occurred_at IS NOT NULL"
                " AND occurred_at < ?", (cutoff,))
            connection.commit()
            return cursor.rowcount if cursor.rowcount > 0 else 0
        finally:
            connection.close()

    def _make_recorder(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._record(event_name, payload)
        return handler

    async def _record(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running:
            return

        try:
            payload_json = json.dumps(payload, ensure_ascii=False,
                                      sort_keys=True, default=str)
        except (TypeError, ValueError):
            payload_json = None

        inner = payload.get("payload", payload)
        symbol = None
        if isinstance(inner, dict):
            symbol = inner.get("symbol")
            account_id = inner.get("account_id")
        if symbol is None:
            symbol = payload.get("symbol")
            account_id = payload.get("account_id")

        self._buffer.append((
            event_name,
            payload.get("source"),
            symbol,
            _to_float(payload.get("timestamp")),
            payload_json,
        ))
        self.recorded_count += 1
        self._per_event[event_name] = self._per_event.get(event_name, 0) + 1

        if len(self._buffer) >= self._flush_size:
            await self._flush()

    async def _flush(self) -> None:
        if not self._buffer or self._context is None:
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        if not self._store_ready:
            self.failure_count += 1
            self._buffer.clear()
            return

        rows, self._buffer = self._buffer, []
        try:
            written = await asyncio.to_thread(self._write, rows)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.error("704 failed to flush %d rows: %s",
                                       len(rows), exc)
            return
        self.flushed_count += written

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        await self._flush()

        if self._retention_days <= 0:
            return
        now = _to_float(payload.get("official_time"))
        if now is None:
            return
        cutoff = now - self._retention_days * 86400.0

        if not self._store_ready:
            return
        try:
            removed = await asyncio.to_thread(self._prune, cutoff)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            return

        self.pruned_count += removed
        self._last_prune_day = now
        await self._context.publish(EVENT_STATS, {
            "recorded": self.recorded_count,
            "flushed": self.flushed_count,
            "pruned": removed,
            "timestamp": now,
        })

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {
            "recorded": self.recorded_count,
            "flushed": self.flushed_count,
            "buffered": len(self._buffer),
            "pruned": self.pruned_count,
            "failures": self.failure_count,
            "watching": len(self._watch_events),
            "per_event": dict(self._per_event),
            "store_ready": self._store_ready,
            "last_error": self._last_error,
        }

        if not self._store_ready:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_STORE_UNAVAILABLE,
                                details=details)

        if self.recorded_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACTIVITY, details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="recorded=%d flushed=%d" % (self.recorded_count, self.flushed_count),
            details=details,
        )

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "recorded": self.recorded_count,
            "flushed": self.flushed_count,
            "pruned": self.pruned_count,
            "per_event": dict(self._per_event),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.recorded_count = int(state.get("recorded", 0))
        self.flushed_count = int(state.get("flushed", 0))
        self.pruned_count = int(state.get("pruned", 0))
        self._per_event = {str(k): int(v)
                           for k, v in (state.get("per_event") or {}).items()}
