from __future__ import annotations

import ast
import importlib.util
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom702"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 702

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler



async def _feed_symbol_map(ctx):
    """708 broadcasts its map on the bus; these tests deliver it directly."""
    registry = yaml.safe_load(
        (ATOM_DIR.parent / "708_symbol_registry" / "manifest.yaml").read_text(encoding="utf-8")
    )["config"]
    aliases = {}
    for canonical, names in registry["canonical_map"].items():
        for alias in names:
            aliases[str(alias).upper()] = str(canonical)
        aliases[str(canonical).upper()] = str(canonical)
    await ctx.handlers[MODULE.EVENT_SYMBOL_MAP]({
        "aliases": aliases,
        "strip_suffixes": registry["strip_suffixes"],
    })

async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "trades.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    await _feed_symbol_map(ctx)
    return atom, ctx, tmp


def _rows(ctx, sql="SELECT * FROM trades"):
    connection = sqlite3.connect(ctx.config["db_path"])
    connection.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in connection.execute(sql)]
    finally:
        connection.close()


def _opened(**over):
    body = {"trade_id": "2084", "ticket": 2084, "symbol": "USTEC", "side": "SELL",
            "size": 0.33, "entry_price": 28340.29, "opened_at": TS,
            "source_event_id": 1, "timestamp": TS}
    body.update(over)
    return body


def _closed(**over):
    body = {"trade_id": "2084", "ticket": 2084, "symbol": "USTEC", "side": "SELL",
            "size": 0.33, "entry_price": 28340.29, "exit_price": 28370.59,
            "opened_at": TS, "closed_at": TS + 600, "reason": "SL",
            "source_event_id": 2, "timestamp": TS + 600}
    body.update(over)
    return body


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_no_arabic_and_no_module_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "time.time()" not in src


def test_manifest_matches_code():
    assert MANIFEST["id"] == 702
    assert set(MANIFEST["subscribes"]) == {
        MODULE.EVENT_OPENED, MODULE.EVENT_CLOSED,
        MODULE.EVENT_REJECTED, MODULE.EVENT_OUTCOME,
        MODULE.EVENT_SYMBOL_MAP}


@pytest.mark.asyncio
async def test_open_and_close_are_separate_rows():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        await ctx.handlers[MODULE.EVENT_CLOSED](_closed())
        rows = _rows(ctx)
        assert [r["kind"] for r in rows] == ["OPENED", "CLOSED"]
        assert rows[1]["exit_price"] == 28370.59
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_outcome_enriches_the_closed_row():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        await ctx.handlers[MODULE.EVENT_CLOSED](_closed())
        await ctx.handlers[MODULE.EVENT_OUTCOME]({
            "ticket": 2084, "pnl": -9.99, "pnl_pct": -0.999,
            "result": "LOSS", "strategy": 410, "timestamp": TS + 600})
        closed = [r for r in _rows(ctx) if r["kind"] == "CLOSED"][0]
        assert closed["pnl"] == -9.99
        assert closed["result"] == "LOSS"
        assert closed["strategy"] == 410
        assert atom.enriched_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_outcome_never_touches_the_open_row():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        await ctx.handlers[MODULE.EVENT_CLOSED](_closed())
        await ctx.handlers[MODULE.EVENT_OUTCOME]({
            "ticket": 2084, "pnl": -9.99, "result": "LOSS", "timestamp": TS})
        opened = [r for r in _rows(ctx) if r["kind"] == "OPENED"][0]
        assert opened["pnl"] is None
        assert opened["result"] is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_same_source_event_is_not_stored_twice():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        assert len(_rows(ctx)) == 1
        assert atom.duplicate_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_partial_close_is_its_own_kind():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_CLOSED](_closed(partial=True, source_event_id=9))
        assert _rows(ctx)[0]["kind"] == "PARTIAL"
        assert _rows(ctx)[0]["partial"] == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_rejected_trade_is_recorded():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_REJECTED]({
            "symbol": "NQ", "side": "BUY", "size": 0.1,
            "reason": "NO_MONEY", "source_event_id": 5, "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["kind"] == "REJECTED"
        assert row["reason"] == "NO_MONEY"
        assert row["ticket"] is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_rows_survive_a_restart():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        fresh = MODULE.Atom()
        fresh_ctx = Ctx(ctx.config)
        await fresh.initialize(fresh_ctx)
        await fresh.start()
        await fresh_ctx.handlers[MODULE.EVENT_CLOSED](_closed())
        assert len(_rows(ctx)) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unreachable_store_does_not_raise():
    atom, ctx, tmp = await _ready(db_path="/proc/nonexistent/trades.db")
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        assert atom.failure_count >= 1
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "t.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_no_trades_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_healthy_after_a_trade():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_then_start_still_stores():
    atom, ctx, tmp = await _ready()
    try:
        await atom.stop()
        await atom.start()
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        assert len(_rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened())
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.stored_count == atom.stored_count
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_broker_names_share_one_canonical_history():
    """A change of broker renames the instrument. Without a canonical column
    the same market's history splits in two and the learning loop sees two
    unrelated instruments."""
    atom, ctx, tmp = await _ready()
    try:
        for index, symbol in enumerate(("USTEC", "NAS100", "US100.a", "NDX")):
            await ctx.handlers[MODULE.EVENT_OPENED](_opened(
                symbol=symbol, ticket=index + 1, source_event_id=index + 1))
        rows = _rows(ctx)
        assert {r["symbol"] for r in rows} == {"USTEC", "NAS100", "US100.a", "NDX"}
        assert {r["canonical_symbol"] for r in rows} == {"NQ100"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_raw_symbol_is_kept_alongside_the_canonical_one():
    """The broker name stays for tracing an order back to the platform."""
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened(symbol="US100.a"))
        row = _rows(ctx)[0]
        assert row["symbol"] == "US100.a"
        assert row["canonical_symbol"] == "NQ100"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unmapped_symbol_still_stores():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_OPENED](_opened(symbol="NOSUCH.xyz"))
        row = _rows(ctx)[0]
        assert row["symbol"] == "NOSUCH.xyz"
        assert row["canonical_symbol"] == "NOSUCH.XYZ"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
