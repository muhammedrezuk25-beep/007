from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DB_TIMEOUT_S = 5.0



ATOM_VERSION = "1.0.0"

EVENT_OPENED = "trade.opened"
EVENT_CLOSED = "trade.closed"
EVENT_REJECTED = "trade.rejected"
EVENT_CONFIRMED = "execution.confirmed"
EVENT_OUTCOME = "market.outcome.realized"

EVENT_STORED = "storage.trades_saved"
EVENT_SYMBOL_MAP = "storage.symbol.map"

KIND_OPENED = "OPENED"
KIND_CLOSED = "CLOSED"
KIND_PARTIAL = "PARTIAL"
KIND_REJECTED = "REJECTED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NO_ACTIVITY = "NO_TRADES_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS trades (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    kind          TEXT NOT NULL,
    trade_id      TEXT,
    ticket        INTEGER,
    symbol            TEXT,
    canonical_symbol  TEXT,
    side          TEXT,
    size          REAL,
    entry_price   REAL,
    exit_price    REAL,
    opened_at     REAL,
    closed_at     REAL,
    reason        TEXT,
    strategy      INTEGER,
    pnl           REAL,
    pnl_pct       REAL,
    result        TEXT,
    partial       INTEGER,
    source_event_id INTEGER,
    stored_at     REAL
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_trades_ticket ON trades(ticket)",
    "CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol, id DESC)",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_trades_dedupe"
    " ON trades(kind, source_event_id) WHERE source_event_id IS NOT NULL",
)

_COLUMNS = ("kind", "trade_id", "ticket", "symbol", "canonical_symbol", "side", "size",
            "entry_price", "exit_price", "opened_at", "closed_at", "reason",
            "strategy", "pnl", "pnl_pct", "result", "partial",
            "source_event_id", "stored_at")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._db_path = ""
        self._store_ready = False
        self._last_error = ""
        self._aliases: dict[str, str] = {}
        self._strip_suffixes: list[str] = []

        self.stored_count = 0
        self.duplicate_count = 0
        self.enriched_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._db_path = str(context.config["db_path"])

        context.subscribe(EVENT_OPENED, self._make_writer(KIND_OPENED))
        context.subscribe(EVENT_CLOSED, self._make_writer(KIND_CLOSED))
        context.subscribe(EVENT_REJECTED, self._make_writer(KIND_REJECTED))
        context.subscribe(EVENT_OUTCOME, self._on_outcome)

        context.subscribe(EVENT_SYMBOL_MAP, self._on_symbol_map)
        self._store_ready = self._ensure_store()
        self._initialized = True
        context.logger.info("702 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        self._context.logger.info("702 started")

    async def stop(self) -> None:
        self._running = False
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "702 stopped (stored=%d, duplicates=%d, enriched=%d)",
                self.stored_count, self.duplicate_count, self.enriched_count,
            )

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_symbol_map(self, payload: dict[str, Any]) -> None:
        aliases = payload.get("aliases")
        if isinstance(aliases, dict) and aliases:
            self._aliases = {str(k): str(v) for k, v in aliases.items()}
        suffixes = payload.get("strip_suffixes")
        if isinstance(suffixes, list):
            self._strip_suffixes = [str(s) for s in suffixes]

    def _canonical(self, symbol: Any) -> str | None:
        if not isinstance(symbol, str) or not symbol.strip():
            return None
        cleaned = symbol.strip().upper()
        for suffix in self._strip_suffixes:
            marker = suffix.upper()
            if marker and cleaned.endswith(marker):
                cleaned = cleaned[: -len(marker)]
                break
        return self._aliases.get(cleaned, cleaned)

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = "%s: %s" % (REASON_STORE_UNAVAILABLE, exc)
            return False

    def _insert(self, row: dict[str, Any]) -> bool:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        try:
            columns = ", ".join(_COLUMNS)
            marks = ", ".join("?" for _ in _COLUMNS)
            cursor = connection.execute(
                "INSERT OR IGNORE INTO trades (%s) VALUES (%s)" % (columns, marks),
                tuple(row.get(name) for name in _COLUMNS),
            )
            connection.commit()
            return cursor.rowcount > 0
        finally:
            connection.close()

    def _enrich(self, ticket: int | None, trade_id: str | None,
                pnl: float | None, pnl_pct: float | None,
                result: str | None, strategy: int | None) -> int:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        try:
            if ticket is not None:
                where, params = "ticket = ?", (ticket,)
            elif trade_id is not None:
                where, params = "trade_id = ?", (trade_id,)
            else:
                return 0
            cursor = connection.execute(
                "UPDATE trades SET pnl = ?, pnl_pct = ?, result = ?,"
                " strategy = COALESCE(?, strategy)"
                " WHERE %s AND kind IN (?, ?)" % where,
                (pnl, pnl_pct, result, strategy) + params + (KIND_CLOSED, KIND_PARTIAL),
            )
            connection.commit()
            return cursor.rowcount
        finally:
            connection.close()

    def _make_writer(self, kind: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._store(kind, payload)
        return handler

    async def _store(self, kind: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        if kind == KIND_CLOSED and payload.get("partial"):
            kind = KIND_PARTIAL

        if not self._store_ready:
            self._store_ready = self._ensure_store()
        if not self._store_ready:
            self.failure_count += 1
            return

        row = {
            "kind": kind,
            "trade_id": payload.get("trade_id"),
            "ticket": _to_int(payload.get("ticket")),
            "account_id": payload.get("account_id"),
            "symbol": payload.get("symbol"),
            "canonical_symbol": self._canonical(payload.get("symbol")),
            "side": payload.get("side"),
            "size": _to_float(payload.get("size")),
            "entry_price": _to_float(payload.get("entry_price")),
            "exit_price": _to_float(payload.get("exit_price")),
            "opened_at": _to_float(payload.get("opened_at")),
            "closed_at": _to_float(payload.get("closed_at")),
            "reason": payload.get("reason"),
            "strategy": _to_int(payload.get("strategy")),
            "pnl": None,
            "pnl_pct": None,
            "result": None,
            "partial": 1 if kind == KIND_PARTIAL else 0,
            "source_event_id": _to_int(payload.get("source_event_id")),
            "stored_at": _to_float(payload.get("timestamp")),
        }

        try:
            inserted = await asyncio.to_thread(self._insert, row)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.error("702 failed to store %s: %s", kind, exc)
            return

        if not inserted:
            self.duplicate_count += 1
            return

        self.stored_count += 1
        body: dict[str, Any] = {
            "kind": kind,
            "ticket": row["ticket"],
            "symbol": row["symbol"],
        }
        if row["stored_at"]:
            body["timestamp"] = row["stored_at"]
        await self._context.publish(EVENT_STORED, body)

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        if not self._store_ready:
            self.failure_count += 1
            return

        try:
            updated = await asyncio.to_thread(
                self._enrich,
                _to_int(payload.get("ticket")),
                payload.get("trade_id"),
                _to_float(payload.get("pnl")),
                _to_float(payload.get("pnl_pct")),
                payload.get("result"),
                _to_int(payload.get("strategy")),
            )
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.error("702 failed to enrich outcome: %s", exc)
            return

        if updated:
            self.enriched_count += updated

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {
            "stored": self.stored_count,
            "duplicates": self.duplicate_count,
            "enriched": self.enriched_count,
            "failures": self.failure_count,
            "store_ready": self._store_ready,
            "last_error": self._last_error,
        }

        if not self._store_ready:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_STORE_UNAVAILABLE,
                                details=details)

        if self.stored_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACTIVITY, details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="stored=%d enriched=%d" % (self.stored_count, self.enriched_count),
            details=details,
        )

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "stored": self.stored_count,
            "duplicates": self.duplicate_count,
            "enriched": self.enriched_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.stored_count = int(state.get("stored", 0))
        self.duplicate_count = int(state.get("duplicates", 0))
        self.enriched_count = int(state.get("enriched", 0))
