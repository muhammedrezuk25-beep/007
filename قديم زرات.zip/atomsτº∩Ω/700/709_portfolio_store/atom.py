from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

_DB_TIMEOUT_S = 5.0

EVENT_IN = "portfolio.summary"
EVENT_OUT = "storage.portfolio_saved"
EVENT_DAY = "SYS_DAY"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_STORE = "STORE_UNAVAILABLE"
REASON_NOTHING_STORED = "NOTHING_STORED_YET"

_TABLE = "portfolio"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS portfolio (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    equity       REAL,
    realised_pnl REAL,
    open_count   INTEGER,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_portfolio_time ON portfolio(occurred_at)",
)


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _dig(sections: dict, event: str, key: str) -> Any:
    section = sections.get(event)
    if isinstance(section, dict):
        return section.get(key)
    return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._min_interval_s = 0.0
        self._retention_days = 0
        self._last_written_at: float | None = None
        self._store_ready = False
        self._last_error = ""
        self.stored_count = 0
        self.skipped_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._min_interval_s = float(cfg["min_write_interval_s"])
        self._retention_days = int(cfg["retention_days"])
        context.subscribe(EVENT_IN, self._on_summary)
        context.subscribe(EVENT_DAY, self._on_day)
        self._store_ready = self._ensure_store()
        self._initialized = True
        context.logger.info("709 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("709 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("709 stopped (stored=%d, skipped=%d)",
                                      self.stored_count, self.skipped_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            if self._context is not None:
                self._context.logger.error("709 cannot open store: %s", exc)
            return False

    def _write(self, row: tuple) -> bool:
        try:
            connection = self._connect()
            try:
                connection.execute(
                    "INSERT INTO portfolio (equity, realised_pnl, open_count,"
                    " occurred_at, payload_json) VALUES (?,?,?,?,?)", row)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return False

    def _prune(self, now: float) -> int:
        if self._retention_days <= 0:
            return 0
        cutoff = now - self._retention_days * 86400.0
        try:
            connection = self._connect()
            try:
                cursor = connection.execute(
                    "DELETE FROM portfolio WHERE occurred_at IS NOT NULL"
                    " AND occurred_at < ?", (cutoff,))
                connection.commit()
                return cursor.rowcount or 0
            finally:
                connection.close()
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return 0

    async def _on_summary(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        occurred = _to_float(inner.get("timestamp", payload.get("timestamp")))

        if occurred is not None and self._last_written_at is not None:
            if occurred - self._last_written_at < self._min_interval_s:
                self.skipped_count += 1
                return

        if not self._store_ready:
            self._store_ready = self._ensure_store()
            if not self._store_ready:
                self.dropped_count += 1
                return

        sections = inner.get("sections")
        sections = sections if isinstance(sections, dict) else {}
        row = (
            _to_float(_dig(sections, "portfolio.account_tracked", "equity")),
            _to_float(_dig(sections, "portfolio.pnl_updated", "realised_pnl")),
            _dig(sections, "portfolio.open_trades_tracked", "open_count"),
            occurred,
            json.dumps(inner, ensure_ascii=False, default=str),
        )
        written = await asyncio.to_thread(self._write, row)
        if not written:
            self.dropped_count += 1
            self._context.logger.error("709 lost a snapshot: %s", self._last_error)
            return

        self.stored_count += 1
        if occurred is not None:
            self._last_written_at = occurred
        body: dict[str, Any] = {"rows": 1, "total": self.stored_count,
                                "skipped": self.skipped_count}
        if occurred is not None:
            body["timestamp"] = occurred
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        removed = 0
        if now is not None:
            removed = await asyncio.to_thread(self._prune, now)
        body: dict[str, Any] = {"rows": 0, "total": self.stored_count,
                                "pruned": removed}
        if now is not None:
            body["timestamp"] = now
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"stored": self.stored_count, "skipped": self.skipped_count,
                   "dropped": self.dropped_count, "db_path": self._db_path,
                   "last_error": self._last_error}
        if not self._store_ready:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_NO_STORE,
                                details=details)
        if self.stored_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NOTHING_STORED, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="stored=%d skipped=%d" % (
                                self.stored_count, self.skipped_count),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "stored": self.stored_count,
                "skipped": self.skipped_count, "dropped": self.dropped_count,
                "last_written_at": self._last_written_at}

    async def restore(self, state: dict[str, Any]) -> None:
        self.stored_count = int(state.get("stored", 0))
        self.skipped_count = int(state.get("skipped", 0))
        self.dropped_count = int(state.get("dropped", 0))
        self._last_written_at = state.get("last_written_at")
