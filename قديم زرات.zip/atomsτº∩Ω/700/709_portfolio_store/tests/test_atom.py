from __future__ import annotations

import ast
import importlib.util
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom709"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0

_SUMMARY = {
    "latest": "portfolio.pnl_updated",
    "sections": {
        "portfolio.account_tracked": {"equity": 10200.0, "balance": 10000.0},
        "portfolio.pnl_updated": {"realised_pnl": 250.0, "win_rate": 0.6},
        "portfolio.open_trades_tracked": {"open_count": 3},
    },
}


class Ctx:
    atom_id = 709

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "portfolio.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, tmp


def rows(ctx):
    connection = sqlite3.connect(ctx.config["db_path"])
    try:
        connection.row_factory = sqlite3.Row
        return [dict(r) for r in connection.execute(
            "SELECT * FROM portfolio ORDER BY id")]
    finally:
        connection.close()


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 709


@pytest.mark.asyncio
async def test_the_summary_lands_with_its_columns_lifted():
    """equity, realised pnl and open count become columns so the history can
    be queried without unpacking every payload."""
    atom, ctx, tmp = await _ready(min_write_interval_s=0.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        row = rows(ctx)[0]
        assert row["equity"] == 10200.0
        assert row["realised_pnl"] == 250.0
        assert row["open_count"] == 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_whole_summary_survives_as_json():
    atom, ctx, tmp = await _ready(min_write_interval_s=0.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        import json
        stored = json.loads(rows(ctx)[0]["payload_json"])
        assert stored["sections"]["portfolio.pnl_updated"]["win_rate"] == 0.6
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_burst_within_the_interval_writes_once():
    """650 republishes on every portfolio event. Without throttling a single
    account update would write a dozen near-identical rows."""
    atom, ctx, tmp = await _ready(min_write_interval_s=60.0)
    try:
        for offset in (0, 1, 5, 30):
            await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS + offset})
        assert len(rows(ctx)) == 1
        assert atom.skipped_count == 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_summary_past_the_interval_is_written():
    atom, ctx, tmp = await _ready(min_write_interval_s=60.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS + 120})
        assert len(rows(ctx)) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_summary_without_sections_still_stores():
    atom, ctx, tmp = await _ready(min_write_interval_s=0.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"latest": "x", "timestamp": TS})
        row = rows(ctx)[0]
        assert row["equity"] is None
        assert row["occurred_at"] == TS
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_retention_prunes_old_snapshots():
    atom, ctx, tmp = await _ready(min_write_interval_s=0.0, retention_days=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 3 * 86400})
        assert rows(ctx) == []
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_unreachable_store_degrades_and_counts_the_loss():
    atom, ctx, tmp = await _ready(db_path="/proc/nowhere/p.db",
                                  min_write_interval_s=0.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        assert (await atom.health_check()).state.name == "DEGRADED"
        assert atom.dropped_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_nothing_is_written_before_start():
    tmp = tempfile.mkdtemp()
    try:
        cfg = {**CONFIG, "db_path": str(Path(tmp) / "p.db"), "min_write_interval_s": 0.0}
        atom = MODULE.Atom()
        ctx = Ctx(cfg)
        await atom.initialize(ctx)
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        assert atom.stored_count == 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "p.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_empty_store_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_keeps_the_throttle_position():
    atom, ctx, tmp = await _ready(min_write_interval_s=60.0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({**_SUMMARY, "timestamp": TS})
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh._last_written_at == TS
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
