from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom708"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 708

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    cfg = {**CONFIG}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_and_no_arabic_and_no_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert "print(" not in src
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_broker_names_collapse_to_one_identity():
    """The whole reason this atom exists: a change of broker must not split
    the history in two."""
    atom, ctx = await _ready()
    for alias in ("USTEC", "NAS100", "US100", "NDX"):
        assert atom.resolve(alias) == "NQ100"


@pytest.mark.asyncio
async def test_case_and_whitespace_do_not_matter():
    atom, ctx = await _ready()
    assert atom.resolve("  ustec  ") == "NQ100"
    assert atom.resolve("NaS100") == "NQ100"


@pytest.mark.asyncio
async def test_broker_suffixes_are_stripped():
    atom, ctx = await _ready()
    assert atom.resolve("US100.a") == "NQ100"
    assert atom.resolve("XAUUSD.raw") == "XAUUSD"
    assert atom.resolve("BTCUSD.pro") == "BTCUSD"


@pytest.mark.asyncio
async def test_patterns_catch_numbered_variants():
    atom, ctx = await _ready()
    assert atom.resolve("NAS100") == "NQ100"
    assert atom.resolve("USTEC100") == "NQ100"


@pytest.mark.asyncio
async def test_gold_and_silver_aliases():
    atom, ctx = await _ready()
    assert atom.resolve("GOLD") == "XAUUSD"
    assert atom.resolve("SILVER") == "XAGUSD"


@pytest.mark.asyncio
async def test_crypto_aliases():
    atom, ctx = await _ready()
    assert atom.resolve("BTCUSDT") == "BTCUSD"
    assert atom.resolve("XBTUSD") == "BTCUSD"


@pytest.mark.asyncio
async def test_unknown_symbol_passes_through_and_is_counted():
    """An unmapped name must not break storage. It is recorded so the gap is
    visible instead of silently splitting history later."""
    atom, ctx = await _ready()
    assert atom.resolve("WEIRD.xyz") == "WEIRD.XYZ"
    assert atom.unmapped_count == 1
    assert atom.is_mapped("WEIRD.xyz") is False


@pytest.mark.asyncio
async def test_unknown_can_be_refused_instead():
    atom, ctx = await _ready(passthrough_unknown=False)
    assert atom.resolve("WEIRD") is None


@pytest.mark.asyncio
async def test_empty_or_non_string_returns_none():
    atom, ctx = await _ready()
    for value in ("", "   ", None, 42, []):
        assert atom.resolve(value) is None


@pytest.mark.asyncio
async def test_resolve_request_answers_with_both():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_RESOLVE_REQUESTED]({
        "request_id": "r1", "symbol": "NAS100", "timestamp": TS})
    answer = [p for n, p in ctx.published if n == MODULE.EVENT_RESOLVED][0]
    assert answer["symbol"] == "NAS100"
    assert answer["canonical"] == "NQ100"
    assert answer["mapped"] is True
    assert answer["request_id"] == "r1"


@pytest.mark.asyncio
async def test_unmapped_request_raises_its_own_event():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_RESOLVE_REQUESTED]({
        "symbol": "NOSUCH", "timestamp": TS})
    unmapped = [p for n, p in ctx.published if n == MODULE.EVENT_UNMAPPED]
    assert unmapped and unmapped[0]["symbol"] == "NOSUCH"


@pytest.mark.asyncio
async def test_repeated_lookups_are_cached():
    atom, ctx = await _ready()
    atom.resolve("USTEC")
    before = atom.resolved_count
    atom.resolve("USTEC")
    assert atom.resolved_count == before


@pytest.mark.asyncio
async def test_health_degraded_when_something_is_unmapped():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "HEALTHY"
    atom.resolve("NOSUCH")
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert "NOSUCH" in status.message


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx(CONFIG))
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    atom.resolve("USTEC")
    atom.resolve("NOSUCH")
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh.resolved_count == atom.resolved_count
    assert fresh._unmapped == atom._unmapped


# ── قصّ اللاحقات: لا يأكل حرفًا من الاسم ──────────────────────────────

import asyncio as _a708
import importlib.util as _iu708
import sys as _sys708
import yaml as _y708
from pathlib import Path as _P708

_D708 = _P708(__file__).resolve().parents[1]
_S708 = _iu708.spec_from_file_location("_sfx708", _D708 / "atom.py")
_M708 = _iu708.module_from_spec(_S708)
_sys708.modules["_sfx708"] = _M708
_sys708.path.insert(0, str(_D708))
try:
    _S708.loader.exec_module(_M708)
finally:
    _sys708.path.remove(str(_D708))

_CFG708 = _y708.safe_load((_D708 / "manifest.yaml").read_text(encoding="utf-8"))["config"]


class _Ctx708:
    atom_id = 708

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self):
        self.config = dict(_CFG708)
        self.handlers = {}

    async def publish(self, name, payload):
        pass

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _stripper():
    atom = _M708.Atom()
    await atom.initialize(_Ctx708())
    return atom


@pytest.mark.asyncio
async def test_a_lower_case_broker_tag_is_removed():
    atom = await _stripper()
    assert atom._strip("EURUSDm") == "EURUSD"
    assert atom._strip("USTECm") == "USTEC"


@pytest.mark.asyncio
async def test_a_name_ending_in_the_same_letter_is_left_whole():
    """"m" is a micro-account tag, but it also ends PLATINUM, CUSTOM and
    BEAM. Stripping it produced PLATINU, CUSTO and BEA, which then matched
    nothing in the canonical map."""
    atom = await _stripper()
    for symbol in ("PLATINUM", "CUSTOM", "BEAM", "ALUMINUM"):
        assert atom._strip(symbol) == symbol


@pytest.mark.asyncio
async def test_punctuated_suffixes_are_unambiguous_and_still_strip():
    atom = await _stripper()
    assert atom._strip("XAUUSD.pro") == "XAUUSD"
    assert atom._strip("EURUSD_i") == "EURUSD"
    assert atom._strip("XAUUSD.raw") == "XAUUSD"


@pytest.mark.asyncio
async def test_a_clean_symbol_is_untouched():
    atom = await _stripper()
    for symbol in ("XAUUSD", "USTEC", "BTCUSD"):
        assert atom._strip(symbol) == symbol


@pytest.mark.asyncio
async def test_a_stem_shorter_than_the_floor_is_not_stripped():
    atom = await _stripper()
    assert atom._strip("ABm") == "ABM"
