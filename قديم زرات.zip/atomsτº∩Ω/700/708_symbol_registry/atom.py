from __future__ import annotations

import re
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_RESOLVE_REQUESTED = "storage.symbol.resolve_requested"
EVENT_RESOLVED = "storage.symbol.resolved"
EVENT_UNMAPPED = "storage.symbol.unmapped"
EVENT_MAP = "storage.symbol.map"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_MAP = "NO_MAPPING_CONFIGURED"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._exact: dict[str, str] = {}
        self._patterns: list[tuple[re.Pattern, str]] = []
        self._min_stem_length = 0
        self._strip_suffixes: list[str] = []
        self._passthrough_unknown = True

        self._unmapped: dict[str, int] = {}
        self._cache: dict[str, str] = {}
        self.resolved_count = 0
        self.unmapped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._strip_suffixes = [str(s) for s in cfg["strip_suffixes"]]
        self._min_stem_length = int(cfg["min_stem_length"])
        self._passthrough_unknown = bool(cfg["passthrough_unknown"])

        for canonical, aliases in dict(cfg["canonical_map"]).items():
            for alias in aliases:
                self._exact[str(alias).strip().upper()] = str(canonical)
            self._exact[str(canonical).strip().upper()] = str(canonical)

        for canonical, pattern in dict(cfg["canonical_patterns"]).items():
            try:
                self._patterns.append((re.compile(pattern, re.IGNORECASE),
                                       str(canonical)))
            except re.error as exc:
                context.logger.error(
                    "708 skipped invalid pattern for %s: %s", canonical, exc)

        context.subscribe(EVENT_RESOLVE_REQUESTED, self._on_resolve_requested)
        context.subscribe("core.atom.started", self._on_atom_started)

        self._initialized = True
        context.logger.info(
            "708 initialised with %d aliases and %d patterns",
            len(self._exact), len(self._patterns))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        await self._context.publish(EVENT_MAP, {
            "aliases": dict(self._exact),
            "strip_suffixes": list(self._strip_suffixes),
            "passthrough_unknown": self._passthrough_unknown,
        })
        self._context.logger.info(
            "708 started and broadcast %d aliases", len(self._exact))

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "708 stopped (resolved=%d, unmapped=%d)",
                self.resolved_count, self.unmapped_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _strip(self, symbol: str) -> str:
        """Removes a broker suffix, never a letter that belongs to the name.

        A bare letter like "m" (micro accounts: EURUSDm) matched the tail of
        any symbol ending in that letter: PLATINUM became PLATINU, BEAM
        became BEA, CUSTOM became CUSTO. The stripped name then missed the
        canonical map entirely.

        A single-character suffix is only removed when what precedes it is a
        recognisable instrument: at least min_stem_length characters, and the
        character before it is not a letter of the same case pattern that
        would make the tail part of a word. Multi-character suffixes carry
        their own punctuation (".pro", "_i", "-5") and are unambiguous.
        """
        cleaned = symbol.strip().upper()
        for suffix in self._strip_suffixes:
            marker = suffix.upper()
            if not marker or not cleaned.endswith(marker):
                continue
            stem = cleaned[: -len(marker)]
            if len(stem) < self._min_stem_length:
                continue
            if len(marker) == 1 and marker.isalnum():
                # A lone letter is only a broker tag when the original had it
                # in lower case: EURUSDm is a micro contract, PLATINUM is not.
                if symbol.strip()[-1:].isupper():
                    continue
            cleaned = stem
            break
        return cleaned

    def resolve(self, symbol: Any) -> str | None:
        if not isinstance(symbol, str) or not symbol.strip():
            return None

        cached = self._cache.get(symbol)
        if cached is not None:
            return cached

        cleaned = self._strip(symbol)
        canonical = self._exact.get(cleaned)

        if canonical is None:
            for pattern, target in self._patterns:
                if pattern.fullmatch(cleaned):
                    canonical = target
                    break

        if canonical is None:
            self._unmapped[symbol] = self._unmapped.get(symbol, 0) + 1
            self.unmapped_count += 1
            if not self._passthrough_unknown:
                return None
            canonical = cleaned

        self._cache[symbol] = canonical
        self.resolved_count += 1
        return canonical

    def is_mapped(self, symbol: Any) -> bool:
        if not isinstance(symbol, str) or not symbol.strip():
            return False
        cleaned = self._strip(symbol)
        if cleaned in self._exact:
            return True
        return any(pattern.fullmatch(cleaned) for pattern, _ in self._patterns)

    async def _on_atom_started(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        await self._context.publish(EVENT_MAP, {
            "aliases": dict(self._exact),
            "strip_suffixes": list(self._strip_suffixes),
            "passthrough_unknown": self._passthrough_unknown,
        })

    async def _on_resolve_requested(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        symbol = payload.get("symbol")

        account_id = payload.get("account_id")
        canonical = self.resolve(symbol)
        mapped = self.is_mapped(symbol)

        body: dict[str, Any] = {
            "request_id": payload.get("request_id"),
            "account_id": account_id,
            "symbol": symbol,
            "canonical": canonical,
            "mapped": mapped,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp

        await self._context.publish(EVENT_RESOLVED, body)

        if not mapped:
            await self._context.publish(EVENT_UNMAPPED, dict(body))
            self._context.logger.warning(
                "708 has no canonical identity for %r - history under this name"
                " will not join the rest", symbol)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {
            "aliases": len(self._exact),
            "patterns": len(self._patterns),
            "resolved": self.resolved_count,
            "unmapped": self.unmapped_count,
            "unmapped_symbols": dict(self._unmapped),
        }

        if not self._exact and not self._patterns:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_MAP, details=details)

        if self._unmapped:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="unmapped: %s" % ",".join(sorted(self._unmapped)),
                details=details)

        return HealthStatus(state=HealthState.HEALTHY,
                            message="resolved=%d" % self.resolved_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "resolved": self.resolved_count,
            "unmapped": self.unmapped_count,
            "unmapped_symbols": dict(self._unmapped),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.resolved_count = int(state.get("resolved", 0))
        self.unmapped_count = int(state.get("unmapped", 0))
        self._unmapped = {str(k): int(v)
                          for k, v in (state.get("unmapped_symbols") or {}).items()}
