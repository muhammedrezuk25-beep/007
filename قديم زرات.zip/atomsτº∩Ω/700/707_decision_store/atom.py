from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DB_TIMEOUT_S = 5.0



ATOM_VERSION = "1.0.0"

EVENT_APPROVED = "decision.approved"
EVENT_REJECTED = "decision.rejected"
EVENT_ORDER_REQUESTED = "execution.order.requested"
EVENT_ORDER_BUILT = "execution.order.built"
EVENT_ORDER_REJECTED = "execution.order.rejected"
EVENT_FINAL = "trading.final_decision"

EVENT_STORED = "storage.decisions_saved"
EVENT_SYMBOL_MAP = "storage.symbol.map"

STAGE_APPROVED = "APPROVED"
STAGE_REJECTED = "REJECTED"
STAGE_ORDER_REQUESTED = "ORDER_REQUESTED"
STAGE_ORDER_BUILT = "ORDER_BUILT"
STAGE_ORDER_REJECTED = "ORDER_REJECTED"
STAGE_SENT = "SENT"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NO_ACTIVITY = "NO_DECISIONS_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    stage        TEXT NOT NULL,
    request_id   TEXT,
    symbol            TEXT,
    canonical_symbol  TEXT,
    direction    TEXT,
    approved     INTEGER,
    reason       TEXT,
    confidence   REAL,
    stability    REAL,
    strategy     INTEGER,
    volume       REAL,
    stop_loss    REAL,
    take_profit  REAL,
    payload_json TEXT,
    decided_at   REAL,
    stored_at    REAL
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_decisions_request ON decisions(request_id)",
    "CREATE INDEX IF NOT EXISTS idx_decisions_symbol ON decisions(symbol, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_decisions_stage ON decisions(stage, id DESC)",
)

_COLUMNS = ("stage", "request_id", "symbol", "canonical_symbol", "direction", "approved", "reason",
            "confidence", "stability", "strategy", "volume", "stop_loss",
            "take_profit", "payload_json", "decided_at", "stored_at")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._db_path = ""
        self._keep_payload = True
        self._store_ready = False
        self._last_error = ""
        self._aliases: dict[str, str] = {}
        self._strip_suffixes: list[str] = []

        self.stored_count = 0
        self.failure_count = 0
        self._per_stage: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._keep_payload = bool(cfg["keep_full_payload"])

        for event, stage in (
            (EVENT_APPROVED, STAGE_APPROVED),
            (EVENT_REJECTED, STAGE_REJECTED),
            (EVENT_ORDER_REQUESTED, STAGE_ORDER_REQUESTED),
            (EVENT_ORDER_BUILT, STAGE_ORDER_BUILT),
            (EVENT_ORDER_REJECTED, STAGE_ORDER_REJECTED),
            (EVENT_FINAL, STAGE_SENT),
        ):
            context.subscribe(event, self._make_writer(stage))

        context.subscribe(EVENT_SYMBOL_MAP, self._on_symbol_map)
        self._store_ready = self._ensure_store()
        self._initialized = True
        context.logger.info("707 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        self._context.logger.info("707 started")

    async def stop(self) -> None:
        self._running = False
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "707 stopped (stored=%d)", self.stored_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_symbol_map(self, payload: dict[str, Any]) -> None:
        aliases = payload.get("aliases")
        if isinstance(aliases, dict) and aliases:
            self._aliases = {str(k): str(v) for k, v in aliases.items()}
        suffixes = payload.get("strip_suffixes")
        if isinstance(suffixes, list):
            self._strip_suffixes = [str(s) for s in suffixes]

    def _canonical(self, symbol: Any) -> str | None:
        if not isinstance(symbol, str) or not symbol.strip():
            return None
        cleaned = symbol.strip().upper()
        for suffix in self._strip_suffixes:
            marker = suffix.upper()
            if marker and cleaned.endswith(marker):
                cleaned = cleaned[: -len(marker)]
                break
        return self._aliases.get(cleaned, cleaned)

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = "%s: %s" % (REASON_STORE_UNAVAILABLE, exc)
            return False

    def _insert(self, row: dict[str, Any]) -> None:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        try:
            columns = ", ".join(_COLUMNS)
            marks = ", ".join("?" for _ in _COLUMNS)
            connection.execute(
                "INSERT INTO decisions (%s) VALUES (%s)" % (columns, marks),
                tuple(row.get(name) for name in _COLUMNS),
            )
            connection.commit()
        finally:
            connection.close()

    def _make_writer(self, stage: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._store(stage, payload)
        return handler

    async def _store(self, stage: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        if not self._store_ready:
            self._store_ready = self._ensure_store()
        if not self._store_ready:
            self.failure_count += 1
            return

        inner = payload.get("payload", payload)
        if not isinstance(inner, dict):
            inner = payload

        payload_json = None
        if self._keep_payload:
            try:
                payload_json = json.dumps(payload, ensure_ascii=False,
                                          sort_keys=True, default=str)
            except (TypeError, ValueError):
                payload_json = None

        approved = payload.get("approved")
        decided_at = _to_float(payload.get("timestamp"))

        row = {
            "stage": stage,
            "request_id": inner.get("request_id") or payload.get("request_id"),
            "symbol": inner.get("symbol") or payload.get("symbol"),
            "canonical_symbol": self._canonical(
                inner.get("symbol") or payload.get("symbol")),
            "direction": (inner.get("direction") or payload.get("direction")
                          or inner.get("side") or payload.get("bias")),
            "approved": None if approved is None else int(bool(approved)),
            "reason": payload.get("reason") or inner.get("reason"),
            "confidence": _to_float(inner.get("confidence")),
            "stability": _to_float(inner.get("stability")),
            "strategy": _to_int(inner.get("strategy")),
            "volume": _to_float(inner.get("volume")),
            "stop_loss": _to_float(inner.get("stop_loss")),
            "take_profit": _to_float(inner.get("take_profit")),
            "payload_json": payload_json,
            "decided_at": decided_at,
            "stored_at": decided_at,
        }

        try:
            await asyncio.to_thread(self._insert, row)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.error("707 failed to store %s: %s", stage, exc)
            return

        self.stored_count += 1
        self._per_stage[stage] = self._per_stage.get(stage, 0) + 1

        body: dict[str, Any] = {
            "stage": stage,
            "request_id": row["request_id"],
            "symbol": row["symbol"],
        }
        if decided_at:
            body["timestamp"] = decided_at
        await self._context.publish(EVENT_STORED, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {
            "stored": self.stored_count,
            "per_stage": dict(self._per_stage),
            "failures": self.failure_count,
            "store_ready": self._store_ready,
            "last_error": self._last_error,
        }

        if not self._store_ready:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_STORE_UNAVAILABLE,
                                details=details)

        if self.stored_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACTIVITY, details=details)

        return HealthStatus(state=HealthState.HEALTHY,
                            message="stored=%d" % self.stored_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "stored": self.stored_count,
            "per_stage": dict(self._per_stage),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.stored_count = int(state.get("stored", 0))
        self._per_stage = {str(k): int(v)
                           for k, v in (state.get("per_stage") or {}).items()}
