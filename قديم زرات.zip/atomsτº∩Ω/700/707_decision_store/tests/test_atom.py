from __future__ import annotations

import ast
import importlib.util
import json
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom707"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 707

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler



async def _feed_symbol_map(ctx):
    """708 broadcasts its map on the bus; these tests deliver it directly."""
    registry = yaml.safe_load(
        (ATOM_DIR.parent / "708_symbol_registry" / "manifest.yaml").read_text(encoding="utf-8")
    )["config"]
    aliases = {}
    for canonical, names in registry["canonical_map"].items():
        for alias in names:
            aliases[str(alias).upper()] = str(canonical)
        aliases[str(canonical).upper()] = str(canonical)
    await ctx.handlers[MODULE.EVENT_SYMBOL_MAP]({
        "aliases": aliases,
        "strip_suffixes": registry["strip_suffixes"],
    })

async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "decisions.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    await _feed_symbol_map(ctx)
    return atom, ctx, tmp


def _rows(ctx, sql="SELECT * FROM decisions ORDER BY id"):
    connection = sqlite3.connect(ctx.config["db_path"])
    connection.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in connection.execute(sql)]
    finally:
        connection.close()


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_no_arabic_and_no_module_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_covers_every_stage():
    assert MANIFEST["id"] == 707
    # six decision stages plus the symbol map broadcast from 708
    assert len(MANIFEST["subscribes"]) == 7


@pytest.mark.asyncio
async def test_one_request_id_traced_across_stages():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({
            "request_id": "req-42", "symbol": "NQ", "direction": "BUY",
            "approved": True, "reason": "ALL_CHECKS_PASSED", "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_ORDER_BUILT]({
            "request_id": "req-42", "symbol": "NQ", "side": "BUY", "volume": 0.01,
            "stop_loss": 28329.99, "take_profit": 28543.0, "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_FINAL]({
            "request_id": "req-42", "symbol": "NQ", "side": "BUY",
            "volume": 0.01, "timestamp": TS})
        rows = _rows(ctx)
        assert [r["stage"] for r in rows] == ["APPROVED", "ORDER_BUILT", "SENT"]
        assert {r["request_id"] for r in rows} == {"req-42"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_rejection_records_its_reason():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({
            "request_id": "r1", "symbol": "BTCUSD", "direction": "BUY",
            "approved": False, "reason": "liquidity,timing", "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["approved"] == 0
        assert row["reason"] == "liquidity,timing"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_order_fields_are_extracted():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_ORDER_BUILT]({
            "request_id": "r1", "symbol": "NQ", "side": "BUY", "volume": 0.05,
            "stop_loss": 100.0, "take_profit": 200.0, "confidence": 0.82,
            "stability": 0.71, "strategy": 410, "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["volume"] == 0.05
        assert row["stop_loss"] == 100.0
        assert row["take_profit"] == 200.0
        assert row["confidence"] == 0.82
        assert row["strategy"] == 410
        assert row["direction"] == "BUY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_full_payload_is_kept_when_configured():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({
            "request_id": "r1", "symbol": "NQ", "direction": "BUY",
            "extra": {"nested": [1, 2]}, "timestamp": TS})
        stored = json.loads(_rows(ctx)[0]["payload_json"])
        assert stored["extra"] == {"nested": [1, 2]}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_payload_can_be_omitted():
    atom, ctx, tmp = await _ready(keep_full_payload=False)
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({
            "request_id": "r1", "symbol": "NQ", "direction": "BUY", "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["payload_json"] is None
        assert row["symbol"] == "NQ"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_nested_payload_shape_is_read():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_ORDER_REQUESTED]({
            "payload": {"request_id": "r9", "symbol": "XAUUSD", "direction": "SELL"},
            "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["request_id"] == "r9"
        assert row["symbol"] == "XAUUSD"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_rows_survive_a_restart():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED](
            {"request_id": "r1", "symbol": "NQ", "timestamp": TS})
        fresh = MODULE.Atom()
        fresh_ctx = Ctx(ctx.config)
        await fresh.initialize(fresh_ctx)
        await fresh.start()
        await fresh_ctx.handlers[MODULE.EVENT_FINAL](
            {"request_id": "r1", "symbol": "NQ", "timestamp": TS})
        assert len(_rows(ctx)) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unreachable_store_does_not_raise():
    atom, ctx, tmp = await _ready(db_path="/proc/nonexistent/d.db")
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({"request_id": "r1"})
        assert atom.failure_count >= 1
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_counts_per_stage():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({"request_id": "a", "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_APPROVED]({"request_id": "b", "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_FINAL]({"request_id": "a", "timestamp": TS})
        details = (await atom.health_check()).details or {}
        assert details["per_stage"]["APPROVED"] == 2
        assert details["per_stage"]["SENT"] == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "d.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_no_decisions_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({"request_id": "r1", "timestamp": TS})
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.stored_count == atom.stored_count
        assert fresh._per_stage == atom._per_stage
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_decisions_carry_the_canonical_symbol():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_APPROVED]({
            "request_id": "r1", "symbol": "NAS100", "direction": "BUY",
            "timestamp": TS})
        row = _rows(ctx)[0]
        assert row["symbol"] == "NAS100"
        assert row["canonical_symbol"] == "NQ100"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
