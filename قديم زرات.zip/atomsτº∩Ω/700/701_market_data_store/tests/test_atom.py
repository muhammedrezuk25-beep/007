from __future__ import annotations

import ast
import importlib.util
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom701"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0
TABLE = MODULE._TABLE


class Ctx:
    atom_id = 701

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "store.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, tmp


def rows(ctx):
    connection = sqlite3.connect(ctx.config["db_path"])
    try:
        connection.row_factory = sqlite3.Row
        return [dict(r) for r in connection.execute(
            "SELECT * FROM " + TABLE + " ORDER BY id")]
    finally:
        connection.close()


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 701


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "s.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_empty_store_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_events_reach_the_disk_after_the_flush_size():
    atom, ctx, tmp = await _ready(flush_size=2)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        assert rows(ctx) == []
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS + 1})
        assert len(rows(ctx)) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_stored_row_carries_the_symbol_and_the_stamp():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "USTEC", "timestamp": TS})
        row = rows(ctx)[0]
        assert row["symbol"] == "USTEC"
        assert row["occurred_at"] == TS
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_whole_payload_survives_as_json():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "extra": {"deep": [1, 2]},
                                            "timestamp": TS})
        import json
        stored = json.loads(rows(ctx)[0]["payload_json"])
        assert stored["extra"]["deep"] == [1, 2]
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_day_event_flushes_a_partial_buffer():
    """Without this a slow day would leave rows in memory overnight and lose
    them on restart."""
    atom, ctx, tmp = await _ready(flush_size=100)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        assert rows(ctx) == []
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
        assert len(rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_retention_prunes_rows_older_than_the_window():
    atom, ctx, tmp = await _ready(flush_size=1, retention_days=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 3 * 86400})
        assert rows(ctx) == []
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_retention_of_zero_keeps_everything():
    atom, ctx, tmp = await _ready(flush_size=1, retention_days=0)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 999 * 86400})
        assert len(rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_write_reports_how_many_rows_landed():
    atom, ctx, tmp = await _ready(flush_size=2)
    try:
        for i in range(2):
            await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS + i})
        report = out(ctx, MODULE.EVENT_OUT)[0]
        assert report["rows"] == 2
        assert report["total"] == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_unreachable_store_degrades_and_counts_the_loss():
    atom, ctx, tmp = await _ready(db_path="/proc/nowhere/store.db", flush_size=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        status = await atom.health_check()
        assert status.state.name == "DEGRADED"
        assert atom.dropped_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_flushes_what_is_still_buffered():
    atom, ctx, tmp = await _ready(flush_size=100)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        await atom.stop()
        assert len(rows(ctx)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_nothing_is_written_before_start():
    tmp = tempfile.mkdtemp()
    try:
        cfg = {**CONFIG, "db_path": str(Path(tmp) / "s.db"), "flush_size": 1}
        atom = MODULE.Atom()
        ctx = Ctx(cfg)
        await atom.initialize(ctx)
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        assert atom.stored_count == 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp = await _ready(flush_size=1)
    try:
        await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "timestamp": TS})
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.stored_count == atom.stored_count
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
