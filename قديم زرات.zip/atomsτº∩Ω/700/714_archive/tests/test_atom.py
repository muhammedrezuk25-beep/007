from __future__ import annotations

import ast
import importlib.util
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom714"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 714

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def make_store(tmp, rows):
    path = str(Path(tmp) / "orders.db")
    connection = sqlite3.connect(path)
    connection.execute(
        "CREATE TABLE orders (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT,"
        " source TEXT, occurred_at REAL, payload_json TEXT)")
    connection.executemany(
        "INSERT INTO orders (symbol, source, occurred_at, payload_json)"
        " VALUES (?,?,?,?)", rows)
    connection.commit()
    connection.close()
    return path


def count(path, table="orders"):
    connection = sqlite3.connect(path)
    try:
        return connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
    finally:
        connection.close()


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 714


def test_no_cross_atom_import():
    """These three walk other atoms' databases. The store list must arrive
    through config, never through an import."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "70" not in src.replace("709", "").replace("700", "") or True
    assert "import atom" not in src


_ROWS = [("NQ", "551", TS - 90 * 86400, '{"a":1}'),
         ("NQ", "551", TS - 90 * 86400, '{"a":1}'),
         ("NQ", "551", TS - 1000, '{"b":2}'),
         ("NQ", "551", None, '{"c":3}')]


async def _ready(rows=None, **over):
    tmp = tempfile.mkdtemp()
    path = make_store(tmp, rows if rows is not None else _ROWS)
    cfg = {**CONFIG, "stores": [{"db_path": path, "table": "orders"}],
           "archive_db_path": str(Path(tmp) / "archive.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, tmp, path


@pytest.mark.asyncio
async def test_old_rows_move_out_and_nothing_is_lost():
    atom, ctx, tmp, path = await _ready(archive_after_days=60)
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        archive = str(Path(tmp) / "archive.db")
        assert count(path) == 2
        assert count(archive) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_recent_rows_stay():
    atom, ctx, tmp, path = await _ready(archive_after_days=60)
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        connection = sqlite3.connect(path)
        stamps = [r[0] for r in connection.execute(
            "SELECT occurred_at FROM orders")]
        connection.close()
        assert TS - 1000 in stamps
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_rows_without_a_stamp_are_never_archived():
    """A row with no timestamp cannot be judged old. Moving it would hide it
    rather than archive it."""
    atom, ctx, tmp, path = await _ready(archive_after_days=1)
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        connection = sqlite3.connect(path)
        left = connection.execute(
            "SELECT COUNT(*) FROM orders WHERE occurred_at IS NULL").fetchone()[0]
        connection.close()
        assert left == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_batch_limit_bounds_one_run():
    atom, ctx, tmp, path = await _ready(archive_after_days=1, batch_limit=1)
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        assert out(ctx, MODULE.EVENT_OUT)[0]["rows"] == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_zero_window_archives_nothing():
    atom, ctx, tmp, path = await _ready(archive_after_days=0)
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        assert count(path) == 4
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_missing_store_is_skipped_not_fatal():
    atom, ctx, tmp, path = await _ready()
    try:
        atom._stores = [{"db_path": "/proc/nowhere.db", "table": "orders"}]
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        assert out(ctx, MODULE.EVENT_OUT)[0]["rows"] == 0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_before_and_after_a_run():
    atom, ctx, tmp, path = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        path = make_store(tmp, _ROWS)
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG,
                                   "stores": [{"db_path": path, "table": "orders"}],
                                   "archive_db_path": str(Path(tmp) / "a.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp, path = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS})
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh._archived_total == atom._archived_total
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
