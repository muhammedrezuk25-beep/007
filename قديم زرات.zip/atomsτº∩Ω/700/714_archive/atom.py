from __future__ import annotations

import asyncio
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

_DB_TIMEOUT_S = 5.0

EVENT_DAY = "SYS_DAY"
EVENT_OUT = "storage.archived"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NEVER_RAN"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._stores: list[dict[str, str]] = []
        self._archive_path = ""
        self._archive_after_days = 0
        self._batch_limit = 0
        self._runs = 0
        self._archived_total = 0
        self._last_error = ""
        self._last_report: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._stores = [dict(s) for s in cfg["stores"]]
        self._archive_path = str(cfg["archive_db_path"])
        self._archive_after_days = int(cfg["archive_after_days"])
        self._batch_limit = int(cfg["batch_limit"])
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("714 initialised over %d stores", len(self._stores))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("714 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("714 stopped (archived=%d)", self._archived_total)

    async def shutdown(self) -> None:
        await self.stop()

    def _archive_one(self, store: dict[str, str], cutoff: float) -> int:
        source = store.get("db_path", "")
        table = store.get("table", "")
        if not source or not table or not Path(source).is_file():
            return 0
        try:
            Path(self._archive_path).parent.mkdir(parents=True, exist_ok=True)
            connection = sqlite3.connect(source, timeout=_DB_TIMEOUT_S)
            try:
                connection.row_factory = sqlite3.Row
                rows = connection.execute(
                    "SELECT * FROM " + table + " WHERE occurred_at IS NOT NULL"
                    " AND occurred_at < ? ORDER BY id LIMIT ?",
                    (cutoff, self._batch_limit)).fetchall()
                if not rows:
                    return 0
                columns = rows[0].keys()
                target = sqlite3.connect(self._archive_path, timeout=_DB_TIMEOUT_S)
                try:
                    target.execute(
                        "CREATE TABLE IF NOT EXISTS " + table + " ("
                        + ", ".join(c + " TEXT" for c in columns) + ")")
                    target.executemany(
                        "INSERT INTO " + table + " VALUES ("
                        + ",".join("?" for _ in columns) + ")",
                        [tuple(str(r[c]) if r[c] is not None else None
                               for c in columns) for r in rows])
                    target.commit()
                finally:
                    target.close()
                moved = [r["id"] for r in rows]
                connection.execute(
                    "DELETE FROM " + table + " WHERE id IN ("
                    + ",".join("?" for _ in moved) + ")", moved)
                connection.commit()
                return len(moved)
            finally:
                connection.close()
        except (sqlite3.Error, OSError) as exc:
            self._last_error = "%s: %s" % (table, exc)
            return 0

    def _run(self, cutoff: float) -> dict[str, int]:
        report = {}
        for store in self._stores:
            moved = self._archive_one(store, cutoff)
            if moved:
                report[store.get("table", "?")] = moved
        return report

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        if now is None or self._archive_after_days <= 0:
            return

        cutoff = now - self._archive_after_days * 86400.0
        report = await asyncio.to_thread(self._run, cutoff)
        moved = sum(report.values())
        self._runs += 1
        self._archived_total += moved
        self._last_report = report

        await self._context.publish(EVENT_OUT, {
            "rows": moved, "total": self._archived_total,
            "per_table": dict(report), "cutoff": cutoff,
            "archive_path": self._archive_path, "timestamp": now})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"runs": self._runs, "archived": self._archived_total,
                   "stores": len(self._stores), "last_report": dict(self._last_report),
                   "last_error": self._last_error}
        if self._runs == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NEVER_RAN, details=details)
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="runs=%d archived=%d" % (
                                self._runs, self._archived_total),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "runs": self._runs,
                "archived": self._archived_total}

    async def restore(self, state: dict[str, Any]) -> None:
        self._runs = int(state.get("runs", 0))
        self._archived_total = int(state.get("archived", 0))
