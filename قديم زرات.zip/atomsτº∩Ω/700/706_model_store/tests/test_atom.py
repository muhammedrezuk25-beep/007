from __future__ import annotations

import ast
import importlib.util
import json
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom706"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]

TS = 1785600000.0


class Ctx:
    atom_id = 706

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    tmp = tempfile.mkdtemp()
    cfg = {**CONFIG, "db_path": str(Path(tmp) / "models.db")}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, tmp


def _out(ctx, name):
    return [p for n, p in ctx.published if n == name]


async def _save(ctx, name="trend_v1", version="1.0.0", data=None, ts=TS):
    await ctx.handlers[MODULE.EVENT_PERSIST_REQUESTED]({
        "model_name": name, "version": version,
        "data": {"w": [0.3, 0.7]} if data is None else data,
        "timestamp": ts,
    })


async def _load(ctx, name="trend_v1", version=None, request_id="r1"):
    body = {"request_id": request_id, "model_name": name}
    if version:
        body["version"] = version
    await ctx.handlers[MODULE.EVENT_LOAD_REQUESTED](body)


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 706
    assert set(MANIFEST["subscribes"]) == {
        MODULE.EVENT_PERSIST_REQUESTED, MODULE.EVENT_LOAD_REQUESTED}
    assert MODULE.EVENT_LOAD_RESPONSE in MANIFEST["publishes"]


def test_no_arabic_and_no_module_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "time.time()" not in src
    assert "datetime.now" not in src


@pytest.mark.asyncio
async def test_save_then_load_round_trip():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx, data={"w": [0.3, 0.7], "bias": 0.1})
        assert len(_out(ctx, MODULE.EVENT_PERSISTED)) == 1

        await _load(ctx)
        response = _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]
        assert response["found"] is True
        assert response["request_id"] == "r1"
        assert response["version"] == "1.0.0"
        assert response["data"] == {"w": [0.3, 0.7], "bias": 0.1}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_data_survives_a_restart():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx)
        fresh = MODULE.Atom()
        fresh_ctx = Ctx(ctx.config)
        await fresh.initialize(fresh_ctx)
        await fresh.start()
        await _load(fresh_ctx)
        assert _out(fresh_ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["found"] is True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_missing_model_answers_not_found():
    atom, ctx, tmp = await _ready()
    try:
        await _load(ctx, name="ghost")
        response = _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]
        assert response["found"] is False
        assert response["request_id"] == "r1"
        assert atom.missing_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_request_id_returns_unchanged():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx)
        await _load(ctx, request_id="abc-123")
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["request_id"] == "abc-123"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_latest_version_when_none_requested():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx, version="1.0.0", data={"v": 1})
        await _save(ctx, version="2.0.0", data={"v": 2})
        await _load(ctx)
        response = _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]
        assert response["version"] == "2.0.0"
        assert response["data"] == {"v": 2}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_specific_version_is_honoured():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx, version="1.0.0", data={"v": 1})
        await _save(ctx, version="2.0.0", data={"v": 2})
        await _load(ctx, version="1.0.0")
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["data"] == {"v": 1}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_same_version_is_overwritten_not_duplicated():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx, version="1.0.0", data={"v": 1})
        await _save(ctx, version="1.0.0", data={"v": 99})
        await _load(ctx, version="1.0.0")
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["data"] == {"v": 99}

        connection = sqlite3.connect(ctx.config["db_path"])
        try:
            count = connection.execute(
                "SELECT COUNT(*) FROM model_versions").fetchone()[0]
        finally:
            connection.close()
        assert count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_old_versions_are_pruned():
    atom, ctx, tmp = await _ready(keep_versions_per_model=3)
    try:
        for i in range(5):
            await _save(ctx, version="1.0.%d" % i, data={"v": i})
        connection = sqlite3.connect(ctx.config["db_path"])
        try:
            rows = [r[0] for r in connection.execute(
                "SELECT version FROM model_versions ORDER BY id")]
        finally:
            connection.close()
        assert rows == ["1.0.2", "1.0.3", "1.0.4"]
        assert atom.pruned_count == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_pruning_off_when_zero():
    atom, ctx, tmp = await _ready(keep_versions_per_model=0)
    try:
        for i in range(4):
            await _save(ctx, version="1.0.%d" % i)
        connection = sqlite3.connect(ctx.config["db_path"])
        try:
            count = connection.execute(
                "SELECT COUNT(*) FROM model_versions").fetchone()[0]
        finally:
            connection.close()
        assert count == 4
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_models_are_isolated_per_name():
    atom, ctx, tmp = await _ready(keep_versions_per_model=2)
    try:
        for i in range(3):
            await _save(ctx, name="a", version="1.0.%d" % i, data={"a": i})
        await _save(ctx, name="b", version="1.0.0", data={"b": 0})
        await _load(ctx, name="b")
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["data"] == {"b": 0}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_save_without_name_or_version_is_refused():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_PERSIST_REQUESTED](
            {"version": "1.0.0", "data": {}})
        await ctx.handlers[MODULE.EVENT_PERSIST_REQUESTED](
            {"model_name": "x", "data": {}})
        assert _out(ctx, MODULE.EVENT_PERSISTED) == []
        assert atom.failure_count == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unknown_type_is_stringified_not_dropped():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx, data={"threshold": 0.5, "note": object()})
        assert len(_out(ctx, MODULE.EVENT_PERSISTED)) == 1
        await _load(ctx)
        stored = _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["data"]
        assert stored["threshold"] == 0.5
        assert isinstance(stored["note"], str)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_circular_data_is_reported_not_swallowed():
    atom, ctx, tmp = await _ready()
    try:
        loop = {}
        loop["self"] = loop
        await _save(ctx, data=loop)
        assert _out(ctx, MODULE.EVENT_PERSISTED) == []
        failures = _out(ctx, MODULE.EVENT_PERSIST_FAILED)
        assert failures and failures[0]["reason"] == "NOT_SERIALISABLE"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unreachable_store_reports_failure():
    atom, ctx, tmp = await _ready(db_path="/proc/nonexistent/models.db")
    try:
        await _save(ctx)
        failures = _out(ctx, MODULE.EVENT_PERSIST_FAILED)
        assert failures
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_load_from_unreachable_store_answers_not_found():
    atom, ctx, tmp = await _ready(db_path="/proc/nonexistent/models.db")
    try:
        await _load(ctx)
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["found"] is False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": str(Path(tmp) / "m.db")}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_no_activity_is_degraded():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_healthy_after_a_save():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx)
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_then_start_still_serves():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx)
        await atom.stop()
        assert atom.failure_count == 0
        await atom.start()
        await _load(ctx)
        assert _out(ctx, MODULE.EVENT_LOAD_RESPONSE)[0]["found"] is True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp = await _ready()
    try:
        await _save(ctx)
        await _load(ctx)
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.saved_count == atom.saved_count
        assert fresh.loaded_count == atom.loaded_count
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
