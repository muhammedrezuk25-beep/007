from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "risk.session_limits"
EVENT_OUT = "portfolio.loss_limits_displayed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NOTHING_YET = "NO_SOURCE_DATA_YET"

_FIELDS = ("session", "session_loss_pct", "max_session_loss_pct", "session_trades",
           "max_session_trades", "equity_drawdown_pct", "max_equity_drawdown_pct",
           "peak_equity", "breached")


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._latest: dict[str, Any] = {}
        self.displayed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_source)
        self._initialized = True
        context.logger.info("664 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("664 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("664 stopped (displayed=%d)",
                                      self.displayed_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_source(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        view = {key: inner.get(key) for key in _FIELDS if key in inner}
        if not view:
            return
        self._latest = view
        self.displayed_count += 1
        body = dict(view)
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"displayed": self.displayed_count, "latest": dict(self._latest)}
        if not self._latest:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NOTHING_YET, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="displayed=%d" % self.displayed_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "latest": dict(self._latest),
                "displayed": self.displayed_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._latest = dict(state.get("latest") or {})
        self.displayed_count = int(state.get("displayed", 0))
