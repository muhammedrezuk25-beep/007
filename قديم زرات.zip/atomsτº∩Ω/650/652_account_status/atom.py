from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "portfolio.account_tracked"
EVENT_OUT = "portfolio.account_status_updated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NOTHING_YET = "NO_SOURCE_DATA_YET"

_FIELD = "status"
_EXTRA = "margin_level"


class Atom(AtomBase):
    """حالة الحساب مصنَّفة من مستوى الهامش: سليم أو تحذير أو حرج.

    يسمع 651 لا الجسر: 651 هو المختصّ بحالة الحساب، وقراءة الجسر مباشرة
    تربط هذه الذرّة بمنصّة بعينها — فحساب بايننس أو حساب ممول ثانٍ لا
    يصلها إطلاقًا.

    والحقل يسافر بهوية حسابه: رقمٌ بلا صاحبه لا يُقرأ — رصيدُ من؟ ومع
    حسابين يصير الرقمان متطابقين في الشكل ومختلفين في المعنى. وحمولةٌ بلا
    هوية تُسقَط ولا تُنسَب لافتراضي.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._latest: Any = None
        self.published_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_account)
        self._initialized = True
        context.logger.info("652 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("652 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("652 stopped (published=%d)",
                                      self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        account_id = inner.get("account_id")
        if account_id in (None, ""):
            self.dropped_count += 1
            return
        value = inner.get(_FIELD)
        if value is None:
            # حقل غائب لا يُنشر صفرًا: الفرق بين "صفر" و"لم يصل" هو الفرق
            # بين معلومة وغيابها.
            self.dropped_count += 1
            return
        self._latest = value
        self.published_count += 1
        # الحالة ومستواها معًا: "تحذير" بلا الرقم لا يقول كم بقي.
        body: dict[str, Any] = {"account_id": str(account_id), "status": value,
                                "margin_level": inner.get(_EXTRA)}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {"published": self.published_count,
                   "dropped": self.dropped_count, "latest": self._latest}
        if self._latest is None:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NOTHING_YET, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="published=%d" % self.published_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "latest": self._latest,
                "published": self.published_count,
                "dropped": self.dropped_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._latest = state.get("latest")
        self.published_count = int(state.get("published", 0))
        self.dropped_count = int(state.get("dropped", 0))
