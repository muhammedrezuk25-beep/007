"""اختبارات الذرّة 654 — حقوق الملكية"""

from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_SPEC = importlib.util.spec_from_file_location("_atom654", ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_SPEC)
sys.modules["_atom654"] = MODULE
sys.path.insert(0, str(ATOM_DIR))
try:
    _SPEC.loader.exec_module(MODULE)
finally:
    sys.path.remove(str(ATOM_DIR))

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785600000.0
SAMPLE_KEY = "equity"
SAMPLE_VALUE = 1020.0


class Ctx:
    atom_id = 654

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self):
        self.config = dict(MANIFEST["config"])
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


# ── البنية ──────────────────────────────────────────────────────────

def test_manifest_matches_code():
    assert MANIFEST["id"] == 654
    assert MANIFEST["publishes"] == [MODULE.EVENT_OUT]
    assert MANIFEST["subscribes"] == [MODULE.EVENT_IN]


def test_it_listens_to_the_owner_not_the_bridge():
    """651 هو المختصّ بحالة الحساب. وقراءة الجسر مباشرة تربط الذرّة
    بمنصّة بعينها: حساب ممول ثانٍ أو حساب بايننس لا يصلها إطلاقًا."""
    assert MODULE.EVENT_IN == "portfolio.account_tracked"
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "platform.account.state" not in src
    assert "sqlite" not in src


def test_no_clock_reading():
    """3 و806 و608 يملكون الساعة. والطابع يُورَّث من الحمولة."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "time.time()" not in src


def test_no_magic_numbers_in_logic():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name.startswith("_on"):
            for inner in ast.walk(node):
                if isinstance(inner, ast.Constant) and isinstance(inner.value, (int, float)):
                    assert inner.value in (0, 1), "رقم سحري: %s" % inner.value


# ── السلوك ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_the_field_is_published_when_it_arrives():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert out(ctx)


@pytest.mark.asyncio
async def test_a_missing_field_publishes_nothing():
    """الفرق بين «صفر» و«لم يصل» هو الفرق بين معلومة وغيابها. ونشر صفر
    مكان الغياب يجعل القارئ يصدّق رقمًا لم يقله أحد."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "timestamp": TS})
    assert not out(ctx)
    assert atom.dropped_count == 1


@pytest.mark.asyncio
async def test_the_stamp_is_inherited_not_minted():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert out(ctx)[0]["timestamp"] == TS


@pytest.mark.asyncio
async def test_it_stays_silent_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert not out(ctx)


@pytest.mark.asyncio
async def test_health_degrades_until_the_first_figure():
    atom, ctx = await _ready()
    assert (await atom.health_check()).message == MODULE.REASON_NOTHING_YET
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restores_the_counters():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.published_count == atom.published_count


@pytest.mark.asyncio
async def test_the_lifecycle_is_clean():
    atom, ctx = await _ready()
    await atom.stop()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert not out(ctx)
    await atom.shutdown()


# ── هوية الحساب تسافر مع الحقل ──────────────────────────────────────

@pytest.mark.asyncio
async def test_the_field_carries_its_account():
    """حقل بلا صاحبه لا يُقرأ: رصيدُ من؟ وحقوقُ أي حساب؟ ومع حسابين
    يصير الرقمان متطابقين في الشكل ومختلفين في المعنى."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", SAMPLE_KEY: SAMPLE_VALUE,
                                         "account_id": "A", "timestamp": TS})
    assert out(ctx)[0]["account_id"] == "A"


@pytest.mark.asyncio
async def test_a_field_without_an_account_is_refused():
    """Fail Closed — القاعدة نفسها في 619 و651."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({SAMPLE_KEY: SAMPLE_VALUE,
                                         "timestamp": TS})
    assert not out(ctx)
