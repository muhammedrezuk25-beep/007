from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom666"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1000.0


class Ctx:
    atom_id = 666

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 666


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _pnl(ctx, realised, daily, wins=1, losses=0, at=TS):
    await ctx.handlers[MODULE.EVENT_PNL]({"realised_pnl": realised, "daily_pnl": daily,
                                           "wins": wins, "losses": losses,
                                           "profit_factor": 2.0, "timestamp": at})


async def _day(ctx, at=TS):
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": at})


@pytest.mark.asyncio
async def test_a_grade_waits_for_enough_days():
    """One good day is not a track record. Below the day threshold the grade
    is withheld rather than guessed."""
    atom, ctx = await _ready(min_days_for_grade=10)
    await _pnl(ctx, 100.0, 100.0, wins=5, losses=1)
    await _day(ctx)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["grade"] is None
    assert last["grade_ready"] is False


@pytest.mark.asyncio
async def test_a_strong_record_earns_its_grade():
    atom, ctx = await _ready(min_days_for_grade=2, strong_win_rate=0.55)
    for day in range(3):
        await _pnl(ctx, 100.0 * (day + 1), 100.0, wins=8, losses=2)
        await _day(ctx, TS + day)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["grade"] == MODULE.GRADE_STRONG


@pytest.mark.asyncio
async def test_a_weak_record_is_graded_weak():
    atom, ctx = await _ready(min_days_for_grade=2, weak_win_rate=0.35)
    for day in range(3):
        await _pnl(ctx, -10.0 * (day + 1), -10.0, wins=1, losses=9)
        await _day(ctx, TS + day)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["grade"] == MODULE.GRADE_WEAK


@pytest.mark.asyncio
async def test_consistency_counts_positive_days():
    atom, ctx = await _ready()
    for daily in (100.0, -20.0, 50.0, 30.0):
        await _pnl(ctx, 100.0, daily)
        await _day(ctx)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["days_recorded"] == 4
    assert last["positive_days"] == 3
    assert last["consistency"] == 0.75


@pytest.mark.asyncio
async def test_drawdown_is_measured_from_the_peak():
    """A curve that reached +300 and fell to +180 gave back 120, even though
    it is still in profit."""
    atom, ctx = await _ready()
    await _pnl(ctx, 300.0, 300.0)
    await _pnl(ctx, 180.0, -120.0)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["peak_realised"] == 300.0
    assert last["max_drawdown"] == 120.0


@pytest.mark.asyncio
async def test_the_peak_never_moves_down():
    atom, ctx = await _ready()
    await _pnl(ctx, 300.0, 300.0)
    await _pnl(ctx, 100.0, -200.0)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["peak_realised"] == 300.0


@pytest.mark.asyncio
async def test_history_is_capped_at_the_window():
    atom, ctx = await _ready(history_days=3)
    for i in range(6):
        await _pnl(ctx, float(i), 1.0)
        await _day(ctx)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["days_recorded"] == 3


@pytest.mark.asyncio
async def test_open_positions_are_carried_through():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OPEN]({"open_count": 4, "timestamp": TS})
    await _pnl(ctx, 10.0, 10.0)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 4


@pytest.mark.asyncio
async def test_a_pnl_event_without_realised_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_PNL]({"daily_pnl": 10.0})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _pnl(ctx, 100.0, 100.0)
    await _day(ctx)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._peak_realised == 100.0
    assert len(fresh._daily) == 1
