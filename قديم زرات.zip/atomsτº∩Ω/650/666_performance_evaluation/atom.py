from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PNL = "portfolio.pnl_updated"
EVENT_OPEN = "portfolio.open_trades_tracked"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "portfolio.performance_evaluated"

GRADE_STRONG = "STRONG"
GRADE_STEADY = "STEADY"
GRADE_WEAK = "WEAK"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_HISTORY = "NO_HISTORY_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._history_days = 0
        self._min_days = 0
        self._strong_win_rate = 0.0
        self._weak_win_rate = 0.0
        self._daily: list[dict[str, Any]] = []
        self._latest_pnl: dict[str, Any] = {}
        self._peak_realised = 0.0
        self._max_drawdown = 0.0
        self._open_count = 0
        self.evaluations = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._history_days = int(cfg["history_days"])
        self._min_days = int(cfg["min_days_for_grade"])
        self._strong_win_rate = float(cfg["strong_win_rate"])
        self._weak_win_rate = float(cfg["weak_win_rate"])
        context.subscribe(EVENT_PNL, self._on_pnl)
        context.subscribe(EVENT_OPEN, self._on_open)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("666 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("666 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("666 stopped (evaluations=%d)", self.evaluations)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_open(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        count = payload.get("open_count")
        if isinstance(count, int):
            self._open_count = count

    async def _on_pnl(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        realised = _to_float(payload.get("realised_pnl"))
        if realised is None:
            return
        self._latest_pnl = dict(payload)

        if realised > self._peak_realised:
            self._peak_realised = realised
        drawdown = round(self._peak_realised - realised, 6)
        if drawdown > self._max_drawdown:
            self._max_drawdown = drawdown

        await self._emit(payload)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if self._latest_pnl:
            self._daily.append({
                "daily_pnl": self._latest_pnl.get("daily_pnl"),
                "realised_pnl": self._latest_pnl.get("realised_pnl"),
                "wins": self._latest_pnl.get("wins"),
                "losses": self._latest_pnl.get("losses"),
            })
            while len(self._daily) > self._history_days:
                self._daily.pop(0)
        await self._emit(payload)

    def evaluate(self) -> dict[str, Any]:
        wins = self._latest_pnl.get("wins") or 0
        losses = self._latest_pnl.get("losses") or 0
        closed = wins + losses
        win_rate = round(wins / closed, 6) if closed else None

        positive_days = len([d for d in self._daily
                             if isinstance(d.get("daily_pnl"), (int, float))
                             and d["daily_pnl"] > 0])
        consistency = (round(positive_days / len(self._daily), 6)
                       if self._daily else None)

        grade = None
        if len(self._daily) >= self._min_days and win_rate is not None:
            if win_rate >= self._strong_win_rate:
                grade = GRADE_STRONG
            elif win_rate <= self._weak_win_rate:
                grade = GRADE_WEAK
            else:
                grade = GRADE_STEADY

        return {
            "realised_pnl": self._latest_pnl.get("realised_pnl"),
            "profit_factor": self._latest_pnl.get("profit_factor"),
            "win_rate": win_rate, "closed_trades": closed,
            "open_count": self._open_count,
            "days_recorded": len(self._daily),
            "positive_days": positive_days, "consistency": consistency,
            "peak_realised": self._peak_realised,
            "max_drawdown": self._max_drawdown,
            "grade": grade, "grade_ready": grade is not None,
        }

    async def _emit(self, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self.evaluate()
        self.evaluations += 1
        stamp = payload.get("timestamp", payload.get("official_time"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = self.evaluate()
        details["evaluations"] = self.evaluations
        if not self._latest_pnl:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_HISTORY, details=details)
        if details["grade"] == GRADE_WEAK:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=GRADE_WEAK, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="days=%d grade=%s" % (
                                len(self._daily), details["grade"] or "pending"),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "daily": list(self._daily),
                "latest": dict(self._latest_pnl), "peak": self._peak_realised,
                "max_drawdown": self._max_drawdown, "evaluations": self.evaluations}

    async def restore(self, state: dict[str, Any]) -> None:
        self._daily = list(state.get("daily") or [])
        self._latest_pnl = dict(state.get("latest") or {})
        self._peak_realised = float(state.get("peak", 0.0))
        self._max_drawdown = float(state.get("max_drawdown", 0.0))
        self.evaluations = int(state.get("evaluations", 0))
