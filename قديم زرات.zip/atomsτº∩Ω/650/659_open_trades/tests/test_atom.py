from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom659"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 659

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 659


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert True


async def _open(ctx, ticket, symbol="NQ", size=0.1):
    await ctx.handlers[MODULE.EVENT_OPENED]({"account_id": "A", "ticket": ticket, "symbol": symbol,
                                              "side": "BUY", "size": size,
                                              "entry_price": 100.0, "timestamp": TS})


@pytest.mark.asyncio
async def test_positions_accumulate_and_clear():
    atom, ctx = await _ready()
    await _open(ctx, 1)
    await _open(ctx, 2)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 2
    await ctx.handlers[MODULE.EVENT_CLOSED]({"ticket": 1, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 1


@pytest.mark.asyncio
async def test_a_partial_close_reduces_without_removing():
    atom, ctx = await _ready()
    await _open(ctx, 1, size=1.0)
    await ctx.handlers[MODULE.EVENT_CLOSED]({"ticket": 1, "size": 0.6,
                                              "partial": True, "timestamp": TS})
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["open_count"] == 1
    assert round(last["total_lots"], 4) == 0.4


@pytest.mark.asyncio
async def test_drift_against_the_platform_is_reported():
    """The platform is the truth. If it holds three positions and this atom
    knows of one, the gap is the symptom of a lost event."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "open_count": 3, "equity": 100.0})
    await _open(ctx, 1)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["drift"] == 2


@pytest.mark.asyncio
async def test_drift_makes_health_degraded():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "open_count": 5})
    await _open(ctx, 1)
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_a_duplicate_open_is_not_counted_twice():
    atom, ctx = await _ready()
    await _open(ctx, 1)
    await _open(ctx, 1)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 1


@pytest.mark.asyncio
async def test_closing_an_unknown_ticket_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_CLOSED]({"ticket": 99, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_the_tracked_ceiling_refuses_rather_than_silently_drops():
    atom, ctx = await _ready(max_tracked_positions=2)
    for i in range(4):
        await _open(ctx, i)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 2


@pytest.mark.asyncio
async def test_positions_are_grouped_by_symbol():
    atom, ctx = await _ready()
    await _open(ctx, 1, symbol="NQ")
    await _open(ctx, 2, symbol="NQ")
    await _open(ctx, 3, symbol="XAU")
    assert out(ctx, MODULE.EVENT_OUT)[-1]["by_symbol"] == {"NQ": 2, "XAU": 1}


# ── فصل الحسابات ────────────────────────────────────────────────────

def test_the_output_carries_the_account():
    """ربحُ من؟ ومراكزُ أي حساب؟ الرقم المجموع من حسابين لا يخصّ
    أيًّا منهما، ويُبنى عليه قرار مخاطرة بمال حقيقي."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "account_id" in src
