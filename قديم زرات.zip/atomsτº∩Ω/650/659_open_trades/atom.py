from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OPENED = "trade.opened"
EVENT_CLOSED = "trade.closed"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_OUT = "portfolio.open_trades_tracked"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRADES = "NO_TRADES_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._max_tracked = 0
        self._open: dict[str, dict[str, Any]] = {}
        self._broker_counts: dict[str, int] = {}
        self.opened_count = 0
        self.closed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_tracked = int(context.config["max_tracked_positions"])
        context.subscribe(EVENT_OPENED, self._on_opened)
        context.subscribe(EVENT_CLOSED, self._on_closed)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        self._initialized = True
        context.logger.info("659 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("659 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("659 stopped (open=%d)", len(self._open))

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            return
        count = payload.get("open_count")
        if isinstance(count, int):
            self._broker_counts[str(account_id)] = count

    async def _on_opened(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        ticket = payload.get("ticket")
        if ticket is None:
            return
        key = str(ticket)
        if key in self._open:
            return
        if len(self._open) >= self._max_tracked:
            self._context.logger.error(
                "659 refuses to track more than %d positions", self._max_tracked)
            return

        self._open[key] = {
            "ticket": ticket, "account_id": payload.get("account_id"),
            "symbol": payload.get("symbol"),
            "side": payload.get("side"), "size": _to_float(payload.get("size")),
            "entry_price": _to_float(payload.get("entry_price")),
            "opened_at": _to_float(payload.get("opened_at")),
        }
        self.opened_count += 1
        await self._emit(payload)

    async def _on_closed(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        ticket = payload.get("ticket")
        if ticket is None:
            return
        key = str(ticket)
        entry = self._open.get(key)
        if entry is None:
            return

        closed_size = _to_float(payload.get("size"))
        if payload.get("partial") and closed_size is not None and entry["size"]:
            remaining = round(entry["size"] - abs(closed_size), 8)
            if remaining > 0:
                entry["size"] = remaining
                await self._emit(payload)
                return
        self._open.pop(key, None)
        self.closed_count += 1
        await self._emit(payload)

    def state(self) -> dict[str, Any]:
        """Open positions, and the drift per account beside the total.

        Summing two accounts hides a surplus in one under a shortfall in the
        other — and that surplus is precisely the orphan position being
        looked for.
        """
        by_symbol: dict[str, int] = {}
        exposure_lots = 0.0
        by_account: dict[str, int] = {}
        for entry in self._open.values():
            symbol = str(entry.get("symbol"))
            by_symbol[symbol] = by_symbol.get(symbol, 0) + 1
            account_id = entry.get("account_id")
            if account_id is not None:
                key = str(account_id)
                by_account[key] = by_account.get(key, 0) + 1
            if entry.get("size"):
                exposure_lots += abs(entry["size"])

        drift_by_account: dict[str, int] = {}
        for account_id, broker_count in self._broker_counts.items():
            drift_by_account[account_id] = broker_count - by_account.get(account_id, 0)
        total_broker = sum(self._broker_counts.values()) if self._broker_counts else None
        drift = (total_broker - len(self._open)) if total_broker is not None else None
        return {
            "open_count": len(self._open), "by_symbol": by_symbol,
            "by_account": by_account, "total_lots": round(exposure_lots, 8),
            "broker_open_count": total_broker, "drift": drift,
            "drift_by_account": drift_by_account,
            "positions": [dict(v) for v in self._open.values()],
        }

    async def _emit(self, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self.state()
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = self.state()
        details["opened_total"] = self.opened_count
        details["closed_total"] = self.closed_count
        if self.opened_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRADES, details=details)
        if details["drift"]:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="drift %d against the platform" % details["drift"],
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="open=%d" % len(self._open), details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "open": dict(self._open),
                "opened": self.opened_count, "closed": self.closed_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._open = dict(state.get("open") or {})
        self.opened_count = int(state.get("opened", 0))
        self.closed_count = int(state.get("closed", 0))
