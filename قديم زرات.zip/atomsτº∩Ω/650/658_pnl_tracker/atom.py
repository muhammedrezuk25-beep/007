from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUTCOME = "market.outcome.realized"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "portfolio.pnl_updated"

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRADES = "NO_CLOSED_TRADES_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._reserve_symbols = 0
        self._books: dict[str, dict[str, Any]] = {}
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._reserve_symbols = int(context.config["tracked_symbols_memory"])
        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("658 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("658 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("658 stopped (accounts=%d)", len(self._books))

    async def shutdown(self) -> None:
        await self.stop()

    def _book(self, account_id: str) -> dict[str, Any]:
        """One book per account.

        Summing two accounts gives a figure belonging to neither, and a risk
        decision is taken on it with real money.
        """
        return self._books.setdefault(account_id, {
            "realised": 0.0, "daily": 0.0, "wins": 0, "losses": 0,
            "breakeven": 0, "gross_profit": 0.0, "gross_loss": 0.0,
            "equity": None, "per_symbol": {}})

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.dropped_count += 1
            return
        equity = _to_float(payload.get("equity"))
        if equity is not None and equity > 0:
            self._book(str(account_id))["equity"] = equity

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.dropped_count += 1
            return
        account_id = str(account_id)
        pnl = _to_float(payload.get("pnl"))
        if pnl is None:
            return

        book = self._book(account_id)
        book["realised"] = round(book["realised"] + pnl, 6)
        book["daily"] = round(book["daily"] + pnl, 6)
        if pnl > 0:
            book["gross_profit"] = round(book["gross_profit"] + pnl, 6)
        elif pnl < 0:
            book["gross_loss"] = round(book["gross_loss"] + abs(pnl), 6)

        result = str(payload.get("result", "")).upper()
        if result == RESULT_WIN:
            book["wins"] += 1
        elif result == RESULT_LOSS:
            book["losses"] += 1
        else:
            book["breakeven"] += 1

        symbol = payload.get("symbol")
        if symbol:
            key = str(symbol)
            per = book["per_symbol"]
            per[key] = round(per.get(key, 0.0) + pnl, 6)
            while len(per) > self._reserve_symbols:
                per.pop(next(iter(per)))

        body = self.state(account_id)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for book in self._books.values():
            book["daily"] = 0.0

    def state(self, account_id: str) -> dict[str, Any]:
        book = self._book(account_id)
        closed = book["wins"] + book["losses"] + book["breakeven"]
        factor = None
        if book["gross_loss"]:
            factor = round(book["gross_profit"] / book["gross_loss"], 6)
        equity = book["equity"]
        return {
            "account_id": account_id,
            "realised_pnl": book["realised"], "daily_pnl": book["daily"],
            "gross_profit": book["gross_profit"],
            "gross_loss": book["gross_loss"],
            "profit_factor": factor, "wins": book["wins"],
            "losses": book["losses"], "breakeven": book["breakeven"],
            "closed_trades": closed,
            "win_rate": round(book["wins"] / closed, 6) if closed else None,
            "equity": equity,
            "realised_pct": (round(book["realised"] / equity * 100.0, 6)
                             if equity else None),
            "per_symbol": dict(book["per_symbol"]),
        }

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        closed = sum(b["wins"] + b["losses"] + b["breakeven"]
                     for b in self._books.values())
        realised = round(sum(b["realised"] for b in self._books.values()), 6)
        details = {"accounts": len(self._books), "closed_trades": closed,
                   "realised_total": realised, "dropped": self.dropped_count,
                   "books": {k: self.state(k) for k in self._books}}
        if closed == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRADES, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="accounts=%d realised=%.2f" % (
                                len(self._books), realised),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "books": {k: dict(v) for k, v in self._books.items()},
                "dropped": self.dropped_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._books = {k: dict(v) for k, v in (state.get("books") or {}).items()}
        for book in self._books.values():
            book["per_symbol"] = dict(book.get("per_symbol") or {})
        self.dropped_count = int(state.get("dropped", 0))
