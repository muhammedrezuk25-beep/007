from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom658"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 658

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 658


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert True


async def _close(ctx, pnl, result="WIN", symbol="NQ"):
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "symbol": symbol, "pnl": pnl,
                                               "result": result, "timestamp": TS})


@pytest.mark.asyncio
async def test_realised_accumulates_across_trades():
    atom, ctx = await _ready()
    await _close(ctx, 100.0)
    await _close(ctx, -40.0, "LOSS")
    assert out(ctx, MODULE.EVENT_OUT)[-1]["realised_pnl"] == 60.0


@pytest.mark.asyncio
async def test_profit_factor_is_gross_profit_over_gross_loss():
    atom, ctx = await _ready()
    await _close(ctx, 300.0)
    await _close(ctx, -100.0, "LOSS")
    assert out(ctx, MODULE.EVENT_OUT)[-1]["profit_factor"] == 3.0


@pytest.mark.asyncio
async def test_no_losses_means_no_profit_factor_not_infinity():
    atom, ctx = await _ready()
    await _close(ctx, 100.0)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["profit_factor"] is None


@pytest.mark.asyncio
async def test_pnl_is_split_per_symbol():
    atom, ctx = await _ready()
    await _close(ctx, 100.0, symbol="NQ")
    await _close(ctx, -30.0, "LOSS", symbol="XAU")
    per = out(ctx, MODULE.EVENT_OUT)[-1]["per_symbol"]
    assert per["NQ"] == 100.0 and per["XAU"] == -30.0


@pytest.mark.asyncio
async def test_the_percentage_needs_an_equity_reference():
    """Without a balance from 619 the percentage is absent, not zero: a risk
    figure computed against an assumed reference is worse than none."""
    atom, ctx = await _ready()
    await _close(ctx, 100.0)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["realised_pct"] is None

    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "equity": 10000.0})
    await _close(ctx, 100.0)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["realised_pct"] == 2.0


@pytest.mark.asyncio
async def test_day_roll_clears_only_the_daily_figure():
    atom, ctx = await _ready()
    await _close(ctx, 100.0)
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    await _close(ctx, 50.0)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["daily_pnl"] == 50.0
    assert last["realised_pnl"] == 150.0


@pytest.mark.asyncio
async def test_an_outcome_without_pnl_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "symbol": "NQ", "result": "WIN"})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_win_rate_counts_breakeven_as_neither():
    atom, ctx = await _ready()
    await _close(ctx, 10.0, "WIN")
    await _close(ctx, 0.0, "BREAKEVEN")
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["breakeven"] == 1
    assert last["closed_trades"] == 2


# ── فصل الحسابات ────────────────────────────────────────────────────

def test_the_output_carries_the_account():
    """ربحُ من؟ ومراكزُ أي حساب؟ الرقم المجموع من حسابين لا يخصّ
    أيًّا منهما، ويُبنى عليه قرار مخاطرة بمال حقيقي."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "account_id" in src
