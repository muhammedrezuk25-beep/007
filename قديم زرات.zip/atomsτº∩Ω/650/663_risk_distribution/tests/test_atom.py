from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom663"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 663

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 663


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert True


_SAMPLE = {"daily_loss_pct": 1.5, "daily_trade_count": 3,
           "open_trade_count": 2, "kill_switch_state": False}


@pytest.mark.asyncio
async def test_it_mirrors_the_source_and_adds_nothing():
    """Display only: every field it emits came from the source event. It never
    computes, filters or enforces."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({**_SAMPLE, "timestamp": TS})
    view = out(ctx, MODULE.EVENT_OUT)[0]
    for key, value in view.items():
        if key == "timestamp":
            continue
        assert _SAMPLE[key] == value


@pytest.mark.asyncio
async def test_an_unrelated_payload_publishes_nothing():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"unrelated": 1})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({**_SAMPLE, "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_OUT)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_healthy_after_the_first_view():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({**_SAMPLE, "timestamp": TS})
    assert (await atom.health_check()).state.name == "HEALTHY"
