from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "portfolio.summary"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRAFFIC = "NO_PORTFOLIO_TRAFFIC"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._watch: list[str] = []
        self._accounts: dict[str, dict[str, dict[str, Any]]] = {}
        self._shared: dict[str, dict[str, Any]] = {}
        self._counts: dict[str, int] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._watch = [str(e) for e in context.config["watch_events"]]
        for event in self._watch:
            context.subscribe(event, self._make_collector(event))
        self._initialized = True
        context.logger.info("650 initialised watching %d events", len(self._watch))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("650 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("650 stopped (published=%d)", self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _make_collector(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._collect(event_name, payload)
        return handler

    async def _collect(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        self._counts[event_name] = self._counts.get(event_name, 0) + 1
        self.published_count += 1

        account_id = inner.get("account_id")
        if account_id in (None, ""):
            self._shared[event_name] = dict(inner)
        else:
            book = self._accounts.setdefault(str(account_id), {})
            book[event_name] = dict(inner)

        body: dict[str, Any] = {
            "latest": event_name,
            "accounts": {k: {e: dict(v) for e, v in book.items()}
                         for k, book in self._accounts.items()},
            "shared": {k: dict(v) for k, v in self._shared.items()},
            "account_count": len(self._accounts),
            "counts": dict(self._counts),
        }
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        seen = set(self._shared)
        for book in self._accounts.values():
            seen.update(book)
        silent = [e for e in self._watch if e not in seen]
        details = {"watching": len(self._watch), "seen": len(seen),
                   "accounts": len(self._accounts),
                   "silent": silent, "counts": dict(self._counts)}
        if not seen:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRAFFIC, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="seen %d/%d · accounts=%d" % (len(seen), len(self._watch),
                                                  len(self._accounts)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "accounts": {k: {e: dict(v) for e, v in b.items()}
                             for k, b in self._accounts.items()},
                "shared": {k: dict(v) for k, v in self._shared.items()},
                "counts": dict(self._counts), "published": self.published_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._accounts = {k: {e: dict(v) for e, v in b.items()}
                          for k, b in (state.get("accounts") or {}).items()}
        self._shared = {k: dict(v) for k, v in (state.get("shared") or {}).items()}
        self._counts = {str(k): int(v) for k, v in (state.get("counts") or {}).items()}
        self.published_count = int(state.get("published", 0))
