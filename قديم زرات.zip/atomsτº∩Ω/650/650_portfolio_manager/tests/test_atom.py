from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom650"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 650

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 650


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert True


@pytest.mark.asyncio
async def test_it_keeps_the_latest_state_of_each_section():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 100.0, "timestamp": TS})
    await ctx.handlers["portfolio.open_trades_tracked"]({"open_count": 2, "timestamp": TS})
    summary = out(ctx, MODULE.EVENT_OUT)[-1]
    assert set(summary["shared"]) == {"portfolio.pnl_updated",
                                        "portfolio.open_trades_tracked"}
    assert summary["latest"] == "portfolio.open_trades_tracked"


@pytest.mark.asyncio
async def test_a_repeated_section_overwrites_rather_than_accumulates():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 100.0})
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 250.0})
    summary = out(ctx, MODULE.EVENT_OUT)[-1]
    assert summary["shared"]["portfolio.pnl_updated"]["realised_pnl"] == 250.0
    assert summary["counts"]["portfolio.pnl_updated"] == 2


@pytest.mark.asyncio
async def test_it_publishes_nothing_of_its_own():
    """A collector republishes; it never computes. Every field it emits came
    from a section event it received."""
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 100.0})
    assert {n for n, _ in ctx.published} == {MODULE.EVENT_OUT}


@pytest.mark.asyncio
async def test_health_names_the_silent_sections():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 1.0})
    details = (await atom.health_check()).details
    assert "portfolio.open_trades_tracked" in details["silent"]
    assert details["seen"] == 1


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 1.0, "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_OUT)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_snapshot_carries_the_books():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.pnl_updated"]({"realised_pnl": 100.0})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._shared["portfolio.pnl_updated"]["realised_pnl"] == 100.0


# ── الصورة الموحّدة لكل حساب ────────────────────────────────────────

def test_it_watches_the_snapshot_too():
    """صورة الحسابات مصدرها 651، وبلا سماعها لا يعرف الجامع كم حسابًا
    يوجد أصلًا — يعرف الأخير الذي تحرّك وحده."""
    assert "portfolio.accounts_snapshot" in MANIFEST["subscribes"]


@pytest.mark.asyncio
async def test_two_accounts_are_kept_apart_in_the_summary():
    """جمعُ حسابين في صورة واحدة يعطي أرقامًا لا تخصّ أيًّا منهما."""
    atom, ctx = await _ready()
    for acc, eq in (("A", 10000.0), ("B", 50000.0)):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": eq, "balance": eq, "timestamp": TS})
    summary = out(ctx, MODULE.EVENT_OUT)[-1]
    assert "accounts" in summary
    assert set(summary["accounts"]) == {"A", "B"}
    assert summary["accounts"]["A"]["portfolio.account_tracked"]["equity"] == 10000.0
    assert summary["accounts"]["B"]["portfolio.account_tracked"]["equity"] == 50000.0


@pytest.mark.asyncio
async def test_a_section_without_an_account_stays_shared():
    """حدود المخاطر ونصيب رأس المال تصل من قسم المخاطر بلا هوية حساب
    اليوم. فتُحفَظ مشتركةً بدل أن تُنسَب لحساب لم يُذكَر."""
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.risk_distribution_displayed"]({
        "daily_loss_pct": 0.42, "timestamp": TS})
    summary = out(ctx, MODULE.EVENT_OUT)[-1]
    assert "shared" in summary
    assert "portfolio.risk_distribution_displayed" in summary["shared"]
