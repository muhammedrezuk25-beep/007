from __future__ import annotations

import ast
import asyncio
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom651"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 651

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 651


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert True


@pytest.mark.asyncio
async def test_a_healthy_margin_level_is_not_flagged():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 10000.0, "margin": 500.0,
                                          "margin_level": 2000.0, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_TRACKED)[0]["status"] == MODULE.STATUS_HEALTHY


@pytest.mark.asyncio
async def test_a_tightening_account_is_visible_before_the_call():
    """A margin call is too late to be useful. The tight band gives the
    platform a chance to see the account narrowing while it still can act."""
    atom, ctx = await _ready(tight_margin_level_pct=200.0, margin_call_level_pct=100.0)
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1000.0, "margin": 600.0,
                                          "margin_level": 150.0, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_TRACKED)[0]["status"] == MODULE.STATUS_TIGHT


@pytest.mark.asyncio
async def test_a_margin_call_level_is_flagged():
    atom, ctx = await _ready(margin_call_level_pct=100.0)
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 500.0, "margin": 600.0,
                                          "margin_level": 80.0, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_TRACKED)[0]["status"] == MODULE.STATUS_CALL


@pytest.mark.asyncio
async def test_no_open_margin_means_no_alarm():
    """With nothing open the margin level is meaningless, and a broker may
    report zero or an enormous number. Neither is a warning."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 10000.0, "margin": 0.0,
                                          "margin_level": 0.0, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_TRACKED)[0]["status"] == MODULE.STATUS_HEALTHY






@pytest.mark.asyncio
async def test_a_snapshot_without_equity_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "balance": 100.0})
    assert out(ctx, MODULE.EVENT_TRACKED) == []


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 100.0, "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_TRACKED)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_one_payload_carries_every_figure():
    """الحقول تسافر معًا في حمولة واحدة، وستّ ذرّات تأخذ كلٌّ حقلها.

    كان 651 ينشرها ستًّا بنفسه: الفَنْوَنة في القارئ، ولا مالك لأي حقل —
    فمن أراد مستوى الهامش قرأه من الجسر وربط نفسه بمنصّة بعينها."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", 
        "balance": 1000.0, "equity": 1020.0, "margin": 50.0,
        "free_margin": 970.0, "margin_level": 2040.0, "timestamp": TS})
    tracked = out(ctx, MODULE.EVENT_TRACKED)
    assert len(tracked) == 1
    for field in ("balance", "equity", "margin", "free_margin",
                  "margin_level", "status"):
        assert field in tracked[0]


@pytest.mark.asyncio
async def test_the_reader_publishes_one_event_only():
    """مخرَج واحد: توزيع الحقول شغل من يملك كل حقل، لا شغل القارئ."""
    # مخرَجان: تغيّر حساب، وصورة كل الحسابات — والثانية لمن يقلع متأخّرًا.
    assert MANIFEST["publishes"] == [MODULE.EVENT_TRACKED, MODULE.EVENT_SNAPSHOT]
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    assert {name for name, _ in ctx.published} == {
        MODULE.EVENT_TRACKED, MODULE.EVENT_SNAPSHOT}


@pytest.mark.asyncio
async def test_a_missing_figure_travels_as_none_not_zero():
    """الفرق بين «صفر» و«لم يصل» هو الفرق بين معلومة وغيابها."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"account_id": "A", "equity": 1020.0, "timestamp": TS})
    tracked = out(ctx, MODULE.EVENT_TRACKED)[0]
    assert tracked["margin"] is None
    assert tracked["balance"] is None


# ── تعدّد الحسابات ──────────────────────────────────────────────────

def test_the_manifest_declares_a_snapshot_and_a_silence_timeout():
    """صورة كاملة بجانب حدث التغيّر: خمس عشرة ذرّة تنتظر account_tracked،
    فذرّة تُعاد تشغيلها تبقى عمياء حتى يتغيّر حساب — وقد لا يتغيّر
    لدقائق في سوق هادئة، والنظام يتداول خلالها بلا أن يعرف حقوقه."""
    assert "portfolio.accounts_snapshot" in MANIFEST["publishes"]
    assert "silence_timeout_s" in CONFIG
    assert "snapshot_interval_s" in CONFIG


@pytest.mark.asyncio
async def test_two_accounts_are_tracked_apart():
    """حالة لكل حساب لا حالة واحدة. والخلط يعطي حقوقًا لا تخصّ أحدهما،
    ويُحسب عليها حجمُ مركزٍ بمال حقيقي."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "A", "equity": 10000.0, "balance": 10000.0,
        "margin": 100.0, "margin_level": 10000.0, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "B", "equity": 50000.0, "balance": 50000.0,
        "margin": 500.0, "margin_level": 10000.0, "timestamp": TS})
    tracked = out(ctx, MODULE.EVENT_TRACKED)
    assert len(tracked) == 2
    by = {t["account_id"]: t for t in tracked}
    assert by["A"]["equity"] == 10000.0
    assert by["B"]["equity"] == 50000.0


@pytest.mark.asyncio
async def test_a_row_without_an_account_id_is_refused():
    """Fail Closed — والقاعدة نفسها في 619."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"equity": 10000.0, "timestamp": TS})
    assert not out(ctx, MODULE.EVENT_TRACKED)
    assert atom.no_identity_count == 1


@pytest.mark.asyncio
async def test_the_snapshot_carries_every_account():
    atom, ctx = await _ready()
    for acc, eq in (("A", 10000.0), ("B", 50000.0)):
        await ctx.handlers[MODULE.EVENT_IN]({
            "account_id": acc, "equity": eq, "margin": 0.0, "timestamp": TS})
    snaps = out(ctx, MODULE.EVENT_SNAPSHOT)
    assert snaps
    accounts = {a["account_id"] for a in snaps[-1]["accounts"]}
    assert accounts == {"A", "B"}


@pytest.mark.asyncio
async def test_a_silent_account_goes_stale_and_is_not_active():
    """صمت المصدر لا يعني أن الحساب اختفى: مراكزه ما زالت في السوق.
    فيُعلَّم ولا يُمحى."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "A", "equity": 10000.0, "margin": 0.0, "timestamp": TS})
    await atom.sweep(TS + 999.0)
    snap = out(ctx, MODULE.EVENT_SNAPSHOT)[-1]
    entry = [a for a in snap["accounts"] if a["account_id"] == "A"][0]
    assert entry["status"] == MODULE.STATUS_STALE
    assert entry["active"] is False
    assert "equity" in entry


@pytest.mark.asyncio
async def test_a_returning_account_becomes_active_again():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "A", "equity": 10000.0, "margin": 0.0, "timestamp": TS})
    await atom.sweep(TS + 999.0)
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "A", "equity": 10500.0, "margin": 0.0,
        "timestamp": TS + 1000.0})
    snap = out(ctx, MODULE.EVENT_SNAPSHOT)[-1]
    entry = [a for a in snap["accounts"] if a["account_id"] == "A"][0]
    assert entry["active"] is True
    assert entry["equity"] == 10500.0


@pytest.mark.asyncio
async def test_the_sweep_runs_on_its_own():
    """sweep بُنيت ولم تُنادَ من أي مكان: حساب صمت مصدره يبقى «نشطًا»
    إلى الأبد، و413 يفنّي عليه إشارات تُبنى على حقوق لا يُعرف أصحّت.

    والصورة تُنشر دوريًّا أيضًا: من يقلع متأخّرًا لا ينتظر تغيّر حساب."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert src.count("sweep") >= 2, "معرَّفة ولا تُنادى"
    assert "_sweep_task" in src


@pytest.mark.asyncio
async def test_a_silent_account_goes_stale_without_being_told():
    # الصمت يُقاس بأحدث طابع رآه لا بساعة الجهاز: حساب B يتقدّم بالزمن
    # فيظهر صمت A — وهذا ما يقع فعلًا حين يستمرّ مصدر ويتوقّف آخر.
    atom, ctx = await _ready(silence_timeout_s=10.0, snapshot_interval_s=0.05)
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "A", "equity": 10000.0, "margin": 0.0, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_IN]({
        "account_id": "B", "equity": 20000.0, "margin": 0.0,
        "timestamp": TS + 60.0})
    await atom.start()
    try:
        await asyncio.sleep(0.2)
    finally:
        await atom.stop()
    assert atom._accounts["A"]["active"] is False
    assert atom._accounts["B"]["active"] is True
