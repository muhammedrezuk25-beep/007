from __future__ import annotations

import asyncio
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "platform.account.state"
EVENT_TRACKED = "portfolio.account_tracked"
EVENT_SNAPSHOT = "portfolio.accounts_snapshot"

STATUS_HEALTHY = "HEALTHY"
STATUS_STALE = "STALE"
STATUS_TIGHT = "TIGHT_MARGIN"
STATUS_CALL = "MARGIN_CALL"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._tight_level_pct = 0.0
        self._call_level_pct = 0.0
        self._accounts: dict[str, dict[str, Any]] = {}
        self._silence_timeout_s = 0.0
        self._snapshot_interval_s = 0.0
        self._last_snapshot_at = 0.0
        self._sweep_task: asyncio.Task | None = None
        self._latest_stamp = 0.0
        self.updates_published = 0
        self.snapshots_published = 0
        self.no_identity_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._tight_level_pct = float(cfg["tight_margin_level_pct"])
        self._call_level_pct = float(cfg["margin_call_level_pct"])
        self._silence_timeout_s = float(cfg["silence_timeout_s"])
        self._snapshot_interval_s = float(cfg["snapshot_interval_s"])
        context.subscribe(EVENT_IN, self._on_account)
        self._initialized = True
        context.logger.info("651 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._sweep_task = asyncio.create_task(self._sweep_loop())
        self._context.logger.info("651 started")

    async def _sweep_loop(self) -> None:
        """Marks the quiet ones, and republishes the picture on a beat.

        sweep was built and never called from anywhere: an account whose
        source went silent stayed "active" forever, and 413 kept fanning
        signals out to it — built on an equity nobody could say was still
        true.

        The snapshot goes out on the same beat whether anything moved or
        not, so an atom that boots late does not wait for some account to
        happen to change before it learns what exists.

        Silence is measured against the newest stamp this atom has seen, not
        against a wall clock: 3 and 806 own the clock, and a reading taken
        here would judge staleness by a different time than the one stamped
        on the data.
        """
        loop = asyncio.get_running_loop()
        try:
            while self._running:
                await asyncio.sleep(self._snapshot_interval_s)
                if not self._running:
                    return
                await self.sweep(self._latest_stamp)
                if self._accounts:
                    await self._publish_snapshot({})
        except asyncio.CancelledError:
            return

    async def stop(self) -> None:
        self._running = False
        if self._sweep_task is not None and not self._sweep_task.done():
            self._sweep_task.cancel()
            try:
                await self._sweep_task
            except asyncio.CancelledError:
                pass
        self._sweep_task = None
        if self._context is not None:
            self._context.logger.info("651 stopped (updates=%d)", self.updates_published)

    async def shutdown(self) -> None:
        await self.stop()

    def classify(self, margin_level: float | None, margin: float | None) -> str:
        """Margin health from the level, and the classification travels with
        the payload rather than being recomputed downstream.

        This atom owns both thresholds in its config; reclassifying in 652
        would give two answers to one question, and they would drift the
        first time one config changed.
        """
        if not margin:
            return STATUS_HEALTHY
        if margin_level is None:
            return STATUS_HEALTHY
        if margin_level <= self._call_level_pct:
            return STATUS_CALL
        if margin_level <= self._tight_level_pct:
            return STATUS_TIGHT
        return STATUS_HEALTHY

    async def _on_account(self, payload: dict[str, Any]) -> None:
        """One state per account, never one state for all of them.

        A single state overwritten by whichever account reported last gives
        an equity belonging to neither, and a position is sized from it with
        real money.

        A row with no account_id is refused rather than attributed to a
        default: that would size from one account's equity and send the order
        to another, with no fault visible anywhere.
        """
        if not self._running or self._context is None:
            return

        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            self._context.logger.warning("651 refuses a row with no account_id")
            return
        account_id = str(account_id)

        balance = _to_float(payload.get("balance"))
        equity = _to_float(payload.get("equity"))
        margin = _to_float(payload.get("margin"))
        free_margin = _to_float(payload.get("free_margin"))
        margin_level = _to_float(payload.get("margin_level"))
        if equity is None:
            return

        stamp = payload.get("timestamp")
        stamped: dict[str, Any] = {}
        if isinstance(stamp, (int, float)):
            stamped["timestamp"] = stamp

        state = {"account_id": account_id,
                 "broker": payload.get("broker"),
                 "server": payload.get("server"),
                 "balance": balance, "equity": equity, "margin": margin,
                 "free_margin": free_margin, "margin_level": margin_level,
                 "currency": payload.get("currency"),
                 "leverage": payload.get("leverage"),
                 "open_count": payload.get("open_count")}
        state["status"] = self.classify(margin_level, margin)
        state["active"] = True
        state["last_seen"] = stamp if isinstance(stamp, (int, float)) else None
        if isinstance(stamp, (int, float)) and stamp > self._latest_stamp:
            self._latest_stamp = stamp
        self._accounts[account_id] = state
        self.updates_published += 1

        await self._context.publish(EVENT_TRACKED, {**state, **stamped})
        await self._publish_snapshot(stamped)

    async def sweep(self, now: float) -> list[str]:
        """Marks the quiet ones and publishes the picture that changed."""
        gone = self.mark_stale(now)
        if gone:
            await self._publish_snapshot({})
        return gone

    def mark_stale(self, now: float) -> list[str]:
        """Marks accounts whose source has gone quiet, and keeps them.

        Silence is not disappearance: the positions are still in the market,
        and dropping the account loses what is known about them. The entry
        stays with everything it held, flagged inactive, and a returning
        source restores it.
        """
        gone = []
        for account_id, state in self._accounts.items():
            last = state.get("last_seen")
            if last is None:
                continue
            if now - float(last) > self._silence_timeout_s and state.get("active"):
                state["active"] = False
                state["status"] = STATUS_STALE
                gone.append(account_id)
        return gone

    async def _publish_snapshot(self, stamped: dict[str, Any]) -> None:
        """The full picture, beside the change event.

        Fifteen atoms wait on the change event. One restarted, or booting
        late, stays blind until an account happens to move — and in a quiet
        market that is minutes of trading without knowing the equity.

        The change event stays: whoever needs to know *what moved* will not
        find it in a picture.
        """
        if self._context is None:
            return
        self.snapshots_published += 1
        await self._context.publish(EVENT_SNAPSHOT, {
            "accounts": [dict(s) for s in self._accounts.values()],
            "active_count": sum(1 for s in self._accounts.values() if s.get("active")),
            "total_count": len(self._accounts),
            **stamped,
        })



    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        active = sum(1 for s in self._accounts.values() if s.get("active"))
        details = {"updates": self.updates_published,
                   "snapshots": self.snapshots_published,
                   "accounts": len(self._accounts), "active": active,
                   "no_identity": self.no_identity_count}
        if not self._accounts:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACCOUNT, details=details)
        if not active:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=STATUS_STALE, details=details)
        unhealthy = [s["account_id"] for s in self._accounts.values()
                     if s.get("active") and s.get("status") != STATUS_HEALTHY]
        if unhealthy:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="margin: %s" % ",".join(unhealthy),
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="accounts=%d" % active, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "accounts": {k: dict(v) for k, v in self._accounts.items()},
                "updates": self.updates_published,
                "snapshots": self.snapshots_published,
                "no_identity": self.no_identity_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._accounts = {k: dict(v)
                          for k, v in (state.get("accounts") or {}).items()}
        self.updates_published = int(state.get("updates", 0))
        self.snapshots_published = int(state.get("snapshots", 0))
        self.no_identity_count = int(state.get("no_identity", 0))
