from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "market_data.news_received"
EVENT_WINDOW = "market_data.calendar_window"
EVENT_OUT = "strategy.news.signal"

SIGNAL_BUY = "BUY"
SIGNAL_SELL = "SELL"

IMPACT_HIGH = "HIGH"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_NEWS = "NO_NEWS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._min_abs_sentiment = 0.0
        self._full_strength_sentiment = 0.0
        self._require_high_impact = False
        self._mute_in_event_window = True
        self._in_event_window = False
        self._received = 0
        self._skipped_neutral = 0
        self._skipped_window = 0
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._min_abs_sentiment = float(cfg["min_abs_sentiment"])
        self._full_strength_sentiment = float(cfg["full_strength_sentiment"])
        self._require_high_impact = bool(cfg["require_high_impact"])
        self._mute_in_event_window = bool(cfg["mute_in_event_window"])
        context.subscribe(EVENT_IN, self._on_news)
        context.subscribe(EVENT_WINDOW, self._on_window)
        self._initialized = True
        context.logger.info("411 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("411 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "411 stopped (signals=%d)", self.signals_published)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_window(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        active = payload.get("locked", payload.get("active"))
        if isinstance(active, bool):
            self._in_event_window = active

    async def _on_news(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        headline = inner.get("headline")
        if not headline:
            return
        self._received += 1

        if self._mute_in_event_window and self._in_event_window:
            self._skipped_window += 1
            return

        score = _to_float(inner.get("sentiment_score"))
        if score is None or abs(score) < self._min_abs_sentiment:
            self._skipped_neutral += 1
            return

        impact = str(inner.get("impact_level") or "").upper()
        if self._require_high_impact and impact != IMPACT_HIGH:
            self._skipped_neutral += 1
            return

        direction = SIGNAL_BUY if score > 0 else SIGNAL_SELL
        strength = 1.0
        if self._full_strength_sentiment > 0:
            strength = min(abs(score) / self._full_strength_sentiment, 1.0)

        body: dict[str, Any] = {
            "symbol": inner.get("symbol"),
            "direction": direction,
            "signal": direction,
            "strength": round(strength, 6),
            "sentiment_score": score,
            "impact_level": impact or "UNKNOWN",
            "headline": headline,
        }
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp

        self.signals_published += 1
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"received": self._received, "signals": self.signals_published,
                   "skipped_neutral": self._skipped_neutral,
                   "skipped_in_event_window": self._skipped_window,
                   "in_event_window": self._in_event_window}
        if self._received == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_NEWS, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="received=%d signals=%d" % (self._received, self.signals_published),
            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "received": self._received,
                "signals": self.signals_published,
                "skipped_neutral": self._skipped_neutral,
                "skipped_window": self._skipped_window}

    async def restore(self, state: dict[str, Any]) -> None:
        self._received = int(state.get("received", 0))
        self.signals_published = int(state.get("signals", 0))
        self._skipped_neutral = int(state.get("skipped_neutral", 0))
        self._skipped_window = int(state.get("skipped_window", 0))
