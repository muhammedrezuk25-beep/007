from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom411"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 411

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 411


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


async def _news(ctx, score=0.8, impact="UNKNOWN", headline="Some headline", at=TS):
    await ctx.handlers[MODULE.EVENT_IN]({
        "headline": headline, "sentiment_score": score,
        "impact_level": impact, "symbol": "NQ", "timestamp": at})


@pytest.mark.asyncio
async def test_a_positive_headline_votes_buy():
    atom, ctx = await _ready()
    await _news(ctx, score=0.8)
    signal = out(ctx, MODULE.EVENT_OUT)[0]
    assert signal["direction"] == MODULE.SIGNAL_BUY
    assert signal["strength"] == 0.8


@pytest.mark.asyncio
async def test_a_negative_headline_votes_sell():
    atom, ctx = await _ready()
    await _news(ctx, score=-0.6)
    signal = out(ctx, MODULE.EVENT_OUT)[0]
    assert signal["direction"] == MODULE.SIGNAL_SELL
    assert signal["strength"] == 0.6


@pytest.mark.asyncio
async def test_a_headline_with_no_measured_sentiment_is_skipped():
    """The bot returns None when no keyword matched at all. Zero would mean
    measured and neutral; None means not measured, and voting on it would be
    inventing a direction."""
    atom, ctx = await _ready()
    await _news(ctx, score=None)
    assert out(ctx, MODULE.EVENT_OUT) == []
    assert atom._skipped_neutral == 1


@pytest.mark.asyncio
async def test_a_weak_score_is_below_the_threshold():
    atom, ctx = await _ready(min_abs_sentiment=0.5)
    await _news(ctx, score=0.2)
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_strength_is_capped_at_one():
    atom, ctx = await _ready(full_strength_sentiment=0.5)
    await _news(ctx, score=1.0)
    assert out(ctx, MODULE.EVENT_OUT)[0]["strength"] == 1.0


@pytest.mark.asyncio
async def test_it_goes_quiet_inside_a_calendar_event_window():
    """A headline published seconds before a rate decision says nothing about
    what follows it, and 463 blocks trading in that window anyway."""
    atom, ctx = await _ready(mute_in_event_window=True)
    await ctx.handlers[MODULE.EVENT_WINDOW]({"locked": True, "timestamp": TS})
    await _news(ctx, score=0.9)
    assert out(ctx, MODULE.EVENT_OUT) == []
    assert atom._skipped_window == 1


@pytest.mark.asyncio
async def test_it_speaks_again_when_the_window_closes():
    atom, ctx = await _ready(mute_in_event_window=True)
    await ctx.handlers[MODULE.EVENT_WINDOW]({"locked": True})
    await _news(ctx, score=0.9)
    await ctx.handlers[MODULE.EVENT_WINDOW]({"locked": False})
    await _news(ctx, score=0.9)
    assert len(out(ctx, MODULE.EVENT_OUT)) == 1


@pytest.mark.asyncio
async def test_high_impact_can_be_required():
    atom, ctx = await _ready(require_high_impact=True)
    await _news(ctx, score=0.9, impact="UNKNOWN")
    assert out(ctx, MODULE.EVENT_OUT) == []
    await _news(ctx, score=0.9, impact="HIGH")
    assert len(out(ctx, MODULE.EVENT_OUT)) == 1


@pytest.mark.asyncio
async def test_a_headline_without_text_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"sentiment_score": 0.9})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await _news(ctx, score=0.8, at=55.0)
    assert out(ctx, MODULE.EVENT_OUT)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_nothing_runs_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await _news(ctx, score=0.9)
    assert atom.signals_published == 0


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _news(ctx, score=0.8)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.signals_published == 1
