"""
412 — استراتيجية الجلسات (Session Strategy)

يشترك: analysis.session_context (158 — معتمَدة فعليًا). ينشر:
strategy.session.signal.

منطق مُستنتَج: لندن ونيويورك (نشاط أعلى، سيولة أكبر) → readiness
"active" (جاهزية تداول). آسيوية (نشاط أقل نسبيًا) → readiness
"cautious" (لا منع، بس سياق تحذيري — قرار التداول الفعلي يبقى
لاستراتيجيات أخرى، هذه سياقية بحتة).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_READINESS_MAP = {"london": "active", "new_york": "active", "asian": "cautious"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("analysis.session_context", self._on_session)
        context.logger.info("SessionStrategy(412) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SessionStrategy(412) بدأ الاستماع لـ158")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_session(self, payload: dict) -> None:
        if self._context is None:
            return
        readiness = _READINESS_MAP.get(payload["session"], "cautious")

        self.signals_published += 1
        await self._context.publish(
            "strategy.session.signal",
            # سياقية: الجاهزية ليست اتجاهًا، فلا تدخل ترجيح 458. وإعطاؤها
            # strength رقميًا يوحي بوزن في مقارنة لا تشارك فيها أصلًا.
            {"symbol": payload.get("symbol"), "direction": readiness,
             "session": payload["session"], "readiness": readiness, **_ts_from(payload)}
        )
