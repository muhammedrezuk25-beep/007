"""
413 — دمج الإشارات (Signal Merger)

يشترك: مخرجات 404-412 (الاستراتيجيات كلها). ينشر:
strategy.signals_merged.

٤١١ (استراتيجية الأخبار) غير مبنية بعد (تعتمد على ١٠٨ غير مبنية)
— الاشتراك بحدثها مسجَّل مسبقًا (Event Bus لا يتطلب ناشرًا فعليًا)،
لن تصل بيانات فعلية منها لحد بنائها.

آلية: نفس نمط تجميع 101/166/210/357 (جامع، قاعدة 1) — يحتفظ بآخر
إشارة معروفة من كل استراتيجية لكل رمز، ينشر لقطة موحَّدة عند أي تحديث.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SOURCE_EVENTS = {
    "strategy.trend.signal": "trend",
    "strategy.reversal.signal": "reversal",
    "strategy.breakout.signal": "breakout",
    "strategy.pullback.signal": "pullback",
    "strategy.momentum.signal": "momentum",
    "strategy.range.signal": "range",
    "strategy.liquidity.signal": "liquidity",
    "strategy.news.signal": "news",  # 411 غير مبنية بعد — مسجَّلة مسبقًا
    "strategy.session.signal": "session",
}


EVENT_ACCOUNTS = "portfolio.accounts_snapshot"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._state: dict[str, dict] = {}
        self._accounts: list[str] = []
        self._max_pairs = 0
        self.published_count = 0
        self.evicted_count = 0
        self.no_account_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_pairs = int(context.config["max_tracked_pairs"])
        for event_name, field_key in _SOURCE_EVENTS.items():
            context.subscribe(event_name, self._make_collector(field_key))
        context.subscribe(EVENT_ACCOUNTS, self._on_accounts)
        context.logger.info("SignalMerger(413) تمت تهيئته (يجمّع %d استراتيجية، بعضها لسا غير مبني)", len(_SOURCE_EVENTS))

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SignalMerger(413) بدأ التجميع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"رموز_مُتابَعة={len(self._state)} منشور={self.published_count}")

    async def snapshot(self) -> dict:
        return {"state": {"%s|%s" % k: v for k, v in self._state.items()},
                "accounts": list(self._accounts),
                "published_count": self.published_count,
                "no_account_count": self.no_account_count}

    async def restore(self, state: dict) -> None:
        raw = state.get("state") or {}
        self._state = {tuple(k.split("|", 1)): v for k, v in raw.items()}
        self._accounts = list(state.get("accounts") or [])
        self.published_count = state.get("published_count", 0)
        self.no_account_count = state.get("no_account_count", 0)

    # ------------------------------------------------------------------

    async def _on_accounts(self, payload: dict) -> None:
        """The active accounts, from their one owner.

        651 holds them; this atom only reads the list. Nine strategies each
        keeping their own copy would be nine states drifting apart, and a
        signal would go to an account one of them still believed in.

        Only the active ones. An account whose source has fallen silent gets
        no signal: it would be built on an equity nobody can say is still
        true.
        """
        accounts = payload.get("accounts")
        if not isinstance(accounts, list):
            return
        self._accounts = [str(a.get("account_id")) for a in accounts
                          if isinstance(a, dict) and a.get("active")
                          and a.get("account_id") not in (None, "")]

        # حالة حسابٍ غادر تُطلَق معه. المفتاح (حساب، رمز)، فلولا هذا
        # بقيت حالة كل حساب توقّف في الذاكرة إلى الأبد.
        known = set(self._accounts)
        for key in [k for k in self._state if k[0] not in known]:
            self._state.pop(key, None)

    def _make_collector(self, field_key: str):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            if not self._accounts:
                self.no_account_count += 1
                return

            symbol = str(payload.get("symbol", "_global"))
            for account_id in self._accounts:
                key = (account_id, symbol)
                if key not in self._state and len(self._state) >= self._max_pairs:
                    # سقف الأزواج: الرموز تتبدّل مع الوقت حتى بحساب واحد،
                    # والأقدم يخرج بدل أن ينمو القاموس بلا حدّ.
                    self._state.pop(next(iter(self._state)), None)
                    self.evicted_count += 1
                pair_state = self._state.setdefault(key, {})
                pair_state[field_key] = payload

                self.published_count += 1
                # العقد الرسمي الذي تنتظره 451 (مانيفستها: upstream_atoms=[413]).
                # كان الاسم هنا strategy.signals_merged بينما 451 تسمع
                # strategy.merged_signal — حرف واحد جوّع سلسلة القرار كلها.
                await self._context.publish(
                    "strategy.merged_signal",
                    {"account_id": account_id, "symbol": symbol,
                     "signals": dict(pair_state), **_ts_from(payload)},
                )

        return handler
