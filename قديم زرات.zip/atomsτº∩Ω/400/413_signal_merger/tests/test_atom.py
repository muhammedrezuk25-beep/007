import asyncio
import inspect
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom413"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom

import yaml as _yaml
from pathlib import Path as _P413

_MANIFEST413 = _yaml.safe_load(
    (_P413(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8"))
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=413, config=dict(_MANIFEST413["config"]), logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_nine_strategies_no_late_binding():
    print("\n--- test_nine_strategies_no_late_binding ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("portfolio.accounts_snapshot",
                      {"accounts": [{"account_id": "A", "active": True}]})

    events = [
        "strategy.trend.signal", "strategy.reversal.signal", "strategy.breakout.signal",
        "strategy.pullback.signal", "strategy.momentum.signal", "strategy.range.signal",
        "strategy.liquidity.signal", "strategy.news.signal", "strategy.session.signal",
    ]
    for name in events:
        await bus.publish(name, {"symbol": "NQ"})

    expected_keys = {"trend", "reversal", "breakout", "pullback", "momentum", "range", "liquidity", "news", "session"}
    # المفتاح صار زوجًا: (حساب، رمز) — فرمزٌ في حسابين كيانان مختلفان.
    assert set(atom._state[("A", "NQ")].keys()) == expected_keys, (
        f"كل استراتيجية لازم تُخزَّن بمفتاحها الصحيح: {set(atom._state[('A', 'NQ')].keys())}"
    )
    print(f"OK — التسعة استراتيجيات (٨ حقيقية + ١ غير مبنية بعد) خُزِّنوا كل واحدة بمفتاحها الصحيح")


async def test_merged_state_accumulates_real_signals():
    print("\n--- test_merged_state_accumulates_real_signals ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("portfolio.accounts_snapshot",
                      {"accounts": [{"account_id": "A", "active": True}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "signal": "BUY"})
    await bus.publish("strategy.momentum.signal", {"symbol": "NQ", "signal": "BUY"})
    last_state = bus.published[-1][1]["signals"]
    assert last_state["trend"]["signal"] == "BUY"
    assert last_state["momentum"]["signal"] == "BUY"
    print(f"OK — تراكم إشارات حقيقية من استراتيجيتين: {last_state}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("portfolio.accounts_snapshot",
                      {"accounts": [{"account_id": "A", "active": True}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "signal": "BUY"})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    # المفتاح زوج، ويُسلسَل نصًّا في اللقطة ثم يعود زوجًا.
    assert atom2._state[("A", "NQ")]["trend"]["signal"] == "BUY"
    assert atom2._accounts == ["A"]
    print("OK — restore() نقل الحالة المجمَّعة بدقّة")


async def main():
    tests = [test_nine_strategies_no_late_binding, test_merged_state_accumulates_real_signals, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


# ── الحساب يدخل هنا ─────────────────────────────────────────────────

def test_the_snapshot_is_the_source_of_active_accounts():
    """الاستراتيجيات 404–412 تقرأ السوق وحدها ولا تعرف حسابًا — والسعر
    حقيقة عن السوق لا عن الحساب.

    فالحساب يدخل عند الدمج: مالك واحد للقائمة بدل تسع ذرّات تحمل نسخة
    منها تتفاوت."""
    assert "portfolio.accounts_snapshot" in MANIFEST["subscribes"]



async def test_one_merged_signal_per_active_account():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.accounts_snapshot"]({
        "accounts": [{"account_id": "A", "active": True},
                     {"account_id": "B", "active": True}],
        "timestamp": TS})
    for name in ("strategy.trend.signal", "strategy.momentum.signal"):
        await ctx.handlers[name]({"symbol": "USTEC", "direction": "BUY",
                                  "strength": 0.7, "timestamp": TS})
    merged = out(ctx)
    assert {m["account_id"] for m in merged} == {"A", "B"}



async def test_a_stale_account_gets_no_signal():
    """حساب صمت مصدره ليس نشطًا: إشارة له تُبنى على حقوق لا يُعرف
    أصحّت أم تغيّرت."""
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.accounts_snapshot"]({
        "accounts": [{"account_id": "A", "active": True},
                     {"account_id": "B", "active": False}],
        "timestamp": TS})
    for name in ("strategy.trend.signal", "strategy.momentum.signal"):
        await ctx.handlers[name]({"symbol": "USTEC", "direction": "BUY",
                                  "strength": 0.7, "timestamp": TS})
    assert {m["account_id"] for m in out(ctx)} == {"A"}



async def test_nothing_is_merged_before_the_first_snapshot():
    """بلا حساب معروف لا وجهة للإشارة. وإرسالها بلا هوية يعني حجمًا
    يُحسب من حقوق حساب ويُرسَل إلى آخر."""
    atom, ctx = await _ready()
    for name in ("strategy.trend.signal", "strategy.momentum.signal"):
        await ctx.handlers[name]({"symbol": "USTEC", "direction": "BUY",
                                  "strength": 0.7, "timestamp": TS})
    assert not out(ctx)
    assert atom.no_account_count >= 1



async def test_the_merge_key_is_the_pair_and_the_account():
    """دمج إشارتين من حسابين يعطي رأيًا لا يخصّ أيًّا منهما."""
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.accounts_snapshot"]({
        "accounts": [{"account_id": "A", "active": True},
                     {"account_id": "B", "active": True}],
        "timestamp": TS})
    for name in ("strategy.trend.signal", "strategy.momentum.signal"):
        await ctx.handlers[name]({"symbol": "USTEC", "direction": "BUY",
                                  "strength": 0.7, "timestamp": TS})
    by = {}
    for m in out(ctx):
        by.setdefault(m["account_id"], []).append(m)
    assert len(by["A"][-1]["signals"]) == len(by["B"][-1]["signals"])


# ── الحساب يدخل هنا ─────────────────────────────────────────────────

_SNAP = "portfolio.accounts_snapshot"


def test_the_snapshot_is_the_source_of_active_accounts():
    """الاستراتيجيات 404–412 تقرأ السوق وحدها ولا تعرف حسابًا، والسعر
    حقيقة عن السوق لا عن الحساب.

    فالحساب يدخل عند الدمج: مالك واحد للقائمة بدل تسع ذرّات تحمل نسخة
    منها تتفاوت."""
    assert _SNAP in _MANIFEST413["subscribes"]


async def test_one_merged_signal_per_active_account():
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True},
                                           {"account_id": "B", "active": True}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "direction": "BUY"})
    merged = [p for n, p in bus.published if n == "strategy.merged_signal"]
    assert {m["account_id"] for m in merged} == {"A", "B"}


async def test_a_stale_account_gets_no_signal():
    """حساب صمت مصدره ليس نشطًا: إشارة له تُبنى على حقوق لا يُعرف
    أصحّت أم تغيّرت."""
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True},
                                           {"account_id": "B", "active": False}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "direction": "BUY"})
    merged = [p for n, p in bus.published if n == "strategy.merged_signal"]
    assert {m["account_id"] for m in merged} == {"A"}


async def test_nothing_is_merged_before_the_first_snapshot():
    """بلا حساب معروف لا وجهة للإشارة، وإرسالها بلا هوية يعني حجمًا
    يُحسب من حقوق حساب ويُرسَل إلى آخر."""
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "direction": "BUY"})
    merged = [p for n, p in bus.published if n == "strategy.merged_signal"]
    assert not merged
    assert atom.no_account_count >= 1


async def test_the_merge_key_is_the_pair_and_the_account():
    """دمج إشارتين من حسابين يعطي رأيًا لا يخصّ أيًّا منهما."""
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True},
                                           {"account_id": "B", "active": True}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "signal": "BUY"})
    await bus.publish("strategy.momentum.signal", {"symbol": "NQ", "signal": "BUY"})
    merged = [p for n, p in bus.published if n == "strategy.merged_signal"]
    per = {}
    for m in merged:
        per[m["account_id"]] = m
    assert set(per["A"]["signals"]) == set(per["B"]["signals"]) == {"trend", "momentum"}


async def test_state_for_a_departed_account_is_released():
    """المفتاح (حساب، رمز) والحسابات تتبدّل: حساب توقّف يترك حالته في
    الذاكرة للأبد، ولا سقف ولا مهلة تُخرجها. وعلى تشغيل متواصل بأيام
    تتراكم بلا حدّ."""
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True},
                                           {"account_id": "B", "active": True}]})
    await bus.publish("strategy.trend.signal", {"symbol": "NQ", "signal": "BUY"})
    assert {k[0] for k in atom._state} == {"A", "B"}

    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True}]})
    assert {k[0] for k in atom._state} == {"A"}


async def test_the_pair_count_is_capped():
    """حتى بحساب واحد: رموز تتبدّل مع الوقت، والقاموس بلا سقف."""
    bus = FakeEventBus(); atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(_SNAP, {"accounts": [{"account_id": "A", "active": True}]})
    for i in range(400):
        await bus.publish("strategy.trend.signal",
                          {"symbol": "SYM%d" % i, "signal": "BUY"})
    assert len(atom._state) <= atom._max_pairs
