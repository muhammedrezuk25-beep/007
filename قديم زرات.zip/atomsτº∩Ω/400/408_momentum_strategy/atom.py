"""
408 — استراتيجية الزخم (Momentum Strategy)

يشترك: analysis.momentum_calculated (152 — معتمَدة فعليًا). ينشر:
strategy.momentum.signal.

منطق مُستنتَج: زخم موجب → BUY (استمرارية صعودية)، سالب → SELL.
زخم=0 بالضبط → صمت (بلا اتجاه واضح للمراهنة على استمراريته).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة."""
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._full_strength_pct = 1.0
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._full_strength_pct = float(context.config["full_strength_momentum_pct"])
        context.subscribe("analysis.momentum_calculated", self._on_momentum)
        context.logger.info("MomentumStrategy(408) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("MomentumStrategy(408) بدأ الاستماع لـ152")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_momentum(self, payload: dict) -> None:
        if self._context is None:
            return
        momentum_pct = payload["momentum_pct"]
        if momentum_pct > 0:
            signal = "BUY"
        elif momentum_pct < 0:
            signal = "SELL"
        else:
            return  # زخم صفر بالضبط — بلا اتجاه واضح، صمت

        self.signals_published += 1
        await self._context.publish(
            "strategy.momentum.signal",
            # القوّة من حجم الزخم نفسه — الرقم موجود، ولا يُخترع شيء.
            # المقياس على دلالة 410: قيمة مطبَّعة في [0..1] تعبّر عن جودة
            # الإشارة، لا صيغة رياضية مقلَّدة عنه. كل استراتيجية تحسبها
            # بطريقتها وتلتزم بالمجال والدلالة.
            {"symbol": payload.get("symbol"), "direction": signal, "signal": signal,
             "momentum_pct": momentum_pct,
             "strength": min(abs(momentum_pct) / self._full_strength_pct, 1.0),
             **_ts_from(payload)}
        )
