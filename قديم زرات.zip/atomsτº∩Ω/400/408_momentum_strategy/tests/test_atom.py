import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom408"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
# الإعداد من المانيفست لا مكتوبًا هنا: قاموس فارغ كان يُسقط الاختبارات
# بـKeyError عند أول مفتاح جديد في العقد بدل أن يُلتقط تلقائيًا.
import yaml  # noqa: E402
_CONFIG = yaml.safe_load(
    (_Path(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=408, config=dict(_CONFIG), logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_positive_momentum_gives_buy_signal():
    print("\n--- test_positive_momentum_gives_buy_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 5.0, "period": 10})
    events = [p for n, p in published if n == "strategy.momentum.signal"]
    # مقارنة على الحقول لا بتساوٍ تام: العقد الموحّد للاستراتيجيات أضاف
    # direction و strength، والتساوي التام يكسر مع كل توسعة مشروعة.
    e = events[0]
    assert e["symbol"] == "NQ"
    assert e["direction"] == "BUY"      # الحقل القانوني
    assert e["signal"] == "BUY"         # الاسم القديم، للتوافق
    assert e["momentum_pct"] == 5.0
    # 5% زخم مقابل full_strength_momentum_pct=0.5 → مقصوص عند 1.0
    assert e["strength"] == 1.0
    print(f"OK — زخم موجب → BUY: {events[0]}")


async def test_negative_momentum_gives_sell_signal():
    print("\n--- test_negative_momentum_gives_sell_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": -3.0, "period": 10})
    events = [p for n, p in published if n == "strategy.momentum.signal"]
    assert events[0]["signal"] == "SELL"
    print(f"OK — زخم سالب → SELL: {events[0]}")


async def test_zero_momentum_no_signal():
    print("\n--- test_zero_momentum_no_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 0.0, "period": 10})
    events = [p for n, p in published if n == "strategy.momentum.signal"]
    assert len(events) == 0
    print("OK — زخم صفر بالضبط → صفر إشارة")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 5.0, "period": 10})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.signals_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_positive_momentum_gives_buy_signal, test_negative_momentum_gives_sell_signal, test_zero_momentum_no_signal, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
