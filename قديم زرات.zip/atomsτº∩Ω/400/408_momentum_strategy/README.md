# 408 — Momentum Strategy (استراتيجية الزخم)

المدخل: `analysis.momentum_calculated` (152 — **معتمَدة فعليًا**).
زخم موجب→BUY، سالب→SELL، صفر بالضبط→صمت.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
4 اختبارات: زخم موجب، زخم سالب، زخم صفر (صمت)، `snapshot`/`restore`.
**نتيجة: 4/4.**
