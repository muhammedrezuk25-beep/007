from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PERFORMANCE = "strategy.performance_tracked"
EVENT_APPROVED = "strategy.switch.approved"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "strategy.switch.requested"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_REQUESTS = "NO_REQUESTS_YET"

TRIGGER_DEGRADING = "STRATEGY_DEGRADING"
TRIGGER_LOSING_STREAK = "LOSING_STREAK"


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._streak_limit = 0
        self._requested: dict[int, bool] = {}
        self._latest: dict[int, dict[str, Any]] = {}
        self.requests_published = 0
        self.approvals_seen = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._streak_limit = int(context.config["losing_streak_limit"])
        context.subscribe(EVENT_PERFORMANCE, self._on_performance)
        context.subscribe(EVENT_APPROVED, self._on_approved)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("417 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("417 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("417 stopped (requests=%d)",
                                      self.requests_published)

    async def shutdown(self) -> None:
        await self.stop()

    def _trigger_for(self, report: dict[str, Any]) -> str | None:
        if report.get("degrading") and report.get("verdict_ready"):
            return TRIGGER_DEGRADING
        streak = _to_int(report.get("losing_streak"))
        if streak is not None and self._streak_limit > 0 and streak >= self._streak_limit:
            return TRIGGER_LOSING_STREAK
        return None

    async def _on_performance(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        strategy = _to_int(payload.get("strategy"))
        if strategy is None:
            return
        self._latest[strategy] = dict(payload)

        trigger = self._trigger_for(payload)
        if trigger is None:
            return
        if self._requested.get(strategy):
            return

        self._requested[strategy] = True
        self.requests_published += 1

        body: dict[str, Any] = {
            "strategy": strategy,
            "trigger": trigger,
            "win_rate": _to_float(payload.get("win_rate")),
            "trades": _to_int(payload.get("trades")),
            "losing_streak": _to_int(payload.get("losing_streak")),
            "net_pnl": _to_float(payload.get("net_pnl")),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        self._context.logger.warning(
            "417 asks 450 to switch away from %d (%s)", strategy, trigger)
        await self._context.publish(EVENT_OUT, body)

    async def _on_approved(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self.approvals_seen += 1
        strategy = _to_int(payload.get("strategy"))
        if strategy is not None:
            self._requested.pop(strategy, None)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._requested.clear()

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        pending = sorted(s for s, asked in self._requested.items() if asked)
        details = {"requests": self.requests_published,
                   "approvals_seen": self.approvals_seen,
                   "pending": pending, "tracked": len(self._latest)}
        if self.requests_published == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_REQUESTS, details=details)
        if pending:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="awaiting 450 on %s" % pending,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="requests=%d" % self.requests_published,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "requested": {str(k): bool(v) for k, v in self._requested.items()},
                "requests": self.requests_published,
                "approvals": self.approvals_seen}

    async def restore(self, state: dict[str, Any]) -> None:
        self._requested = {int(k): bool(v)
                           for k, v in (state.get("requested") or {}).items()}
        self.requests_published = int(state.get("requests", 0))
        self.approvals_seen = int(state.get("approvals", 0))
