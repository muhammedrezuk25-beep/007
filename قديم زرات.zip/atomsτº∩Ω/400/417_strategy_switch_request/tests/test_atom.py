from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom417"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 417

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


async def _report(ctx, strategy=404, degrading=False, ready=True, streak=0, at=TS):
    await ctx.handlers[MODULE.EVENT_PERFORMANCE]({
        "strategy": strategy, "degrading": degrading, "verdict_ready": ready,
        "losing_streak": streak, "win_rate": 0.2, "trades": 10,
        "net_pnl": -50.0, "timestamp": at})


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 417


def test_it_only_requests_and_never_switches():
    """Two-event pattern: this atom asks, 450 answers. It publishes a request
    and nothing else."""
    assert MANIFEST["publishes"] == ["strategy.switch.requested"]


@pytest.mark.asyncio
async def test_a_degrading_strategy_triggers_a_request():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    request = out(ctx)[0]
    assert request["strategy"] == 404
    assert request["trigger"] == MODULE.TRIGGER_DEGRADING


@pytest.mark.asyncio
async def test_a_verdict_that_is_not_ready_does_not_trigger():
    """416 withholds its verdict below the trade threshold. Acting on a
    withheld verdict would switch a strategy on two trades of noise."""
    atom, ctx = await _ready()
    await _report(ctx, degrading=True, ready=False)
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_a_losing_streak_triggers_on_its_own():
    atom, ctx = await _ready(losing_streak_limit=5)
    await _report(ctx, degrading=False, streak=5)
    assert out(ctx)[0]["trigger"] == MODULE.TRIGGER_LOSING_STREAK


@pytest.mark.asyncio
async def test_a_short_streak_does_not_trigger():
    atom, ctx = await _ready(losing_streak_limit=5)
    await _report(ctx, degrading=False, streak=3)
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_a_healthy_strategy_is_left_alone():
    atom, ctx = await _ready()
    await _report(ctx, degrading=False, streak=0)
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_the_request_is_not_repeated_while_450_is_silent():
    """Edge triggered: one request per strategy until 450 answers, otherwise
    every closed trade would file the same request again."""
    atom, ctx = await _ready()
    for _ in range(4):
        await _report(ctx, degrading=True)
    assert len(out(ctx)) == 1


@pytest.mark.asyncio
async def test_an_approval_clears_the_pending_request():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    await ctx.handlers[MODULE.EVENT_APPROVED]({"strategy": 404, "approved": True,
                                               "timestamp": TS})
    assert (await atom.health_check()).details["pending"] == []


@pytest.mark.asyncio
async def test_a_new_request_is_allowed_after_the_answer():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    await ctx.handlers[MODULE.EVENT_APPROVED]({"strategy": 404, "timestamp": TS})
    await _report(ctx, degrading=True)
    assert len(out(ctx)) == 2


@pytest.mark.asyncio
async def test_two_strategies_are_tracked_apart():
    atom, ctx = await _ready()
    await _report(ctx, strategy=404, degrading=True)
    await _report(ctx, strategy=409, degrading=True)
    assert {r["strategy"] for r in out(ctx)} == {404, 409}


@pytest.mark.asyncio
async def test_a_report_without_a_strategy_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_PERFORMANCE]({"degrading": True,
                                                  "verdict_ready": True})
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_day_roll_clears_pending_requests():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom._requested == {}


@pytest.mark.asyncio
async def test_health_is_degraded_while_450_has_not_answered():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert 404 in status.details["pending"]


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_requests_yet_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_nothing_runs_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await _report(ctx, degrading=True)
    assert atom.requests_published == 0


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _report(ctx, degrading=True)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._requested == {404: True}
    assert fresh.requests_published == 1
