"""
406 — استراتيجية الاختراق (Breakout Strategy)

يشترك: market.bos.detected (204 — معتمَدة فعليًا). ينشر:
strategy.breakout.signal.

منطق مُستنتَج: كل BOS = إشارة استمرارية اختراق بطبيعته (204 نفسها
تؤكِّد استمرارية اتجاهية، لا كسر عشوائي) — direction="high"→BUY،
"low"→SELL. تقرر لحالها من مدخلها الخاص فقط.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _strength(payload: dict, full_pct: float) -> dict:
    price = payload.get("price")
    level = payload.get("level")
    if not isinstance(price, (int, float)) or not isinstance(level, (int, float)):
        return {}
    if level == 0:
        return {}
    depth_pct = abs(price - level) / abs(level) * 100.0
    return {"strength": min(depth_pct / full_pct, 1.0) if full_pct > 0 else 1.0,
            "break_depth_pct": round(depth_pct, 6)}

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SIGNAL_MAP = {"high": "BUY", "low": "SELL"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._full_pct = float(context.config["full_strength_break_pct"])
        context.subscribe("market.bos.detected", self._on_bos)
        context.logger.info("BreakoutStrategy(406) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("BreakoutStrategy(406) بدأ الاستماع لـ204")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_bos(self, payload: dict) -> None:
        if self._context is None:
            return
        signal = _SIGNAL_MAP.get(payload["direction"])
        if signal is None:
            return

        self.signals_published += 1
        await self._context.publish(
            "strategy.breakout.signal",
            # strength غائبة: عمق الاختراق يحتاج المستوى المكسور، و204
            # يرسل السعر وحده. تُضاف حين يرسل 204 حقل level.
            {"symbol": payload.get("symbol"), "direction": signal, "signal": signal,
             "price": payload.get("price"),
             **_strength(payload, self._full_pct), **_ts_from(payload)}
        )
