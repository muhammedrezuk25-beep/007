import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom406"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
import yaml as _yaml  # noqa: E402
from pathlib import Path as _MP  # noqa: E402
_CONFIG = _yaml.safe_load(
    (_MP(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=406, config=dict(_CONFIG), logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_high_bos_gives_buy_signal():
    print("\n--- test_high_bos_gives_buy_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 110})
    events = [p for n, p in published if n == "strategy.breakout.signal"]
    # Field-by-field, not an exact match: the unified strategy contract
    # added direction, timestamp and strength, and an exact comparison
    # breaks on every legitimate extension.
    _expected = {"symbol": "NQ", "signal": "BUY", "price": 110}
    for _k, _v in _expected.items():
        assert events[0][_k] == _v
    print(f"OK — BOS اتجاه high → BUY: {events[0]}")


async def test_low_bos_gives_sell_signal():
    print("\n--- test_low_bos_gives_sell_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "low", "price": 90})
    events = [p for n, p in published if n == "strategy.breakout.signal"]
    assert events[0]["signal"] == "SELL"
    print(f"OK — BOS اتجاه low → SELL: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 110})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.signals_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_high_bos_gives_buy_signal, test_low_bos_gives_sell_signal, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


async def test_strength_scales_with_break_depth():
    """A break that barely clears the level is weaker than one that clears it
    by a wide margin. Without the level from 204 there is no depth to measure
    and 406's vote carries no weight in 458."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    await atom._on_bos({"symbol": "NQ", "direction": "high",
                        "price": 100.05, "level": 100.0})
    shallow = [p for n, p in published if n == "strategy.breakout.signal"][0]
    assert 0 < shallow["strength"] < 1.0

    context2, published2 = make_context()
    atom2 = Atom()
    await atom2.initialize(context2)
    await atom2._on_bos({"symbol": "NQ", "direction": "high",
                         "price": 101.0, "level": 100.0})
    deep = [p for n, p in published2 if n == "strategy.breakout.signal"][0]
    assert deep["strength"] > shallow["strength"]


async def test_strength_is_capped_at_one():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high",
                        "price": 200.0, "level": 100.0})
    assert [p for n, p in published][0]["strength"] == 1.0


async def test_no_level_means_no_strength_not_a_guess():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100.0})
    event = [p for n, p in published][0]
    assert "strength" not in event


async def test_a_zero_level_is_refused():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high",
                        "price": 100.0, "level": 0})
    assert "strength" not in [p for n, p in published][0]


async def test_unknown_direction_publishes_nothing():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "sideways", "price": 100.0})
    assert published == []


async def test_lifecycle_is_reversible():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    status = await atom.health_check()
    assert status.state.name in ("HEALTHY", "DEGRADED", "UNKNOWN", "UNHEALTHY")


async def test_snapshot_restore_round_trip():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high",
                        "price": 101.0, "level": 100.0})
    snap = await atom.snapshot()
    fresh = Atom()
    await fresh.initialize(make_context()[0])
    if snap is not None:
        await fresh.restore(snap)
    assert True
