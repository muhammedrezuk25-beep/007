# 406 — Breakout Strategy (استراتيجية الاختراق)

المدخل: `market.bos.detected` (204 — **معتمَدة فعليًا**). كل BOS =
إشارة استمرارية — high→BUY، low→SELL.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
3 اختبارات: BOS(high)→BUY، BOS(low)→SELL، `snapshot`/`restore`.
**نتيجة: 3/3.**
