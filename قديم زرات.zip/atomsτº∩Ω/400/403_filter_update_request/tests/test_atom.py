import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom403"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=403, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_below_threshold_no_request():
    print("\n--- test_below_threshold_no_request ---")
    context, published = make_context({"exit_threshold": 3})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "BUY", "majority": "SELL"})
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "SELL", "majority": "BUY"})
    events = [p for n, p in published if n == "strategy.filters.update_requested"]
    assert len(events) == 0
    print("OK — خروجان بس (تحت العتبة 3) → صفر طلب")


async def test_reaching_threshold_publishes_request():
    print("\n--- test_reaching_threshold_publishes_request ---")
    context, published = make_context({"exit_threshold": 3})
    atom = Atom()
    await atom.initialize(context)
    for _ in range(3):
        await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "BUY", "majority": "SELL"})
    events = [p for n, p in published if n == "strategy.filters.update_requested"]
    assert len(events) == 1
    assert events[0]["exit_count"] == 3
    print(f"OK — 3 خروجات (بلغت العتبة) → طلب تحديث فلاتر: {events[0]}")


async def test_counter_resets_after_request():
    print("\n--- test_counter_resets_after_request ---")
    context, published = make_context({"exit_threshold": 2})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "BUY", "majority": "SELL"})
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "SELL", "majority": "BUY"})  # طلب أول هون
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "BUY", "majority": "SELL"})  # يبدأ عدّ جديد
    events = [p for n, p in published if n == "strategy.filters.update_requested"]
    assert len(events) == 1, "العدّاد تصفّر بعد الطلب الأول — خروج ثالث بس لا يكفي لطلب تانٍ"
    print("OK — العدّاد تصفّر بعد كل طلب (Edge-triggered لكل تجاوز)")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"exit_threshold": 3})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_exit_summary({"symbol": "NQ", "majority_flipped": True, "previous_majority": "BUY", "majority": "SELL"})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._exit_counts["NQ"] == 1
    print("OK — restore() نقل عدّاد الخروج بدقّة")


async def main():
    tests = [
        test_below_threshold_no_request,
        test_reaching_threshold_publishes_request,
        test_counter_resets_after_request,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
