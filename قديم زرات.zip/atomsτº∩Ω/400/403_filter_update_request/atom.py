"""
403 — طلب تحديث الفلاتر (Filter Update Request)

محسوم: نمط الحدثين — تنشر strategy.filters.update_requested بس،
450 (غير مبنية بعد) توافق/ترفض.

المُحفِّز غير مُحدَّد بالسبك — استُنتِج: يشترك بمخرجات 402
(strategy.exit_rules_summary، حقيقية ومبنية). تكرار خروج متتالٍ (٣+
خلال نافذة قصيرة) = مؤشر سوق متذبذب/غير موثوق بالإعدادات الحالية —
طلب مراجعة الفلاتر. Edge-triggered: طلب واحد بس لكل تجاوز عتبة،
يتصفّر العدّاد بعد كل طلب.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_EXIT_THRESHOLD = 3


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._exit_threshold = _DEFAULT_EXIT_THRESHOLD
        self._exit_counts: dict[str, int] = {}
        self.requests_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._exit_threshold = int(context.config.get("exit_threshold", _DEFAULT_EXIT_THRESHOLD))
        context.subscribe("strategy.exit_rules_summary", self._on_exit_summary)
        context.logger.info("FilterUpdateRequest(403) تمت تهيئته (exit_threshold=%d)", self._exit_threshold)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("FilterUpdateRequest(403) بدأ الاستماع لـ402")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"طلبات_منشورة={self.requests_published}")

    async def snapshot(self) -> dict:
        return {"exit_counts": self._exit_counts, "requests_published": self.requests_published}

    async def restore(self, state: dict) -> None:
        self._exit_counts = state.get("exit_counts", {})
        self.requests_published = state.get("requests_published", 0)

    # ------------------------------------------------------------------

    async def _on_exit_summary(self, payload: dict) -> None:
        if not payload.get("majority_flipped"):
            return
        if self._context is None:
            return
        symbol = payload["symbol"]
        self._exit_counts[symbol] = self._exit_counts.get(symbol, 0) + 1

        if self._exit_counts[symbol] >= self._exit_threshold:
            self.requests_published += 1
            await self._context.publish(
                "strategy.filters.update_requested",
                {"symbol": symbol, "reason": "excessive_exit_triggers", "exit_count": self._exit_counts[symbol]},
            )
            self._exit_counts[symbol] = 0  # تصفير بعد الطلب — Edge-triggered لكل تجاوز
