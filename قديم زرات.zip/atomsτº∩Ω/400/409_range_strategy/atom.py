"""
409 — استراتيجية النطاق (Range Strategy)

يشترك: market.trend.changed (207 — معتمَدة فعليًا). ينشر:
strategy.range.signal.

منطق مُستنتَج: مكمِّلة لـ404 حرفيًا (نفس المدخل، تتعامل مع الحالة
المعاكسة) — RANGE فقط تُطلِق إشارة هون. **بلا اتجاه BUY/SELL** —
حركة عرضية بطبيعتها بلا انحياز اتجاهي، فرض اتجاه هنا يكون تخمينًا
كاذبًا. تنشر condition سياقية بس (`range_active`)، تفيد استراتيجيات
أو قرارات لاحقة تحتاج "تجنّب التداول الاتجاهي الآن" دون فرض بديل.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.trend.changed", self._on_trend_changed)
        context.logger.info("RangeStrategy(409) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("RangeStrategy(409) بدأ الاستماع لـ207")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_trend_changed(self, payload: dict) -> None:
        if self._context is None:
            return
        if payload["state"] != "RANGE":
            return  # مكمِّلة لـ404 — RANGE بس، الباقي خارج نطاقها

        self.signals_published += 1
        await self._context.publish(
            "strategy.range.signal",
            # سياقية لا اتجاهية. strength تحتاج حدّي النطاق والسعر الحالي،
            # وهذه الذرة تستلم حالة الاتجاه وحدها.
            {"symbol": payload.get("symbol"), "direction": "RANGE",
             "condition": "range_active", **_ts_from(payload)}
        )
