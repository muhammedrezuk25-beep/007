# 405 — Reversal Strategy (استراتيجية الانعكاس)

المدخل: `market.structure.updated` (210 — **معتمَدة فعليًا**). يستخرج
`state` (من 207 عبر تجميع 210) — `TRANSITION` تحديدًا يُطلِق إشارة
انعكاس.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
4 اختبارات: TRANSITION يُطلِق إشارة، UPTREND لا يُطلِق، غياب الحقل
بلا خطأ، `snapshot`/`restore`. **نتيجة: 4/4.**
