"""
405 — استراتيجية الانعكاس (Reversal Strategy)

يشترك: market.structure.updated (210 — معتمَدة فعليًا). ينشر:
strategy.reversal.signal.

منطق مُستنتَج: يستخرج حقل "state" (حالة الاتجاه من 207، عبر تجميع
210) من الحالة الموحَّدة — TRANSITION تحديدًا (إشارة انعكاس غير
مؤكَّدة بعد كاتجاه ثابت) هي مثار استراتيجية الانعكاس بطبيعتها؛
UPTREND/DOWNTREND/RANGE لا تستأهل إشارة انعكاس هنا (تلك أدوار
استراتيجيات أخرى).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.structure.updated", self._on_structure_updated)
        context.logger.info("ReversalStrategy(405) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ReversalStrategy(405) بدأ الاستماع لـ210")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_structure_updated(self, payload: dict) -> None:
        if self._context is None:
            return
        inner_state = payload.get("state", {})
        if inner_state.get("state") != "TRANSITION":
            return  # بلا إشارة انعكاس تحديدًا الآن

        self.signals_published += 1
        await self._context.publish(
            "strategy.reversal.signal",
            # إشارة سياقية لا اتجاهية: REVERSAL_WATCH ليست BUY ولا SELL،
            # فيتخطّاها 452 و458 بفلتر الاتجاه الصالح. strength تحتاج عمق
            # الاختراق ثم العودة — حالة عبر الزمن لا تحتفظ بها الذرة بعد.
            {"symbol": payload.get("symbol"), "direction": "REVERSAL_WATCH",
             "signal": "REVERSAL_WATCH", **_ts_from(payload)}
        )
