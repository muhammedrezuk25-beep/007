import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom401"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=401, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_publishes_a_summary_not_a_decision():
    """The build paper says 401 collects entry conditions and shows them:
    a sub-collector, not a decision maker. It used to count votes and publish
    strategy.entry_confirmed, which is a decision 450 owns."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {
            "trend":    {"direction": "BUY", "strength": 0.8},
            "momentum": {"direction": "BUY"},
            "breakout": {"direction": "SELL"},
        },
        "timestamp": 100.0,
    })
    events = [p for n, p in published if n == "strategy.entry_rules_summary"]
    assert len(events) == 1
    summary = events[0]
    assert summary["symbol"] == "NQ"
    assert summary["contributing"] == 3
    assert summary["buy_count"] == 2
    assert summary["sell_count"] == 1


async def test_no_decision_event_is_ever_published():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {"trend": {"direction": "BUY"}, "momentum": {"direction": "BUY"}},
    })
    assert [n for n, _ in published] == ["strategy.entry_rules_summary"]


async def test_each_rule_keeps_its_strength():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {"liquidity": {"direction": "BUY", "strength": 0.9}},
    })
    rules = [p for n, p in published if n == "strategy.entry_rules_summary"][0]["rules"]
    assert rules["liquidity"]["strength"] == 0.9


async def test_timestamp_is_inherited():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}, "timestamp": 55.0,
    })
    assert [p for n, p in published][0]["timestamp"] == 55.0


async def test_no_directional_rule_publishes_nothing():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"session": {"other": 1}}})
    assert published == []


async def test_malformed_payload_is_ignored():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"signals": {}})
    await atom._on_signals_merged({"symbol": "NQ", "signals": []})
    assert published == []


async def test_snapshot_restore():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.initialize(make_context()[0])
    await atom2.restore(snap)
    assert atom2.summaries_published == 1


def test_run_all():
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and asyncio.iscoroutinefunction(fn):
            asyncio.run(fn())
