"""
401 — مدير قواعد الدخول (Entry Rules Manager)

لا سبك دقيق للمدخل أُعطي — استُنتِج: يشترك بمخرجات 413
(strategy.merged_signal، حقيقية ومبنية). منطق: قاعدة دخول عامة —
يتطلب **حد أدنى من الاتفاق** بين الاستراتيجيات ذات الدلالة الاتجاهية
الواضحة (trend/breakout/pullback/momentum/liquidity) على نفس
الاتجاه قبل اعتبار الدخول "مؤكَّدًا" — تصفية ضوضاء إشارة استراتيجية
واحدة معزولة. عتبة افتراضية: 2 اتفاق على الأقل. ينشر:
strategy.entry_rules_summary.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_MIN_AGREEMENT = 2
_DIRECTIONAL_STRATEGIES = ["trend", "breakout", "pullback", "momentum", "liquidity"]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._min_agreement = _DEFAULT_MIN_AGREEMENT
        self.summaries_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_agreement = int(context.config.get("min_agreement", _DEFAULT_MIN_AGREEMENT))
        context.subscribe("strategy.merged_signal", self._on_signals_merged)
        context.logger.info("EntryRulesManager(401) تمت تهيئته (min_agreement=%d)", self._min_agreement)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("EntryRulesManager(401) بدأ الاستماع لـ413")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تأكيدات_منشورة={self.summaries_published}")

    async def snapshot(self) -> dict:
        return {"summaries_published": self.summaries_published}

    async def restore(self, state: dict) -> None:
        self.summaries_published = state.get("summaries_published", 0)

    # ------------------------------------------------------------------

    async def _on_signals_merged(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload.get("symbol")
        signals = payload.get("signals")
        if not symbol or not isinstance(signals, dict):
            return

        rules = {}
        for strategy_name in _DIRECTIONAL_STRATEGIES:
            entry = signals.get(strategy_name)
            if isinstance(entry, dict):
                direction = entry.get("direction") or entry.get("signal")
                if direction:
                    rules[strategy_name] = {
                        "direction": direction,
                        "strength": entry.get("strength"),
                    }
        if not rules:
            return

        directions = [r["direction"] for r in rules.values()]
        summary = {
            "symbol": symbol,
            "rules": rules,
            "contributing": len(rules),
            "buy_count": directions.count("BUY"),
            "sell_count": directions.count("SELL"),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            summary["timestamp"] = stamp

        self.summaries_published += 1
        await self._context.publish("strategy.entry_rules_summary", summary)
