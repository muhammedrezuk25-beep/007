"""
415 — طلب اختيار استراتيجية (Strategy Selection Request)

محسوم: نمط الحدثين — تنشر strategy.selection.requested بس، 450
(غير مبنية بعد) توافق/ترفض.

المُحفِّز: يشترك بمخرجات 414 (strategy.quality_scored، حقيقية
ومبنية). دقة منخفضة (<0.4 افتراضيًا) بعد عيّنة كافية (5+ تقييمات) =
مثار لطلب مراجعة/تبديل الاستراتيجيات المُساهِمة.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_MIN_SAMPLES = 5
_ACCURACY_THRESHOLD = 0.4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._min_samples = _MIN_SAMPLES
        self._accuracy_threshold = _ACCURACY_THRESHOLD
        self._sample_counts: dict[str, int] = {}
        self._last_requested: dict[str, bool] = {}
        self.requests_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_samples = int(context.config.get("min_samples", _MIN_SAMPLES))
        self._accuracy_threshold = float(context.config.get("accuracy_threshold", _ACCURACY_THRESHOLD))
        context.subscribe("strategy.quality_scored", self._on_evaluation)
        context.logger.info("StrategySelectionRequest(415) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("StrategySelectionRequest(415) بدأ الاستماع لـ414")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"طلبات_منشورة={self.requests_published}")

    async def snapshot(self) -> dict:
        return {"sample_counts": self._sample_counts, "last_requested": self._last_requested, "requests_published": self.requests_published}

    async def restore(self, state: dict) -> None:
        self._sample_counts = state.get("sample_counts", {})
        self._last_requested = state.get("last_requested", {})
        self.requests_published = state.get("requests_published", 0)

    # ------------------------------------------------------------------

    async def _on_evaluation(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        self._sample_counts[symbol] = self._sample_counts.get(symbol, 0) + 1

        if self._sample_counts[symbol] < self._min_samples:
            return

        is_low_accuracy = payload["accuracy"] < self._accuracy_threshold
        already_requested = self._last_requested.get(symbol, False)

        if is_low_accuracy and not already_requested:
            self.requests_published += 1
            self._last_requested[symbol] = True
            await self._context.publish(
                "strategy.selection.requested", {"symbol": symbol, "reason": "low_accuracy", "accuracy": payload["accuracy"]}
            )
        elif not is_low_accuracy:
            self._last_requested[symbol] = False  # الدقة تحسّنت — يمكن طلب تانٍ لاحقًا لو تدهورت مجددًا
