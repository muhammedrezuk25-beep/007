import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom415"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=415, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_insufficient_samples_no_request():
    print("\n--- test_insufficient_samples_no_request ---")
    context, published = make_context({"min_samples": 5, "accuracy_threshold": 0.4})
    atom = Atom()
    await atom.initialize(context)
    for _ in range(3):
        await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})
    events = [p for n, p in published if n == "strategy.selection.requested"]
    assert len(events) == 0
    print("OK — 3 عيّنات بس (تحت الحد 5) → صفر طلب رغم دقة منخفضة")


async def test_sufficient_samples_low_accuracy_triggers_request():
    print("\n--- test_sufficient_samples_low_accuracy_triggers_request ---")
    context, published = make_context({"min_samples": 5, "accuracy_threshold": 0.4})
    atom = Atom()
    await atom.initialize(context)
    for _ in range(5):
        await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})
    events = [p for n, p in published if n == "strategy.selection.requested"]
    assert len(events) == 1
    assert events[0]["reason"] == "low_accuracy"
    print(f"OK — 5 عيّنات، دقة منخفضة → طلب اختيار: {events[0]}")


async def test_request_not_repeated_while_still_low():
    print("\n--- test_request_not_repeated_while_still_low ---")
    context, published = make_context({"min_samples": 5, "accuracy_threshold": 0.4})
    atom = Atom()
    await atom.initialize(context)
    for _ in range(7):
        await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})
    events = [p for n, p in published if n == "strategy.selection.requested"]
    assert len(events) == 1, "الدقة لسا منخفضة — Edge-triggered، بلا طلب مكرَّر"
    print("OK — دقة منخفضة مستمرة → طلب واحد بس (Edge-triggered)")


async def test_request_retriggers_after_recovery_and_relapse():
    print("\n--- test_request_retriggers_after_recovery_and_relapse ---")
    context, published = make_context({"min_samples": 2, "accuracy_threshold": 0.4})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})
    await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})  # طلب أول
    await atom._on_evaluation({"symbol": "NQ", "correct": True, "accuracy": 0.6})   # تحسّنت — تصفير الحالة
    await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.2})  # تدهورت مجددًا — طلب تانٍ
    events = [p for n, p in published if n == "strategy.selection.requested"]
    assert len(events) == 2
    print(f"OK — تحسّن ثم تدهور مجددًا → طلب تانٍ صحيح: {len(events)} طلبات")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"min_samples": 5})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_evaluation({"symbol": "NQ", "correct": False, "accuracy": 0.1})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._sample_counts["NQ"] == 1
    print("OK — restore() نقل عدّاد العيّنات بدقّة")


async def main():
    tests = [
        test_insufficient_samples_no_request,
        test_sufficient_samples_low_accuracy_triggers_request,
        test_request_not_repeated_while_still_low,
        test_request_retriggers_after_recovery_and_relapse,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
