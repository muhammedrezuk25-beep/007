import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom402"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=402, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_publishes_a_summary_not_a_trigger():
    """The build paper describes 402 as a sub-collector that shows exit rules.
    It used to publish strategy.exit_triggered, which is an action 450 owns.
    The flip is now reported as a field, not as a command."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {"trend": {"direction": "BUY"}, "momentum": {"direction": "BUY"}},
        "timestamp": 10.0,
    })
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert len(events) == 1
    assert events[0]["majority"] == "BUY"
    assert events[0]["majority_flipped"] is False


async def test_flip_is_reported_as_a_field():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "SELL"}}})
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert len(events) == 2
    assert events[1]["majority_flipped"] is True
    assert events[1]["previous_majority"] == "BUY"


async def test_persisting_majority_is_not_a_flip():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for _ in range(2):
        await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert events[1]["majority_flipped"] is False


async def test_tie_leaves_the_majority_unset():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {"trend": {"direction": "BUY"}, "momentum": {"direction": "SELL"}},
    })
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert events[0]["majority"] is None
    assert events[0]["majority_flipped"] is False


async def test_a_tie_does_not_overwrite_the_last_majority():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    await atom._on_signals_merged({
        "symbol": "NQ",
        "signals": {"trend": {"direction": "BUY"}, "momentum": {"direction": "SELL"}},
    })
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "SELL"}}})
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert events[2]["previous_majority"] == "BUY"
    assert events[2]["majority_flipped"] is True


async def test_each_symbol_is_tracked_apart():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    await atom._on_signals_merged({"symbol": "XAU", "signals": {"trend": {"direction": "SELL"}}})
    events = [p for n, p in published if n == "strategy.exit_rules_summary"]
    assert events[1]["previous_majority"] is None


async def test_no_directional_rule_publishes_nothing():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"session": {"other": 1}}})
    assert published == []


async def test_timestamp_is_inherited():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({
        "symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}, "timestamp": 77.0})
    assert published[0][1]["timestamp"] == 77.0


async def test_snapshot_restore():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_signals_merged({"symbol": "NQ", "signals": {"trend": {"direction": "BUY"}}})
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.initialize(make_context()[0])
    await atom2.restore(snap)
    assert atom2.summaries_published == 1


def test_run_all():
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and asyncio.iscoroutinefunction(fn):
            asyncio.run(fn())
