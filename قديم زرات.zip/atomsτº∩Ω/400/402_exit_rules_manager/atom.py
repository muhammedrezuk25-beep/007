"""
402 — مدير قواعد الخروج (Exit Rules Manager)

لا سبك دقيق للمدخل أُعطي — استُنتِج: يشترك بمخرجات 413
(strategy.merged_signal، حقيقية ومبنية). منطق: يتتبّع اتجاه
الأغلبية بذاكرته المستقلة (نفس منطق 401، لا استدعاء بينهما — قاعدة
0) — لو الأغلبية **انقلبت** عن الاتجاه المعروف سابقًا، هذا مثار
خروج طبيعي (الإجماع الذي دعم الصفقة لم يعد قائمًا). ينشر:
strategy.exit_rules_summary.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DIRECTIONAL_STRATEGIES = ["trend", "breakout", "pullback", "momentum", "liquidity"]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_majority_direction: dict[str, str] = {}
        self.summaries_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("strategy.merged_signal", self._on_signals_merged)
        context.logger.info("ExitRulesManager(402) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ExitRulesManager(402) بدأ الاستماع لـ413")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"خروج_مُطلَق={self.summaries_published}")

    async def snapshot(self) -> dict:
        return {"last_majority_direction": self._last_majority_direction, "summaries_published": self.summaries_published}

    async def restore(self, state: dict) -> None:
        self._last_majority_direction = state.get("last_majority_direction", {})
        self.summaries_published = state.get("summaries_published", 0)

    # ------------------------------------------------------------------

    async def _on_signals_merged(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload.get("symbol")
        signals = payload.get("signals")
        if not symbol or not isinstance(signals, dict):
            return

        rules = {}
        for strategy_name in _DIRECTIONAL_STRATEGIES:
            entry = signals.get(strategy_name)
            if isinstance(entry, dict):
                direction = entry.get("direction") or entry.get("signal")
                if direction:
                    rules[strategy_name] = {
                        "direction": direction,
                        "strength": entry.get("strength"),
                    }
        if not rules:
            return

        directions = [r["direction"] for r in rules.values()]
        buy_count = directions.count("BUY")
        sell_count = directions.count("SELL")
        majority = None
        if buy_count > sell_count:
            majority = "BUY"
        elif sell_count > buy_count:
            majority = "SELL"

        previous = self._last_majority_direction.get(symbol)
        summary = {
            "symbol": symbol,
            "rules": rules,
            "contributing": len(rules),
            "buy_count": buy_count,
            "sell_count": sell_count,
            "majority": majority,
            "previous_majority": previous,
            "majority_flipped": bool(
                previous is not None and majority is not None and previous != majority),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            summary["timestamp"] = stamp

        self.summaries_published += 1
        await self._context.publish("strategy.exit_rules_summary", summary)

        if majority is not None:
            self._last_majority_direction[symbol] = majority
