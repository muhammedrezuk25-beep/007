from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUTCOME = "market.outcome.realized"
EVENT_CONFIRMED = "execution.confirmed"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "strategy.performance_tracked"

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_RESULTS = "NO_RESULTS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._min_trades = 0
        self._degrade_win_rate = 0.0
        self._stats: dict[tuple[str, int], dict[str, float]] = {}
        self._streaks: dict[tuple[str, int], int] = {}
        self.dropped_count = 0
        self.tracked_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._min_trades = int(cfg["min_trades_for_verdict"])
        self._degrade_win_rate = float(cfg["degraded_win_rate"])
        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("416 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("416 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("416 stopped (tracked=%d)", self.tracked_count)

    async def shutdown(self) -> None:
        await self.stop()

    def performance_of(self, key: tuple[str, int]) -> dict[str, Any]:
        """Performance of one strategy in one account.

        The same strategy in two accounts is measured twice: the accounts
        risk different percentages under different limits, so summing their
        results hides a failure in one under a success in the other.
        """
        entry = self._stats.get(key)
        if entry is None:
            return {}
        account_id, strategy = key
        trades = entry["trades"]
        wins = entry["wins"]
        gross_profit = entry["gross_profit"]
        gross_loss = entry["gross_loss"]
        return {
            "account_id": account_id,
            "strategy": strategy,
            "trades": int(trades),
            "wins": int(wins),
            "losses": int(entry["losses"]),
            "net_pnl": round(entry["net_pnl"], 6),
            "gross_profit": round(gross_profit, 6),
            "gross_loss": round(gross_loss, 6),
            "win_rate": round(wins / trades, 6) if trades else None,
            "profit_factor": (round(gross_profit / gross_loss, 6)
                              if gross_loss else None),
            "average_pnl": round(entry["net_pnl"] / trades, 6) if trades else None,
            "losing_streak": self._streaks.get(key, 0),
            "verdict_ready": trades >= self._min_trades,
        }

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        strategy = _to_int(payload.get("strategy"))
        if strategy is None:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.dropped_count += 1
            return
        key = (str(account_id), strategy)

        entry = self._stats.setdefault(key, {
            "trades": 0.0, "wins": 0.0, "losses": 0.0,
            "net_pnl": 0.0, "gross_profit": 0.0, "gross_loss": 0.0})
        entry["trades"] += 1
        self.tracked_count += 1

        pnl = _to_float(payload.get("pnl"))
        if pnl is not None:
            entry["net_pnl"] += pnl
            if pnl > 0:
                entry["gross_profit"] += pnl
            elif pnl < 0:
                entry["gross_loss"] += abs(pnl)

        result = str(payload.get("result", "")).upper()
        if result == RESULT_WIN:
            entry["wins"] += 1
            self._streaks[key] = 0
        elif result == RESULT_LOSS:
            entry["losses"] += 1
            self._streaks[key] = self._streaks.get(key, 0) + 1

        body = self.performance_of(key)
        body["degrading"] = self._is_degrading(key)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    def _is_degrading(self, key: tuple[str, int]) -> bool:
        entry = self._stats.get(key)
        if entry is None or entry["trades"] < self._min_trades:
            return False
        return (entry["wins"] / entry["trades"]) < self._degrade_win_rate

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._streaks.clear()

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        degrading = ["%s/%d" % k for k in self._stats if self._is_degrading(k)]
        details = {"strategies": len(self._stats), "tracked": self.tracked_count,
                   "degrading": degrading,
                   "performance": {"%s/%d" % k: self.performance_of(k)
                                   for k in self._stats}}
        if not self._stats:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_RESULTS, details=details)
        if degrading:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="underperforming: %s" % degrading,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="strategies=%d tracked=%d" % (
                                len(self._stats), self.tracked_count),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "stats": {"%s|%d" % k: dict(v) for k, v in self._stats.items()},
                "streaks": {"%s|%d" % k: int(v) for k, v in self._streaks.items()},
                "tracked": self.tracked_count,
                "dropped": self.dropped_count}

    async def restore(self, state: dict[str, Any]) -> None:
        def _key(raw: str) -> tuple[str, int]:
            account_id, strategy = raw.split("|", 1)
            return account_id, int(strategy)

        self._stats = {_key(k): dict(v)
                       for k, v in (state.get("stats") or {}).items()}
        self._streaks = {_key(k): int(v)
                         for k, v in (state.get("streaks") or {}).items()}
        self.tracked_count = int(state.get("tracked", 0))
        self.dropped_count = int(state.get("dropped", 0))
