from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom416"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 416

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 416


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _close(ctx, strategy, pnl, result):
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "strategy": strategy, "pnl": pnl,
                                               "result": result, "timestamp": TS})


@pytest.mark.asyncio
async def test_results_accumulate_per_strategy():
    atom, ctx = await _ready()
    await _close(ctx, 410, 100.0, "WIN")
    await _close(ctx, 410, -40.0, "LOSS")
    await _close(ctx, 404, 20.0, "WIN")
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["strategy"] == 404
    assert atom.performance_of(("A", 410))["net_pnl"] == 60.0


@pytest.mark.asyncio
async def test_profit_factor_and_win_rate():
    atom, ctx = await _ready()
    await _close(ctx, 410, 300.0, "WIN")
    await _close(ctx, 410, -100.0, "LOSS")
    view = atom.performance_of(("A", 410))
    assert view["profit_factor"] == 3.0
    assert view["win_rate"] == 0.5


@pytest.mark.asyncio
async def test_no_losses_means_no_profit_factor():
    atom, ctx = await _ready()
    await _close(ctx, 410, 50.0, "WIN")
    assert atom.performance_of(("A", 410))["profit_factor"] is None


@pytest.mark.asyncio
async def test_a_verdict_waits_for_enough_trades():
    """Judging a strategy on two trades is noise. Below the threshold the
    verdict is withheld rather than guessed."""
    atom, ctx = await _ready(min_trades_for_verdict=10)
    for _ in range(3):
        await _close(ctx, 410, -10.0, "LOSS")
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["verdict_ready"] is False
    assert last["degrading"] is False


@pytest.mark.asyncio
async def test_a_losing_strategy_is_flagged_once_judgeable():
    atom, ctx = await _ready(min_trades_for_verdict=5, degraded_win_rate=0.35)
    for _ in range(5):
        await _close(ctx, 410, -10.0, "LOSS")
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["verdict_ready"] is True
    assert last["degrading"] is True


@pytest.mark.asyncio
async def test_a_winning_strategy_is_not_flagged():
    atom, ctx = await _ready(min_trades_for_verdict=5, degraded_win_rate=0.35)
    for _ in range(5):
        await _close(ctx, 410, 10.0, "WIN")
    assert out(ctx, MODULE.EVENT_OUT)[-1]["degrading"] is False


@pytest.mark.asyncio
async def test_a_win_breaks_the_losing_streak():
    atom, ctx = await _ready()
    await _close(ctx, 410, -10.0, "LOSS")
    await _close(ctx, 410, -10.0, "LOSS")
    assert atom.performance_of(("A", 410))["losing_streak"] == 2
    await _close(ctx, 410, 10.0, "WIN")
    assert atom.performance_of(("A", 410))["losing_streak"] == 0


@pytest.mark.asyncio
async def test_an_outcome_without_a_strategy_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "pnl": 10.0, "result": "WIN"})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_a_missing_pnl_still_counts_the_trade():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "strategy": 410, "result": "WIN"})
    assert atom.performance_of(("A", 410))["trades"] == 1
    assert atom.performance_of(("A", 410))["net_pnl"] == 0.0


@pytest.mark.asyncio
async def test_day_roll_clears_streaks_not_totals():
    atom, ctx = await _ready()
    await _close(ctx, 410, -10.0, "LOSS")
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom.performance_of(("A", 410))["losing_streak"] == 0
    assert atom.performance_of(("A", 410))["trades"] == 1


@pytest.mark.asyncio
async def test_health_names_the_degrading_strategies():
    atom, ctx = await _ready(min_trades_for_verdict=3, degraded_win_rate=0.5)
    for _ in range(3):
        await _close(ctx, 404, -5.0, "LOSS")
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert "A/404" in status.details["degrading"]


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _close(ctx, 410, 30.0, "WIN")
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.performance_of(("A", 410))["net_pnl"] == 30.0


# ── الأداء لكل حساب ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_performance_is_kept_per_account():
    """استراتيجية الاتجاه في حسابين تُقاس مرّتين: الحسابان يخاطران
    بنسبتين مختلفتين وحدودهما مختلفة، فجمعُ نتائجهما يخفي فشلًا في
    أحدهما بنجاحٍ في الآخر."""
    atom, ctx = await _ready()
    for acc, pnl in (("A", 100.0), ("B", -50.0)):
        await ctx.handlers["market.outcome.realized"]({"account_id": "A", 
            "account_id": acc, "strategy": 404, "symbol": "USTEC",
            "pnl": pnl, "pnl_pct": pnl / 1000.0,
            "result": "WIN" if pnl > 0 else "LOSS", "timestamp": TS})
    tracked = out(ctx, MODULE.EVENT_OUT)
    by = {t["account_id"]: t for t in tracked}
    assert set(by) == {"A", "B"}


@pytest.mark.asyncio
async def test_an_outcome_without_an_account_is_dropped():
    """Fail Closed — نتيجة بلا حساب تُنسَب لاستراتيجية في حساب لم
    تُنفَّذ فيه."""
    atom, ctx = await _ready()
    await ctx.handlers["market.outcome.realized"]({
        "strategy": 404, "symbol": "USTEC", "pnl": 100.0,
        "result": "WIN", "timestamp": TS})
    assert not out(ctx, MODULE.EVENT_OUT)
