"""اختبارات: 410 ينشر strength و timestamp اللذين يطلبهما 464."""
from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"full_strength_gap_ratio": 0.002}


def _load():
    spec = importlib.util.spec_from_file_location("_atom410", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom410"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 410
    config = CONFIG
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    def __init__(self):
        self.published = []; self.handlers = {}
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready():
    m = _load(); a = m.Atom(); c = Ctx()
    await a.initialize(c); await a.start()
    return m, a, c


def _gap(direction="bullish", low=63000.0, high=63126.0):
    # Every event that reaches an atom has been stamped by core.event_bus,
    # so a realistic inbound payload carries a timestamp. 410 propagates it
    # rather than taking a fresh reading - 464 consumes that field.
    return {"symbol": "BTCUSDT", "direction": direction,
            "gap_low": low, "gap_high": high, "timestamp": 1700000000.5}


@pytest.mark.asyncio
async def test_publishes_strength_and_timestamp():
    """464 يرفض أي إشارة بلا هذين الحقلين."""
    m, a, c = await _ready()
    await a._on_imbalance(_gap())
    p = c.published[-1][1]
    assert "strength" in p and p["timestamp"] == 1700000000.5
    assert p["strength"] is not None
    assert p["timestamp"] > 0


@pytest.mark.asyncio
async def test_wider_gap_gives_higher_strength():
    m, a, c = await _ready()
    await a._on_imbalance(_gap(low=63000.0, high=63031.5))   # 0.05%
    narrow = c.published[-1][1]["strength"]
    await a._on_imbalance(_gap(low=63000.0, high=63094.5))   # 0.15%
    wide = c.published[-1][1]["strength"]
    assert wide > narrow


@pytest.mark.asyncio
async def test_strength_capped_at_one():
    m, a, c = await _ready()
    await a._on_imbalance(_gap(low=63000.0, high=70000.0))
    assert c.published[-1][1]["strength"] == 1.0


@pytest.mark.asyncio
async def test_strength_normalized_by_price_not_absolute():
    """فجوة 10 نقاط على 100 ليست كفجوة 10 نقاط على 60000."""
    m, a, c = await _ready()
    await a._on_imbalance(_gap(low=100.0, high=110.0))       # 10%
    small_price = c.published[-1][1]["strength"]
    await a._on_imbalance(_gap(low=60000.0, high=60010.0))   # 0.017%
    big_price = c.published[-1][1]["strength"]
    assert small_price > big_price


@pytest.mark.asyncio
async def test_missing_gap_gives_null_not_guess():
    """القوة لا تُخمَّن — المستهلك يرفض بلا قوة بدل بناء على رقم مخترع."""
    m, a, c = await _ready()
    await a._on_imbalance({"symbol": "BTCUSDT", "direction": "bullish", "timestamp": 1700000000.5})
    assert c.published[-1][1]["strength"] is None


@pytest.mark.asyncio
async def test_inverted_gap_rejected():
    m, a, c = await _ready()
    await a._on_imbalance(_gap(low=63100.0, high=63000.0))
    assert c.published[-1][1]["strength"] is None


@pytest.mark.asyncio
async def test_original_fields_preserved():
    """إضافة لا حذف — التوافق الرجعي محفوظ."""
    m, a, c = await _ready()
    await a._on_imbalance(_gap())
    p = c.published[-1][1]
    for key in ("symbol", "signal", "gap_low", "gap_high"):
        assert key in p


@pytest.mark.asyncio
async def test_meets_464_threshold():
    """قوة تتجاوز min_liquidity_strength = 0.4 في 464."""
    m, a, c = await _ready()
    await a._on_imbalance(_gap(low=63000.0, high=63063.0))   # 0.1% ⇒ 0.5
    assert c.published[-1][1]["strength"] >= 0.4
