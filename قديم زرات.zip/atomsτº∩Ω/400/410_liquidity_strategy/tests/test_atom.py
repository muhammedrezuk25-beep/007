import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import yaml  # noqa: E402

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom410"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
# الإعداد يُقرأ من المانيفست نفسه لا يُكتب يدويًا هنا — وإلا انحرف الاختبار
# عن العقد الفعلي كما حدث: atom.py يقرأ full_strength_gap_ratio بينما كان
# الاختبار يمرّر config فارغًا فيسقط بـKeyError.
_MANIFEST = _Path(__file__).resolve().parents[1] / "manifest.yaml"
_CONFIG = yaml.safe_load(_MANIFEST.read_text(encoding="utf-8"))["config"]


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=410, config=dict(_CONFIG), logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_bullish_fvg_gives_buy_signal():
    print("\n--- test_bullish_fvg_gives_buy_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_imbalance({"symbol": "NQ", "direction": "bullish", "gap_low": 100, "gap_high": 105, "timestamp": 1700000000.5})
    events = [p for n, p in published if n == "strategy.liquidity.signal"]
    # الحمولة أضافت strength و timestamp في 1.1.0 (يطلبهما 464)، فالمقارنة
    # على الحقول الثابتة لا على تساوٍ تام — timestamp متغيّر بطبيعته.
    assert events[0]["symbol"] == "NQ"
    assert events[0]["signal"] == "BUY"
    assert events[0]["gap_low"] == 100
    assert events[0]["gap_high"] == 105
    assert "strength" in events[0]
    assert events[0]["timestamp"] == 1700000000.5   # inherited, not re-read
    print(f"OK — فجوة صعودية → BUY: {events[0]}")


async def test_bearish_fvg_gives_sell_signal():
    print("\n--- test_bearish_fvg_gives_sell_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_imbalance({"symbol": "NQ", "direction": "bearish", "gap_low": 100, "gap_high": 105, "timestamp": 1700000000.5})
    events = [p for n, p in published if n == "strategy.liquidity.signal"]
    assert events[0]["signal"] == "SELL"
    print(f"OK — فجوة هبوطية → SELL: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_imbalance({"symbol": "NQ", "direction": "bullish", "gap_low": 100, "gap_high": 105, "timestamp": 1700000000.5})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.signals_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_bullish_fvg_gives_buy_signal, test_bearish_fvg_gives_sell_signal, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
