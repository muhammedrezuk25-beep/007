# 410 — Liquidity Strategy (استراتيجية السيولة)

المدخل: `market.imbalance.detected` (255 — **معتمَدة فعليًا**). فجوة
(FVG) = منطقة دعم/مقاومة متوقَّعة — Bullish→BUY، Bearish→SELL.

⚠️ مختلفة عن 407 عمدًا: تلك تعتمد على اكتساح سيولة فعلي (254)، هذه
على فجوة سعرية غير مُختبرة (255) — مفهومان مختلفان بالـSMC.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
3 اختبارات: FVG صعودية→BUY، هبوطية→SELL، `snapshot`/`restore`.
**نتيجة: 3/3.**
