"""
410 — استراتيجية السيولة (Liquidity Strategy)

يشترك: market.imbalance.detected (255 — معتمَدة فعليًا). ينشر:
strategy.liquidity.signal.

منطق SMC مُستنتَج: الفجوة (FVG) تُعامَل كمنطقة دعم/مقاومة متوقَّعة
— السعر يميل للعودة نحوها ويحترمها. Bullish FVG (فجوة صعودية) → BUY
(السوق مرشَّح يعود يختبر الفجوة كدعم ويستمر صاعدًا). Bearish FVG →
SELL. مختلفة عن 407 عمدًا (تلك تعتمد على اكتساح سيولة فعلي 254،
هذه على فجوة سعرية غير مُختبرة بعد 255 — مفهومان مختلفان بالـSMC).
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin. When the inbound event carries none, the key is omitted and
    core.event_bus stamps it via setdefault - stamped once, never invented.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SIGNAL_MAP = {"bullish": "BUY", "bearish": "SELL"}


def _to_float(value):
    """يرفض NaN كما يرفض غير الرقمي — NaN يجتاز كل مقارنة صامتاً."""
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0
        self._full_strength_ratio = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._full_strength_ratio = float(context.config["full_strength_gap_ratio"])
        context.subscribe("market.imbalance.detected", self._on_imbalance)
        context.logger.info("LiquidityStrategy(410) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("LiquidityStrategy(410) بدأ الاستماع لـ255")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    @staticmethod
    def _gap_strength(gap_low, gap_high) -> float | None:
        """قوة الإشارة من اتساع الفجوة نسبةً إلى سعرها.

        فجوة أوسع تعني اختلالاً أقوى. النسبة تُطبَّع على نطاق معلن في
        config كي لا يتغيّر المقياس بتغيّر سعر الأداة — فجوة 10 نقاط
        على 100 ليست كفجوة 10 نقاط على 60000.

        بلا حدّي الفجوة تُرجَع None: القوة لا تُخمَّن، والمستهلك يرفض
        الإشارة بلا قوة بدل أن يبني على رقم مخترع."""
        low = _to_float(gap_low)
        high = _to_float(gap_high)
        if low is None or high is None or low <= 0 or high <= low:
            return None
        return (high - low) / low

    async def _on_imbalance(self, payload: dict) -> None:
        if self._context is None:
            return
        signal = _SIGNAL_MAP.get(payload["direction"])
        if signal is None:
            return

        gap_low = payload.get("gap_low")
        gap_high = payload.get("gap_high")
        ratio = self._gap_strength(gap_low, gap_high)
        strength = (None if ratio is None
                    else round(min(1.0, ratio / self._full_strength_ratio), 4))

        self.signals_published += 1
        await self._context.publish(
            "strategy.liquidity.signal",
            {
                "symbol": payload.get("symbol"),
                # direction هو الحقل القانوني في العقد الموحّد للاستراتيجيات؛
                # signal يبقى للتوافق مع من كان يقرؤه.
                "direction": signal,
                "signal": signal,
                "gap_low": gap_low,
                "gap_high": gap_high,
                # الحقلان مطلب 464: يرفض إشارة بلا قوة أو بلا طابع زمني.
                # إضافة لا حذف — التوافق الرجعي محفوظ.
                "strength": strength,
                **_ts_from(payload),
            },
        )
