from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "strategy.unified"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRAFFIC = "NO_STRATEGY_TRAFFIC"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._watch: list[str] = []
        self._sections: dict[str, dict[str, Any]] = {}
        self._counts: dict[str, int] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._watch = [str(e) for e in context.config["watch_events"]]
        for event in self._watch:
            context.subscribe(event, self._make_collector(event))
        self._initialized = True
        context.logger.info("400 initialised watching %d events", len(self._watch))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("400 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("400 stopped (published=%d)", self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _make_collector(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._collect(event_name, payload)
        return handler

    async def _collect(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        self._sections[event_name] = dict(inner)
        self._counts[event_name] = self._counts.get(event_name, 0) + 1
        self.published_count += 1

        directions: dict[str, int] = {}
        for name, section in self._sections.items():
            direction = section.get("direction") or section.get("signal")
            if isinstance(direction, str):
                directions[direction] = directions.get(direction, 0) + 1

        body: dict[str, Any] = {
            "latest": event_name,
            "sections": {k: dict(v) for k, v in self._sections.items()},
            "counts": dict(self._counts),
            "direction_tally": directions,
        }
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        silent = [e for e in self._watch if e not in self._sections]
        details = {"watching": len(self._watch), "seen": len(self._sections),
                   "silent": silent, "counts": dict(self._counts)}
        if not self._sections:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRAFFIC, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="seen %d/%d" % (len(self._sections), len(self._watch)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "sections": dict(self._sections),
                "counts": dict(self._counts), "published": self.published_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._sections = dict(state.get("sections") or {})
        self._counts = {str(k): int(v) for k, v in (state.get("counts") or {}).items()}
        self.published_count = int(state.get("published", 0))
