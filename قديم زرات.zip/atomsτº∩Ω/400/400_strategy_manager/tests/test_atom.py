from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom400"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 400

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 400


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_it_keeps_the_latest_signal_of_each_strategy():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"symbol": "NQ", "direction": "BUY"})
    await ctx.handlers["strategy.liquidity.signal"]({"symbol": "NQ", "direction": "SELL"})
    view = out(ctx, MODULE.EVENT_OUT)[-1]
    assert set(view["sections"]) == {"strategy.trend.signal", "strategy.liquidity.signal"}


@pytest.mark.asyncio
async def test_the_direction_tally_counts_the_sides():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY"})
    await ctx.handlers["strategy.momentum.signal"]({"direction": "BUY"})
    await ctx.handlers["strategy.range.signal"]({"direction": "SELL"})
    tally = out(ctx, MODULE.EVENT_OUT)[-1]["direction_tally"]
    assert tally == {"BUY": 2, "SELL": 1}


@pytest.mark.asyncio
async def test_it_publishes_nothing_of_its_own():
    """A collector republishes; the tally is a count of what arrived, not a
    verdict. 413 merges and 450 decides."""
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY"})
    assert {n for n, _ in ctx.published} == {MODULE.EVENT_OUT}


@pytest.mark.asyncio
async def test_a_repeated_signal_overwrites():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY"})
    await ctx.handlers["strategy.trend.signal"]({"direction": "SELL"})
    view = out(ctx, MODULE.EVENT_OUT)[-1]
    assert view["direction_tally"] == {"SELL": 1}
    assert view["counts"]["strategy.trend.signal"] == 2


@pytest.mark.asyncio
async def test_health_names_the_silent_strategies():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY"})
    details = (await atom.health_check()).details
    assert "strategy.liquidity.signal" in details["silent"]


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY", "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_OUT)[0]["timestamp"] == 55.0


@pytest.mark.asyncio
async def test_snapshot_carries_the_sections():
    atom, ctx = await _ready()
    await ctx.handlers["strategy.trend.signal"]({"direction": "BUY"})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._sections["strategy.trend.signal"]["direction"] == "BUY"
