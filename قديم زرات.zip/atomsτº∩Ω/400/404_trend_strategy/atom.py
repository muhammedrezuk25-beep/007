"""
404 — استراتيجية الاتجاه (Trend Strategy)

يشترك: market.trend.changed (207 — معتمَدة فعليًا). ينشر:
strategy.trend.signal.

منطق مُستنتَج: UPTREND → BUY، DOWNTREND → SELL، RANGE/TRANSITION
→ **بلا إشارة إطلاقًا** (استراتيجية اتجاهية بطبيعتها — لا تتداول
بغياب اتجاه واضح، صمت أفضل من إشارة كاذبة). تقرر لحالها من مدخلاتها
الخاصة فقط (قاعدة 10 المؤكَّدة: كل استراتيجية مستقلة تمامًا).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SIGNAL_MAP = {"UPTREND": "BUY", "DOWNTREND": "SELL"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.trend.changed", self._on_trend_changed)
        context.logger.info("TrendStrategy(404) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TrendStrategy(404) بدأ الاستماع لـ207")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_trend_changed(self, payload: dict) -> None:
        if self._context is None:
            return
        signal = _SIGNAL_MAP.get(payload["state"])
        if signal is None:
            return  # RANGE/TRANSITION — صمت متعمَّد، لا إشارة كاذبة

        self.signals_published += 1
        await self._context.publish(
            "strategy.trend.signal",
            # direction هو الحقل القانوني في العقد الموحّد؛ signal يبقى
            # للتوافق مع من كان يقرؤه. strength غائبة عمدًا: حالة الاتجاه
            # تصنيفية، وقوّتها تحتاج تاريخ ثباتها — لا تحتفظ به هذه الذرة.
            {"symbol": payload.get("symbol"), "direction": signal, "signal": signal,
             "source_trend_state": payload["state"], **_ts_from(payload)}
        )
