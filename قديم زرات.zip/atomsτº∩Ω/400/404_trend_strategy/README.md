# 404 — Trend Strategy (استراتيجية الاتجاه)

المدخل: `market.trend.changed` (207 — **معتمَدة فعليًا**). UPTREND→BUY،
DOWNTREND→SELL، RANGE/TRANSITION→صمت متعمَّد (لا إشارة كاذبة).

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
4 اختبارات: UPTREND، DOWNTREND، RANGE+TRANSITION (صمت)،
`snapshot`/`restore`. **نتيجة: 4/4.**
