import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom404"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=404, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_uptrend_gives_buy_signal():
    print("\n--- test_uptrend_gives_buy_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
    events = [p for n, p in published if n == "strategy.trend.signal"]
    _required = {"symbol": "NQ", "signal": "BUY", "source_trend_state": "UPTREND"}
    for _k, _v in _required.items():
        assert events[0][_k] == _v
    print(f"OK — UPTREND → BUY: {events[0]}")


async def test_downtrend_gives_sell_signal():
    print("\n--- test_downtrend_gives_sell_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "DOWNTREND"})
    events = [p for n, p in published if n == "strategy.trend.signal"]
    assert events[0]["signal"] == "SELL"
    print(f"OK — DOWNTREND → SELL: {events[0]}")


async def test_range_and_transition_give_no_signal():
    print("\n--- test_range_and_transition_give_no_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "RANGE"})
    await atom._on_trend_changed({"symbol": "NQ", "state": "TRANSITION"})
    events = [p for n, p in published if n == "strategy.trend.signal"]
    assert len(events) == 0, "بلا اتجاه واضح — صمت متعمَّد، لا إشارة كاذبة"
    print("OK — RANGE وTRANSITION → صفر إشارة (صمت متعمَّد)")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.signals_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_uptrend_gives_buy_signal, test_downtrend_gives_sell_signal, test_range_and_transition_give_no_signal, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
