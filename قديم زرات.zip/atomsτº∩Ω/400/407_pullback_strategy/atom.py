"""
407 — استراتيجية الارتداد (Pullback Strategy)

يشترك: market.sweep.detected (254 — **معتمَدة فعليًا الآن، بُنيت
بالجلسة السابقة مباشرة**). ينشر: strategy.pullback.signal.

منطق SMC قياسي مُستنتَج: اكتساح سيولة جهة الشراء (فوق قمم سابقة)
= "شفط سيولة" (Liquidity Grab) يسبق غالبًا ارتدادًا **هبوطيًا** —
direction="buy_side" → SELL. اكتساح جهة البيع (تحت قيعان سابقة) يسبق
ارتدادًا **صعوديًا** — direction="sell_side" → BUY. (عكس اتجاه
الاكتساح نفسه — هذا هو جوهر "الارتداد" بعد شفط السيولة).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _strength(payload: dict, full_pct: float) -> dict:
    level = payload.get("level", payload.get("price"))
    penetration = payload.get("penetration")
    if not isinstance(level, (int, float)) or level == 0:
        return {}
    if not isinstance(penetration, (int, float)):
        current = payload.get("current_price")
        if not isinstance(current, (int, float)):
            return {}
        penetration = abs(current - level)
    depth_pct = abs(penetration) / abs(level) * 100.0
    return {"strength": min(depth_pct / full_pct, 1.0) if full_pct > 0 else 1.0,
            "sweep_depth_pct": round(depth_pct, 6)}

def _ts_from(payload: dict) -> dict:
    """يورّث طابع الحدث الوارد ولا يقرأ ساعة.

    العقد الموحّد للاستراتيجيات يفرض timestamp، و3 و806 وحدهما يقرآن
    الساعة هنا. وحين لا يحمل الوارد طابعًا يُترك الحقل: core.event_bus
    يختمه مرّة واحدة، فلا يُخترع زمن في أي نقطة وسطى.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SIGNAL_MAP = {"buy_side": "SELL", "sell_side": "BUY"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._full_pct = float(context.config["full_strength_sweep_pct"])
        context.subscribe("market.sweep.detected", self._on_sweep)
        context.logger.info("PullbackStrategy(407) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("PullbackStrategy(407) بدأ الاستماع لـ254")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_sweep(self, payload: dict) -> None:
        if self._context is None:
            return
        signal = _SIGNAL_MAP.get(payload["direction"])
        if signal is None:
            return

        self.signals_published += 1
        await self._context.publish(
            "strategy.pullback.signal",
            # strength غائبة: عمق الاكتساح يحتاج المستوى المُكتسَح، و254
            # يرسل السعر وحده. تُضاف حين يرسل 254 حقل level.
            {"symbol": payload.get("symbol"), "direction": signal, "signal": signal,
             "swept_price": payload.get("price"),
             **_strength(payload, self._full_pct), **_ts_from(payload)}
        )
