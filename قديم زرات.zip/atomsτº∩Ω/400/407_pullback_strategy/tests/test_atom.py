import asyncio
import inspect
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom407"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
import yaml as _yaml  # noqa: E402
from pathlib import Path as _MP  # noqa: E402
_CONFIG = _yaml.safe_load(
    (_MP(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=407, config=dict(_CONFIG), logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_buy_side_sweep_gives_sell_signal():
    print("\n--- test_buy_side_sweep_gives_sell_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side", "price": 110})
    events = [p for n, p in published if n == "strategy.pullback.signal"]
    # Field-by-field, not an exact match: the unified strategy contract
    # added direction, timestamp and strength, and an exact comparison
    # breaks on every legitimate extension.
    _expected = {"symbol": "NQ", "signal": "SELL", "swept_price": 110}
    for _k, _v in _expected.items():
        assert events[0][_k] == _v
    print(f"OK — اكتساح جهة الشراء (شفط فوق قمم) → SELL (ارتداد هبوطي متوقَّع): {events[0]}")


async def test_sell_side_sweep_gives_buy_signal():
    print("\n--- test_sell_side_sweep_gives_buy_signal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "sell_side", "price": 90})
    events = [p for n, p in published if n == "strategy.pullback.signal"]
    assert events[0]["signal"] == "BUY"
    print(f"OK — اكتساح جهة البيع (شفط تحت قيعان) → BUY (ارتداد صعودي متوقَّع): {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side", "price": 110})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.signals_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def test_compatible_with_254_documented_payload_shape():
    """إصلاح مخالفة دستورية حقيقية: النسخة السابقة من هذا الاختبار
    كانت تستورد كود 254 مباشرة (import atom_xxx) — مخالفة صريحة
    للمادة 15/16 (يحظر الاستدعاء المباشر لذرة أخرى)، حتى لو بملف
    اختبار بس (المادة 12 تعتبر الاختبارات جزء من الذرة). الحل
    الصحيح دستوريًا: نتحقق من التوافق عبر حدث مُصطنَع **مطابق حرفيًا**
    للشكل الموثَّق لمخرجات 254 (بلا أي استيراد لكودها الفعلي) —
    هذا بالضبط ما يفترضه العقد عبر Event Bus أصلًا (المادة 18: الذرة
    تعرف محتوى الحدث بس، لا مصدره)."""
    print("\n--- test_compatible_with_254_documented_payload_shape ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # الشكل الموثَّق حرفيًا بـ254/README.md وmanifest.yaml: {symbol, direction, price}
    documented_254_shape = {"symbol": "NQ", "direction": "sell_side", "price": 21000.0}
    await atom._on_sweep(documented_254_shape)
    events = [p for n, p in published if n == "strategy.pullback.signal"]
    assert len(events) == 1
    assert events[0]["signal"] == "BUY"
    print(f"OK — توافق مؤكَّد مع الشكل الموثَّق لـ254، بلا أي استيراد مباشر لكودها: {events[0]}")


async def main():
    tests = [
        test_buy_side_sweep_gives_sell_signal,
        test_sell_side_sweep_gives_buy_signal,
        test_snapshot_restore,
        test_compatible_with_254_documented_payload_shape,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


async def test_strength_scales_with_sweep_depth():
    """Price that barely pierced the pool is a weaker pullback signal than one
    that ran far past it before turning."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side",
                          "price": 100.0, "level": 100.0, "penetration": 0.02})
    shallow = [p for n, p in published if n == "strategy.pullback.signal"][0]

    context2, published2 = make_context()
    atom2 = Atom()
    await atom2.initialize(context2)
    await atom2._on_sweep({"symbol": "NQ", "direction": "buy_side",
                           "price": 100.0, "level": 100.0, "penetration": 0.1})
    deep = [p for n, p in published2 if n == "strategy.pullback.signal"][0]
    assert deep["strength"] > shallow["strength"]


async def test_penetration_is_derived_when_absent():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side",
                          "price": 100.0, "level": 100.0, "current_price": 100.1})
    assert [p for n, p in published][0]["strength"] > 0


async def test_strength_is_capped_at_one():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side",
                          "price": 100.0, "level": 100.0, "penetration": 50.0})
    assert [p for n, p in published][0]["strength"] == 1.0


async def test_no_level_means_no_strength():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side", "price": 0})
    assert "strength" not in [p for n, p in published][0]


async def test_unknown_direction_publishes_nothing():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "nowhere", "price": 100.0})
    assert published == []


async def test_lifecycle_is_reversible():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom.start()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert (await atom.health_check()) is not None


async def test_snapshot_restore_round_trip():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sweep({"symbol": "NQ", "direction": "buy_side",
                          "price": 100.0, "level": 100.0, "penetration": 0.05})
    snap = await atom.snapshot()
    fresh = Atom()
    await fresh.initialize(make_context()[0])
    if snap is not None:
        await fresh.restore(snap)
    assert True
