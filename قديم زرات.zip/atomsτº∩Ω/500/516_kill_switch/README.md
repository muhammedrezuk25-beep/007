# 516 — Kill Switch (إدارة المخاطر) — v2.0.0

**أهم ذرة أمانًا بكل المشروع.** توسعة كاملة عن v1 — قفل نهائي قسم 500.

## توصيتي الصريحة لإعادة التفعيل (كانت النقطة المفتوحة الوحيدة)

**يدوي فقط، بلا استثناء حسب السبب.** بمجرد `kill_switch_state=true`،
تبقى `true` حتى `risk.kill_switch.reset_requested` صريح من مشغّل —
**لا** مسار تلقائي بيوم جديد، **لا** مسار تلقائي بزوال السبب. مُختبَر
صراحة: يوم جديد يصفّر `daily_loss_pct` بس، **لا** `kill_switch_state`.
السبب: أتمتة إعادة تفعيل أخطر لحظة بالنظام بدون تأكيد بشري إن المشكلة
الحقيقية (لا مجرد رقم) انحلّت — معيار قياسي بأي Circuit Breaker حقيقي.

## رأس المال المرجعي — Equity الحالية

توثيقي لهذه الذرة تحديدًا — 516 يستقبل `loss_pct` جاهزة، لا يحسبها من
رقم خام. الالتزام يقع على ناشر `risk.loss_reported`، مسجَّل بـ
`metadata.reference_capital` للتوثيق.

## تفكيك: Halt شامل مقابل رفض تحقق بس

| السبب | الأثر |
|---|---|
| `RISK_DAILY_LIMIT` / `RISK_SYSTEM_LIMIT` / `RISK_STRATEGY_LIMIT` / `MAX_CONSECUTIVE_LOSSES` | `emergency.halt` شامل فعلي |
| `MAX_DAILY_TRADES` / `MAX_OPEN_TRADES` | رفض `risk.validation.requested` بس — **صفر تأثير على صفقات قائمة** |
| `KILL_SWITCH` | رفض أي طلب جديد طالما `kill_switch_state=true` |

سقف عدد الصفقات ليس خطرًا مباشرًا على المركز القائم — رفض طلبات جديدة
كافٍ، مُختبَر صراحة (صفر `emergency.halt` عند تجاوز `max_daily_trades`).

## ⚠️ `MAX_CONSECUTIVE_LOSSES` — بدون رمز قياسي صريح بقائمتك

استُخدِم بنفس نمط تسمية الأسباب العشرة (`MAX_*`) — صحّحه لو قصدك رمزًا
مختلفًا لهذا البُعد تحديدًا.

## ⚠️ ثلاثة حدود مُخزَّنة فقط، بلا فحص فعلي

`max_exposure_pct`/`max_leverage`/`max_margin_usage_pct` بالـ`config`
لكن **لا مصدر حدث حي** يزوّد 516 بقيمها اللحظية بعد. تحتاج ذرة/حدث
منفصل (من 600/611 مثلاً) قبل تفعيلها عمليًا.

## `snapshot()` — مطابق حرفيًا للسبك المُعطى

9 حقول بالضبط: `daily_loss_pct`، `system_loss_pct`، `strategy_loss_pct`،
`daily_trade_count`، `open_trade_count`، `consecutive_losses`،
`kill_switch_state`، `kill_switch_reason`، `day_index`.

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

11 اختبارًا: رموز الأسباب القياسية، 3 خسائر متتالية → halt، صفقة
رابحة تصفّر العدّاد، تتبّع عدد الصفقات اليومية/المفتوحة بدقّة، تحقّق
مقبول عند النظافة، رفض `MAX_DAILY_TRADES`/`MAX_OPEN_TRADES` بلا halt
شامل، رفض `KILL_SWITCH` لأي طلب بعد تفعيل الحالة، **بقاء الحالة عبر
يوم جديد (يدوي فقط)**، **اختبار الانحدار للسيناريو الحرج الأصلي
(1.9%+Restart+0.2%=2.1%)**، وجولة `snapshot`/`restore` لكل الحقول
التسعة. **نتيجة آخر تشغيل: 11/11.**
