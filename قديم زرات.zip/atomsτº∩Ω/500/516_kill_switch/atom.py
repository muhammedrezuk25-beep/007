"""
516 — Kill Switch (إدارة المخاطر) — v2، توسعة القفل النهائي لقسم 500

آلية: subscribe فقط، critical: true.

افتراضات أحداث صريحة (لا سبك أعطى الاسم/الشكل الدقيق):
  - risk.loss_reported {loss_pct, atom_id|None}
  - trade.opened {atom_id|None}
  - trade.closed {atom_id|None, pnl_pct}  — pnl_pct سالب = خسارة (يزيد
    consecutive_losses)، موجب/صفر = ربح (يصفّره)
  - risk.validation.requested {request_id, atom_id|None}
  - risk.kill_switch.reset_requested {operator, reason} — إعادة تفعيل يدوية فقط

رأس المال المرجعي (Equity الحالية، لا Balance ولا HWM): توثيقي
لهذه الذرة — 516 لا يحسب %من رقم خام، يستقبل loss_pct جاهزة من
الناشر. المُلزَم فعليًا بهالقاعدة هو مَن ينشر risk.loss_reported، لا
516 نفسها — مُسجَّلة هنا للتوثيق فقط.

تفكيك خطر مباشر (emergency.halt) عن سقف سياسة (رفض تحقق بس):
RISK_DAILY_LIMIT/RISK_SYSTEM_LIMIT/RISK_STRATEGY_LIMIT/
MAX_CONSECUTIVE_LOSSES → halt شامل فعلي. MAX_DAILY_TRADES/
MAX_OPEN_TRADES → رفض طلبات جديدة فقط (risk.validation.completed)،
بلا إيقاف صفقات قائمة — مجرد سقف عدد، لا خطر مباشر.

MAX_CONSECUTIVE_LOSSES ليست برمز قياسي صريح بقائمتك (10 أسباب) —
استُخدِمت بنفس نمط التسمية (MAX_*)، صحّحها لو قصدك رمزًا مختلفًا.

max_exposure_pct/max_leverage/max_margin_usage_pct: تُخزَّن بـ
config فقط، **بلا فحص فعلي هنا** — لا مصدر حدث حي يزوّد 516 بهالقيم
لحظيًا بعد. تحتاج ذرة/حدث منفصل يوفّرها قبل تفعيل هالثلاثة عمليًا.

إعادة التفعيل: **يدوي فقط، بلا استثناء حسب السبب** (توصيتي
الصريحة لنقطة 4 المفتوحة — راجع الرد المرافق). بمجرد kill_switch_state
= true، تبقى true حتى risk.kill_switch.reset_requested صريح — لا
مسار تلقائي بيوم جديد ولا بزوال سبب.
"""

from __future__ import annotations

from typing import Any

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _reset_stamp(payload: dict) -> dict:
    """reset_at is the instant the operator asked, not the instant we handled it."""
    ts = payload.get("timestamp")
    return {"reset_at": ts} if isinstance(ts, (int, float)) else {}


_SOURCE_ATOM_ID = 516


def _atom_key(value: Any) -> int | None:
    """Strategy identity is an integer everywhere in the registry, but
    atom_id crosses the bus inside a JSON payload and can arrive as "404".
    In Python "404" != 404, so a string id looked up nothing: the limits
    dict returned None and the per-strategy halt never fired. A strategy
    could lose the whole account and this atom would not stop it.

    Normalising here, at the single point where the id enters, keeps every
    lookup and every accumulator on one key type.
    """
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None

        # الحدود
        self._daily_loss_limit_pct = 2.0
        self._system_loss_limit_pct = 3.0
        self._strategy_loss_limits: dict[int, float] = {}
        self._max_consecutive_losses = 3
        self._max_daily_trades = 10
        self._max_open_trades = 3
        # مخزَّنة فقط، بلا فحص فعلي (راجع docstring)
        self._max_exposure_pct = 20.0
        self._max_leverage = 10.0
        self._max_margin_usage_pct = 50.0

        self._day_index = int(time.time() // 86400)
        self._daily_loss_pct = 0.0
        self._system_loss_pct = 0.0
        self._strategy_loss_pct: dict[int, float] = {}
        self._daily_trade_count = 0
        self._open_trade_count = 0
        self._consecutive_losses = 0
        self._external_breaches: dict[str, dict] = {}
        self._max_state_divergence_pct = 0.0
        self._diverged = False
        self.divergence_count = 0
        self._halted_accounts: dict[str, str] = {}
        self._halted_pairs: dict[tuple[str, str], str] = {}
        self._kill_switch_state = False
        self._kill_switch_reason: str | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._daily_loss_limit_pct = float(context.config.get("daily_loss_limit_pct", 2.0))
        self._system_loss_limit_pct = float(context.config.get("system_loss_limit_pct", 3.0))
        self._max_consecutive_losses = int(context.config.get("max_consecutive_losses", 3))
        self._max_daily_trades = int(context.config.get("max_daily_trades", 10))
        # بنمط بقيّة مفاتيح هذه الذرّة: افتراضي عند الغياب. وهي حرجة —
        # لا تسقط لأجل مفتاح إعداد، فالإيقاف أهمّ من التقاطع.
        self._max_state_divergence_pct = float(
            context.config.get("max_state_divergence_pct", 0.25))
        self._max_open_trades = int(context.config.get("max_open_trades", 3))
        self._max_exposure_pct = float(context.config.get("max_exposure_pct", 20.0))
        self._max_leverage = float(context.config.get("max_leverage", 10.0))
        self._max_margin_usage_pct = float(context.config.get("max_margin_usage_pct", 50.0))
        raw_limits = context.config.get("strategy_loss_limits", {})
        self._strategy_loss_limits = {int(k): float(v) for k, v in raw_limits.items()}

        context.subscribe("risk.loss_reported", self._on_loss_reported)
        context.subscribe("trade.opened", self._on_trade_opened)
        context.subscribe("trade.closed", self._on_trade_closed)
        # نتيجة الصفقة المحسوبة من 517 — trade.closed لا يحملها
        context.subscribe("market.outcome.realized", self._on_outcome)
        context.subscribe("SYS_DAY", self._on_day)
        context.subscribe("risk.limit.hit", self._on_limit_hit)
        context.subscribe("risk.unified", self._on_section_state)
        context.subscribe("risk.validation.requested", self._on_validation_requested)
        context.subscribe("risk.kill_switch.reset_requested", self._on_reset_requested)

        context.logger.info("KillSwitch(516) تمت تهيئته — critical")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("KillSwitch(516) بدأ الاستماع — kill_switch_state=%s", self._kill_switch_state)

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        self._maybe_roll_day()
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=(
                f"kill_switch={self._kill_switch_state} day={self._day_index} "
                f"daily_loss={self._daily_loss_pct:.2f}%/{self._daily_loss_limit_pct}% "
                f"consecutive_losses={self._consecutive_losses}/{self._max_consecutive_losses} "
                f"daily_trades={self._daily_trade_count}/{self._max_daily_trades} "
                f"open_trades={self._open_trade_count}/{self._max_open_trades}"
            ),
        )

    async def snapshot(self) -> dict:
        return {
            "daily_loss_pct": self._daily_loss_pct,
            "system_loss_pct": self._system_loss_pct,
            "strategy_loss_pct": dict(self._strategy_loss_pct),
            "daily_trade_count": self._daily_trade_count,
            "open_trade_count": self._open_trade_count,
            "consecutive_losses": self._consecutive_losses,
            "external_breaches": dict(self._external_breaches),
            "kill_switch_state": self._kill_switch_state,
            "kill_switch_reason": self._kill_switch_reason,
            "day_index": self._day_index,
        }

    async def restore(self, state: dict) -> None:
        self._daily_loss_pct = state.get("daily_loss_pct", 0.0)
        self._system_loss_pct = state.get("system_loss_pct", 0.0)
        self._strategy_loss_pct = {int(k): v for k, v in state.get("strategy_loss_pct", {}).items()}
        self._daily_trade_count = state.get("daily_trade_count", 0)
        self._open_trade_count = state.get("open_trade_count", 0)
        self._consecutive_losses = state.get("consecutive_losses", 0)
        self._external_breaches = dict(state.get("external_breaches") or {})
        self._kill_switch_state = state.get("kill_switch_state", False)
        self._kill_switch_reason = state.get("kill_switch_reason")
        self._day_index = state.get("day_index", int(time.time() // 86400))

    # ------------------------------------------------------------------ الزمن

    def _maybe_roll_day(self) -> None:
        current_day = int(time.time() // 86400)
        if current_day != self._day_index:
            self._day_index = current_day
            self._daily_loss_pct = 0.0
            self._strategy_loss_pct = {}
            self._daily_trade_count = 0
            # kill_switch_state عمدًا لا يتصفّر هون — يدوي فقط بلا استثناء

    # ------------------------------------------------------------------ خسائر

    async def _on_loss_reported(self, payload: dict) -> None:
        self._maybe_roll_day()
        loss_pct = float(payload.get("loss_pct", 0.0))
        atom_id = _atom_key(payload.get("atom_id"))

        self._daily_loss_pct += loss_pct
        self._system_loss_pct += loss_pct
        if atom_id is not None:
            self._strategy_loss_pct[atom_id] = self._strategy_loss_pct.get(atom_id, 0.0) + loss_pct

        if self._daily_loss_pct >= self._daily_loss_limit_pct:
            await self._trigger_halt(None, "RISK_DAILY_LIMIT", self._daily_loss_pct,
                                     self._daily_loss_limit_pct, payload.get("timestamp"))
        if self._system_loss_pct >= self._system_loss_limit_pct:
            await self._trigger_halt(None, "RISK_SYSTEM_LIMIT", self._system_loss_pct,
                                     self._system_loss_limit_pct, payload.get("timestamp"))
        if atom_id is not None:
            limit = self._strategy_loss_limits.get(atom_id)
            current = self._strategy_loss_pct.get(atom_id, 0.0)
            if limit is not None and current >= limit:
                await self._trigger_halt([atom_id], "RISK_STRATEGY_LIMIT", current, limit,
                                         payload.get("timestamp"))

    # ------------------------------------------------------------------ صفقات

    async def _on_trade_opened(self, payload: dict) -> None:
        self._maybe_roll_day()
        self._daily_trade_count += 1
        self._open_trade_count += 1

    async def _on_trade_closed(self, payload: dict) -> None:
        """عدد المراكز المفتوحة فقط.

        الربح والخسارة لا يُقرآن من هنا: 563 ينقل صفوف trade_events كما هي،
        والجدول يحمل سعر الدخول والخروج لا نتيجة محسوبة. فكان
        payload.get("pnl_pct", 0.0) يعطي صفرًا دائمًا، وصفر ليس خسارة —
        فبقي عدّاد الخسائر المتتالية على صفر مهما توالت الخسائر.
        الحساب عند 517، ويصل عبر market.outcome.realized أدناه.
        """
        self._open_trade_count = max(0, self._open_trade_count - 1)

    async def _on_outcome(self, payload: dict) -> None:
        """نتيجة الصفقة كما حسبها 517 — هنا يُعدّ التتابع.

        يُعتمد على حقل result لا على إشارة الرقم: صفقة التعادل ليست خسارة،
        وقراءة pnl < 0 وحدها تعدّها ربحًا فتصفّر التتابع في غير موضعه.
        """
        result = str(payload.get("result", "")).upper()
        if result == "LOSS":
            self._consecutive_losses += 1
            if self._consecutive_losses >= self._max_consecutive_losses:
                await self._trigger_halt(
                    None, "MAX_CONSECUTIVE_LOSSES", self._consecutive_losses,
                    self._max_consecutive_losses, payload.get("timestamp")
                )
        elif result == "WIN":
            self._consecutive_losses = 0

    # ------------------------------------------------------------------ تحقّق طلبات جديدة

    async def _on_day(self, payload: dict) -> None:
        """Daily counters roll on the day event from 806, never on a local
        clock reading. Without this subscription the daily loss limit was
        cumulative across days and tripped permanently once reached.

        The kill switch itself is not cleared here: it is re-armed by an
        explicit human act only.
        """
        self._daily_loss_pct = 0.0
        self._daily_trade_count = 0
        self._consecutive_losses = 0
        self._external_breaches.clear()
        if self._context is not None:
            self._context.logger.info("516 daily counters rolled")

    async def _on_section_state(self, payload: dict) -> None:
        """Cross-checks 500's daily loss against this atom's own.

        The two are computed independently from the same events, and that
        duplication is deliberate: this atom is critical, and taking the
        figure from 500 would mean 500's failure disables the halt. So it is
        not merged.

        But the disagreement is not swallowed. It is the only evidence
        available that an event went missing between them — one lost loss
        report left the two 0.90 points apart on a measured run, and this is
        the atom that stops trading. The number stays this atom's own; only
        the gap is announced.
        """
        if self._context is None:
            return
        section = payload.get("daily_loss_pct")
        if not isinstance(section, (int, float)):
            return
        gap = abs(float(section) - self._daily_loss_pct)
        if gap <= self._max_state_divergence_pct:
            self._diverged = False
            return
        if self._diverged:
            return
        self._diverged = True
        self.divergence_count += 1
        stamp = payload.get("timestamp")
        body = {"mine": round(self._daily_loss_pct, 6),
                "section": round(float(section), 6),
                "gap": round(gap, 6),
                "limit": self._max_state_divergence_pct,
                "source_atom": _SOURCE_ATOM_ID}
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish("risk.state.diverged", body)
        self._context.logger.warning(
            "516 يختلف عن 500 في الخسارة اليومية: %.4f مقابل %.4f",
            self._daily_loss_pct, float(section))

    async def _on_limit_hit(self, payload: dict) -> None:
        """Breaches reported by 506, 507 and 508.

        They compute, this atom enforces. A breach blocks new orders through
        _on_validation_requested; it does not trip the kill switch, which stays
        reserved for the loss limits this atom owns directly.
        """
        reason = payload.get("reason")
        if not reason:
            return
        reason = str(reason)
        account_id = payload.get("account_id")
        symbol = payload.get("symbol")
        self._external_breaches[reason] = {
            "value": payload.get("value"),
            "limit": payload.get("limit"),
            "symbol": symbol,
            "account_id": account_id,
        }
        if self._context is not None:
            self._context.logger.warning(
                "516 recorded external breach %s (value=%s limit=%s)",
                reason, payload.get("value"), payload.get("limit"))

        if account_id in (None, ""):
            return
        account_id = str(account_id)
        stamp = payload.get("timestamp")
        body = {"account_id": account_id, "reason": reason,
                "value": payload.get("value"), "limit": payload.get("limit"),
                "source_atom": _SOURCE_ATOM_ID}
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp

        if symbol and payload.get("strategy") is not None:
            # حدّ استراتيجية: الزوج في حسابه وحده. الاستراتيجية نفسها في
            # حساب آخر لم تخسر، وإيقافها معه يوقف مالًا سليمًا بدليل لا
            # يخصّه.
            self._halted_pairs[(account_id, str(symbol))] = reason
            body["symbol"] = symbol
            body["strategy"] = payload.get("strategy")
            await self._context.publish("risk.halt.pair", body)
            return

        self._halted_accounts[account_id] = reason
        await self._context.publish("risk.halt.account", body)

    async def _on_validation_requested(self, payload: dict) -> None:
        if self._context is None:
            return
        request_id = payload.get("request_id")

        if self._kill_switch_state:
            await self._respond_validation(request_id, False, "KILL_SWITCH")
            return
        account_id = payload.get("account_id")
        symbol = payload.get("symbol")
        if account_id not in (None, ""):
            account_id = str(account_id)
            if account_id in self._halted_accounts:
                await self._respond_validation(
                    request_id, False, self._halted_accounts[account_id])
                return
            if symbol and (account_id, str(symbol)) in self._halted_pairs:
                await self._respond_validation(
                    request_id, False,
                    self._halted_pairs[(account_id, str(symbol))])
                return
        if self._daily_trade_count >= self._max_daily_trades:
            await self._respond_validation(request_id, False, "MAX_DAILY_TRADES")
            return
        if self._open_trade_count >= self._max_open_trades:
            await self._respond_validation(request_id, False, "MAX_OPEN_TRADES")
            return
        # الخروق التي لا تحمل حسابًا تخصّ النظام كلّه.
        systemic = [r for r, b in self._external_breaches.items()
                    if b.get("account_id") in (None, "")]
        if systemic:
            await self._respond_validation(
                request_id, False, ",".join(sorted(systemic)))
            return
        await self._respond_validation(request_id, True, None)

    async def _respond_validation(self, request_id, approved: bool, reason: str | None) -> None:
        await self._context.publish(
            "risk.validation.completed", {"request_id": request_id, "approved": approved, "reason": reason}
        )

    # ------------------------------------------------------------------ Kill Switch نفسه

    async def _trigger_halt(self, atom_ids: list[int] | None, reason: str, value, limit,
                            inbound_ts: float | None = None) -> None:
        """Stamp the halt with the instant of the loss that caused it.

        Order of preference, project-wide: inherited timestamp, then 806
        official_time where system time is what is meant, then nothing - and
        core.event_bus stamps it via setdefault. A fresh clock reading here
        would place the most important event in the system at a different
        instant than its own evidence.
        """
        if self._context is None:
            return
        self._kill_switch_state = True
        self._kill_switch_reason = reason
        stamp = {"timestamp": inbound_ts} if isinstance(inbound_ts, (int, float)) else {}
        await self._context.publish(
            "emergency.halt",
            {
                "reason": reason, "atom_ids": atom_ids, "source_atom": _SOURCE_ATOM_ID,
                **stamp, "severity": "critical",
                "value": round(value, 4) if isinstance(value, float) else value, "limit": limit,
            },
        )

    async def _on_reset_requested(self, payload: dict) -> None:
        """Manual re-arm only - no automatic path under any condition.

        Does not reset the counters themselves (daily_loss and friends); those
        roll over by their own logic on a new day. This clears kill_switch_state
        only, by an explicit human act.
        """
        if self._context is None:
            return
        self._kill_switch_state = False
        self._kill_switch_reason = None
        self._external_breaches.clear()
        self._halted_accounts.clear()
        self._halted_pairs.clear()
        await self._context.publish(
            "risk.kill_switch.reset_completed",
            {"operator": payload.get("operator"), **_reset_stamp(payload)}
        )
