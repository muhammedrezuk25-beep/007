import asyncio
import pytest
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
import time

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom516"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self, config=None, atom_id=516):
        return AtomContext(
            atom_id=atom_id, config=config or {}, logger=_NullLogger(),
            publish=self.publish, subscribe=self.subscribe,
        )


DEFAULT_CONFIG = {
    "daily_loss_limit_pct": 2.0, "system_loss_limit_pct": 3.0,
    "strategy_loss_limits": {404: 1.0},
    "max_consecutive_losses": 3, "max_daily_trades": 10, "max_open_trades": 3,
}


async def _started(config=None):
    """Config from the manifest so a new contract key does not break these
    tests with a KeyError instead of testing what they were written for."""
    import yaml as _yaml
    from pathlib import Path as _MP
    manifest = _yaml.safe_load(
        (_MP(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
    )["config"]
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({**manifest, **DEFAULT_CONFIG,
                                            **(config or {})}))
    await atom.start()
    return atom, bus


async def test_reason_codes_use_standard_strings():
    print("\n--- test_reason_codes_use_standard_strings ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("risk.loss_reported", {"loss_pct": 2.5})
    halts = [p for n, p in bus.published if n == "emergency.halt"]
    assert halts[0]["reason"] == "RISK_DAILY_LIMIT", halts[0]
    print(f"OK — رمز السبب القياسي بالضبط: {halts[0]['reason']}")


async def test_consecutive_losses_trigger_halt():
    print("\n--- test_consecutive_losses_trigger_halt ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))

    for _ in range(2):
        await bus.publish("market.outcome.realized", {"strategy": 404, "result": "LOSS", "pnl_pct": -0.1})
    halts = [p for n, p in bus.published if n == "emergency.halt"]
    assert len(halts) == 0, "خسارتان بس، تحت العتبة (3)"

    await bus.publish("market.outcome.realized", {"strategy": 404, "result": "LOSS", "pnl_pct": -0.1})  # الثالثة
    halts = [p for n, p in bus.published if n == "emergency.halt" and p["reason"] == "MAX_CONSECUTIVE_LOSSES"]
    assert len(halts) == 1 and halts[0]["value"] == 3
    print(f"OK — 3 خسائر متتالية → MAX_CONSECUTIVE_LOSSES: {halts[0]}")


async def test_winning_trade_resets_consecutive_counter():
    print("\n--- test_winning_trade_resets_consecutive_counter ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("market.outcome.realized", {"strategy": 404, "result": "LOSS", "pnl_pct": -0.1})
    await bus.publish("market.outcome.realized", {"strategy": 404, "result": "LOSS", "pnl_pct": -0.1})
    assert atom._consecutive_losses == 2
    await bus.publish("market.outcome.realized", {"strategy": 404, "result": "WIN", "pnl_pct": 0.5})  # ربح
    assert atom._consecutive_losses == 0
    print("OK — صفقة رابحة تصفّر عدّاد الخسائر المتتالية")


async def test_trade_counts_tracked_correctly():
    print("\n--- test_trade_counts_tracked_correctly ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("trade.opened", {"atom_id": 404})
    await bus.publish("trade.opened", {"atom_id": 405})
    assert atom._daily_trade_count == 2 and atom._open_trade_count == 2
    await bus.publish("trade.closed", {"atom_id": 404, "pnl_pct": 0.1})
    assert atom._daily_trade_count == 2, "daily_trade_count لا ينقص عند الإغلاق"
    assert atom._open_trade_count == 1, "open_trade_count ينقص عند الإغلاق"
    print(f"OK — daily={atom._daily_trade_count} open={atom._open_trade_count}")


async def test_validation_approved_when_clean():
    print("\n--- test_validation_approved_when_clean ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("risk.validation.requested", {"request_id": "r1", "atom_id": 404})
    resp = [p for n, p in bus.published if n == "risk.validation.completed"][0]
    assert resp == {"request_id": "r1", "approved": True, "reason": None}
    print(f"OK — {resp}")


async def test_validation_rejected_max_daily_trades_no_full_halt():
    print("\n--- test_validation_rejected_max_daily_trades_no_full_halt ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({**DEFAULT_CONFIG, "max_daily_trades": 2}))
    await bus.publish("trade.opened", {"atom_id": 404})
    await bus.publish("trade.opened", {"atom_id": 404})

    await bus.publish("risk.validation.requested", {"request_id": "r2", "atom_id": 404})
    resp = [p for n, p in bus.published if n == "risk.validation.completed"][0]
    assert resp == {"request_id": "r2", "approved": False, "reason": "MAX_DAILY_TRADES"}

    halts = [p for n, p in bus.published if n == "emergency.halt"]
    assert len(halts) == 0, "سقف عدد صفقات = رفض تحقق بس، مو halt شامل لصفقات قائمة"
    print(f"OK — {resp}؛ صفر emergency.halt (سقف سياسة بس، لا خطر مباشر)")


async def test_validation_rejected_max_open_trades():
    print("\n--- test_validation_rejected_max_open_trades ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({**DEFAULT_CONFIG, "max_open_trades": 1}))
    await bus.publish("trade.opened", {"atom_id": 404})
    await bus.publish("risk.validation.requested", {"request_id": "r3", "atom_id": 405})
    resp = [p for n, p in bus.published if n == "risk.validation.completed"][0]
    assert resp["approved"] is False and resp["reason"] == "MAX_OPEN_TRADES"
    print(f"OK — {resp}")


async def test_kill_switch_state_rejects_all_new_validation_with_kill_switch_reason():
    print("\n--- test_kill_switch_state_rejects_all_new_validation_with_kill_switch_reason ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("risk.loss_reported", {"loss_pct": 2.5})  # يفعّل halt
    assert atom._kill_switch_state is True

    await bus.publish("risk.validation.requested", {"request_id": "r4", "atom_id": 999})
    resp = [p for n, p in bus.published if n == "risk.validation.completed"][-1]
    assert resp == {"request_id": "r4", "approved": False, "reason": "KILL_SWITCH"}
    print(f"OK — بعد تفعيل الحالة، أي طلب جديد يُرفَض بسبب KILL_SWITCH صراحة: {resp}")


async def test_kill_switch_state_survives_day_rollover_manual_only():
    print("\n--- test_kill_switch_state_survives_day_rollover_manual_only ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("risk.loss_reported", {"loss_pct": 2.5})
    assert atom._kill_switch_state is True

    atom._day_index -= 1  # محاكاة يوم جديد
    atom._maybe_roll_day()
    assert atom._kill_switch_state is True, "يوم جديد لا يصفّر kill_switch_state — يدوي فقط"
    assert atom._daily_loss_pct == 0.0, "لكن daily_loss نفسها تتصفّر طبيعيًا كالمعتاد"

    await bus.publish("risk.kill_switch.reset_requested", {"operator": "trader_1"})
    assert atom._kill_switch_state is False
    reset_events = [p for n, p in bus.published if n == "risk.kill_switch.reset_completed"]
    assert len(reset_events) == 1 and reset_events[0]["operator"] == "trader_1"
    print("OK — يوم جديد لا يصفّر الحالة؛ فقط reset_requested صريح يصفّرها")


async def test_critical_restart_scenario_still_works():
    """اختبار الانحدار — نفس السيناريو الحرج الأصلي (1.9%+Restart+0.2%)
    لازم يبقى صحيحًا بعد كل التوسعة."""
    print("\n--- test_critical_restart_scenario_still_works ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("risk.loss_reported", {"loss_pct": 1.9})
    snap = await atom.snapshot()

    bus2 = FakeEventBus()
    atom2 = Atom()
    await atom2.initialize(bus2.make_context(DEFAULT_CONFIG))
    await atom2.restore(snap)
    await bus2.publish("risk.loss_reported", {"loss_pct": 0.2})

    assert abs(atom2._daily_loss_pct - 2.1) < 1e-9
    halts = [p for n, p in bus2.published if n == "emergency.halt" and p["reason"] == "RISK_DAILY_LIMIT"]
    assert len(halts) == 1
    print(f"OK — السيناريو الحرج لسا صحيح بعد التوسعة: {atom2._daily_loss_pct}%")


async def test_snapshot_restore_covers_all_new_fields():
    print("\n--- test_snapshot_restore_covers_all_new_fields ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(DEFAULT_CONFIG))
    await bus.publish("trade.opened", {"atom_id": 404})
    await bus.publish("market.outcome.realized", {"strategy": 404, "result": "LOSS", "pnl_pct": -0.1})
    await bus.publish("risk.loss_reported", {"loss_pct": 2.5})  # يفعّل الحالة
    snap = await atom.snapshot()

    expected_keys = {
        "daily_loss_pct", "system_loss_pct", "strategy_loss_pct", "daily_trade_count",
        "open_trade_count", "consecutive_losses", "kill_switch_state", "kill_switch_reason", "day_index",
        "external_breaches",
    }
    assert set(snap.keys()) == expected_keys, snap.keys()

    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._kill_switch_state is True
    assert atom2._daily_trade_count == 1
    assert atom2._consecutive_losses == 1
    print(f"OK — كل الحقول التسعة انتقلت بدقّة، بما فيها kill_switch_state=True")


async def main():
    tests = [
        test_reason_codes_use_standard_strings,
        test_consecutive_losses_trigger_halt,
        test_winning_trade_resets_consecutive_counter,
        test_trade_counts_tracked_correctly,
        test_validation_approved_when_clean,
        test_validation_rejected_max_daily_trades_no_full_halt,
        test_validation_rejected_max_open_trades,
        test_kill_switch_state_rejects_all_new_validation_with_kill_switch_reason,
        test_kill_switch_state_survives_day_rollover_manual_only,
        test_critical_restart_scenario_still_works,
        test_snapshot_restore_covers_all_new_fields,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


# ═══ external limit reports from 506, 507 and 508 ═══

@pytest.mark.asyncio
async def test_external_breach_blocks_new_orders():
    """506, 507 and 508 compute; this atom enforces. A breach they report must
    reach the validation gate, otherwise their limits publish into nothing."""
    atom, bus = await _started()
    await bus.publish("risk.limit.hit",
                      {"reason": "SESSION_LOSS_LIMIT", "value": 1.5, "limit": 1.0})
    responses = []
    bus.subscribe("risk.validation.completed",
                  lambda p: responses.append(p) or asyncio.sleep(0))
    await bus.publish("risk.validation.requested", {"request_id": "r1"})
    await asyncio.sleep(0)
    assert responses and responses[-1]["approved"] is False
    assert "SESSION_LOSS_LIMIT" in responses[-1]["reason"]


@pytest.mark.asyncio
async def test_an_external_breach_does_not_trip_the_kill_switch():
    """The kill switch stays reserved for the loss limits this atom owns.
    A session or exposure breach blocks orders without demanding a manual
    re-arm of the whole platform."""
    atom, bus = await _started()
    await bus.publish("risk.limit.hit",
                      {"reason": "MAX_EXPOSURE", "value": 95.0, "limit": 20.0})
    assert atom._kill_switch_state is False


@pytest.mark.asyncio
async def test_multiple_breaches_are_all_reported():
    atom, bus = await _started()
    for reason in ("SESSION_LOSS_LIMIT", "MAX_EXPOSURE"):
        await bus.publish("risk.limit.hit", {"reason": reason})
    responses = []
    bus.subscribe("risk.validation.completed",
                  lambda p: responses.append(p) or asyncio.sleep(0))
    await bus.publish("risk.validation.requested", {"request_id": "r1"})
    await asyncio.sleep(0)
    assert responses[-1]["reason"] == "MAX_EXPOSURE,SESSION_LOSS_LIMIT"


@pytest.mark.asyncio
async def test_day_roll_clears_daily_counters_and_breaches():
    """Without SYS_DAY the daily loss limit was cumulative across days and
    tripped permanently once reached."""
    atom, bus = await _started()
    await bus.publish("risk.loss_reported", {"loss_pct": 0.5, "atom_id": 404})
    await bus.publish("risk.limit.hit", {"reason": "MAX_EXPOSURE"})
    await bus.publish("SYS_DAY", {"count": 1, "official_time": 1785686400.0})
    assert atom._daily_loss_pct == 0.0
    assert atom._daily_trade_count == 0
    assert atom._consecutive_losses == 0
    assert atom._external_breaches == {}


@pytest.mark.asyncio
async def test_reset_clears_external_breaches_too():
    atom, bus = await _started()
    await bus.publish("risk.limit.hit", {"reason": "MAX_EXPOSURE"})
    await bus.publish("risk.kill_switch.reset_requested", {"operator": "m"})
    assert atom._external_breaches == {}


@pytest.mark.asyncio
async def test_breach_without_a_reason_is_ignored():
    atom, bus = await _started()
    await bus.publish("risk.limit.hit", {"value": 1.0})
    assert atom._external_breaches == {}


# ── هوية الاستراتيجية: نصّ أم رقم ────────────────────────────────────

import importlib.util as _iu516
import sys as _sys516
from pathlib import Path as _P516

_D516 = _P516(__file__).resolve().parents[1]
_S516 = _iu516.spec_from_file_location("_lim516", _D516 / "atom.py")
_M516 = _iu516.module_from_spec(_S516)
_sys516.modules["_lim516"] = _M516
_sys516.path.insert(0, str(_D516))
try:
    _S516.loader.exec_module(_M516)
finally:
    _sys516.path.remove(str(_D516))

import yaml as _y516

_CFG516 = _y516.safe_load((_D516 / "manifest.yaml").read_text(encoding="utf-8"))["config"]


class _Cap516:
    atom_id = 516

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, **over):
        self.config = {**_CFG516, "strategy_loss_limits": {"404": 10.0},
                       "daily_loss_limit_pct": 999.0,
                       "system_loss_limit_pct": 999.0, **over}
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _halts_for(atom_id_value):
    atom = _M516.Atom()
    ctx = _Cap516()
    await atom.initialize(ctx)
    await atom.start()
    for i in range(4):
        await ctx.handlers["risk.loss_reported"](
            {"loss_pct": 5.0, "atom_id": atom_id_value, "timestamp": 1785600000.0 + i})
    return [p for n, p in ctx.published
            if n == "emergency.halt" and p.get("reason") == "RISK_STRATEGY_LIMIT"]


@pytest.mark.asyncio
async def test_a_numeric_strategy_id_hits_its_limit():
    assert await _halts_for(404)


@pytest.mark.asyncio
async def test_a_string_strategy_id_hits_the_same_limit():
    """The limits dict is keyed by int, but atom_id crosses the bus inside a
    JSON payload and arrives as "404". In Python "404" != 404, so the lookup
    returned None and the per-strategy limit never fired: a strategy could
    lose the whole account and 516 would not stop it.

    The general daily limit hid this — it tripped first and made the halt
    look like it worked. Raising the general limits is what exposed it.
    """
    assert await _halts_for("404")


@pytest.mark.asyncio
async def test_a_malformed_strategy_id_is_ignored_not_crashed():
    atom = _M516.Atom()
    ctx = _Cap516()
    await atom.initialize(ctx)
    await atom.start()
    for bad in ("abc", "", [], {}):
        await ctx.handlers["risk.loss_reported"](
            {"loss_pct": 5.0, "atom_id": bad, "timestamp": 1785600000.0})
    assert True


@pytest.mark.asyncio
async def test_the_accumulator_keys_do_not_split_by_type():
    """Reporting the same strategy once as int and once as string must add
    up to one figure, not two half-figures that never reach the limit."""
    atom = _M516.Atom()
    ctx = _Cap516()
    await atom.initialize(ctx)
    await atom.start()
    await ctx.handlers["risk.loss_reported"](
        {"loss_pct": 6.0, "atom_id": 404, "timestamp": 1785600000.0})
    await ctx.handlers["risk.loss_reported"](
        {"loss_pct": 6.0, "atom_id": "404", "timestamp": 1785600001.0})
    assert len(atom._strategy_loss_pct) == 1
    assert list(atom._strategy_loss_pct.values())[0] == 12.0


# ── ثلاث درجات إيقاف ────────────────────────────────────────────────

import yaml as _y516
from pathlib import Path as _P516

_MANIFEST516 = _y516.safe_load(
    (_P516(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8"))
_TS516 = 1785600000.0


def test_the_three_halt_levels_are_declared():
    """قرار المالك: إيقاف زوج · إيقاف حساب · إيقاف شامل.

    وثلاثتها بأثر مختلف: الأوّل يوقف الزوج في حسابه، والثاني كل أزواج
    الحساب، والثالث كل الذرّات — والنواة تبقى."""
    for event in ("risk.halt.pair", "risk.halt.account", "emergency.halt"):
        assert event in _MANIFEST516["publishes"]


async def test_an_account_breach_halts_that_account_only():
    """خسارة جلسة في حساب توقفه وحده. وإيقاف الكلّ لخسارة أحدهم يخالف
    قرار المالك."""
    atom, bus = await _started()
    await bus.publish("risk.limit.hit", {
        "account_id": "A", "reason": "MAX_SESSION_LOSS",
        "value": 2.5, "limit": 2.0, "timestamp": _TS516})
    halts = [p for n, p in bus.published if n == "risk.halt.account"]
    assert halts and halts[-1]["account_id"] == "A"
    assert not [p for n, p in bus.published if n == "emergency.halt"]


async def test_a_strategy_breach_halts_the_pair_only():
    atom, bus = await _started()
    await bus.publish("risk.limit.hit", {
        "account_id": "A", "symbol": "USTEC", "strategy": 404,
        "reason": "STRATEGY_LOSS_LIMIT", "value": 1.5, "limit": 1.0,
        "timestamp": _TS516})
    halts = [p for n, p in bus.published if n == "risk.halt.pair"]
    assert halts
    assert halts[-1]["account_id"] == "A" and halts[-1]["symbol"] == "USTEC"
    assert not [p for n, p in bus.published if n == "risk.halt.account"]


async def test_a_halted_account_refuses_its_own_orders_only():
    atom, bus = await _started()
    await bus.publish("risk.limit.hit", {
        "account_id": "A", "reason": "MAX_SESSION_LOSS",
        "value": 2.5, "limit": 2.0, "timestamp": _TS516})
    for account_id, request_id in (("A", "r1"), ("B", "r2")):
        await bus.publish("risk.validation.requested", {
            "account_id": account_id, "request_id": request_id,
            "timestamp": _TS516})
    replies = {p["request_id"]: p for n, p in bus.published
               if n == "risk.validation.completed"}
    assert replies["r1"]["approved"] is False
    assert replies["r2"]["approved"] is True


async def test_a_system_loss_still_halts_everything():
    """خسارة النظام كلّه تبقى إيقافًا شاملًا — والنواة تعمل."""
    atom, bus = await _started()
    await bus.publish("risk.loss_reported", {
        "account_id": "A", "loss_pct": 5.0, "timestamp": _TS516})
    assert [p for n, p in bus.published if n == "emergency.halt"]


# ── الرقمان يتقاطعان: الاختلاف دليل فقدان ───────────────────────────

def test_the_kill_switch_cross_checks_the_section_figure():
    """500 و516 يحسبان الخسارة اليومية من الأحداث نفسها، كلٌّ بنسخته.

    والازدواج مقصود: 516 حرجة، ولو أخذت رقمها من 500 لعطّل سقوطُ 500
    الإيقافَ كلّه. فلا تُدمَجان.

    لكن اختلافهما لا يمرّ صامتًا: هو الدليل الوحيد المتاح على أن حدثًا
    ضاع بينهما — وقيس على تشغيل: حدث خسارة واحد ضائع ترك 0.90 نقطة
    فارقًا، و516 هو من يوقف."""
    assert "risk.unified" in _MANIFEST516["subscribes"]
    assert "risk.state.diverged" in _MANIFEST516["publishes"]
    assert "max_state_divergence_pct" in _MANIFEST516["config"]


async def test_matching_figures_say_nothing():
    atom, bus = await _started()
    await bus.publish("risk.loss_reported", {"account_id": "A", "loss_pct": 1.0,
                                             "timestamp": _TS516})
    await bus.publish("risk.unified", {"daily_loss_pct": 1.0, "timestamp": _TS516})
    assert not [p for n, p in bus.published if n == "risk.state.diverged"]


async def test_a_divergence_is_announced():
    atom, bus = await _started()
    await bus.publish("risk.loss_reported", {"account_id": "A", "loss_pct": 1.0,
                                             "timestamp": _TS516})
    # 500 رأى خسارة أخرى لم تصل هنا
    await bus.publish("risk.unified", {"daily_loss_pct": 1.9, "timestamp": _TS516})
    diverged = [p for n, p in bus.published if n == "risk.state.diverged"]
    assert diverged
    assert diverged[-1]["mine"] == 1.0
    assert diverged[-1]["section"] == 1.9


async def test_the_kill_switch_keeps_its_own_number():
    """لا تأخذ رقم 500: الازدواج هو الحماية."""
    atom, bus = await _started()
    await bus.publish("risk.loss_reported", {"account_id": "A", "loss_pct": 1.0,
                                             "timestamp": _TS516})
    await bus.publish("risk.unified", {"daily_loss_pct": 99.0, "timestamp": _TS516})
    assert atom._daily_loss_pct == 1.0
    assert atom._kill_switch_state is False
