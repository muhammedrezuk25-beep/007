"""اختبارات الذرة 517 — حاسب نتيجة الصفقة."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
# الإعداد من المانيفست لا مكتوبًا هنا: أي مفتاح جديد في العقد كان
# يُسقط الاختبارات بـKeyError بدل أن يُلتقط تلقائيًا.
import yaml
from pathlib import Path as _P
CONFIG = yaml.safe_load(
    (_P(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]


def _load():
    spec = importlib.util.spec_from_file_location("_atom517", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom517"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 517
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _specs(c, symbol="US100", contract_size=1.0):
    """معاملات العقود من 618 — وبلا معامل لا يُحسب ربح."""
    h = c.handlers.get("market.symbol_specs")
    if h is None:
        return
    await h({"provider": "MT5", "symbols": [
        {"symbol": symbol, "contract_size": contract_size,
         "tick_value": 1.0, "tick_size": 0.01}], "timestamp": 1785600000.0})


async def _ready(config=None):
    m = _load(); a = m.Atom(); c = Ctx(config)
    await a.initialize(c); await a.start()
    return m, a, c


def _trade(side="BUY", entry=100.0, exit_price=110.0, size=1.0, tid="t1", symbol="US100",
           account_id="A", **extra):
    # الصفقة تحمل حسابها: نسبة الربح تُحسب على رصيد ذلك الحساب، و516
    # يبني حدَّه عليها.
    return {"trade_id": tid, "account_id": account_id, "symbol": symbol,
            "side": side, "entry_price": entry, "exit_price": exit_price,
            "size": size, **extra}


def _events(c, name):
    return [p for n, p in c.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


# ── حساب الربح: دالة نقية ──

def test_buy_profits_on_rise():
    m = _load()
    assert m.Atom.compute_pnl("BUY", 100.0, 110.0, 2.0, 1.0) == pytest.approx(20.0)


def test_buy_loses_on_fall():
    m = _load()
    assert m.Atom.compute_pnl("BUY", 100.0, 95.0, 2.0, 1.0) == pytest.approx(-10.0)


def test_sell_profits_on_fall():
    """عكس الإشارة في البيع يقلب كل إحصاء أداء."""
    m = _load()
    assert m.Atom.compute_pnl("SELL", 100.0, 90.0, 2.0, 1.0) == pytest.approx(20.0)


def test_sell_loses_on_rise():
    m = _load()
    assert m.Atom.compute_pnl("SELL", 100.0, 105.0, 2.0, 1.0) == pytest.approx(-10.0)


# ── التصنيف ──

@pytest.mark.asyncio
async def test_classification():
    m, a, c = await _ready()
    await _specs(c)
    assert a.classify(5.0) == "WIN"
    assert a.classify(-5.0) == "LOSS"
    assert a.classify(0.005) == "BREAKEVEN"    # داخل النطاق
    assert a.classify(-0.005) == "BREAKEVEN"


# ── النشر ──

@pytest.mark.asyncio
async def test_publishes_outcome_with_all_fields():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](
        _trade(strategy="trend", opened_at=1000.0, closed_at=1300.0))
    out = _events(c, "market.outcome.realized")[0]
    assert out["result"] == "WIN"
    assert out["pnl"] == pytest.approx(10.0)
    assert out["strategy"] == "trend"
    assert out["duration_s"] == pytest.approx(300.0)


@pytest.mark.asyncio
async def test_loss_publishes_separate_event():
    """516 يبني حدّه على الخسارة ولا يعنيه الربح."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(exit_price=90.0))
    losses = _events(c, "risk.loss_reported")
    assert len(losses) == 1
    assert losses[0]["loss"] == pytest.approx(10.0)   # موجبة


@pytest.mark.asyncio
async def test_win_publishes_no_loss_event():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade())
    assert _events(c, "risk.loss_reported") == []


@pytest.mark.asyncio
async def test_cumulative_pnl_tracked():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(tid="a", exit_price=110.0))   # +10
    await c.handlers["trade.closed"](_trade(tid="b", exit_price=95.0))    # −5
    assert a.stats()["total_pnl"] == pytest.approx(5.0)
    assert _events(c, "risk.loss_reported")[-1]["cumulative_pnl"] == pytest.approx(5.0)


@pytest.mark.asyncio
async def test_win_rate():
    m, a, c = await _ready()
    await _specs(c)
    for i, ex in enumerate([110.0, 120.0, 90.0]):
        await c.handlers["trade.closed"](_trade(tid=f"t{i}", exit_price=ex))
    s = a.stats()
    assert s["wins"] == 2 and s["losses"] == 1
    assert s["win_rate"] == pytest.approx(2 / 3, abs=1e-4)  # مقرّب لأربع خانات


# ── الرفض ──

@pytest.mark.asyncio
async def test_duplicate_not_counted_twice():
    """صفقة مكررة تضاعف الربح في كل إحصاء بعدها."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(tid="same"))
    await c.handlers["trade.closed"](_trade(tid="same"))
    assert len(_events(c, "market.outcome.realized")) == 1
    assert a._rejected["duplicate"] == 1


@pytest.mark.asyncio
async def test_missing_price_rejected_not_guessed():
    """رقم مالي مخترع أخطر من غيابه."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](
        {"account_id": "A", "trade_id": "x", "symbol": "US100", "side": "BUY", "size": 1.0})
    assert _events(c, "market.outcome.realized") == []
    assert a._rejected["shape"] == 1


@pytest.mark.asyncio
async def test_unknown_side_rejected():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(side="MAYBE"))
    assert _events(c, "market.outcome.realized") == []
    assert a._rejected["unknown_side"] == 1


@pytest.mark.asyncio
async def test_negative_and_nan_rejected():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(tid="n1", entry=-5.0))
    await c.handlers["trade.closed"](_trade(tid="n2", size=0.0))
    await c.handlers["trade.closed"](_trade(tid="n3", exit_price=float("nan")))
    assert _events(c, "market.outcome.realized") == []
    assert sum(a._rejected.values()) == 3


@pytest.mark.asyncio
async def test_alternative_field_names_accepted():
    """entry/exit/volume بدل entry_price/exit_price/size."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](
        {"account_id": "A", "id": "alt", "symbol": "US100", "side": "SELL",
         "entry": 100.0, "exit": 90.0, "volume": 3.0})
    out = _events(c, "market.outcome.realized")[0]
    assert out["pnl"] == pytest.approx(30.0)


# ── الصحة واللقطة ──

@pytest.mark.asyncio
async def test_health_no_trades_is_degraded_not_broken():
    """لا صفقة مغلقة ليس عطلاً — قد لا يكون النظام تداول بعد."""
    m, a, c = await _ready()
    await _specs(c)
    s = await a.health_check()
    assert s.state.name == "DEGRADED"
    assert "NO_CLOSED_TRADES" in s.message


@pytest.mark.asyncio
async def test_health_healthy_after_trade():
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade())
    assert (await a.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_stats_and_dedup_survive_restart():
    """صافي الربح تاريخ حقيقي — ومفاتيح التكرار تمنع الحساب المزدوج."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["trade.closed"](_trade(tid="keep"))
    snap = await a.snapshot()

    fresh = m.Atom(); fc = Ctx()
    await fresh.initialize(fc); await fresh.restore(snap); await fresh.start()
    assert fresh.stats()["total_pnl"] == pytest.approx(10.0)
    await fc.handlers["trade.closed"](_trade(tid="keep"))
    assert _events(fc, "market.outcome.realized") == []


@pytest.mark.asyncio
async def test_stop_is_reversible():
    m, a, c = await _ready()
    await _specs(c)
    await a.stop(); assert a._running is False
    await a.start(); assert a._running is True


# ── معامل العقد في حساب الربح ───────────────────────────────────────

@pytest.mark.asyncio
async def test_the_contract_size_multiplies_the_result():
    """كان يحسب (فرق السعر × الحجم) بلا معامل العقد.

    والذهب معامله 100: صفقة ربحت 2508 دولارًا تُبلَّغ 25.08، وخسارة
    بلغت 3724 تُبلَّغ 37.24 — و516 يبني حدّ الإيقاف على هذا الرقم، فلا
    ينقلب المفتاح ولو خسر الحساب أضعاف حدّه.

    وقيس على تشغيل حيّ: صافي -12.16 والصحيح -1215.95."""
    m, a, c = await _ready()
    await _specs(c)
    await c.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "XAUUSD", "contract_size": 100.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": 1785600000.0})
    await c.handlers["trade.closed"](_trade(
        tid="gold", symbol="XAUUSD", side="BUY", entry=2841.44,
        exit_price=2850.00, size=2.93))
    out = _events(c, "market.outcome.realized")[-1]
    assert round(out["pnl"], 2) == 2508.08


@pytest.mark.asyncio
async def test_a_result_without_a_contract_size_is_refused():
    """رقم ربحٍ بلا معامل رقمٌ مخترَع، و516 يوقف عليه — فلا يُنشر."""
    m, a, c = await _ready()
    await c.handlers["trade.closed"](_trade(
        tid="nospec", symbol="XAUUSD", side="BUY", entry=2841.44,
        exit_price=2850.00, size=2.93))
    assert not _events(c, "market.outcome.realized")
