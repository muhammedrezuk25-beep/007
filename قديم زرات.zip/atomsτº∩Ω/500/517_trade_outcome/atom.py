"""
517 — حاسب نتيجة الصفقة (Trade Outcome Calculator)
====================================================
يحسب نتيجة كل صفقة مغلقة وينشرها، فتتعلّم النماذج والاستراتيجيات من
أدائها الفعلي.

**لماذا في قسم 500 لا في قسم التنفيذ**: المال ملك 500 حصراً. ذرة التنفيذ
تُعلن الوقائع — فتح · إغلاق · أسعار — ولا تحسب ربحاً. حساب الربح في
مكانين يعني رقمين متضاربين لا أحد يعرف أيهما الصحيح.

**من ينتظره**:
- 360 (تتبّع دقة النماذج) — ينتظر `market.outcome.realized`
- 414 (تقييم الاستراتيجية) — ينتظره أيضاً
- 516 (مفتاح الأمان) — ينتظر `risk.loss_reported`

ثلاثتها عقودها صحيحة والناشر كان غائباً. **لا يُعدَّل أيٌّ منها.**

**لا يخترع شيئاً**: صفقة تصل بلا سعر دخول أو خروج أو حجم لا يُحسب لها
ربح — تُرفض وتُسجَّل. رقم مالي مخترع أخطر من غيابه.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_TRADE_CLOSED = "trade.closed"
EVENT_OUTCOME = "market.outcome.realized"
EVENT_LOSS = "risk.loss_reported"
EVENT_ACCOUNT = "portfolio.account_tracked"   # 619

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"
RESULT_BREAKEVEN = "BREAKEVEN"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

REASON_NO_INPUT = "NO_CLOSED_TRADES_YET"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
BAD_SIDE = "unknown_side"
BAD_PRICE = "bad_price"
DUPLICATE = "duplicate"


def _to_float(value: Any) -> float | None:
    """يرفض NaN كما يرفض غير الرقمي — NaN يجتاز كل مقارنة صامتاً."""
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._breakeven_epsilon = 0.0
        self._pnl_reference = "balance"
        self._reference_balance: dict[str, float] = {}
        self.no_identity_count = 0
        self._recent_limit = 0

        self._seen: list[str] = []
        self._wins = 0
        self._losses = 0
        self._breakeven = 0
        self._total_pnl = 0.0
        self._contract_size: dict[str, float] = {}
        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._breakeven_epsilon = float(cfg["breakeven_epsilon"])
        self._pnl_reference = str(cfg["pnl_reference"])
        self._recent_limit = int(cfg["duplicate_memory"])

        context.subscribe(EVENT_TRADE_CLOSED, self._on_trade_closed)
        # حالة الحساب من 619. النسبة المئوية تحتاج مرجعًا، وبغيابه ظلّت
        # loss_pct غائبة عن 516 — وهو يقول في كوده إنه "لا يحسب % من رقم
        # خام". فبقي مفتاح الأمان لا ينطلق مهما بلغت الخسائر.
        context.subscribe(EVENT_ACCOUNT, self._on_account_state)
        context.subscribe("market.symbol_specs", self._on_specs)

        self._initialized = True
        context.logger.info("تهيّأت الذرة %d", context.atom_id)

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (صفقات=%d، ربح=%d، خسارة=%d، صافي=%.2f)",
                self._context.atom_id, self._received,
                self._wins, self._losses, self._total_pnl,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # -------------------------------------------------- الحساب --

    @staticmethod
    def compute_pnl(side: str, entry: float, exit_price: float,
                    size: float, contract_size: float) -> float:
        """ربح الصفقة. دالة نقية — تُختبر بلا سياق.

        الشراء يربح بالصعود، والبيع يربح بالهبوط. عكس الإشارة في البيع
        خطأ يقلب كل إحصاء أداء رأساً على عقب.

        ومعامل العقد يضرب النتيجة: الذهب معامله 100، فبدونه تُبلَّغ صفقة
        ربحت 2508 دولارًا بـ25.08. و516 يبني حدّ الإيقاف على هذا الرقم،
        فلا ينقلب المفتاح ولو خسر الحساب أضعاف حدّه."""
        move = exit_price - entry
        if side == SIDE_SELL:
            move = -move
        return move * size * contract_size

    def classify(self, pnl: float) -> str:
        """تصنيف النتيجة. النطاق حول الصفر يُعدّ تعادلاً — فرق سنت واحد
        ليس ربحاً ولا خسارة، وعدّه كذلك يشوّه نسبة النجاح."""
        if abs(pnl) <= self._breakeven_epsilon:
            return RESULT_BREAKEVEN
        return RESULT_WIN if pnl > 0 else RESULT_LOSS

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str, detail: str = "") -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1
        if self._context is not None:
            self._context.logger.warning(
                "رُفضت صفقة مغلقة — %s%s", reason, f": {detail}" if detail else "",
            )

    async def _on_trade_closed(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        self._received += 1

        trade_id = inner.get("trade_id") or inner.get("id")
        account_id = inner.get("account_id")
        symbol = inner.get("symbol")
        side = str(inner.get("side", "")).strip().upper()
        entry = _to_float(inner.get("entry_price", inner.get("entry")))
        exit_price = _to_float(inner.get("exit_price", inner.get("exit")))
        size = _to_float(inner.get("size", inner.get("volume")))

        if not isinstance(symbol, str) or not symbol.strip():
            self._reject(BAD_SHAPE, "بلا رمز")
            return
        if account_id in (None, ""):
            self.no_identity_count += 1
            self._reject(BAD_SHAPE, "بلا حساب")
            return
        account_id = str(account_id)
        if side not in (SIDE_BUY, SIDE_SELL):
            self._reject(BAD_SIDE, side or "غائب")
            return
        if entry is None or exit_price is None or size is None:
            self._reject(BAD_SHAPE, "سعر دخول أو خروج أو حجم ناقص")
            return
        if entry <= 0 or exit_price <= 0 or size <= 0:
            self._reject(BAD_PRICE, f"entry={entry} exit={exit_price} size={size}")
            return

        # صفقة واحدة لا تُحسب مرتين — تكرارها يضاعف الربح في كل إحصاء
        key = str(trade_id) if trade_id else f"{symbol}|{entry}|{exit_price}|{size}"
        if key in self._seen:
            self._reject(DUPLICATE, key[:40])
            return
        self._seen.append(key)
        del self._seen[:-self._recent_limit]

        # لا معامل، لا رقم: ربحٌ بلا مضاعِف رقمٌ مخترَع، و516 يوقف عليه.
        contract_size = self._contract_size.get(str(symbol))
        if contract_size is None or contract_size <= 0:
            self._reject(BAD_SHAPE, "بلا معامل عقد")
            return
        pnl = self.compute_pnl(side, entry, exit_price, size, contract_size)
        result = self.classify(pnl)

        self._total_pnl += pnl
        if result == RESULT_WIN:
            self._wins += 1
        elif result == RESULT_LOSS:
            self._losses += 1
        else:
            self._breakeven += 1

        opened_at = _to_float(inner.get("opened_at"))
        closed_at = _to_float(inner.get("closed_at")) or time.time()
        duration = (closed_at - opened_at) if opened_at else None

        # النسبة على مرجع الحساب. تبقى None إن لم يصل مرجع بعد — ولا تُخترع:
        # 516 يبني عليها قرار إيقاف التداول، ورقم محسوب على مرجع مفترَض
        # يوقف التداول في غير موضعه أو لا يوقفه في موضعه.
        # النسبة من رصيد حسابها: ربحُ مئةٍ في حسابٍ بعشرة آلاف واحدٌ
        # بالمئة، وفي حسابٍ بمئة ألف عُشر ذلك. ونسبة محسوبة على رصيد حساب
        # آخر تبني عليها 516 حدَّه فيوقف بلا سبب أو لا يوقف عند سبب.
        reference = self._reference_balance.get(account_id)
        pnl_pct = None
        if reference:
            pnl_pct = round(pnl / reference * 100.0, 6)

        outcome = {
            "trade_id": trade_id,
            "account_id": account_id,
            "symbol": symbol,
            "strategy": inner.get("strategy"),
            "direction": side,
            "entry": entry,
            "exit": exit_price,
            "size": size,
            "pnl": round(pnl, 6),
            # 500 يقرأ pnl_pct لعدّ الخسائر المتتالية، و360 و414 يقرآن
            # النتيجة لتقييم النماذج والاستراتيجيات
            "pnl_pct": pnl_pct,
            "reference_balance": reference,
            "result": result,
            "duration_s": round(duration, 1) if duration is not None else None,
            "closed_at": closed_at,
        }

        self._published += 1
        await self._context.publish(EVENT_OUTCOME, outcome)

        # الخسارة تُعلَن منفصلة: 516 يبني حدّه عليها ولا يعنيه الربح
        if result == RESULT_LOSS:
            await self._context.publish(EVENT_LOSS, {
                "trade_id": trade_id,
                "account_id": account_id,
                "symbol": symbol,
                "loss": round(abs(pnl), 6),
                # الحقل الذي ينتظره 516 حرفيًا. بغيابه كان يقرأ خسارة صفر
                # بعد كل صفقة خاسرة، فلا يتراكم شيء ولا ينطلق مفتاح الأمان.
                "loss_pct": abs(pnl_pct) if pnl_pct is not None else None,
                "atom_id": inner.get("strategy"),
                "cumulative_pnl": round(self._total_pnl, 6),
                "closed_at": closed_at,
            })

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        """Contract sizes from 618, per symbol."""
        symbols = payload.get("symbols")
        if not isinstance(symbols, list):
            return
        for row in symbols:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            size = _to_float(row.get("contract_size"))
            if symbol and size is not None and size > 0:
                self._contract_size[str(symbol)] = size

    async def _on_account_state(self, payload: dict[str, Any]) -> None:
        """يحفظ المرجع الذي تُقاس عليه نسبة الربح والخسارة.

        المرجع هو الرصيد لا حقوق الملكية افتراضيًا: حقوق الملكية تتحرّك مع
        كل تكّة بينما المركز مفتوح، فنسبة محسوبة عليها تتغيّر بلا أن يتغيّر
        شيء في نتيجة الصفقة نفسها. والرصيد ثابت حتى يُغلق مركز.

        وما دام لم يصل مرجع، تبقى pnl_pct غائبة ولا تُخترع: رقم مخاطرة
        محسوب على مرجع مفترَض أخطر من رقم غائب — لأن 516 يبني عليه قرار
        إيقاف التداول.
        """
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        reference = _to_float(payload.get(self._pnl_reference))
        if reference is not None and reference > 0:
            self._reference_balance[str(account_id)] = reference

    def stats(self) -> dict[str, Any]:
        closed = self._wins + self._losses + self._breakeven
        return {
            "closed_trades": closed,
            "wins": self._wins,
            "losses": self._losses,
            "breakeven": self._breakeven,
            "total_pnl": round(self._total_pnl, 6),
            "win_rate": round(self._wins / closed, 4) if closed else None,
        }

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {**self.stats(), "received": self._received,
                   "rejected": {k: v for k, v in self._rejected.items() if v}}

        # لا صفقة مغلقة ليس عطلاً — قد لا يكون النظام تداول بعد
        if self._received == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"صفقات={self._published} صافي={self._total_pnl:.2f}",
            details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        """الإحصاء يُحفظ: صافي الربح وعدد الصفقات تاريخ حقيقي لا حالة
        لحظية. ومفاتيح التكرار تُحفظ كي لا تُحسب صفقة مرتين بعد إعادة
        التشغيل."""
        return {
            "version": ATOM_VERSION,
            "wins": self._wins,
            "losses": self._losses,
            "breakeven": self._breakeven,
            "total_pnl": self._total_pnl,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
            "seen": list(self._seen[-self._recent_limit:]) if self._recent_limit else [],
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._wins = int(state.get("wins", 0))
        self._losses = int(state.get("losses", 0))
        self._breakeven = int(state.get("breakeven", 0))
        self._total_pnl = float(state.get("total_pnl", 0.0))
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
        self._seen = [str(k) for k in (state.get("seen") or [])]
