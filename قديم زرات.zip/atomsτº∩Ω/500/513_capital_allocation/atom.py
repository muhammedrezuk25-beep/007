from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_WIN_RATE_FLOOR = 0.5
_MIN_WEIGHT_FACTOR = 0.1
_MAX_PNL_PENALTY = -0.9

ATOM_VERSION = "1.0.0"

EVENT_OUTCOME = "market.outcome.realized"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_DAY = "SYS_DAY"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_completed"

EVENT_OUT = "risk.capital_allocation"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"
REASON_NO_HISTORY = "NO_CLOSED_TRADES_YET"

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._base_weight = 0.0
        self._min_trades = 0
        self._min_share_pct = 0.0
        self._max_share_pct = 0.0
        self._reserve_pct = 0.0
        self._halt_freezes = True

        self._books: dict[str, dict[str, Any]] = {}
        self._frozen = False
        self.no_identity_count = 0

        self.publish_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base_weight = float(cfg["base_weight"])
        self._min_trades = int(cfg["min_trades_for_weighting"])
        self._min_share_pct = float(cfg["min_share_pct"])
        self._max_share_pct = float(cfg["max_share_pct"])
        self._reserve_pct = float(cfg["reserve_pct"])
        self._halt_freezes = bool(cfg["freeze_on_halt"])

        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_DAY, self._on_day)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)

        self._initialized = True
        context.logger.info("513 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("513 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "513 stopped (published=%d)", self.publish_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _book(self, account_id: str) -> dict[str, Any]:
        """One allocation book per account.

        Capital in one account is not distributed by another account's
        record: a strategy that earned in one has no claim to a bigger share
        where it never traded.
        """
        return self._books.setdefault(account_id, {"equity": None, "stats": {}})

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)
        equity = _to_float(payload.get("equity"))
        if equity is None or equity <= 0:
            return
        book = self._book(account_id)
        changed = equity != book["equity"]
        book["equity"] = equity
        if changed:
            await self._emit(account_id, payload)

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        strategy = _to_int(payload.get("strategy"))
        if strategy is None:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)

        entry = self._book(account_id)["stats"].setdefault(
            strategy, {"trades": 0.0, "wins": 0.0, "losses": 0.0, "pnl_pct": 0.0})
        entry["trades"] += 1

        result = str(payload.get("result", "")).upper()
        if result == RESULT_WIN:
            entry["wins"] += 1
        elif result == RESULT_LOSS:
            entry["losses"] += 1

        pnl_pct = _to_float(payload.get("pnl_pct"))
        if pnl_pct is not None:
            entry["pnl_pct"] = round(entry["pnl_pct"] + pnl_pct, 6)

        await self._emit(account_id, payload)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        await self._emit_all(payload)

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        if self._halt_freezes:
            self._frozen = True
        await self._emit_all(payload)

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._frozen = False
        await self._emit_all(payload)

    async def _emit_all(self, payload: dict[str, Any]) -> None:
        for account_id in list(self._books):
            await self._emit(account_id, payload)

    def _weight_of(self, account_id: str, strategy: int) -> float:
        entry = self._book(account_id)["stats"].get(strategy)
        if entry is None or entry["trades"] < self._min_trades:
            return self._base_weight

        trades = entry["trades"]
        win_rate = entry["wins"] / trades if trades else 0.0
        average_pnl = entry["pnl_pct"] / trades if trades else 0.0

        weight = self._base_weight * (_WIN_RATE_FLOOR + win_rate)
        if average_pnl > 0:
            weight *= 1.0 + min(average_pnl, 1.0)
        elif average_pnl < 0:
            weight *= max(_MIN_WEIGHT_FACTOR, 1.0 + max(average_pnl, _MAX_PNL_PENALTY))
        return max(weight, 0.0)

    def allocation(self, account_id: str) -> dict[str, Any]:
        book = self._book(account_id)
        stats = book["stats"]
        equity = book["equity"]
        weights = {sid: self._weight_of(account_id, sid) for sid in stats}
        total = sum(weights.values())

        allocatable = max(0.0, 100.0 - self._reserve_pct)
        shares: dict[int, float] = {}

        if self._frozen or total <= 0 or not weights:
            for sid in weights:
                shares[sid] = 0.0
        else:
            for sid, weight in weights.items():
                share = weight / total * allocatable
                share = min(share, self._max_share_pct)
                share = max(share, self._min_share_pct)
                shares[sid] = round(share, 6)

            excess = sum(shares.values())
            if excess > allocatable and excess > 0:
                scale = allocatable / excess
                shares = {sid: round(value * scale, 6)
                          for sid, value in shares.items()}

        capital = {}
        if equity:
            capital = {sid: round(equity * pct / 100.0, 2)
                       for sid, pct in shares.items()}

        return {
            "account_id": account_id,
            "equity": equity,
            "reserve_pct": self._reserve_pct,
            "allocatable_pct": allocatable,
            "frozen": self._frozen,
            "shares_pct": {str(k): v for k, v in shares.items()},
            "capital": {str(k): v for k, v in capital.items()},
            "weights": {str(k): round(v, 6) for k, v in weights.items()},
            "stats": {str(k): dict(v) for k, v in stats.items()},
        }

    async def _emit(self, account_id: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self.allocation(account_id)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        self.publish_count += 1
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {
            "accounts": len(self._books),
            "published": self.publish_count,
            "frozen": self._frozen,
            "no_identity": self.no_identity_count,
            "books": {a: self.allocation(a) for a in self._books},
        }

        if not any(b["equity"] is not None for b in self._books.values()):
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACCOUNT, details=details)

        if not any(b["stats"] for b in self._books.values()):
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_HISTORY, details=details)

        if self._frozen:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="frozen after halt", details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="accounts=%d reserve=%.1f%%" % (
                len(self._books), self._reserve_pct),
            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "books": {a: {"equity": b["equity"],
                          "stats": {str(k): dict(v) for k, v in b["stats"].items()}}
                      for a, b in self._books.items()},
            "frozen": self._frozen,
            "published": self.publish_count,
            "no_identity": self.no_identity_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._books = {
            a: {"equity": b.get("equity"),
                "stats": {int(k): dict(v) for k, v in (b.get("stats") or {}).items()}}
            for a, b in (state.get("books") or {}).items()}
        self._frozen = bool(state.get("frozen", False))
        self.publish_count = int(state.get("published", 0))
        self.no_identity_count = int(state.get("no_identity", 0))
