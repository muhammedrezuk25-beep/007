from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom513"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 513

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(equity=10000.0, **over):
    cfg = {**CONFIG}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    if equity:
        await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "equity": equity, "timestamp": TS})
    return atom, ctx


async def _record(ctx, strategy, wins, losses, pnl):
    for _ in range(wins):
        await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", 
            "strategy": strategy, "result": "WIN", "pnl_pct": pnl, "timestamp": TS})
    for _ in range(losses):
        await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", 
            "strategy": strategy, "result": "LOSS", "pnl_pct": -abs(pnl),
            "timestamp": TS})


def _last(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT][-1]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    tree = ast.parse(src)
    assert ast.get_docstring(tree) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in manifest)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 513
    assert MANIFEST["publishes"] == [MODULE.EVENT_OUT]


@pytest.mark.asyncio
async def test_a_profitable_strategy_gets_more_than_a_losing_one():
    atom, ctx = await _ready()
    await _record(ctx, 410, 9, 3, 0.6)
    await _record(ctx, 404, 3, 9, 0.4)
    shares = _last(ctx)["shares_pct"]
    assert shares["410"] > shares["404"]


@pytest.mark.asyncio
async def test_shares_never_exceed_the_allocatable_pool():
    atom, ctx = await _ready(reserve_pct=20.0)
    for strategy in (401, 404, 406, 408, 410):
        await _record(ctx, strategy, 8, 4, 0.5)
    state = _last(ctx)
    assert sum(state["shares_pct"].values()) <= state["allocatable_pct"] + 1e-6


@pytest.mark.asyncio
async def test_reserve_is_never_allocated():
    atom, ctx = await _ready(reserve_pct=30.0)
    await _record(ctx, 410, 10, 2, 1.0)
    state = _last(ctx)
    assert state["allocatable_pct"] == 70.0
    assert sum(state["shares_pct"].values()) <= 70.0 + 1e-6


@pytest.mark.asyncio
async def test_max_share_caps_a_dominant_strategy():
    atom, ctx = await _ready(max_share_pct=30.0)
    await _record(ctx, 410, 12, 0, 2.0)
    await _record(ctx, 404, 1, 11, 2.0)
    assert _last(ctx)["shares_pct"]["410"] <= 30.0


@pytest.mark.asyncio
async def test_a_new_strategy_gets_the_base_weight():
    atom, ctx = await _ready(min_trades_for_weighting=10)
    await _record(ctx, 999, 2, 0, 0.5)
    assert _last(ctx)["weights"]["999"] == CONFIG["base_weight"]


@pytest.mark.asyncio
async def test_capital_follows_equity():
    atom, ctx = await _ready(equity=10000.0)
    await _record(ctx, 410, 10, 2, 0.5)
    first = _last(ctx)["capital"]["410"]
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "equity": 20000.0, "timestamp": TS})
    second = _last(ctx)["capital"]["410"]
    assert round(second, 2) == round(first * 2, 2)


@pytest.mark.asyncio
async def test_halt_freezes_every_share_to_zero():
    atom, ctx = await _ready()
    await _record(ctx, 410, 10, 2, 0.5)
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "RISK_DAILY_LIMIT",
                                           "timestamp": TS})
    state = _last(ctx)
    assert state["frozen"] is True
    assert sum(state["shares_pct"].values()) == 0.0


@pytest.mark.asyncio
async def test_reset_restores_the_allocation():
    atom, ctx = await _ready()
    await _record(ctx, 410, 10, 2, 0.5)
    before = sum(_last(ctx)["shares_pct"].values())
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "X", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_RESET]({"operator": "m", "timestamp": TS})
    state = _last(ctx)
    assert state["frozen"] is False
    assert round(sum(state["shares_pct"].values()), 6) == round(before, 6)


@pytest.mark.asyncio
async def test_freeze_can_be_turned_off():
    atom, ctx = await _ready(freeze_on_halt=False)
    await _record(ctx, 410, 10, 2, 0.5)
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "X", "timestamp": TS})
    assert _last(ctx)["frozen"] is False


@pytest.mark.asyncio
async def test_outcome_without_a_strategy_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "result": "WIN", "pnl_pct": 1.0,
                                              "timestamp": TS})
    assert atom._book("A")["stats"] == {}


@pytest.mark.asyncio
async def test_missing_pnl_pct_still_counts_the_trade():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "strategy": 410, "result": "WIN",
                                              "timestamp": TS})
    assert atom._book("A")["stats"][410]["trades"] == 1
    assert atom._book("A")["stats"][410]["pnl_pct"] == 0.0


@pytest.mark.asyncio
async def test_health_degraded_without_account():
    atom, ctx = await _ready(equity=None)
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_degraded_without_history():
    atom, ctx = await _ready()
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert status.message == MODULE.REASON_NO_HISTORY


@pytest.mark.asyncio
async def test_health_healthy_with_history():
    atom, ctx = await _ready()
    await _record(ctx, 410, 5, 1, 0.5)
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx(CONFIG))
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _record(ctx, 410, 6, 2, 0.5)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh._book("A")["stats"] == atom._book("A")["stats"]
    assert fresh._frozen == atom._frozen


# ── التخصيص لكل حساب ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_allocation_is_computed_per_account():
    """رأس مال حساب لا يُوزَّع على أداء حساب آخر: استراتيجية ناجحة في
    حساب لا تستحقّ نصيبًا أكبر في حساب لم تُنفَّذ فيه."""
    atom, ctx = await _ready()
    for acc, eq in (("A", 10000.0), ("B", 100000.0)):
        await ctx.handlers["portfolio.account_tracked"]({"account_id": "A", 
            "account_id": acc, "equity": eq, "timestamp": TS})
    allocations = [p for n, p in ctx.published if n == "risk.capital_allocation"]
    by = {a["account_id"]: a for a in allocations}
    assert set(by) == {"A", "B"}
    assert by["A"]["equity"] == 10000.0
    assert by["B"]["equity"] == 100000.0


@pytest.mark.asyncio
async def test_a_strategy_result_credits_only_its_account():
    atom, ctx = await _ready()
    for acc in ("A", "B"):
        await ctx.handlers["portfolio.account_tracked"]({"account_id": "A", 
            "account_id": acc, "equity": 10000.0, "timestamp": TS})
    await ctx.handlers["market.outcome.realized"]({"account_id": "A", 
        "account_id": "A", "strategy": 404, "result": "WIN",
        "pnl_pct": 0.5, "timestamp": TS})
    assert 404 in atom._book("A")["stats"]
    assert 404 not in atom._book("B")["stats"]


@pytest.mark.asyncio
async def test_an_outcome_without_an_account_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers["market.outcome.realized"]({
        "strategy": 404, "result": "WIN", "pnl_pct": 0.5, "timestamp": TS})
    assert atom.no_identity_count == 1
