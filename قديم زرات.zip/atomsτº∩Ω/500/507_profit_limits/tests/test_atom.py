from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom507"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 507

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    cfg = {**CONFIG}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "balance": 10000.0, "equity": 10000.0,
                                              "timestamp": TS})
    return atom, ctx


def _breaches(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_BREACH]


async def _outcome(ctx, pnl_pct, result="WIN", ts=TS):
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "pnl_pct": pnl_pct, "result": result,
                                              "timestamp": ts})


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_and_no_arabic_and_no_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert "print(" not in src
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 507
    assert MODULE.EVENT_BREACH in MANIFEST["publishes"]


@pytest.mark.asyncio
async def test_daily_target_breaches():
    atom, ctx = await _ready(daily_profit_target_pct=3.0)
    await _outcome(ctx, 1.5)
    assert _breaches(ctx) == []
    await _outcome(ctx, 1.6)
    breach = _breaches(ctx)[0]
    assert breach["reason"] == MODULE.BREACH_DAILY_TARGET
    assert round(breach["value"], 1) == 3.1


@pytest.mark.asyncio
async def test_losses_reduce_the_daily_profit():
    atom, ctx = await _ready(daily_profit_target_pct=3.0)
    await _outcome(ctx, 2.0)
    await _outcome(ctx, -0.5, "LOSS")
    assert round(atom._book("A")["daily_profit_pct"], 2) == 1.5
    assert _breaches(ctx) == []


@pytest.mark.asyncio
async def test_giveback_measured_from_the_peak():
    """A day that reached +2.5% and fell back to +0.9% gave back 1.6%, even
    though it is still in profit."""
    atom, ctx = await _ready(max_profit_giveback_pct=1.5,
                             daily_profit_target_pct=0.0)
    await _outcome(ctx, 2.5)
    assert atom._book("A")["peak_profit_pct"] == 2.5
    await _outcome(ctx, -1.6, "LOSS")
    breach = _breaches(ctx)[0]
    assert breach["reason"] == MODULE.BREACH_GIVEBACK
    assert round(breach["value"], 1) == 1.6


@pytest.mark.asyncio
async def test_peak_never_moves_down():
    atom, ctx = await _ready(max_profit_giveback_pct=0.0,
                             daily_profit_target_pct=0.0)
    await _outcome(ctx, 3.0)
    await _outcome(ctx, -2.0, "LOSS")
    assert atom._book("A")["peak_profit_pct"] == 3.0


@pytest.mark.asyncio
async def test_wins_and_losses_counted():
    atom, ctx = await _ready(daily_profit_target_pct=0.0)
    await _outcome(ctx, 1.0, "WIN")
    await _outcome(ctx, 1.0, "WIN")
    await _outcome(ctx, -0.5, "LOSS")
    assert atom._book("A")["wins"] == 2
    assert atom._book("A")["losses"] == 1


@pytest.mark.asyncio
async def test_missing_pnl_pct_is_not_invented():
    """517 leaves pnl_pct absent when no balance reference arrived. Treating
    that as zero would silently move the daily figure."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"account_id": "A", "result": "WIN", "timestamp": TS})
    assert atom._book("A")["daily_profit_pct"] == 0.0


@pytest.mark.asyncio
async def test_a_breach_is_raised_once():
    atom, ctx = await _ready(daily_profit_target_pct=1.0)
    for _ in range(3):
        await _outcome(ctx, 1.0)
    assert len(_breaches(ctx)) == 1


@pytest.mark.asyncio
async def test_day_roll_clears_everything():
    atom, ctx = await _ready(daily_profit_target_pct=1.0)
    await _outcome(ctx, 5.0)
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom._book("A")["daily_profit_pct"] == 0.0
    assert atom._book("A")["peak_profit_pct"] == 0.0
    assert atom._book("A")["wins"] == 0
    assert atom._book("A")["breaches"] == set()


@pytest.mark.asyncio
async def test_limit_of_zero_is_off():
    atom, ctx = await _ready(daily_profit_target_pct=0.0,
                             max_profit_giveback_pct=0.0)
    await _outcome(ctx, 50.0)
    await _outcome(ctx, -40.0, "LOSS")
    assert _breaches(ctx) == []


@pytest.mark.asyncio
async def test_health_degraded_without_account():
    atom = MODULE.Atom()
    ctx = Ctx(CONFIG)
    await atom.initialize(ctx)
    await atom.start()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_healthy_within_limits():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx(CONFIG))
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _outcome(ctx, 1.2)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh._book("A")["daily_profit_pct"] == atom._book("A")["daily_profit_pct"]
    assert fresh._book("A")["peak_profit_pct"] == atom._book("A")["peak_profit_pct"]
