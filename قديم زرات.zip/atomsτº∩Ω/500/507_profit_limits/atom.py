from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUTCOME = "market.outcome.realized"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_DAY = "SYS_DAY"
EVENT_RESET = "risk.kill_switch.reset_completed"

EVENT_OUT = "risk.profit_limits"
EVENT_BREACH = "risk.limit.hit"

BREACH_DAILY_TARGET = "DAILY_PROFIT_TARGET"
BREACH_GIVEBACK = "PROFIT_GIVEBACK"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._daily_target_pct = 0.0
        self._max_giveback_pct = 0.0

        self._books: dict[str, dict] = {}

        self.no_identity_count = 0
        self.breach_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._daily_target_pct = float(cfg["daily_profit_target_pct"])
        self._max_giveback_pct = float(cfg["max_profit_giveback_pct"])

        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_DAY, self._on_day)
        context.subscribe(EVENT_RESET, self._on_reset)

        self._initialized = True
        context.logger.info("507 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("507 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "507 stopped (breaches=%d)", self.breach_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _book(self, account_id: str) -> dict:
        """One book per account.

        A single profit book across accounts credited one account gains earned in another, and the day target closed both when only one had reached it.
        """
        return self._books.setdefault(account_id, {"daily_profit_pct": 0.0, "peak_profit_pct": 0.0, "reference_balance": None, "wins": 0, "losses": 0, "breaches": set()})

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        balance = _to_float(payload.get("balance"))
        if balance is None or balance <= 0:
            return
        book = self._book(str(account_id))
        if book["reference_balance"] is None:
            book["reference_balance"] = balance

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return

        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)
        book = self._book(account_id)

        result = str(payload.get("result", "")).upper()
        if result == RESULT_WIN:
            book["wins"] += 1
        elif result == RESULT_LOSS:
            book["losses"] += 1

        pnl_pct = _to_float(payload.get("pnl_pct"))
        if pnl_pct is None:
            return

        book["daily_profit_pct"] = round(book["daily_profit_pct"] + pnl_pct, 6)
        if book["daily_profit_pct"] > book["peak_profit_pct"]:
            book["peak_profit_pct"] = book["daily_profit_pct"]

        await self._check_target(account_id, payload)
        await self._check_giveback(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for book in self._books.values():
            book["daily_profit_pct"] = 0.0
            book["peak_profit_pct"] = 0.0
            book["wins"] = 0
            book["losses"] = 0
            book["breaches"].clear()
        await self._emit_all(payload)

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for book in self._books.values():
            book["breaches"].clear()
        await self._emit_all(payload)

    async def _emit_all(self, payload: dict[str, Any]) -> None:
        for account_id in list(self._books):
            await self._emit(account_id, payload)

    async def _check_target(self, account_id: str,
                            payload: dict[str, Any]) -> None:
        book = self._book(account_id)
        if self._daily_target_pct <= 0:
            return
        if book["daily_profit_pct"] < self._daily_target_pct:
            return
        await self._raise(account_id, BREACH_DAILY_TARGET,
                          book["daily_profit_pct"],
                          self._daily_target_pct, payload)

    async def _check_giveback(self, account_id: str,
                              payload: dict[str, Any]) -> None:
        book = self._book(account_id)
        if self._max_giveback_pct <= 0 or book["peak_profit_pct"] <= 0:
            return
        given = round(book["peak_profit_pct"] - book["daily_profit_pct"], 6)
        if given < self._max_giveback_pct:
            return
        await self._raise(account_id, BREACH_GIVEBACK, given,
                          self._max_giveback_pct, payload)

    async def _raise(self, account_id: str, reason: str, value: float,
                     limit: float, payload: dict[str, Any]) -> None:
        """A breach names its account: halting one halts its pairs alone."""
        book = self._book(account_id)
        if self._context is None or reason in book["breaches"]:
            return
        book["breaches"].add(reason)
        self.breach_count += 1
        body: dict[str, Any] = {
            "account_id": account_id,
            "reason": reason,
            "value": value,
            "limit": limit,
            "daily_profit_pct": book["daily_profit_pct"],
            "peak_profit_pct": book["peak_profit_pct"],
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_BREACH, body)
        self._context.logger.warning(
            "507 breach %s: %s >= %s", reason, value, limit)

    def _state(self, account_id: str) -> dict[str, Any]:
        book = self._book(account_id)
        return {
            "account_id": account_id,
            "daily_profit_pct": book["daily_profit_pct"],
            "peak_profit_pct": book["peak_profit_pct"],
            "giveback_pct": round(
                max(0.0, book["peak_profit_pct"] - book["daily_profit_pct"]), 6),
            "daily_profit_target_pct": self._daily_target_pct,
            "max_profit_giveback_pct": self._max_giveback_pct,
            "wins": book["wins"],
            "losses": book["losses"],
            "reference_balance": book["reference_balance"],
            "breached": sorted(book["breaches"]),
        }

    async def _emit(self, account_id: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self._state(account_id)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {"accounts": len(self._books),
                   "no_identity": self.no_identity_count,
                   "books": {a: self._state(a) for a in self._books}}
        details["breach_count"] = self.breach_count

        if not self._books:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACCOUNT, details=details)

        breached = {a: sorted(b["breaches"]) for a, b in self._books.items()
                    if b["breaches"]}
        if breached:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="breached: %s" % ",".join(
                    "%s/%s" % (a, ",".join(r)) for a, r in breached.items()),
                details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="accounts=%d" % len(self._books),
            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "books": {a: {**b, "breaches": sorted(b["breaches"])}
                      for a, b in self._books.items()},
            "breach_count": self.breach_count,
            "no_identity": self.no_identity_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._books = {a: {**b, "breaches": set(b.get("breaches") or [])}
                       for a, b in (state.get("books") or {}).items()}
        self.breach_count = int(state.get("breach_count", 0))
        self.no_identity_count = int(state.get("no_identity", 0))
