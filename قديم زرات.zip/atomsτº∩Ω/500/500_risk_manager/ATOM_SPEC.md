# ATOM_SPEC - 500 Risk Manager

> **Provenance warning.** Section 500 has no build paper. Twelve other sections
> got one; this one did not. Everything in section 2 and 5 below is inference
> from documented anchors, not from a spec written for 500. The anchors are
> named in section 3 so the reasoning can be checked and overturned.

## 1. Identity

| | |
|---|---|
| id | **500** (fixed for life) |
| folder | `atoms/500/500_risk_manager` (free - the core identifies by id only) |
| version | 1.0.0 |
| critical | **false** - it reports, it blocks nothing |
| startup_mode | auto |
| entrypoint | `atom:Atom` |

## 2. Single responsibility

Assemble the risk picture of the platform from its section's events and publish
it as one unified state.

**Not its job:** enforcing any limit, halting trading, sizing a position,
validating an order, or holding a threshold. All of that is 516 and the
unbuilt 501-515.

## 3. Why it exists - and what the design rests on

Every field of the Risk model already exists inside 516:

```
_daily_loss_pct   _system_loss_pct   _strategy_loss_pct   _daily_trade_count
_open_trade_count _consecutive_losses _kill_switch_state  _kill_switch_reason
```

**516 publishes none of them.** Its three events are `emergency.halt`
(reason, atom_ids, severity, value, limit), `risk.validation.completed`
(request_id, approved, reason) and `risk.kill_switch.reset_completed`
(operator, reset_at). The picture itself never leaves the atom.

Consequently the planned consumers have nothing to read: 856 (risk dashboard),
663 (risk distribution), 664/665 (loss and profit limit displays) and section
700 (storage).

**Documented anchors this design rests on:**

| Anchor | Where it comes from |
|---|---|
| the `Risk` model, nine fields | unified appendix, section 2, item 8 |
| "manager = collector, rule 1" | the pattern in all twelve build papers - 101, 150, 350, 400, 450, 550, 650, 700 |
| "500 owns capital and the rule / enforcement; 650 only displays" | section 650 build paper |
| `SYS_DAY` as the day source | 806's manifest and code |
| unified event naming `<section>.unified` | 101 publishes `market_data.unified`, 150 publishes `analysis.unified` |

**What is inference, not given:** the event name `risk.unified`, the decision
that 500 collects rather than enforces, and the choice of these six inbound
events. A build paper for section 500 could overturn any of the three.

## 4. Mechanism

1. Subscribe to six events: a reported loss, a trade opening, a trade closing,
   a halt, a reset, and the day tick.
2. Update the mirrored state.
3. Publish the whole picture as `risk.unified`, stamped with the inbound
   event's own timestamp.
4. On `SYS_DAY`, zero the daily counters only.

## 5. Settled decisions

### 5.1 It collects, it does not enforce
516 owns enforcement and is the only atom that can halt trading. Two enforcers
counting independently would eventually disagree about whether trading is
allowed, and the one that was wrong would still be able to act. The arithmetic
here is a deliberate mirror that drives nothing.
*Guarded by:* `test_collects_but_does_not_enforce` - asserts the only published
event is `risk.unified` and that no limit lives in config.

### 5.2 The day rolls on 806, not on a local clock
An atom deciding "it is a new day" from its own clock rolls at a different
instant than every other atom doing the same, and the daily numbers stop lining
up across the platform. 516 currently does `time.time() // 86400` internally;
this atom takes the sanctioned source instead.
*Guarded by:* `test_day_source_is_806_not_a_local_clock` - asserts there is no
`time.time()` and no `86400` anywhere in the file.

### 5.3 The kill switch never self-clears
Not on a day roll, not on `stop()`, not on `restore()`. It mirrors 516's own
rule: once true, only an explicit human reset turns it off. A picture that
quietly cleared the halt at midnight would report a market as open that the
operator closed.
*Guarded by:* `test_day_roll_never_clears_the_kill_switch`,
`test_snapshot_restore_round_trip_keeps_the_halt`.

### 5.4 It publishes nothing until it has received something
An all-zero risk state on boot reads as "no losses, no trades, kill switch off"
when the truth is "nothing is known yet". Silence is the honest state, and
health reports it as DEGRADED.
*Guarded by:* `test_publishes_nothing_before_any_input`,
`test_day_roll_alone_publishes_nothing`.

### 5.5 An active kill switch is DEGRADED, never HEALTHY
The atom itself is fine, but the platform is not trading. A risk report reading
green while the switch is on is exactly the wrong signal to a dashboard.
*Guarded by:* `test_active_kill_switch_is_degraded_never_healthy`.

### 5.6 `stop()` does not zero the book
A restarted collector reporting a clean book while real losses stand is worse
than no report at all.
*Guarded by:* `test_stop_does_not_zero_the_book`.

### 5.7 An open trade does not close at midnight
The day roll clears `daily_loss_pct`, `strategy_loss_pct` and
`daily_trade_count`. It leaves `open_trade_count`, `system_loss_pct` and
`consecutive_losses` alone.
*Guarded by:* `test_day_roll_clears_daily_but_not_system`.

## 6. Full contract

See `api_spec.yaml`. Summary:

**Publishes:** `risk.unified` - the nine-field Risk model.

**Subscribes:** `risk.loss_reported` (517), `trade.opened` and `trade.closed`
(563), `emergency.halt` and `risk.kill_switch.reset_completed` (516),
`SYS_DAY` (806).

**Dependencies:** 516, 517, 806.

## 7. Settings

| Key | Value | Reasoning |
|---|---|---|
| `publish_on_day_roll` | `true` | A day roll zeroes the daily counters, which is a real change to the picture. A consumer driven only by change events would otherwise keep showing yesterday's daily loss until the next trade arrives. Setting it false makes the roll silent, which is only sensible for a consumer that polls. |

No threshold lives here on purpose - a limit in this config would be a second
place to define the same rule 516 already owns.

## 8. Health states

| State | Condition | Effect |
|---|---|---|
| `UNHEALTHY` | not started | restart policy applies |
| `DEGRADED` | nothing received yet, or kill switch active | logged, **no restart** |
| `HEALTHY` | collecting and not halted | - |

`details` carries the whole Risk model plus `published` and `day_rolls`.

## 9. Snapshot

Saves the full Risk model plus `seen_any`, `published` and `day_rolls`.
`seen_any` matters: without it a restored atom would publish its first picture
as if it had just learned it, and `kill_switch_state` is restored on purpose
(5.3).

## 10. Safe modification

**Safe without fear**
- `publish_on_day_roll`
- adding an *optional* field to `risk.unified`
- log wording, health message text

**Breaks consumers - needs coordination**
- renaming or removing any of the nine Risk fields: the payload is the
  documented data model, and 856 / 663 / 664 / 665 / 700 are all specified
  against it
- changing when it publishes: a consumer written for change-driven updates
  behaves differently under a periodic one

**Violates a settled decision - do not do**
- adding any threshold or any halting behaviour (5.1)
- reading a clock for the day roll (5.2)
- clearing the kill switch anywhere but on the reset event (5.3)
- publishing a zeroed picture before real input (5.4)
- returning HEALTHY while the kill switch is on (5.5)

## 11. Who depends on it

**Consumes from:** 516, 517, 563, 806.

**Consumed by: nobody yet.** The planned consumers - 856, 663, 664, 665, and
section 700 - are all unbuilt. This is stated plainly rather than left
implicit: as of this version the atom publishes into an empty room, and its
value is realised the day one of those is built.

**If 500 stops:** nothing stops. No enforcement depends on it, and no order
path passes through it. The platform loses visibility of its own risk state,
not its ability to run or to halt.

## 12. Tests

24 tests.

| Area | Count | What it guards |
|---|---|---|
| structure | 5 | syntax, no `print()`, manifest matches code, payload is exactly the Risk model, collects-not-enforces |
| collecting | 6 | loss accumulation across three scopes, trade counts, non-negative open count, consecutive losses, halt and reset, malformed input |
| day roll | 3 | daily cleared but system kept, kill switch survives, source is 806 |
| honesty | 4 | nothing before input, day roll alone publishes nothing, timestamp inherited, no invented timestamp |
| health | 4 | three states plus halted-is-DEGRADED |
| lifecycle | 2 | stop does not zero the book, snapshot keeps the halt |

## 13. Behaviour proven by running

Unit tests: **24 passed in 0.75s**.

Live chain through a miniature bus with the real 516 and 517:

```
1) trade opened      open=1  daily=1  consec=0  daily_loss=0.0   system=0.0   kill=False
2) closed at a loss  open=0  daily=1  consec=1  daily_loss=0.0   system=0.0   kill=False
3) loss over limit   open=0  daily=1  consec=1  daily_loss=90.0  system=90.0  kill=True
4) SYS_DAY           open=0  daily=0  consec=1  daily_loss=0.0   system=90.0  kill=True
```

Step 3 shows 516 halting and 500 picking the halt up through the event, with no
contact between the two atoms. Step 4 shows the day clearing the daily figures
while the halt and the system loss stand.

**Not yet proven:** behaviour under a real 563 emitting real `trade.opened` /
`trade.closed` from actual executions. The chain test drove those events
directly.

## 14. Deliberately not built

- **No limits, no halting.** 5.1. The unbuilt 501-515 own thresholds and
  sizing; 516 owns the switch.
- **No `risk.limit.hit`.** The 850 paper names that event for dashboard 856,
  but no spec defines when it fires or what it carries. Inventing it here would
  be guessing at a contract, so it is left unbuilt and named as a gap.
- **No exposure, leverage or margin.** 516 holds `max_exposure_pct`,
  `max_leverage` and `max_margin_usage_pct` in config and, by its own comment,
  never checks them - no live source supplies those values yet. Mirroring three
  numbers nobody measures would put false figures in a published picture.
- **No history.** Only the current state is held. Risk over time belongs to
  section 700.
