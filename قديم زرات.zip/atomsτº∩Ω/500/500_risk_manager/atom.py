"""
500 - Risk Manager
==================
Single responsibility: assemble the platform's risk picture from the events of
its section and publish it as one unified state. It collects; it does not
enforce.

Why it exists: every number in the Risk model already exists inside 516 -
daily loss, system loss, per-strategy loss, trade counts, consecutive losses,
kill switch state and reason. 516 never publishes any of them. It emits
emergency.halt when a limit breaks, risk.validation.completed as a yes/no, and
a reset confirmation. Nothing carries the picture itself.

So nothing outside 516 can see the risk state. The dashboards planned to show
it (856), the portfolio views planned to display limits (663, 664, 665) and
storage all have nothing to read. This atom publishes that picture.

Settled decisions:

  * It collects, it does not enforce. 516 owns enforcement and is the only atom
    that can halt trading. Two enforcers with independently counted numbers
    would eventually disagree about whether trading is allowed, and the one
    that is wrong would still be able to act. Here the arithmetic is mirrored
    deliberately - duplication is the price of isolation, and this copy drives
    nothing.

  * The day rolls on 806's SYS_DAY, not on a local clock reading. A collector
    that decides "it is a new day" from its own clock rolls at a different
    instant than every other atom doing the same, and the daily numbers stop
    lining up across the platform.

  * kill_switch_state never clears on a day roll. It mirrors 516's own rule:
    once true it stays true until an explicit human reset. A risk picture that
    quietly cleared the halt at midnight would be reporting a market as open
    that the operator closed.

  * It publishes nothing until it has received something. An all-zero risk
    state on boot reads as "no losses, no trades, kill switch off" when the
    truth is "nothing is known yet". Silence is the honest state; health
    reports it as DEGRADED.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LOSS = "risk.loss_reported"
EVENT_TRADE_OPENED = "trade.opened"
EVENT_TRADE_CLOSED = "trade.closed"
EVENT_OUTCOME = "market.outcome.realized"   # 517
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_completed"
EVENT_DAY = "SYS_DAY"
EVENT_EXPOSURE = "risk.exposure"

EVENT_OUT = "risk.unified"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_RISK_INPUT_YET"
REASON_HALTED = "KILL_SWITCH_ACTIVE"


def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh reading.

    The risk picture describes the moment of the event that changed it. When
    the inbound event carries no stamp the key is omitted and core.event_bus
    stamps it once via setdefault.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


def _atom_key(value: Any) -> int | None:
    """Strategy id, or nothing — never an exception.

    int() on a raw payload field threw ValueError inside an event handler for
    any id that was not a clean number. That stopped the whole loss stream,
    and 516 builds its halt limits on it: the system would be left without a
    kill switch while losing.
    """
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._seen_any = False

        self._daily_loss_pct = 0.0
        self._system_loss_pct = 0.0
        self._strategy_loss_pct: dict[int, float] = {}
        self._daily_trade_count = 0
        self._open_trade_count = 0
        self._consecutive_losses = 0
        self._kill_switch_state = False
        self._exposure_pct: float | None = None
        self._max_exposure_pct: float | None = None
        self._kill_switch_reason: str | None = None

        self.published_count = 0
        self.day_rolls = 0

    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        # No thresholds are read here on purpose: this atom compares nothing.
        # Limits belong to 516, which enforces them.
        self._publish_on_day_roll = bool(context.config["publish_on_day_roll"])

        context.subscribe(EVENT_LOSS, self._on_loss)
        context.subscribe(EVENT_TRADE_OPENED, self._on_trade_opened)
        context.subscribe(EVENT_TRADE_CLOSED, self._on_trade_closed)
        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)
        context.subscribe(EVENT_EXPOSURE, self._on_exposure)
        context.subscribe(EVENT_DAY, self._on_day)

        self._initialized = True
        context.logger.info("500 initialised as a collector - it enforces nothing")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("500 started")

    async def stop(self) -> None:
        """Reversible. The risk numbers are deliberately kept.

        Restart is stop() then start(). Zeroing the loss counters here would
        make a restarted collector report a clean book while real losses stand,
        and the kill switch state would read as inactive.
        """
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "500 stopped (published=%d, kill_switch=%s)",
                self.published_count, self._kill_switch_state,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------------------------

    def _state(self) -> dict[str, Any]:
        """The Risk model exactly as the unified data model defines it."""
        return {
            "daily_loss_pct": round(self._daily_loss_pct, 6),
            "system_loss_pct": round(self._system_loss_pct, 6),
            "strategy_loss_pct": {str(k): round(v, 6) for k, v in self._strategy_loss_pct.items()},
            "daily_trade_count": self._daily_trade_count,
            "open_trade_count": self._open_trade_count,
            "consecutive_losses": self._consecutive_losses,
            "kill_switch_state": self._kill_switch_state,
            "kill_switch_reason": self._kill_switch_reason,
            "exposure_pct": self._exposure_pct,
            "max_exposure_pct": self._max_exposure_pct,
        }

    async def _emit(self, source: dict[str, Any]) -> None:
        if self._context is None:
            return
        self._seen_any = True
        self.published_count += 1
        await self._context.publish(EVENT_OUT, {**self._state(), **_ts_from(source)})

    # ------------------------------------------------------------------

    async def _on_loss(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        loss = _to_float(payload.get("loss_pct"))
        if loss is None:
            return
        self._daily_loss_pct += loss
        self._system_loss_pct += loss
        atom_id = payload.get("atom_id")
        key = _atom_key(atom_id)
        if key is not None:
            self._strategy_loss_pct[key] = self._strategy_loss_pct.get(key, 0.0) + loss
        await self._emit(payload)

    async def _on_trade_opened(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._daily_trade_count += 1
        self._open_trade_count += 1
        await self._emit(payload)

    async def _on_trade_closed(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        # عدد المراكز فقط. trade.closed ينقل صف trade_events كما هو، ولا
        # يحمل نتيجة محسوبة — 563 لا يحسب ربحًا. النتيجة تصل من 517.
        self._open_trade_count = max(0, self._open_trade_count - 1)
        await self._emit(payload)

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        """نتيجة الصفقة من 517. يُعتمد على result لا على إشارة الرقم:
        التعادل ليس خسارة ولا ربحًا، فلا يزيد التتابع ولا يصفّره."""
        if not self._running:
            return
        result = str(payload.get("result", "")).upper()
        if result == "LOSS":
            self._consecutive_losses += 1
        elif result == "WIN":
            self._consecutive_losses = 0
        await self._emit(payload)

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._kill_switch_state = True
        self._kill_switch_reason = str(payload.get("reason", ""))
        await self._emit(payload)

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._kill_switch_state = False
        self._kill_switch_reason = None
        await self._emit(payload)

    async def _on_exposure(self, payload: dict[str, Any]) -> None:
        """Notional exposure from 508.

        508 computes how much of the account is actually in the market and
        published it into an empty room: the one figure that answers "how
        exposed am I right now" reached neither this unified view nor any
        dashboard. It is carried here rather than recomputed — 508 owns the
        contract sizes and the tick values, and duplicating that arithmetic
        would give two answers to one question.
        """
        exposure = payload.get("exposure_pct")
        limit = payload.get("max_exposure_pct")
        if isinstance(exposure, (int, float)):
            self._exposure_pct = round(float(exposure), 6)
        if isinstance(limit, (int, float)):
            self._max_exposure_pct = round(float(limit), 6)
        await self._emit(payload)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        """A new day resets the daily counters - and only those.

        kill_switch_state is untouched by design: it mirrors 516's rule that
        once the switch is on, only an explicit human reset turns it off.
        """
        if not self._running:
            return
        self._daily_loss_pct = 0.0
        self._strategy_loss_pct = {}
        self._daily_trade_count = 0
        self.day_rolls += 1
        if self._publish_on_day_roll and self._seen_any:
            await self._emit(payload)

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {**self._state(), "published": self.published_count, "day_rolls": self.day_rolls}

        # Nothing received yet. Reporting HEALTHY here would let a dashboard
        # read the all-zero picture as an all-clear, when the truth is that
        # nothing is known. Restarting does not produce a risk event either.
        if not self._seen_any:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)

        # An active kill switch is a correct state of the world, not a fault in
        # this atom - but it must never read as HEALTHY, because the platform
        # is not trading.
        if self._kill_switch_state:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="%s: %s" % (REASON_HALTED, self._kill_switch_reason),
                                details=details)

        return HealthStatus(state=HealthState.HEALTHY,
                            message="published=%d" % self.published_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "seen_any": self._seen_any,
            "published": self.published_count,
            "day_rolls": self.day_rolls,
            **self._state(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._seen_any = bool(state.get("seen_any", False))
        self.published_count = int(state.get("published", 0))
        self.day_rolls = int(state.get("day_rolls", 0))
        self._daily_loss_pct = float(state.get("daily_loss_pct", 0.0))
        self._system_loss_pct = float(state.get("system_loss_pct", 0.0))
        self._strategy_loss_pct = {
            int(k): float(v) for k, v in (state.get("strategy_loss_pct") or {}).items()
        }
        self._daily_trade_count = int(state.get("daily_trade_count", 0))
        self._open_trade_count = int(state.get("open_trade_count", 0))
        self._consecutive_losses = int(state.get("consecutive_losses", 0))
        # An active kill switch survives a restore on purpose.
        self._kill_switch_state = bool(state.get("kill_switch_state", False))
        self._exposure_pct = state.get("exposure_pct")
        self._max_exposure_pct = state.get("max_exposure_pct")
        self._kill_switch_reason = state.get("kill_switch_reason")
