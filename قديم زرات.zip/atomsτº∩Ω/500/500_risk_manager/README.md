# 500 - Risk Manager

Assembles the platform's risk picture from its section's events and publishes it
as one unified state. **It collects; it does not enforce.**

```
517 -> risk.loss_reported ------\
563 -> trade.opened / closed ---+--> 500 --> risk.unified
516 -> emergency.halt ----------/
516 -> kill_switch.reset -------/
806 -> SYS_DAY -----------------/
```

## Why it exists

Every number in the Risk model already lives inside **516** - daily loss, system
loss, per-strategy loss, trade counts, consecutive losses, kill switch state and
reason. **516 never publishes any of them.** It emits `emergency.halt` when a
limit breaks, `risk.validation.completed` as a yes/no, and a reset confirmation.
None of those carries the picture.

So nothing outside 516 can see the risk state. This atom publishes it.

## What it publishes

`risk.unified` - the Risk data model, field for field:

```
daily_loss_pct · system_loss_pct · strategy_loss_pct
daily_trade_count · open_trade_count · consecutive_losses
kill_switch_state · kill_switch_reason · timestamp?
```

## What it refuses to do

- **Does not enforce.** 516 is the only atom that can halt trading. The
  arithmetic here is a deliberate mirror and drives nothing.
- **Does not read a clock.** The day rolls on 806's `SYS_DAY`. There is no
  `time.time()` in this atom - a test asserts it.
- **Does not clear the kill switch** on a day roll, a restart, or a restore.
- **Does not publish an all-clear it has not earned.** Before the first real
  input it publishes nothing and reports `DEGRADED`.

## Health

| State | When |
|---|---|
| `UNHEALTHY` | not started |
| `DEGRADED` | nothing received yet, or kill switch active |
| `HEALTHY` | collecting, switch off |

An active kill switch is `DEGRADED`, never `HEALTHY` - the platform is not
trading, and the risk report must not read green while it is stopped.

## Settings

| Key | Default | Why |
|---|---|---|
| `publish_on_day_roll` | `true` | a day roll zeroes the daily counters, which is a real change; a change-driven consumer would otherwise show yesterday's loss until the next trade |

No thresholds live here. Limits belong to 516.

## Testing

```bash
pytest atoms/500/500_risk_manager/tests/ -q
```

24 tests.
