"""Tests for atom 500 - Risk Manager."""

from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]

# Unique module name. Loading every atom under the shared name "atom" makes the
# second atom in a process import the first one's cached module.
_MODULE_NAME = "_atom500"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]

TS = 1700000000.5

# The Risk model as the unified data model defines it.
RISK_FIELDS = {
    "daily_loss_pct", "system_loss_pct", "strategy_loss_pct", "daily_trade_count",
    "open_trade_count", "consecutive_losses", "kill_switch_state", "kill_switch_reason",
}


class Ctx:
    atom_id = 500

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config if config is not None else CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(config=None):
    atom = MODULE.Atom()
    ctx = Ctx(config)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def _states(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


def _last(ctx):
    return _states(ctx)[-1]


# ---------------------------------------------------------------- structure


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 500
    assert MANIFEST["publishes"] == [MODULE.EVENT_OUT]
    assert set(MANIFEST["subscribes"]) == {
        MODULE.EVENT_LOSS, MODULE.EVENT_TRADE_OPENED, MODULE.EVENT_TRADE_CLOSED,
        MODULE.EVENT_HALT, MODULE.EVENT_RESET, MODULE.EVENT_DAY,
        MODULE.EVENT_OUTCOME, MODULE.EVENT_EXPOSURE,
    }


@pytest.mark.asyncio
async def test_payload_is_exactly_the_risk_model():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    assert RISK_FIELDS <= set(_last(ctx))
    # الانكشاف يُضاف إلى النموذج ولا يُحسب هنا: 508 يملك معاملات العقود
    # وقيم النقاط، وإعادة حسابها هنا تعطي جوابين لسؤال واحد.
    assert set(_last(ctx)) - RISK_FIELDS == {
        "timestamp", "exposure_pct", "max_exposure_pct"}


def test_collects_but_does_not_enforce():
    """Settled decision: 516 is the only enforcer.

    Two enforcers counting independently would eventually disagree about
    whether trading is allowed, and the wrong one could still act.
    """
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "emergency.halt" in src          # it listens
    assert 'publish(EVENT_OUT' in src       # and it publishes only its own state
    assert MANIFEST["publishes"] == ["risk.unified"]
    assert "limit" not in MANIFEST["config"]


# ---------------------------------------------------------------- collecting


@pytest.mark.asyncio
async def test_loss_accumulates_daily_system_and_per_strategy():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 1.5, "atom_id": 410, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 2.0, "atom_id": 410, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 0.5, "atom_id": 404, "timestamp": TS})
    state = _last(ctx)
    assert state["daily_loss_pct"] == 4.0
    assert state["system_loss_pct"] == 4.0
    assert state["strategy_loss_pct"] == {"410": 3.5, "404": 0.5}


@pytest.mark.asyncio
async def test_trade_counts_track_open_and_daily():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    await ctx.handlers[MODULE.EVENT_TRADE_CLOSED]({"pnl_pct": 1.0, "timestamp": TS})
    state = _last(ctx)
    assert state["daily_trade_count"] == 2
    assert state["open_trade_count"] == 1


@pytest.mark.asyncio
async def test_open_count_never_goes_negative():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_CLOSED]({"pnl_pct": 1.0, "timestamp": TS})
    assert _last(ctx)["open_trade_count"] == 0


@pytest.mark.asyncio
async def test_consecutive_losses_count_up_and_reset_on_a_win():
    atom, ctx = await _ready()
    for _ in range(3):
        await ctx.handlers[MODULE.EVENT_OUTCOME]({"result": "LOSS", "timestamp": TS})
    assert _last(ctx)["consecutive_losses"] == 3
    await ctx.handlers[MODULE.EVENT_OUTCOME]({"result": "WIN", "timestamp": TS})
    assert _last(ctx)["consecutive_losses"] == 0


@pytest.mark.asyncio
async def test_halt_and_reset_move_the_switch():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "RISK_DAILY_LIMIT", "timestamp": TS})
    assert _last(ctx)["kill_switch_state"] is True
    assert _last(ctx)["kill_switch_reason"] == "RISK_DAILY_LIMIT"
    await ctx.handlers[MODULE.EVENT_RESET]({"operator": "mohammed", "timestamp": TS})
    assert _last(ctx)["kill_switch_state"] is False
    assert _last(ctx)["kill_switch_reason"] is None


@pytest.mark.asyncio
async def test_malformed_loss_is_ignored_without_publishing():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": "not a number"})
    assert _states(ctx) == []


# ---------------------------------------------------------------- day roll


@pytest.mark.asyncio
async def test_day_roll_clears_daily_but_not_system():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 3.0, "atom_id": 410, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    await ctx.handlers[MODULE.EVENT_DAY]({"count": 1, "timestamp": TS})
    state = _last(ctx)
    assert state["daily_loss_pct"] == 0.0
    assert state["daily_trade_count"] == 0
    assert state["strategy_loss_pct"] == {}
    assert state["system_loss_pct"] == 3.0     # survives the day
    assert state["open_trade_count"] == 1      # an open trade does not close at midnight


@pytest.mark.asyncio
async def test_day_roll_never_clears_the_kill_switch():
    """Settled decision, mirroring 516: once on, only an explicit human reset
    turns it off. A picture that cleared the halt at midnight would report a
    market as open that the operator closed."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "RISK_SYSTEM_LIMIT", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_DAY]({"count": 1, "timestamp": TS})
    assert _last(ctx)["kill_switch_state"] is True


@pytest.mark.asyncio
async def test_day_source_is_806_not_a_local_clock():
    """Settled decision: the day rolls on SYS_DAY.

    A collector deciding "new day" from its own clock rolls at a different
    instant than every other atom doing the same.
    """
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert MODULE.EVENT_DAY == "SYS_DAY"
    assert "time.time()" not in src
    assert "86400" not in src


# ------------------------------------------------- refuses to look all-clear


@pytest.mark.asyncio
async def test_publishes_nothing_before_any_input():
    """Settled decision: an all-zero picture on boot reads as an all-clear when
    the truth is that nothing is known yet."""
    atom, ctx = await _ready()
    assert _states(ctx) == []


@pytest.mark.asyncio
async def test_day_roll_alone_publishes_nothing():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_DAY]({"count": 1, "timestamp": TS})
    assert _states(ctx) == []


@pytest.mark.asyncio
async def test_timestamp_is_inherited_not_reread():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    assert _last(ctx)["timestamp"] == TS


@pytest.mark.asyncio
async def test_no_inbound_timestamp_means_no_invented_one():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({})
    assert "timestamp" not in _last(ctx)


# ---------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_input_yet_is_degraded():
    atom, _ = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_active_kill_switch_is_degraded_never_healthy():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "RISK_DAILY_LIMIT", "timestamp": TS})
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_healthy_once_collecting_and_not_halted():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    assert (await atom.health_check()).state.name == "HEALTHY"


# ---------------------------------------------------------------- lifecycle


@pytest.mark.asyncio
async def test_stop_does_not_zero_the_book():
    """A restarted collector reporting a clean book while real losses stand is
    worse than no report at all."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 4.0, "atom_id": 410, "timestamp": TS})
    await atom.stop()
    await atom.start()
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"timestamp": TS})
    assert _last(ctx)["system_loss_pct"] == 4.0


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip_keeps_the_halt():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LOSS]({"loss_pct": 2.0, "atom_id": 404, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_HALT]({"reason": "MAX_CONSECUTIVE_LOSSES", "timestamp": TS})
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh._kill_switch_state is True
    assert fresh._kill_switch_reason == "MAX_CONSECUTIVE_LOSSES"
    assert fresh._system_loss_pct == 2.0
    assert fresh._strategy_loss_pct == {404: 2.0}


# ── الانكشاف يدخل الصورة الموحّدة ───────────────────────────────────

@pytest.mark.asyncio
async def test_exposure_reaches_the_unified_view():
    """508 يحسب الانكشاف بالقيمة الاسمية وينشره، وكان ينشر إلى غرفة
    فارغة: الرقم الوحيد الذي يقول كم من الحساب في السوق الآن لم يكن
    يظهر في صورة المخاطر الموحّدة ولا على أي لوحة."""
    atom, ctx = await _ready()
    await ctx.handlers["risk.exposure"]({
        "symbol": "USTEC", "notional": 2840.0, "equity": 10000.0,
        "exposure_pct": 3.1, "max_exposure_pct": 10.0, "timestamp": TS})
    unified = [p for n, p in ctx.published if n == "risk.unified"]
    assert unified
    assert unified[-1]["exposure_pct"] == 3.1
    assert unified[-1]["max_exposure_pct"] == 10.0


# ── معرّف الاستراتيجية لا يُحوَّل بلا حماية ─────────────────────────

@pytest.mark.asyncio
async def test_a_non_numeric_strategy_id_does_not_crash():
    """int(atom_id) بلا حماية: خسارة تحمل معرّفًا نصّيًّا ترمي ValueError
    داخل معالج أحداث، فيتوقّف تيّار الخسائر كلّه — و516 يبني حدّه عليه،
    فيصير النظام بلا مفتاح إيقاف وهو يخسر."""
    atom, ctx = await _ready()
    for bad in ("trend", "", "404a", 3.7, None, []):
        await ctx.handlers["risk.loss_reported"]({
            "loss_pct": 0.5, "atom_id": bad, "timestamp": TS})
    assert atom._daily_loss_pct > 0


@pytest.mark.asyncio
async def test_a_numeric_strategy_id_is_still_credited():
    atom, ctx = await _ready()
    await ctx.handlers["risk.loss_reported"]({
        "loss_pct": 0.5, "atom_id": 404, "timestamp": TS})
    assert atom._strategy_loss_pct.get(404) == 0.5
