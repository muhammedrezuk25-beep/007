from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom506"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 506

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    cfg = {**CONFIG}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def _breaches(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_BREACH]


async def _equity(ctx, value, ts=TS):
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({"account_id": "A", "equity": value, "balance": value,
                                              "timestamp": ts})


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_and_no_arabic_and_no_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert "print(" not in src
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 506
    assert MODULE.EVENT_BREACH in MANIFEST["publishes"]


@pytest.mark.asyncio
async def test_session_loss_accumulates_and_breaches():
    atom, ctx = await _ready(max_session_loss_pct=1.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "LONDON", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 0.6, "timestamp": TS})
    assert _breaches(ctx) == []
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 0.5, "timestamp": TS})
    assert _breaches(ctx)[0]["reason"] == MODULE.BREACH_SESSION_LOSS


@pytest.mark.asyncio
async def test_session_change_resets_its_counters():
    atom, ctx = await _ready(max_session_loss_pct=1.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "ASIA", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 1.5, "timestamp": TS})
    assert len(_breaches(ctx)) == 1
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "LONDON", "timestamp": TS})
    assert atom._book("A")["session_loss_pct"] == 0.0
    assert atom._book("A")["session_trades"] == 0


@pytest.mark.asyncio
async def test_session_trade_count_breaches():
    atom, ctx = await _ready(max_session_trades=2)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    for _ in range(2):
        await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"account_id": "A", "ticket": 1, "timestamp": TS})
    assert _breaches(ctx)[0]["reason"] == MODULE.BREACH_SESSION_TRADES


@pytest.mark.asyncio
async def test_drawdown_is_measured_from_the_days_peak():
    """A floor on balance moves with the account; a percentage of the opening
    balance ignores profit made during the day. The peak protects both."""
    atom, ctx = await _ready(max_equity_drawdown_pct=4.0)
    await _equity(ctx, 10000.0)
    await _equity(ctx, 10520.0)
    assert atom._book("A")["peak_equity"] == 10520.0
    await _equity(ctx, 10240.0)
    assert round(atom._book("A")["drawdown_pct"], 2) == 2.66
    assert _breaches(ctx) == []


@pytest.mark.asyncio
async def test_drawdown_breaches_against_the_peak_not_the_open():
    atom, ctx = await _ready(max_equity_drawdown_pct=4.0)
    await _equity(ctx, 10000.0)
    await _equity(ctx, 11000.0)
    await _equity(ctx, 10500.0)
    breach = _breaches(ctx)
    assert breach and breach[0]["reason"] == MODULE.BREACH_DRAWDOWN
    assert round(breach[0]["value"], 2) == 4.55


@pytest.mark.asyncio
async def test_a_breach_is_raised_once_not_repeatedly():
    atom, ctx = await _ready(max_session_loss_pct=1.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    for _ in range(3):
        await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 2.0, "timestamp": TS})
    assert len(_breaches(ctx)) == 1


@pytest.mark.asyncio
async def test_day_roll_clears_everything():
    atom, ctx = await _ready(max_session_loss_pct=1.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    await _equity(ctx, 10000.0)
    await _equity(ctx, 9000.0)
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 5.0, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom._book("A")["session_loss_pct"] == 0.0
    assert atom._book("A")["drawdown_pct"] == 0.0
    assert atom._book("A")["breaches"] == set()
    assert atom._book("A")["peak_equity"] == 9000.0


@pytest.mark.asyncio
async def test_limit_of_zero_is_off():
    atom, ctx = await _ready(max_session_loss_pct=0.0, max_session_trades=0,
                             max_equity_drawdown_pct=0.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 99.0, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({"account_id": "A", "ticket": 1, "timestamp": TS})
    assert _breaches(ctx) == []


@pytest.mark.asyncio
async def test_reset_clears_breaches():
    atom, ctx = await _ready(max_session_loss_pct=1.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 2.0, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_RESET]({"operator": "m", "timestamp": TS})
    assert atom._book("A")["breaches"] == set()


@pytest.mark.asyncio
async def test_health_degraded_without_account():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_degraded_without_session():
    atom, ctx = await _ready()
    await _equity(ctx, 10000.0)
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert status.message == MODULE.REASON_NO_SESSION


@pytest.mark.asyncio
async def test_health_healthy_when_within_limits():
    atom, ctx = await _ready()
    await _equity(ctx, 10000.0)
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "LONDON", "timestamp": TS})
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx(CONFIG))
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_SESSION]({"session": "NY", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_LOSS]({"account_id": "A", "loss_pct": 0.4, "timestamp": TS})
    await _equity(ctx, 10000.0)
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh._session == "NY"
    assert fresh._book("A")["session_loss_pct"] == atom._book("A")["session_loss_pct"]
    assert fresh._book("A")["peak_equity"] == atom._book("A")["peak_equity"]


# ── حدود لكل حساب ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_the_equity_peak_is_kept_per_account():
    """قمّة حقوق واحدة لكل الحسابات: حسابٌ بثمانية عشر ألفًا بعد حسابٍ
    بمئة وأربعة وثمانين ألفًا يبدو متراجعًا تسعين بالمئة — فيُغلق
    وهو سليم."""
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "big", "equity": 184177.88, "timestamp": TS})
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "small", "equity": 18417.79, "timestamp": TS})
    breaches = [p for n, p in ctx.published if n == "risk.limit.hit"]
    assert not breaches


@pytest.mark.asyncio
async def test_a_real_drawdown_in_one_account_is_caught():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "A", "equity": 10000.0, "timestamp": TS})
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "A", "equity": 9000.0, "timestamp": TS})
    breaches = [p for n, p in ctx.published if n == "risk.limit.hit"]
    assert breaches
    assert breaches[-1]["account_id"] == "A"


@pytest.mark.asyncio
async def test_one_account_breaching_leaves_the_other_alone():
    """قرار المالك: إيقاف حساب يوقف أزواجه وحده."""
    atom, ctx = await _ready()
    for acc in ("A", "B"):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": 10000.0, "timestamp": TS})
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "A", "equity": 9000.0, "timestamp": TS})
    breaches = [p for n, p in ctx.published if n == "risk.limit.hit"]
    assert {b["account_id"] for b in breaches} == {"A"}


@pytest.mark.asyncio
async def test_an_account_without_an_id_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers["portfolio.account_tracked"]({
        "equity": 10000.0, "timestamp": TS})
    assert not [p for n, p in ctx.published if n == "risk.session_limits"]
