from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_SESSION = "analysis.session_context"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_LOSS = "risk.loss_reported"
EVENT_TRADE_OPENED = "trade.opened"
EVENT_DAY = "SYS_DAY"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_completed"

EVENT_OUT = "risk.session_limits"
EVENT_BREACH = "risk.limit.hit"

BREACH_SESSION_LOSS = "SESSION_LOSS_LIMIT"
BREACH_SESSION_TRADES = "MAX_SESSION_TRADES"
BREACH_DRAWDOWN = "EQUITY_DRAWDOWN_LIMIT"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"
REASON_NO_SESSION = "NO_SESSION_CONTEXT"

SESSION_UNKNOWN = "UNKNOWN"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._max_session_loss_pct = 0.0
        self._max_session_trades = 0
        self._max_equity_drawdown_pct = 0.0

        self._session = SESSION_UNKNOWN

        self._books: dict[str, dict[str, Any]] = {}

        self.breach_count = 0
        self.no_identity_count = 0
        self.session_changes = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._max_session_loss_pct = float(cfg["max_session_loss_pct"])
        self._max_session_trades = int(cfg["max_session_trades"])
        self._max_equity_drawdown_pct = float(cfg["max_equity_drawdown_pct"])

        context.subscribe(EVENT_SESSION, self._on_session)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_LOSS, self._on_loss)
        context.subscribe(EVENT_TRADE_OPENED, self._on_trade_opened)
        context.subscribe(EVENT_DAY, self._on_day)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)

        self._initialized = True
        context.logger.info("506 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("506 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "506 stopped (breaches=%d)", self.breach_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_session(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        session = payload.get("session")
        if not isinstance(session, str) or not session:
            return
        session = session.strip().upper()
        if session == self._session:
            return
        self._session = session
        for book in self._books.values():
            book["session_loss_pct"] = 0.0
            book["session_trades"] = 0
            book["breaches"].discard(BREACH_SESSION_LOSS)
            book["breaches"].discard(BREACH_SESSION_TRADES)
        self.session_changes += 1
        await self._emit_all(payload)

    def _book(self, account_id: str) -> dict[str, Any]:
        """One book per account.

        A single equity peak across accounts made an eighteen-thousand
        account arriving after a hundred-and-eighty-four-thousand one look
        ninety percent down — and it was closed while perfectly sound.
        """
        return self._books.setdefault(account_id, {
            "peak_equity": None, "equity": None, "drawdown_pct": 0.0,
            "session_loss_pct": 0.0, "session_trades": 0, "breaches": set()})

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)
        equity = _to_float(payload.get("equity"))
        if equity is None or equity <= 0:
            return
        book = self._book(account_id)
        book["equity"] = equity
        peak = book["peak_equity"]
        if peak is None or equity > peak:
            book["peak_equity"] = equity
            book["drawdown_pct"] = 0.0
        else:
            book["drawdown_pct"] = round((peak - equity) / peak * 100.0, 6)
        await self._check_drawdown(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_loss(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        loss_pct = _to_float(payload.get("loss_pct"))
        if loss_pct is None or account_id in (None, ""):
            self.no_identity_count += account_id in (None, "")
            return
        account_id = str(account_id)
        book = self._book(account_id)
        book["session_loss_pct"] = round(
            book["session_loss_pct"] + abs(loss_pct), 6)
        await self._check_session_loss(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_trade_opened(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)
        self._book(account_id)["session_trades"] += 1
        await self._check_session_trades(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for book in self._books.values():
            book["session_loss_pct"] = 0.0
            book["session_trades"] = 0
            book["drawdown_pct"] = 0.0
            book["peak_equity"] = book["equity"]
            book["breaches"].clear()
        await self._emit_all(payload)

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        await self._emit_all(payload)

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for book in self._books.values():
            book["breaches"].clear()
        await self._emit_all(payload)

    async def _emit_all(self, payload: dict[str, Any]) -> None:
        """A state per account: one figure for all of them belongs to none."""
        for account_id in list(self._books):
            await self._emit(account_id, payload)

    async def _check_session_loss(self, account_id: str,
                                  payload: dict[str, Any]) -> None:
        book = self._book(account_id)
        if self._max_session_loss_pct <= 0:
            return
        if book["session_loss_pct"] < self._max_session_loss_pct:
            return
        await self._raise(account_id, BREACH_SESSION_LOSS,
                          book["session_loss_pct"],
                          self._max_session_loss_pct, payload)

    async def _check_session_trades(self, account_id: str,
                                    payload: dict[str, Any]) -> None:
        book = self._book(account_id)
        if self._max_session_trades <= 0:
            return
        if book["session_trades"] < self._max_session_trades:
            return
        await self._raise(account_id, BREACH_SESSION_TRADES,
                          book["session_trades"],
                          self._max_session_trades, payload)

    async def _check_drawdown(self, account_id: str,
                              payload: dict[str, Any]) -> None:
        book = self._book(account_id)
        if self._max_equity_drawdown_pct <= 0 or book["peak_equity"] is None:
            return
        if book["drawdown_pct"] < self._max_equity_drawdown_pct:
            return
        await self._raise(account_id, BREACH_DRAWDOWN, book["drawdown_pct"],
                          self._max_equity_drawdown_pct, payload)

    async def _raise(self, account_id: str, reason: str, value: float,
                     limit: float, payload: dict[str, Any]) -> None:
        """A breach names its account.

        The owner's rule: halting an account halts its pairs alone. A breach
        without a name would stop every account for one account's loss.
        """
        book = self._book(account_id)
        if self._context is None or reason in book["breaches"]:
            return
        book["breaches"].add(reason)
        self.breach_count += 1
        body: dict[str, Any] = {
            "account_id": account_id,
            "reason": reason,
            "value": value,
            "limit": limit,
            "session": self._session,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_BREACH, body)
        self._context.logger.warning(
            "506 breach %s: %s >= %s", reason, value, limit)

    def _state(self, account_id: str) -> dict[str, Any]:
        book = self._book(account_id)
        return {
            "account_id": account_id,
            "session": self._session,
            "session_loss_pct": book["session_loss_pct"],
            "session_trades": book["session_trades"],
            "max_session_loss_pct": self._max_session_loss_pct,
            "max_session_trades": self._max_session_trades,
            "peak_equity": book["peak_equity"],
            "equity": book["equity"],
            "equity_drawdown_pct": book["drawdown_pct"],
            "max_equity_drawdown_pct": self._max_equity_drawdown_pct,
            "breached": sorted(book["breaches"]),
        }

    async def _emit(self, account_id: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self._state(account_id)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {"session": self._session,
                   "accounts": len(self._books),
                   "no_identity": self.no_identity_count,
                   "books": {a: self._state(a) for a in self._books}}
        details["breach_count"] = self.breach_count

        if not any(b["equity"] is not None for b in self._books.values()):
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACCOUNT, details=details)

        if self._session == SESSION_UNKNOWN:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_SESSION, details=details)

        breached = {a: sorted(b["breaches"]) for a, b in self._books.items()
                    if b["breaches"]}
        if breached:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="breached: %s" % ",".join(
                    "%s/%s" % (a, ",".join(r)) for a, r in breached.items()),
                details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="session=%s accounts=%d" % (self._session, len(self._books)),
            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "session": self._session,
            "books": {a: {**b, "breaches": sorted(b["breaches"])}
                      for a, b in self._books.items()},
            "breach_count": self.breach_count,
            "no_identity": self.no_identity_count,
            "session_changes": self.session_changes,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._session = str(state.get("session", SESSION_UNKNOWN))
        self._books = {a: {**b, "breaches": set(b.get("breaches") or [])}
                       for a, b in (state.get("books") or {}).items()}
        self.breach_count = int(state.get("breach_count", 0))
        self.no_identity_count = int(state.get("no_identity", 0))
        self.session_changes = int(state.get("session_changes", 0))
