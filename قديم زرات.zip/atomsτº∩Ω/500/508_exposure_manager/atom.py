from __future__ import annotations

import asyncio
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_TRADE_OPENED = "trade.opened"
EVENT_TRADE_CLOSED = "trade.closed"
EVENT_VALIDATION_REQUESTED = "risk.validation.requested"
EVENT_DAY = "SYS_DAY"

EVENT_OUT = "risk.exposure"
EVENT_BREACH = "risk.limit.hit"

BREACH_EXPOSURE = "MAX_EXPOSURE"
REASON_INVALID_SPEC = "INVALID_SYMBOL_SPEC"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"
REASON_NO_SPECS = "NO_SYMBOL_SPECS"

EVENT_SPECS = "market.symbol_specs"

class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._max_exposure_pct = 0.0

        self._specs: dict[str, dict[str, float]] = {}
        self._open: dict[str, dict[str, Any]] = {}
        self._books: dict[str, dict[str, Any]] = {}
        self.no_identity_count = 0
        self._breached = False
        self._last_error = ""

        self.breach_count = 0
        self.invalid_spec_count = 0
        self.refresh_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._max_exposure_pct = float(cfg["max_exposure_pct"])

        context.subscribe(EVENT_SPECS, self._on_specs)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_TRADE_OPENED, self._on_opened)
        context.subscribe(EVENT_TRADE_CLOSED, self._on_closed)
        context.subscribe(EVENT_VALIDATION_REQUESTED, self._on_validation)
        context.subscribe(EVENT_DAY, self._on_day)

        self._initialized = True
        context.logger.info("508 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("508 started")

    async def stop(self) -> None:
        self._running = False
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "508 stopped (breaches=%d, invalid_specs=%d)",
                self.breach_count, self.invalid_spec_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        """Contract specifications, delivered rather than fetched.

        This atom used to open the bridge database itself. That put a risk atom
        inside a file section 600 owns, and tied it to MT5: a Binance
        account's specs live somewhere else entirely, so every trade on it
        would be refused for a figure this atom simply could not see.

        Keyed by symbol across providers. The same symbol at two brokers can
        carry different contract sizes, and mixing them gives a wrong
        exposure on real money — so a later reading replaces an earlier one
        for that symbol rather than merging with it.
        """
        if self._context is None:
            return
        symbols = payload.get("symbols")
        if not isinstance(symbols, list):
            return
        loaded = 0
        for row in symbols:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            size = _to_float(row.get("contract_size"))
            if not symbol or size is None or size <= 0:
                self.invalid_spec_count += 1
                continue
            self._specs[str(symbol)] = {
                "contract_size": size,
                "tick_value": _to_float(row.get("tick_value")),
                "tick_size": _to_float(row.get("tick_size")),
            }
            loaded += 1
        if loaded:
            self.refresh_count += 1


    def notional_of(self, symbol: str, size: float, price: float) -> float | None:
        spec = self._specs.get(symbol)
        if spec is None:
            return None
        return abs(size) * price * spec["contract_size"]

    def _book(self, account_id: str) -> dict[str, Any]:
        """One exposure book per account.

        A single total across accounts measured a hundred-thousand account's
        positions against a ten-thousand one's equity: the ceiling would fire
        on a sound account and stay silent on an over-exposed one.
        """
        return self._books.setdefault(account_id, {
            "equity": None, "notional": 0.0, "exposure_pct": 0.0,
            "breached": False})

    def _recompute(self, account_id: str) -> None:
        book = self._book(account_id)
        total = 0.0
        for entry in self._open.values():
            if entry.get("account_id") != account_id:
                continue
            value = entry.get("notional")
            if value is not None:
                total += value
        book["notional"] = round(total, 6)
        equity = book["equity"]
        if equity and equity > 0:
            book["exposure_pct"] = round(total / equity * 100.0, 6)
        else:
            book["exposure_pct"] = 0.0

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)
        equity = _to_float(payload.get("equity"))
        if equity is None or equity <= 0:
            return
        self._book(account_id)["equity"] = equity
        self._recompute(account_id)
        await self._check(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_opened(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        ticket = payload.get("ticket")
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        size = _to_float(payload.get("size"))
        price = _to_float(payload.get("entry_price"))
        if ticket is None or not symbol or size is None or price is None:
            return
        if account_id in (None, ""):
            self.no_identity_count += 1
            return
        account_id = str(account_id)

        notional = self.notional_of(str(symbol), size, price)
        if notional is None:
            self.invalid_spec_count += 1
            self._context.logger.error(
                "508 has no valid spec for %s - exposure not counted", symbol)

        self._open[str(ticket)] = {
            "account_id": account_id, "symbol": symbol, "size": size,
            "price": price, "notional": notional,
        }
        self._recompute(account_id)
        await self._check(account_id, payload)
        await self._emit(account_id, payload)

    async def _on_closed(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        ticket = payload.get("ticket")
        if ticket is None:
            return
        entry = self._open.get(str(ticket))
        if entry is None:
            return

        closed_size = _to_float(payload.get("size"))
        if payload.get("partial") and closed_size is not None:
            remaining = entry["size"] - abs(closed_size)
            if remaining > 0:
                entry["size"] = remaining
                entry["notional"] = self.notional_of(
                    str(entry["symbol"]), remaining, entry["price"])
            else:
                self._open.pop(str(ticket), None)
        else:
            self._open.pop(str(ticket), None)

        account_id = str(entry.get("account_id") or "")
        if account_id:
            self._recompute(account_id)
            await self._emit(account_id, payload)

    async def _on_validation(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        if str(symbol) in self._specs:
            return

        self.invalid_spec_count += 1
        # A breach names its account and symbol. Nameless, 516 reads it as a
        # systemic breach and refuses every request from every account: one
        # symbol without specs left 893 refusals and no order at all on a
        # measured run, while the other accounts were perfectly sound.
        body: dict[str, Any] = {
            "reason": REASON_INVALID_SPEC,
            "account_id": payload.get("account_id"),
            "symbol": symbol,
            "request_id": payload.get("request_id"),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_BREACH, body)
        self._context.logger.error(
            "508 refuses %s: contract_size, tick_value or tick_size is missing"
            " or zero", symbol)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        for account_id in list(self._books):
            await self._emit(account_id, payload)

    async def _check(self, account_id: str, payload: dict[str, Any]) -> None:
        """A breach names its account: halting one halts its pairs alone."""
        book = self._book(account_id)
        if self._context is None or self._max_exposure_pct <= 0:
            return
        if book["exposure_pct"] < self._max_exposure_pct:
            book["breached"] = False
            return
        if book["breached"]:
            return
        book["breached"] = True
        self.breach_count += 1
        body: dict[str, Any] = {
            "account_id": account_id,
            "reason": BREACH_EXPOSURE,
            "value": book["exposure_pct"],
            "limit": self._max_exposure_pct,
            "notional": book["notional"],
            "equity": book["equity"],
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_BREACH, body)
        self._context.logger.warning(
            "508 breach %s: %.2f%% >= %.2f%%",
            BREACH_EXPOSURE, book["exposure_pct"], self._max_exposure_pct)

    def _state(self, account_id: str) -> dict[str, Any]:
        book = self._book(account_id)
        mine = sum(1 for e in self._open.values()
                   if e.get("account_id") == account_id)
        return {
            "account_id": account_id,
            "notional": book["notional"],
            "equity": book["equity"],
            "exposure_pct": book["exposure_pct"],
            "max_exposure_pct": self._max_exposure_pct,
            "open_positions": mine,
            "symbols_with_spec": len(self._specs),
            "breached": book["breached"],
        }

    async def _emit(self, account_id: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self._state(account_id)
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)

        details = {"accounts": len(self._books),
                   "open_positions": len(self._open),
                   "symbols_with_spec": len(self._specs),
                   "no_identity": self.no_identity_count,
                   "books": {a: self._state(a) for a in self._books}}
        details["invalid_specs"] = self.invalid_spec_count
        details["breach_count"] = self.breach_count
        details["last_error"] = self._last_error

        if not self._specs:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_NO_SPECS,
                                details=details)

        if not any(b["equity"] is not None for b in self._books.values()):
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ACCOUNT, details=details)

        breached = [a for a, b in self._books.items() if b["breached"]]
        if breached:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="exposure breached: %s" % ",".join(breached),
                details=details)

        return HealthStatus(
            state=HealthState.HEALTHY,
            message="accounts=%d" % len(self._books), details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "open": dict(self._open),
            "books": dict(self._books),
            "invalid_specs": self.invalid_spec_count,
            "breach_count": self.breach_count,
            "no_identity": self.no_identity_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._open = dict(state.get("open") or {})
        self._books = {a: dict(b) for a, b in (state.get("books") or {}).items()}
        self.invalid_spec_count = int(state.get("invalid_specs", 0))
        self.breach_count = int(state.get("breach_count", 0))
        self.no_identity_count = int(state.get("no_identity", 0))
