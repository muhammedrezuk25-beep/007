from __future__ import annotations

import ast
import importlib.util
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom508"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0

# Real values read off a live MT5 account.
SPECS = {"USTEC": (1.0, 0.01, 0.01), "XAUUSD": (100.0, 0.1, 0.01),
         "EURUSD": (100000.0, 1.0, 0.00001), "BTCUSD": (1.0, 0.01, 0.01),
         "BADSYM": (0.0, 0.0, 0.0)}


class Ctx:
    atom_id = 508

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _make_db(specs=None):
    tmp = tempfile.mkdtemp()
    path = str(Path(tmp) / "nq.db")
    connection = sqlite3.connect(path)
    connection.execute(
        "CREATE TABLE prices (symbol TEXT PRIMARY KEY, contract_size REAL,"
        " tick_value REAL, tick_size REAL)")
    for symbol, (cs, tv, ts) in (SPECS if specs is None else specs).items():
        connection.execute("INSERT INTO prices VALUES (?,?,?,?)", (symbol, cs, tv, ts))
    connection.commit()
    connection.close()
    return path, tmp


async def _ready(**over):
    specs = over.pop("specs", None)
    over.pop("db_path", None)
    cfg = {**CONFIG}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    atom._running = True
    if specs is None:
        specs = [("USTEC", 1.0, 1.0, 0.01), ("EURUSD", 100000.0, 1.0, 0.00001),
                 ("XAUUSD", 100.0, 1.0, 0.01)]
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": s, "contract_size": c, "tick_value": v,
                     "tick_size": k} for s, c, v, k in specs],
        "timestamp": TS})
    return atom, ctx, None


def _breaches(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_BREACH]


def _exposure(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


async def _equity(ctx, value, ts=TS, account_id="A"):
    await ctx.handlers[MODULE.EVENT_ACCOUNT]({
        "account_id": account_id, "equity": value, "timestamp": ts})


async def _open(ctx, ticket, symbol, size, price, ts=TS, account_id="A"):
    await ctx.handlers[MODULE.EVENT_TRADE_OPENED]({
        "account_id": account_id, "ticket": ticket, "symbol": symbol,
        "size": size, "entry_price": price, "timestamp": ts})


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_and_no_arabic_and_no_docstring():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    manifest = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert "print(" not in src
    assert ast.get_docstring(ast.parse(src)) is None
    for text in (src, manifest):
        assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_it_touches_no_database_at_all():
    """الجسر ملف قسم 600. وفتحه من ذرّة مخاطر يربطها بمنصّة واحدة:
    حساب على بايننس لا تصله معاملاته، فتُرفض كل صفقة عليه ظنًّا أن
    البيان غائب."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for marker in ("sqlite3", "nq_brain", "SELECT", "_bridge_connect"):
        assert marker not in src


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_notional_uses_the_brokers_contract_size():
    """0.33 lots is 9,372 on an index and 87,450 on gold. Without the broker's
    own contract size the two look identical and exposure is wrong by orders
    of magnitude."""
    atom, ctx, tmp = await _ready()
    try:
        assert round(atom.notional_of("USTEC", 0.33, 28400.0), 2) == 9372.00
        assert round(atom.notional_of("XAUUSD", 0.33, 2650.0), 2) == 87450.00
        assert round(atom.notional_of("EURUSD", 0.33, 1.085), 2) == 35805.00
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_exposure_is_notional_over_equity_not_margin():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 10000.0)
        await _open(ctx, 1, "USTEC", 0.33, 28400.0)
        state = _exposure(ctx)[-1]
        assert round(state["notional"], 2) == 9372.00
        assert round(state["exposure_pct"], 2) == 93.72
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_positions_accumulate():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "USTEC", 0.33, 28400.0)
        await _open(ctx, 2, "XAUUSD", 0.33, 2650.0)
        assert round(_exposure(ctx)[-1]["notional"], 2) == 96822.00
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_closing_removes_the_position():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "USTEC", 0.33, 28400.0)
        await ctx.handlers[MODULE.EVENT_TRADE_CLOSED]({"ticket": 1, "timestamp": TS})
        assert _exposure(ctx)[-1]["notional"] == 0.0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_partial_close_reduces_not_removes():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "USTEC", 1.0, 28400.0)
        await ctx.handlers[MODULE.EVENT_TRADE_CLOSED]({
            "ticket": 1, "size": 0.6, "partial": True, "timestamp": TS})
        assert round(_exposure(ctx)[-1]["notional"], 2) == round(0.4 * 28400.0, 2)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_exposure_breach():
    atom, ctx, tmp = await _ready(max_exposure_pct=20.0)
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "XAUUSD", 0.33, 2650.0)
        breach = _breaches(ctx)
        assert breach and breach[0]["reason"] == MODULE.BREACH_EXPOSURE
        assert round(breach[0]["value"], 2) == 87.45
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_zero_spec_refuses_instead_of_defaulting_to_one():
    """Fail closed: a market maker returning zero for contract size must not
    be treated as 1.0, which would understate exposure silently."""
    atom, ctx, tmp = await _ready()
    try:
        assert atom.notional_of("BADSYM", 1.0, 100.0) is None
        await ctx.handlers[MODULE.EVENT_VALIDATION_REQUESTED]({
            "request_id": "r1", "symbol": "BADSYM", "timestamp": TS})
        breach = _breaches(ctx)
        assert breach and breach[0]["reason"] == MODULE.REASON_INVALID_SPEC
        assert breach[0]["request_id"] == "r1"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_unknown_symbol_is_refused_too():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_VALIDATION_REQUESTED]({
            "request_id": "r1", "symbol": "NEVER_SEEN", "timestamp": TS})
        assert _breaches(ctx)[0]["reason"] == MODULE.REASON_INVALID_SPEC
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_known_symbol_passes_silently():
    atom, ctx, tmp = await _ready()
    try:
        await ctx.handlers[MODULE.EVENT_VALIDATION_REQUESTED]({
            "request_id": "r1", "symbol": "USTEC", "timestamp": TS})
        assert _breaches(ctx) == []
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_position_without_spec_is_not_counted():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "BADSYM", 1.0, 100.0)
        assert _exposure(ctx)[-1]["notional"] == 0.0
        assert atom.invalid_spec_count == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_no_specs_yet_is_degraded_not_unhealthy():
    """قبل وصول أوّل حزمة معاملات لا يعرف هذا القسم شيئًا — وهو مدخل
    جائع لا عطل فيه."""
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG})
    await atom.initialize(ctx)
    atom._running = True
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_degraded_without_account():
    atom, ctx, tmp = await _ready()
    try:
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_healthy_within_limits():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    path, tmp = _make_db()
    try:
        atom = MODULE.Atom()
        await atom.initialize(Ctx({**CONFIG, "db_path": path}))
        assert (await atom.health_check()).state.name == "UNHEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_snapshot_restore_keeps_open_positions():
    atom, ctx, tmp = await _ready()
    try:
        await _equity(ctx, 100000.0)
        await _open(ctx, 1, "USTEC", 0.33, 28400.0)
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert round(fresh._book("A")["notional"], 2) == 9372.00
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ── الجسر ملك قسم 600 ───────────────────────────────────────────────

def test_it_does_not_open_the_bridge_itself():
    """كان يفتح nq_brain.db ليقرأ معاملات العقود، وهو ذرّة مخاطر.

    والأثر ليس أسلوبيًّا: الجسر ملف MT5، فحساب على بايننس أو ريثمك لا
    تصله معاملاته أبدًا — ويرفض 508 التداول عليه ظنًّا أن البيان غائب."""
    import yaml as _y
    manifest = _y.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
    assert "db_path" not in manifest["config"]
    assert "market.symbol_specs" in manifest["subscribes"]
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "sqlite3" not in src
    assert "nq_brain" not in src


@pytest.mark.asyncio
async def test_specs_arrive_as_an_event():
    atom, ctx, _ = await _ready(specs=[])
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "USTEC", "contract_size": 1.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": TS})
    assert atom.notional_of("USTEC", 1.0, 28400.0) == 28400.0


@pytest.mark.asyncio
async def test_specs_from_two_providers_do_not_collide():
    """رمز واحد عند وسيطين قد يختلف معامله. والخلط يعطي انكشافًا خاطئًا
    بمال حقيقي."""
    atom, ctx, _ = await _ready(specs=[])
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "USTEC", "contract_size": 1.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": TS})
    await ctx.handlers["market.symbol_specs"]({
        "provider": "binance",
        "symbols": [{"symbol": "BTCUSD", "contract_size": 1.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": TS})
    assert atom.notional_of("USTEC", 1.0, 28400.0) == 28400.0
    assert atom.notional_of("BTCUSD", 1.0, 63000.0) == 63000.0


@pytest.mark.asyncio
async def test_a_missing_spec_names_its_symbol_not_the_whole_system():
    """خرق معاملات العقد كان يُنشر بلا حساب، و516 يعدّ ما لا حساب له
    خرقًا نظاميًّا فيرفض كل طلب من كل حساب.

    وقيس على تشغيل حيّ: رمزٌ واحد بلا معاملات ترك 893 رفضًا وصفر أمر —
    والحسابات الأخرى سليمة تمامًا."""
    atom, ctx, _ = await _ready(specs=[("USTEC", 1.0, 1.0, 0.01)])
    await ctx.handlers["risk.validation.requested"]({
        "account_id": "GOLD", "symbol": "XAUUSD",
        "request_id": "r1", "timestamp": TS})
    breaches = [p for n, p in ctx.published if n == "risk.limit.hit"]
    assert breaches
    assert breaches[-1]["account_id"] == "GOLD"
    assert breaches[-1]["symbol"] == "XAUUSD"
