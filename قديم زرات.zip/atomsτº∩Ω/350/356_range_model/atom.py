"""
356 — نموذج التذبذب الاحتمالي (Range Probability Model)

المدخل: analysis.volatility_calculated (153). ينشر:
probability.range_model_updated.

منطق مُستنتَج: احتمال حركة عرضية (Range) يتصاعد مع التذبذب
(std_dev) — تفسير تداولي قياسي: تذبذب مرتفع بلا اتجاه واضح غالبًا
يدل على تردد/تجميع (Range)، لا استمرارية اتجاهية. نطاق نسبي (لا
مطلق، بما إن std_dev بوحدات السعر الخام): std_dev/(std_dev + مرجع
ثابت) — دالة تتقارب لـ1 بدون سقف صريح يحتاج ضبط لكل أداة.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_REFERENCE_SCALE = 10.0  # مرجع تطبيع افتراضي — يحتاج ضبط فعلي حسب الأداة وقت الإنتاج


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._reference_scale = _REFERENCE_SCALE
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._reference_scale = float(context.config.get("reference_scale", _REFERENCE_SCALE))
        context.subscribe("analysis.volatility_calculated", self._on_volatility)
        context.logger.info("RangeProbabilityModel(356) تمت تهيئته (reference_scale=%.2f)", self._reference_scale)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("RangeProbabilityModel(356) بدأ الاستماع لـ153")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_volatility(self, payload: dict) -> None:
        if self._context is None:
            return
        std_dev = payload["std_dev"]
        range_probability = std_dev / (std_dev + self._reference_scale) if (std_dev + self._reference_scale) > 0 else 0.0

        self.updates_count += 1
        await self._context.publish(
            "probability.range_model_updated",
            {"symbol": payload.get("symbol"), "std_dev": std_dev, "range_probability": round(range_probability, 4)},
        )
