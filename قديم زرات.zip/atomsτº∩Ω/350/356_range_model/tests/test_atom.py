import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom356"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=356, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_zero_volatility_zero_range_probability():
    print("\n--- test_zero_volatility_zero_range_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_volatility({"symbol": "NQ", "std_dev": 0.0})
    events = [p for n, p in published if n == "probability.range_model_updated"]
    assert events[0]["range_probability"] == 0.0
    print(f"OK — صفر تذبذب → صفر احتمال Range: {events[0]}")


async def test_high_volatility_higher_range_probability():
    print("\n--- test_high_volatility_higher_range_probability ---")
    context1, published1 = make_context({"reference_scale": 10.0})
    atom1 = Atom()
    await atom1.initialize(context1)
    await atom1._on_volatility({"symbol": "NQ", "std_dev": 2.0})

    context2, published2 = make_context({"reference_scale": 10.0})
    atom2 = Atom()
    await atom2.initialize(context2)
    await atom2._on_volatility({"symbol": "NQ", "std_dev": 50.0})

    low = [p for n, p in published1 if n == "probability.range_model_updated"][0]["range_probability"]
    high = [p for n, p in published2 if n == "probability.range_model_updated"][0]["range_probability"]
    assert high > low
    print(f"OK — تذبذب أعلى → احتمال Range أعلى: {low} < {high}")


async def test_range_probability_bounded_below_one():
    print("\n--- test_range_probability_bounded_below_one ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_volatility({"symbol": "NQ", "std_dev": 100000.0})  # تذبذب ضخم جدًا
    events = [p for n, p in published if n == "probability.range_model_updated"]
    assert 0 < events[0]["range_probability"] < 1.0
    print(f"OK — حتى تذبذب ضخم جدًا، الاحتمال يبقى تحت 1.0 بدقّة: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_volatility({"symbol": "NQ", "std_dev": 5.0})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.updates_count == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [
        test_zero_volatility_zero_range_probability,
        test_high_volatility_higher_range_probability,
        test_range_probability_bounded_below_one,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
