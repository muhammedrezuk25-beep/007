import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom365"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self, atom_id=365):
        return AtomContext(
            atom_id=atom_id, config={}, logger=_NullLogger(),
            publish=self.publish, subscribe=self.subscribe,
        )


def _install_fake_706(bus: FakeEventBus, known_models: dict) -> None:
    """706 مزيَّفة للاختبار فقط — تجاوب على كل load_requested بالبيانات
    المعروفة أو found=False. تُثبِت منطق 365 صحيح، لا تكامل حقيقي مع 706."""
    async def fake_706_handler(payload):
        model_name = payload["model_name"]
        found = model_name in known_models
        await bus.publish(
            "storage.persistence.load_response",
            {
                "request_id": payload["request_id"], "found": found,
                "version": known_models.get(model_name, {}).get("version"),
                "data": known_models.get(model_name, {}).get("data"),
            },
        )
    bus.subscribe("storage.persistence.load_requested", fake_706_handler)


async def test_successful_load_registers_into_364_cache_and_confirms():
    print("\n--- test_successful_load_registers_into_364_cache_and_confirms ---")
    bus = FakeEventBus()
    _install_fake_706(bus, {"vol_model": {"version": "3.0.0", "data": {"x": 1}}})
    atom = Atom()
    await atom.initialize(bus.make_context())

    await bus.publish("model.load_requested", {"model_name": "vol_model"})

    register_events = [p for n, p in bus.published if n == "model.register_requested"]
    assert len(register_events) == 1, "لازم يعيد النشر لـ364 لتحديث الكاش الحي"
    assert register_events[0] == {"model_name": "vol_model", "version": "3.0.0", "data": {"x": 1}}

    loaded_events = [p for n, p in bus.published if n == "model.loaded"]
    assert len(loaded_events) == 1
    assert atom.loaded_count == 1
    print(f"OK — تحميل ناجح من 706 (مزيَّفة) أعاد التسجيل بـ364 وأكَّد التحميل: {loaded_events[0]}")


async def test_model_not_found_in_storage_publishes_failure():
    print("\n--- test_model_not_found_in_storage_publishes_failure ---")
    bus = FakeEventBus()
    _install_fake_706(bus, {})  # لا نماذج معروفة إطلاقًا
    atom = Atom()
    await atom.initialize(bus.make_context())

    await bus.publish("model.load_requested", {"model_name": "does_not_exist"})

    failed_events = [p for n, p in bus.published if n == "model.load_failed"]
    assert len(failed_events) == 1
    assert atom.failed_count == 1
    register_events = [p for n, p in bus.published if n == "model.register_requested"]
    assert len(register_events) == 0, "لا تسجيل بالكاش لنموذج غير موجود فعليًا"
    print(f"OK — نموذج غير موجود بالتخزين → load_failed، لا تسجيل زائف: {failed_events[0]}")


async def test_response_with_unknown_request_id_ignored_safely():
    print("\n--- test_response_with_unknown_request_id_ignored_safely ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    # رد يصل بلا طلب مطابق مسبق (مثلاً وصل متأخر بعد أن نُسي الطلب)
    await bus.publish("storage.persistence.load_response", {"request_id": "unknown-xyz", "found": True, "data": "x"})
    assert atom.loaded_count == 0 and atom.failed_count == 0
    print("OK — رد بـrequest_id غير معروف يُتجاهَل بأمان، بلا استثناء ولا تأثير")


async def test_multiple_concurrent_loads_do_not_cross_contaminate():
    print("\n--- test_multiple_concurrent_loads_do_not_cross_contaminate ---")
    bus = FakeEventBus()
    _install_fake_706(bus, {
        "model_a": {"version": "1.0.0", "data": "A"},
        "model_b": {"version": "1.0.0", "data": "B"},
    })
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.load_requested", {"model_name": "model_a"})
    await bus.publish("model.load_requested", {"model_name": "model_b"})

    registers = {r["model_name"]: r["data"] for n, r in bus.published if n == "model.register_requested"}
    assert registers == {"model_a": "A", "model_b": "B"}
    print(f"OK — طلبان متزامنان لنموذجين مختلفين، كل واحد وصل ببياناته الصحيحة: {registers}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    _install_fake_706(bus, {"m": {"version": "1.0.0", "data": "x"}})
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.load_requested", {"model_name": "m"})
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.initialize(bus.make_context())
    await atom2.restore(snap)
    assert atom2.loaded_count == 1
    print("OK — restore() نقل عدّادات loaded/failed بدقّة")


async def main():
    tests = [
        test_successful_load_registers_into_364_cache_and_confirms,
        test_model_not_found_in_storage_publishes_failure,
        test_response_with_unknown_request_id_ignored_safely,
        test_multiple_concurrent_loads_do_not_cross_contaminate,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
