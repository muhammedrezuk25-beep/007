"""
365 — Model Loader (محمّل النماذج، الاحتمالات)

المسؤولية: يجسر بين التخزين الدائم (706 Persistence، غير مبنية بعد)
وكاش 364 (Model Repository) الحي — تحميل "بارد" لنموذج مو موجود
حاليًا بكاش 364، لا مجرد استعلام عمّا هو محمَّل أصلًا (هذا دور 364
نفسها عبر get_requested/get_response).

706 غير مبنية بعد: يُنشَر storage.persistence.load_requested نحوها،
لا مستهلك حقيقي حاليًا. الاختبارات تحاكي "706 مزيَّفة" (fake responder
بالاختبار فقط) للتحقق من صحة منطق 365 نفسه — لا تحقق تكامل حقيقي مع
706 فعلية (لأنها غير موجودة).

بعد تحميل ناجح من 706: 365 تنشر model.register_requested
(نفس حدث تسجيل 364 — تُدخِل النموذج المحمَّل حديثًا لكاش 364 الحي
تلقائيًا، توحيد مصدر بدل تكرار منطق تخزين)، ثم model.loaded
كتأكيد إتمام خاص فيها.
"""

from __future__ import annotations

import time
import uuid

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._pending_requests: dict[str, dict] = {}  # request_id -> {"model_name": ..., "requested_at": ...}
        self.loaded_count = 0
        self.failed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("model.load_requested", self._on_load_requested)
        context.subscribe("storage.persistence.load_response", self._on_persistence_response)
        context.logger.info("ModelLoader(365) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelLoader(365) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"loaded={self.loaded_count} failed={self.failed_count} pending={len(self._pending_requests)}",
        )

    async def snapshot(self) -> dict:
        return {"loaded_count": self.loaded_count, "failed_count": self.failed_count}

    async def restore(self, state: dict) -> None:
        self.loaded_count = state.get("loaded_count", 0)
        self.failed_count = state.get("failed_count", 0)

    # ------------------------------------------------------------------

    async def _on_load_requested(self, payload: dict) -> None:
        if self._context is None:
            return
        model_name = payload["model_name"]
        version = payload.get("version")
        internal_request_id = str(uuid.uuid4())
        self._pending_requests[internal_request_id] = {
            "model_name": model_name, "version": version, "requested_at": time.time(),
        }
        await self._context.publish(
            "storage.persistence.load_requested",
            {"request_id": internal_request_id, "model_name": model_name, "version": version},
        )

    async def _on_persistence_response(self, payload: dict) -> None:
        if self._context is None:
            return
        request_id = payload.get("request_id")
        pending = self._pending_requests.pop(request_id, None)
        if pending is None:
            return  # رد لطلب مو منّا، أو وصل بعد timeout — يُتجاهَل بأمان

        model_name = pending["model_name"]
        if not payload.get("found"):
            self.failed_count += 1
            await self._context.publish(
                "model.load_failed", {"model_name": model_name, "reason": "غير موجود بالتخزين الدائم (706)"}
            )
            return

        version = payload.get("version")
        data = payload.get("data")

        # يُدخِل النموذج المحمَّل حديثًا لكاش 364 الحي — توحيد مصدر،
        # لا تكرار منطق تخزين هنا
        await self._context.publish(
            "model.register_requested", {"model_name": model_name, "version": version, "data": data}
        )
        self.loaded_count += 1
        await self._context.publish("model.loaded", {"model_name": model_name, "version": version})
