"""
358 — معامل هيرست (Hurst Exponent)

يشترك: market_data.candle_closed. منطق: يحدد هل السوق اتجاهي
(H>0.55) أو عرضي (H≤0.55)، نفس منطق "البوابة الثامنة" بوثيقة الـ8
بوابات (لم تُرفَق لي — أطبّق التعريف الإحصائي القياسي لمعامل هيرست
نفسه، لا نسخة مبسَّطة كـ165). ينشر: probability.hurst_calculated.

منطق حساب حقيقي (R/S — Rescaled Range Analysis، الطريقة القياسية
الأبسط لتقدير H): لعائدات نافذة من N شمعة —
1. عائدات لوغاريتمية: r_i = ln(close_i / close_{i-1})
2. الانحراف التراكمي عن المتوسط: Y_k = Σ(r_i - mean(r))، لـk=1..N
3. المدى R = max(Y) - min(Y)
4. الانحراف المعياري S لعائدات النافذة
5. R/S، وH = ln(R/S) / ln(N/2)

تقدير بنافذة واحدة (لا انحدار متعدد المقاييس الكامل) — تبسيط
عملي للحساب اللحظي التراكمي، موثَّق صراحة، ليس التعريف الأكاديمي
الكامل متعدد النطاقات.
"""

from __future__ import annotations

import math

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

PROBABILITY_CENTER = 0.5


_DEFAULT_WINDOW = 30
_TREND_THRESHOLD = 0.55


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._closes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("HurstExponent(358) تمت تهيئته (window=%d)", self._window)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("HurstExponent(358) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(candle["close"])
        if len(closes) > self._window + 1:
            closes.pop(0)
        if len(closes) <= self._window:
            return

        hurst = self._compute_hurst(closes)
        regime = "trending" if hurst > _TREND_THRESHOLD else "range"

        self.calculations_count += 1
        await self._context.publish(
            "probability.hurst_calculated", {"symbol": symbol, "hurst": round(hurst, 4), "regime": regime}
        )

    @staticmethod
    def _compute_hurst(closes: list[float]) -> float:
        returns = [math.log(closes[i] / closes[i - 1]) for i in range(1, len(closes)) if closes[i - 1] > 0]
        n = len(returns)
        if n < 2:
            return PROBABILITY_CENTER

        mean_r = sum(returns) / n
        cumulative = 0.0
        cumulative_series = []
        for r in returns:
            cumulative += r - mean_r
            cumulative_series.append(cumulative)

        range_r = max(cumulative_series) - min(cumulative_series)
        variance = sum((r - mean_r) ** 2 for r in returns) / n
        std_dev = math.sqrt(variance)

        if std_dev == 0 or range_r == 0:
            return PROBABILITY_CENTER  # بلا تباين حقيقي — لا يمكن الحكم، قيمة محايدة

        rs = range_r / std_dev
        denominator = math.log(n / 2)
        if denominator == 0:
            return PROBABILITY_CENTER
        hurst = math.log(rs) / denominator
        return max(0.0, min(1.0, hurst))  # تقييد للنطاق النظري الصحيح [0,1]
