"""اختبارات الذرة 359 — تجميع الثقة.

المعادلة تُختبر كدالة نقية، والجدول مأخوذ حرفياً من ورقة الإصلاح.
"""
from __future__ import annotations
import ast, importlib.util, re, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]


def _load():
    spec = importlib.util.spec_from_file_location("_atom359", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom359"] = m
    spec.loader.exec_module(m); return m


import yaml as _y359
from pathlib import Path as _P359

_CFG359 = _y359.safe_load(
    (_P359(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8"))["config"]


class Ctx:
    atom_id = 359
    config = dict(_CFG359)
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    def __init__(self):
        self.published = []; self.handlers = {}
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready():
    m = _load(); a = m.Atom(); c = Ctx()
    await a.initialize(c); await a.start()
    return m, a, c


def _metrics(prob, agreement, coverage, deviation=0.20, direction="BUY", **extra):
    return {"symbol": "BTCUSDT", "probability_up": prob, "probability_center": 0.5,
            "probability_max_deviation": deviation, "agreement_score": agreement,
            "coverage": coverage, "dominant_direction": direction, **extra}


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_knows_nothing_about_individual_models():
    """ذرة حسابية بحتة — لا تعرف اسم نموذج ولا عددها."""
    code = re.sub(r'"""[\s\S]*?"""', "",
                  (ATOM_DIR / "atom.py").read_text(encoding="utf-8"))
    for banned in ('"trend"', '"reversal"', '"breakout"', '"pullback"',
                   '"momentum"', '"range"', "* 2"):
        assert banned not in code, f"وجد {banned}"


# ── جدول التحقق من ورقة الإصلاح ──
@pytest.mark.parametrize("label,prob,agree,cover,expected,passes", [
    ("6 متفقة صاعدة",        0.70, 1.00, 1.00, 1.00, True),
    ("4 متاحة كلها متفقة",   0.70, 1.00, 1.00, 1.00, True),
    ("3 صاعدة + محايد",      0.65, 1.00, 1.00, 0.75, True),
    ("5 صاعدة + هابط",       0.633, 0.833, 1.00, 0.55, False),
    ("3 متفقة من 6 متاحة",   0.70, 1.00, 0.50, 0.50, False),
    ("3 صاعدة + 3 هابطة",    0.50, 0.50, 1.00, 0.00, False),
])
def test_confidence_table_matches_fix_paper(label, prob, agree, cover, expected, passes):
    m = _load()
    got = m.Atom.compute_confidence(_metrics(prob, agree, cover))["confidence"]
    assert got == pytest.approx(expected, abs=0.02), f"{label}: {got}"
    assert (got >= 0.70) is passes, f"{label}: العتبة"


def test_full_agreement_reaches_one():
    """الإصلاح الجوهري: الإجماع الكامل يبلغ 1.0 لا 0.40."""
    m = _load()
    got = m.Atom.compute_confidence(_metrics(0.70, 1.0, 1.0))["confidence"]
    assert got == pytest.approx(1.0)   # 0.20/0.20 قد يعطي 0.9999… بالفاصلة العائمة


def test_old_formula_ceiling_is_gone():
    """المعادلة القديمة كانت تعطي 0.40 في أفضل حالة."""
    m = _load()
    old = abs(0.70 - 0.5) * 2
    new = m.Atom.compute_confidence(_metrics(0.70, 1.0, 1.0))["confidence"]
    assert old == pytest.approx(0.40)
    assert new > 0.70


def test_wider_model_range_handled_without_code_change():
    """نموذج بمدى 0.35 يُقاس بمداه هو لا بمدى مفترض."""
    m = _load()
    got = m.Atom.compute_confidence(
        _metrics(0.85, 1.0, 1.0, deviation=0.35))["confidence"]
    assert got == pytest.approx(1.0)


def test_zero_deviation_gives_zero_not_crash():
    """مدى صفري: ثقة صفر — لا قسمة على صفر ولا افتراض مدى."""
    m = _load()
    assert m.Atom.compute_confidence(_metrics(0.70, 1.0, 1.0, deviation=0.0))["confidence"] == 0.0


def test_out_of_range_probability_capped():
    """قيمة خارج المدى المعلن لا تعطي ثقة > 1."""
    m = _load()
    out = m.Atom.compute_confidence(_metrics(0.95, 1.0, 1.0, deviation=0.20))
    assert out["directional_strength"] == 1.0
    assert out["confidence"] == 1.0


def test_each_factor_isolated_for_diagnosis():
    """انخفاض الثقة يُشخَّص: أي عامل أسقطها."""
    m = _load()
    weak_dir = m.Atom.compute_confidence(_metrics(0.55, 1.0, 1.0))
    disagree = m.Atom.compute_confidence(_metrics(0.70, 0.5, 1.0))
    low_cover = m.Atom.compute_confidence(_metrics(0.70, 1.0, 0.5))
    assert weak_dir["directional_strength"] < 0.5
    assert weak_dir["agreement_score"] == 1.0
    assert disagree["agreement_score"] == 0.5
    assert disagree["directional_strength"] == 1.0
    assert low_cover["coverage"] == 0.5


@pytest.mark.asyncio
async def test_waits_for_both_sources():
    m, a, c = await _ready()
    await c.handlers["probability.models_merged"](_metrics(0.70, 1.0, 1.0))
    assert c.published == []
    await c.handlers["probability.hurst_calculated"]({"symbol": "BTCUSDT", "hurst": 0.62})
    assert len(c.published) == 1


@pytest.mark.asyncio
async def test_published_payload_carries_diagnostics():
    m, a, c = await _ready()
    await c.handlers["probability.hurst_calculated"]({"symbol": "BTCUSDT", "hurst": 0.62})
    await c.handlers["probability.models_merged"](
        _metrics(0.70, 1.0, 1.0, participating_models=4, available_models=4))
    name, p = c.published[-1]
    assert name == "probability.confidence_aggregated"
    assert p["bias"] == "BUY" and p["confidence"] == 1.0
    for key in ("directional_strength", "agreement_score", "coverage",
                "participating_models", "available_models"):
        assert key in p


@pytest.mark.asyncio
async def test_malformed_payload_dropped_not_crash():
    m, a, c = await _ready()
    await c.handlers["probability.models_merged"]({})
    await c.handlers["probability.hurst_calculated"]({"symbol": "X"})
    assert c.published == []
    assert a._dropped == 2


@pytest.mark.asyncio
async def test_health_progression():
    m, a, c = await _ready()
    assert (await a.health_check()).state.name == "DEGRADED"
    await c.handlers["probability.models_merged"](_metrics(0.70, 1.0, 1.0))
    assert "WAITING" in (await a.health_check()).message
    await c.handlers["probability.hurst_calculated"]({"symbol": "BTCUSDT", "hurst": 0.6})
    assert (await a.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_state_not_restored():
    m, a, c = await _ready()
    await c.handlers["probability.models_merged"](_metrics(0.70, 1.0, 1.0))
    snap = await a.snapshot()
    fresh = m.Atom(); await fresh.initialize(Ctx()); await fresh.restore(snap)
    assert fresh._latest_metrics == {} and fresh._latest_hurst == {}
    assert fresh.published_count == snap["published_count"]


# ── استقرار ميّت لا يُبنى عليه قرار ──────────────────────────────────

def test_the_manifest_declares_a_hurst_freshness_window():
    """358 قد يتجمّد، وهذه الذرّة تستمرّ بقيمة استقرار عمرها ساعات:
    ثقة عالية على سوق تغيّر تمامًا، وقرار تداول يُبنى عليها."""
    import yaml as _y
    from pathlib import Path as _P
    manifest = _y.safe_load(
        (_P(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8"))
    assert "max_hurst_age_s" in manifest["config"]


@pytest.mark.asyncio
async def test_a_stale_hurst_blocks_publication():
    m, a, c = await _ready()
    await c.handlers["probability.hurst_calculated"]({
        "symbol": "NQ", "hurst": 0.62, "timestamp": 1000.0})
    await c.handlers["probability.models_merged"]({
        **_metrics(0.8, 0.9, 1.0), "symbol": "NQ", "timestamp": 9999.0})
    out = [p for n, p in c.published if n == "probability.confidence_aggregated"]
    assert not out
    assert a.stale_hurst_count == 1


@pytest.mark.asyncio
async def test_a_fresh_hurst_publishes():
    m, a, c = await _ready()
    await c.handlers["probability.hurst_calculated"]({
        "symbol": "NQ", "hurst": 0.62, "timestamp": 1000.0})
    await c.handlers["probability.models_merged"]({
        **_metrics(0.8, 0.9, 1.0), "symbol": "NQ", "timestamp": 1005.0})
    out = [p for n, p in c.published if n == "probability.confidence_aggregated"]
    assert out


@pytest.mark.asyncio
async def test_a_payload_without_a_stamp_is_not_judged_stale():
    """طابع غائب ليس طابعًا قديمًا: الرفض عليه يوقف السلسلة بلا سبب."""
    m, a, c = await _ready()
    await c.handlers["probability.hurst_calculated"]({"symbol": "NQ", "hurst": 0.62})
    await c.handlers["probability.models_merged"]({
        **_metrics(0.8, 0.9, 1.0), "symbol": "NQ"})
    out = [p for n, p in c.published if n == "probability.confidence_aggregated"]
    assert out
