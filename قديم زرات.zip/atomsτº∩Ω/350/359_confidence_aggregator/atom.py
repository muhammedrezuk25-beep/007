"""
359 — تجميع الثقة الكلية (Confidence Aggregator)
==================================================
**ذرة حسابية بحتة.** تقرأ مقاييس الدمج من 357 ومعامل هيرست من 358،
وتحوّلهما إلى ثقة.

**لا تعرف عن النماذج شيئاً**: لا عددها، ولا أسماءها، ولا مدياتها. كل
ما تحتاجه يصلها في الحمولة.

**ما تغيّر**: كانت تقرأ نموذج الاتجاه بعينه (`models["trend"]`) وتحسب
`|p − 0.5| × 2`. وهذا سببان لعطل واحد:

1. **مدخل ناقص** — نموذج من ستة، فاتفاق النماذج لا أثر له
2. **مسطرة خاطئة** — `× 2` يفترض مدى [0, 1] والنماذج تُخرج [0.3, 0.7]،
   فأقصى ثقة ممكنة 0.40 بينما 454 يشترط 0.70

**المعادلة الآن**:

```
directional_strength = |probability_up − center| ÷ max_deviation
confidence = directional_strength × agreement_score × coverage
```

**ثلاثة عوامل مستقلة**: انخفاض الثقة يُشخَّص فوراً — ضعف اتجاه، أم
اختلاف نماذج، أم نقص مصادر. بلا تتبّع ست ذرات.

**`min` و`max` حماية حقيقية**: لو أخرج نموذج قيمة خارج مداه المعلن،
تتجاوز `directional_strength` الواحد.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

PROBABILITY_CENTER = 0.5


ATOM_VERSION = "2.0.0"

EVENT_MODELS = "probability.models_merged"
EVENT_HURST = "probability.hurst_calculated"
EVENT_OUT = "probability.confidence_aggregated"

REASON_NO_INPUT = "NO_INPUT_YET"
REASON_WAITING = "WAITING_FOR_BOTH_SOURCES"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._latest_metrics: dict[str, dict[str, Any]] = {}
        self._latest_hurst: dict[str, float] = {}
        self._hurst_at: dict[str, float] = {}
        self._max_hurst_age_s = 0.0
        self.stale_hurst_count = 0
        self.published_count = 0
        self._dropped = 0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_hurst_age_s = float(context.config["max_hurst_age_s"])
        context.subscribe(EVENT_MODELS, self._on_models_merged)
        context.subscribe(EVENT_HURST, self._on_hurst)
        self._initialized = True
        context.logger.info("تهيّأت الذرة %d", context.atom_id)

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (نُشر=%d، أُسقط=%d)",
                self._context.atom_id, self.published_count, self._dropped,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    async def _on_models_merged(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        if not isinstance(symbol, str):
            self._dropped += 1
            return
        self._latest_metrics[symbol] = payload
        await self._try_publish(symbol)

    async def _on_hurst(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        hurst = _to_float(payload.get("hurst"))
        if not isinstance(symbol, str) or hurst is None:
            self._dropped += 1
            return
        self._latest_hurst[symbol] = hurst
        stamp = _to_float(payload.get("timestamp"))
        if stamp is not None:
            self._hurst_at[symbol] = stamp
        await self._try_publish(symbol)

    # -------------------------------------------------- الحساب --

    @staticmethod
    def compute_confidence(metrics: dict[str, Any]) -> dict[str, float]:
        """يحوّل مقاييس 357 إلى ثقة. دالة نقية — تُختبر بلا سياق."""
        probability = _to_float(metrics.get("probability_up"))
        center = _to_float(metrics.get("probability_center"))
        deviation = _to_float(metrics.get("probability_max_deviation"))
        agreement = _to_float(metrics.get("agreement_score"))
        coverage = _to_float(metrics.get("coverage"))

        if probability is None:
            probability = PROBABILITY_CENTER
        if center is None:
            center = PROBABILITY_CENTER
        if agreement is None:
            agreement = 0.0
        if coverage is None:
            coverage = 0.0

        # مدى صفري أو مفقود يعني نماذج بلا انحراف معلن — الثقة صفر،
        # لا قسمة على صفر ولا افتراض مدى من عندنا.
        if deviation is None or deviation <= 0:
            strength = 0.0
        else:
            strength = min(1.0, abs(probability - center) / deviation)

        confidence = strength * agreement * coverage
        return {
            "confidence": max(0.0, min(1.0, confidence)),
            "directional_strength": round(strength, 6),
            "agreement_score": round(agreement, 6),
            "coverage": round(coverage, 6),
        }

    async def _try_publish(self, symbol: str) -> None:
        if self._context is None:
            return
        # المصدران معاً — نشر ثقة بلا استقرار قيمة ناقصة
        if symbol not in self._latest_metrics or symbol not in self._latest_hurst:
            return

        # واستقرار قديم أسوأ من غائب: 358 يتوقّف إن ماتت التغذية، وتبقى
        # قيمته الأخيرة في القاموس ساعات. فتُنشر ثقة عالية على سوق تغيّر،
        # ويُقاس عليها حجم مركز بمال حقيقي.
        #
        # وطابع غائب ليس طابعًا قديمًا: الرفض عليه يوقف السلسلة لحقل ناقص
        # لا لبيانات ميّتة.
        hurst_at = self._hurst_at.get(symbol)
        metrics_at = _to_float(self._latest_metrics[symbol].get("timestamp"))
        if hurst_at is not None and metrics_at is not None:
            if metrics_at - hurst_at > self._max_hurst_age_s:
                self.stale_hurst_count += 1
                return

        metrics = self._latest_metrics[symbol]
        computed = self.compute_confidence(metrics)

        self.published_count += 1
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol,
            "bias": metrics.get("dominant_direction", "NEUTRAL"),
            "confidence": round(computed["confidence"], 4),
            "stability": round(self._latest_hurst[symbol], 4),
            # حقول التشخيص: أي عامل أسقط الثقة
            "directional_strength": computed["directional_strength"],
            "agreement_score": computed["agreement_score"],
            "coverage": computed["coverage"],
            "participating_models": metrics.get("participating_models"),
            "available_models": metrics.get("available_models"),
        })

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message="لم تبدأ")

        details = {"published": self.published_count, "dropped": self._dropped,
                   "with_metrics": len(self._latest_metrics),
                   "with_hurst": len(self._latest_hurst)}

        if not self._latest_metrics and not self._latest_hurst:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        if self.published_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_WAITING, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"نُشر={self.published_count}", details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "published_count": self.published_count,
                "dropped": self._dropped}

    async def restore(self, state: dict[str, Any]) -> None:
        """المقاييس وهيرست لا تُستعادان: احتمال من تشغيل سابق يُبنى عليه
        قرار اليوم."""
        self.published_count = int(state.get("published_count", 0))
        self._dropped = int(state.get("dropped", 0))
