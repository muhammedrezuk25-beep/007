import asyncio
import pytest
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom360"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=360, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_correct_prediction_tracked():
    print("\n--- test_correct_prediction_tracked ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY", "confidence": 0.7, "stability": 0.6})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})  # مُصطنَع — الحدث الحقيقي غير مبني بعد
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events[0]["correct"] is True
    assert events[0]["accuracy"] == 1.0
    print(f"OK — تنبؤ BUY + نتيجة up = صحيح: {events[0]}")


async def test_incorrect_prediction_tracked():
    print("\n--- test_incorrect_prediction_tracked ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY", "confidence": 0.7, "stability": 0.6})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "down"})
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events[0]["correct"] is False
    assert events[0]["accuracy"] == 0.0
    print(f"OK — تنبؤ BUY + نتيجة down = خطأ: {events[0]}")


async def test_outcome_without_prior_prediction_ignored():
    print("\n--- test_outcome_without_prior_prediction_ignored ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})  # بلا تنبؤ سابق
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert len(events) == 0
    print("OK — نتيجة بلا تنبؤ سابق → صفر تتبّع")


async def test_neutral_prediction_not_tracked():
    print("\n--- test_neutral_prediction_not_tracked ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "NEUTRAL", "confidence": 0.0, "stability": 0.5})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert len(events) == 0, "NEUTRAL ليس تنبؤًا اتجاهيًا قابلًا للقياس"
    print("OK — تنبؤ NEUTRAL لا يُحتسَب (لا اتجاه فعلي للمقارنة)")


async def test_running_accuracy_across_multiple_predictions():
    print("\n--- test_running_accuracy_across_multiple_predictions ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY", "confidence": 0.7, "stability": 0.6})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})  # صحيح: 1/1
    await atom._on_prediction({"symbol": "NQ", "bias": "SELL", "confidence": 0.7, "stability": 0.6})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})  # خطأ: 1/2
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events[-1]["accuracy"] == 0.5
    assert events[-1]["total_predictions"] == 2
    print(f"OK — دقة تراكمية عبر تنبؤين: {events[-1]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY", "confidence": 0.7, "stability": 0.6})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up"})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._correct_count == 1 and atom2._total_count == 1
    print("OK — restore() نقل عدّادات الدقة بدقّة")


async def main():
    tests = [
        test_correct_prediction_tracked,
        test_incorrect_prediction_tracked,
        test_outcome_without_prior_prediction_ignored,
        test_neutral_prediction_not_tracked,
        test_running_accuracy_across_multiple_predictions,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


@pytest.mark.asyncio
async def test_actual_direction_is_derived_from_entry_and_exit():
    """517 publishes entry and exit, never actual_direction. Reading the
    missing key raised KeyError on every closed trade and model accuracy was
    never computed."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY"})
    await atom._on_outcome({"symbol": "NQ", "entry": 100.0, "exit": 110.0})
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events and events[0]["correct"] is True


@pytest.mark.asyncio
async def test_a_losing_trade_marks_the_prediction_wrong():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY"})
    await atom._on_outcome({"symbol": "NQ", "entry": 100.0, "exit": 90.0})
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events and events[0]["correct"] is False


@pytest.mark.asyncio
async def test_breakeven_is_skipped_not_guessed():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY"})
    await atom._on_outcome({"symbol": "NQ", "entry": 100.0, "exit": 100.0})
    assert [p for n, p in published if n == "probability.model_accuracy_tracked"] == []


@pytest.mark.asyncio
async def test_explicit_actual_direction_still_wins():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_prediction({"symbol": "NQ", "bias": "BUY"})
    await atom._on_outcome({"symbol": "NQ", "actual_direction": "up",
                            "entry": 100.0, "exit": 90.0})
    events = [p for n, p in published if n == "probability.model_accuracy_tracked"]
    assert events and events[0]["correct"] is True
