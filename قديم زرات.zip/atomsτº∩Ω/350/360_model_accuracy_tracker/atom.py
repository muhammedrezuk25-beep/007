"""
360 — تتبّع دقة النماذج (Model Accuracy Tracker)

لا سبك دقيق للمدخلات أُعطي — استُنتِج: يقارن تنبؤ 359
(probability.confidence_aggregated، حقيقية ومبنية) بنتيجة فعلية
لاحقة. **لا حدث "نتيجة فعلية" مبني بعد بأي قسم** (يحتاج بيانات تنفيذ
حقيقية من قسم 550/700، غير مبنيين) — افترضت اسمًا معقولاً
(market.outcome.realized {symbol, actual_direction}) وعلّمته صراحة
كافتراض، مُختبَر بأحداث مُصطنَعة فقط.

آلية: يحتفظ بآخر تنبؤ (bias) لكل رمز، وعند وصول نتيجة فعلية،
يقارنها، يحدّث عدّاد دقة تراكمي (صحيح/إجمالي). ينشر:
probability.model_accuracy_tracked.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_prediction: dict[str, str] = {}
        self._correct_count = 0
        self._total_count = 0
        self._skipped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("probability.confidence_aggregated", self._on_prediction)
        context.subscribe("market.outcome.realized", self._on_outcome)
        context.logger.info("ModelAccuracyTracker(360) تمت تهيئته — market.outcome.realized افتراضي غير مبني")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelAccuracyTracker(360) بدأ التتبّع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        accuracy = (self._correct_count / self._total_count) if self._total_count > 0 else None
        return HealthStatus(state=HealthState.HEALTHY, message=f"دقة={accuracy} ({self._correct_count}/{self._total_count})")

    async def snapshot(self) -> dict:
        return {"last_prediction": self._last_prediction, "correct_count": self._correct_count, "total_count": self._total_count}

    async def restore(self, state: dict) -> None:
        self._last_prediction = state.get("last_prediction", {})
        self._correct_count = state.get("correct_count", 0)
        self._total_count = state.get("total_count", 0)

    # ------------------------------------------------------------------

    async def _on_prediction(self, payload: dict) -> None:
        symbol = payload["symbol"]
        bias = payload.get("bias")
        if bias and bias != "NEUTRAL":
            self._last_prediction[symbol] = bias

    @staticmethod
    def _actual_direction(payload: dict) -> str | None:
        declared = payload.get("actual_direction")
        if isinstance(declared, str) and declared:
            return declared
        entry = _to_float(payload.get("entry"))
        exit_price = _to_float(payload.get("exit"))
        if entry is None or exit_price is None or entry == exit_price:
            return None
        return "up" if exit_price > entry else "down"

    async def _on_outcome(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        prediction = self._last_prediction.get(symbol)
        if prediction is None:
            return

        actual_direction = self._actual_direction(payload)
        if actual_direction is None:
            self._skipped += 1
            return

        predicted_direction = "up" if prediction == "BUY" else "down"
        is_correct = predicted_direction == actual_direction

        self._total_count += 1
        if is_correct:
            self._correct_count += 1

        accuracy = self._correct_count / self._total_count
        await self._context.publish(
            "probability.model_accuracy_tracked",
            {"symbol": symbol, "correct": is_correct, "accuracy": round(accuracy, 4), "total_predictions": self._total_count},
        )
