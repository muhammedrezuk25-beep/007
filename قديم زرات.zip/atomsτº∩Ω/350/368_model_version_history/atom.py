"""
368 — Model Version History (سجل تغييرات النماذج، الاحتمالات)

المسؤولية: سجل تدقيق (Audit Log) لكل حدث دورة حياة نموذج — إنشاء/
تحديث (model.saved)، حذف (model.deleted)، اعتماد نسخة كنشطة
(model.version_adopted). دور "الجامع" الصرف (قاعدة 1): تسجيل فقط،
بلا أي صلاحية تعديل/حذف فعلي على 364 أو أي ذرة أخرى.

v1.1.0 — توسعة مؤكَّدة: كل حدث يُضاف كسطر بالتاريخ بلا تفرّع منطقي
إضافي — الحقل الوحيد الجديد هو action (saved/deleted/version_adopted)،
بلا معالجة خاصة لكل نوع (لا حذف سطر سابق عند deleted، لا تمييز حالة
"النسخة النشطة حاليًا" — هذا سجل تاريخي بحت، ليس عارضًا لحالة حالية).

هذه الذرة نفسها هي "المصدر الوحيد" لتاريخ النماذج — فقدان سجلها
عبر Restart بلا snapshot/restore يعني ضياع تاريخ لا يمكن استرجاعه من
أي مكان آخر.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        # {model_name: [{"action": ..., "version": ..., "timestamp": ...}, ...]} — بترتيب زمني تصاعدي
        self._history: dict[str, list[dict]] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("model.saved", self._make_recorder("saved"))
        context.subscribe("model.deleted", self._make_recorder("deleted"))
        context.subscribe("model.version_adopted", self._make_recorder("version_adopted"))
        context.subscribe("model.history_requested", self._on_history_requested)
        context.logger.info("ModelVersionHistory(368) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelVersionHistory(368) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total_entries = sum(len(v) for v in self._history.values())
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._history)} نموذج مُتابَع، {total_entries} حدث تدقيق إجمالًا",
        )

    async def snapshot(self) -> dict:
        return {"history": self._history}

    async def restore(self, state: dict) -> None:
        self._history = state.get("history", {})

    # ------------------------------------------------------------------

    def _make_recorder(self, action: str):
        """factory بنفس مبدأ 766 (تفادي عيب الإغلاق المتأخر) — كل نوع
        حدث يسجَّل بـaction الصحيح الخاص فيه، لا آخر نوع بالحلقة."""

        async def handler(payload: dict) -> None:
            model_name = payload["model_name"]
            entry = {
                "action": action,
                "version": payload.get("version"),
                "timestamp": payload.get("timestamp", time.time()),
            }
            self._history.setdefault(model_name, []).append(entry)

        return handler

    async def _on_history_requested(self, payload: dict) -> None:
        if self._context is None:
            return
        request_id = payload["request_id"]
        model_name = payload["model_name"]
        await self._context.publish(
            "model.history_response",
            {"request_id": request_id, "model_name": model_name, "history": list(self._history.get(model_name, []))},
        )

