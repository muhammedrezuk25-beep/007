import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom368"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self, atom_id=368):
        return AtomContext(
            atom_id=atom_id, config={}, logger=_NullLogger(),
            publish=self.publish, subscribe=self.subscribe,
        )


async def test_records_saved_events_in_chronological_order():
    print("\n--- test_records_saved_events_in_chronological_order ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.saved", {"model_name": "m", "version": "1.0.0", "timestamp": 100.0})
    await bus.publish("model.saved", {"model_name": "m", "version": "1.1.0", "timestamp": 200.0})
    await bus.publish("model.saved", {"model_name": "m", "version": "2.0.0", "timestamp": 300.0})

    versions = [e["version"] for e in atom._history["m"]]
    actions = [e["action"] for e in atom._history["m"]]
    assert versions == ["1.0.0", "1.1.0", "2.0.0"], versions
    assert actions == ["saved", "saved", "saved"]
    print(f"OK — 3 تسجيلات saved بترتيب زمني صحيح: {versions}")


async def test_three_distinct_event_types_recorded_with_correct_action_no_late_binding_bug():
    """الاختبار الأهم بالتوسعة — يثبت عدم وجود عيب الإغلاق المتأخر
    (نفس نمط 766): saved/deleted/version_adopted كل واحد لازم يُسجَّل
    بـaction الصحيح الخاص فيه، لا آخر نوع اشتُرك به."""
    print("\n--- test_three_distinct_event_types_recorded_with_correct_action_no_late_binding_bug ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())

    await bus.publish("model.saved", {"model_name": "m", "version": "1.0.0"})
    await bus.publish("model.version_adopted", {"model_name": "m", "version": "1.0.0"})
    await bus.publish("model.deleted", {"model_name": "m", "version": "0.9.0"})

    actions = [e["action"] for e in atom._history["m"]]
    assert actions == ["saved", "version_adopted", "deleted"], (
        f"كل حدث لازم يُسجَّل بـaction مصدره الصحيح بالضبط، لا نفس القيمة مكررة (عيب إغلاق متأخر)، لقيت: {actions}"
    )
    print(f"OK — 3 أنواع أحداث مختلفة، كل واحد سُجِّل بـaction صحيح بدقّة: {actions}")


async def test_deleted_does_not_remove_prior_entries_pure_audit_log():
    print("\n--- test_deleted_does_not_remove_prior_entries_pure_audit_log ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.saved", {"model_name": "m", "version": "1.0.0"})
    await bus.publish("model.deleted", {"model_name": "m", "version": "1.0.0"})
    assert len(atom._history["m"]) == 2, "سجل تدقيق بحت — deleted يُضاف كسطر جديد، لا يحذف سطر saved السابق"
    print(f"OK — {len(atom._history['m'])} سطر بالسجل بعد saved+deleted — كلاهما محفوظان كتاريخ")


async def test_different_models_tracked_independently():
    print("\n--- test_different_models_tracked_independently ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.saved", {"model_name": "a", "version": "1.0.0"})
    await bus.publish("model.saved", {"model_name": "b", "version": "1.0.0"})
    await bus.publish("model.saved", {"model_name": "a", "version": "1.1.0"})

    assert len(atom._history["a"]) == 2
    assert len(atom._history["b"]) == 1
    print(f"OK — a: {len(atom._history['a'])} حدث، b: {len(atom._history['b'])} حدث — بلا تداخل")


async def test_history_query_via_request_response():
    print("\n--- test_history_query_via_request_response ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.saved", {"model_name": "m", "version": "1.0.0"})
    await bus.publish("model.version_adopted", {"model_name": "m", "version": "1.0.0"})

    await bus.publish("model.history_requested", {"request_id": "q1", "model_name": "m"})
    resp = [p for n, p in bus.published if n == "model.history_response"][0]
    assert resp["request_id"] == "q1"
    assert [e["action"] for e in resp["history"]] == ["saved", "version_adopted"]
    print(f"OK — استعلام السجل يرجع كل الأحداث بترتيبها: {[e['action'] for e in resp['history']]}")


async def test_query_for_unknown_model_returns_empty_history_not_error():
    print("\n--- test_query_for_unknown_model_returns_empty_history_not_error ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.history_requested", {"request_id": "q2", "model_name": "never_registered"})
    resp = [p for n, p in bus.published if n == "model.history_response"][0]
    assert resp["history"] == []
    print("OK — نموذج غير مسجَّل إطلاقًا → سجل فارغ، لا خطأ")


async def test_snapshot_restore_is_the_only_source_of_truth():
    """الأهم لهذه الذرة تحديدًا — فقدان السجل عبر Restart بلا
    snapshot/restore يعني ضياع تاريخ لا يُستعاد من أي مكان آخر."""
    print("\n--- test_snapshot_restore_is_the_only_source_of_truth ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.saved", {"model_name": "m", "version": "1.0.0"})
    await bus.publish("model.version_adopted", {"model_name": "m", "version": "1.0.0"})
    snap = await atom.snapshot()

    atom_lost = Atom()
    await atom_lost.initialize(bus.make_context())
    assert atom_lost._history == {}, "بلا restore()، السجل التاريخي بيضيع كليًا — يثبت أهمية الحفظ"

    atom_restored = Atom()
    await atom_restored.initialize(bus.make_context())
    await atom_restored.restore(snap)
    assert [e["action"] for e in atom_restored._history["m"]] == ["saved", "version_adopted"]
    print("OK — بلا restore(): تاريخ مفقود كليًا. مع restore(): استُعيد كاملًا بترتيبه الصحيح")


async def main():
    tests = [
        test_records_saved_events_in_chronological_order,
        test_three_distinct_event_types_recorded_with_correct_action_no_late_binding_bug,
        test_deleted_does_not_remove_prior_entries_pure_audit_log,
        test_different_models_tracked_independently,
        test_history_query_via_request_response,
        test_query_for_unknown_model_returns_empty_history_not_error,
        test_snapshot_restore_is_the_only_source_of_truth,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
