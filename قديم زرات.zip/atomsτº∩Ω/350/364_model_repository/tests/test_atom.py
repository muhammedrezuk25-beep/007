import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom364"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self, atom_id=364):
        return AtomContext(
            atom_id=atom_id, config={}, logger=_NullLogger(),
            publish=self.publish, subscribe=self.subscribe,
        )


async def test_register_stores_and_publishes_persist_request_and_confirmation():
    print("\n--- test_register_stores_and_publishes_persist_request_and_confirmation ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.register_requested", {"model_name": "vol_forecast", "version": "1.0.0", "data": {"w": [1, 2, 3]}})

    assert atom._models["vol_forecast"]["1.0.0"]["data"] == {"w": [1, 2, 3]}
    persist_events = [p for n, p in bus.published if n == "model.persist_requested"]
    assert len(persist_events) == 1, "لازم يُنشَر طلب حفظ حتى لو ما فيه مستهلك حاليًا (706 غير مبنية)"
    registered_events = [p for n, p in bus.published if n == "model.saved"]
    assert len(registered_events) == 1
    print(f"OK — تسجيل محلي + طلب حفظ منشور (بانتظار 706) + تأكيد تسجيل: {registered_events[0]}")


async def test_get_returns_latest_version_when_unspecified():
    print("\n--- test_get_returns_latest_version_when_unspecified ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.register_requested", {"model_name": "m", "version": "1.0.0", "data": "v1"})
    await bus.publish("model.register_requested", {"model_name": "m", "version": "2.0.0", "data": "v2"})

    await bus.publish("model.get_requested", {"request_id": "r1", "model_name": "m"})
    resp = [p for n, p in bus.published if n == "model.get_response"][0]
    assert resp["request_id"] == "r1"
    assert resp["found"] is True
    assert resp["version"] == "2.0.0" and resp["data"] == "v2"
    print(f"OK — طلب بلا تحديد إصدار يرجع الأحدث: {resp}")


async def test_get_specific_version():
    print("\n--- test_get_specific_version ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.register_requested", {"model_name": "m", "version": "1.0.0", "data": "v1"})
    await bus.publish("model.register_requested", {"model_name": "m", "version": "2.0.0", "data": "v2"})

    await bus.publish("model.get_requested", {"request_id": "r2", "model_name": "m", "version": "1.0.0"})
    resp = [p for n, p in bus.published if n == "model.get_response"][-1]
    assert resp["version"] == "1.0.0" and resp["data"] == "v1"
    print(f"OK — إصدار محدَّد صراحة يُرجَع بدقّة: {resp}")


async def test_get_not_found_returns_found_false():
    print("\n--- test_get_not_found_returns_found_false ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.get_requested", {"request_id": "r3", "model_name": "does_not_exist"})
    resp = [p for n, p in bus.published if n == "model.get_response"][0]
    assert resp["found"] is False and resp["data"] is None
    print(f"OK — نموذج غير موجود → found=False بدل استثناء: {resp}")


async def test_request_id_matching_works_with_multiple_concurrent_requests():
    print("\n--- test_request_id_matching_works_with_multiple_concurrent_requests ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.register_requested", {"model_name": "a", "version": "1.0.0", "data": "A"})
    await bus.publish("model.register_requested", {"model_name": "b", "version": "1.0.0", "data": "B"})

    await bus.publish("model.get_requested", {"request_id": "req-a", "model_name": "a"})
    await bus.publish("model.get_requested", {"request_id": "req-b", "model_name": "b"})

    responses = {r["request_id"]: r for n, r in bus.published if n == "model.get_response"}
    assert responses["req-a"]["data"] == "A"
    assert responses["req-b"]["data"] == "B"
    print(f"OK — request_id يطابق كل رد لطلبه الصحيح وسط طلبات متعددة")


async def test_snapshot_restore_preserves_full_cache():
    print("\n--- test_snapshot_restore_preserves_full_cache ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("model.register_requested", {"model_name": "m", "version": "1.0.0", "data": "v1"})
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.initialize(bus.make_context())
    await atom2.restore(snap)
    assert atom2._models["m"]["1.0.0"]["data"] == "v1"
    print("OK — restore() نقل الكاش الكامل — لا فقدان نماذج عبر Restart رغم عدم وجود 706 بعد")


async def main():
    tests = [
        test_register_stores_and_publishes_persist_request_and_confirmation,
        test_get_returns_latest_version_when_unspecified,
        test_get_specific_version,
        test_get_not_found_returns_found_false,
        test_request_id_matching_works_with_multiple_concurrent_requests,
        test_snapshot_restore_preserves_full_cache,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
