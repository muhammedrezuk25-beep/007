"""
364 — Model Repository (مستودع النماذج، الاحتمالات)

المسؤولية: تخزين نماذج بالذاكرة (Knowledge لا State)، عبر أحداث فقط
— لا كتابة قرص مباشرة (تنتظر 706 Persistence، غير موجودة بعد؛
تنشر طلب حفظ فقط، قاعدة 0).

نطاق مؤكَّد صراحة (لا افتراض): تخزّن **تعريف/معاملات النموذج بس**
— الأوزان، الإعدادات، البنية (شكل النموذج نفسه). **لا** تُخزِّن نتائج
تداول/تنبؤات (تلك مسؤولية 706 وقت ما يُبنى)، **ولا** حالة تشغيل
(عدّادات، هل محمَّل حاليًا — تلك مسؤولية snapshot()/restore() العادية
تبع أي ذرة، لا دور خاص لـ364 فيها). بمعنى آخر: 364 = "شو هو النموذج"،
لا "شو أنتج" ولا "شو حالته هلق". حقل `data` هنا **عمدًا عام/غير
مُفسَّر** (opaque) — يخزّن أيًا كان المُرسِل بالضبط، الالتزام بالنطاق
مسؤولية الناشر (364 لا تتحقق من محتوى data).

706 غير مبنية بعد: model.persist_requested تُنشَر
دائمًا (السلوك الصحيح المطلوب)، لكن لا أحد يستهلكها فعليًا حاليًا —
هذا متوقَّع ومقصود، لا خطأ. الاختبارات تتحقق من *أن الحدث نُشِر
بالشكل الصحيح*، لا من نتيجة معالجته (لأنه لا معالج حقيقي موجود بعد).

آلية طلب/استجابة عبر الأحداث (بلا استدعاء مباشر بين ذرات — قاعدة 0):
get_requested يحمل request_id، get_response يرجعه بنفس القيمة، يسمح
للطالب بمطابقة رده وسط أحداث كتير محتملة على نفس الـEvent Bus.

snapshot/restore: يحفظ الكاش الكامل بالذاكرة — يعطي مرونة حتى قبل
وجود 706 (Restart لا يفقد النماذج المسجَّلة).
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        # {model_name: {version: {"data": ..., "registered_at": float}}}
        self._models: dict[str, dict[str, dict]] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("model.register_requested", self._on_register_requested)
        context.subscribe("model.get_requested", self._on_get_requested)
        context.logger.info("ModelRepository(364) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelRepository(364) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total_versions = sum(len(v) for v in self._models.values())
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._models)} نموذج، {total_versions} إصدار إجمالًا",
        )

    async def snapshot(self) -> dict:
        return {"models": self._models}

    async def restore(self, state: dict) -> None:
        self._models = state.get("models", {})

    # ------------------------------------------------------------------

    async def _on_register_requested(self, payload: dict) -> None:
        model_name = payload["model_name"]
        version = payload["version"]
        data = payload.get("data")

        self._models.setdefault(model_name, {})[version] = {"data": data, "registered_at": time.time()}

        if self._context is not None:
            # طلب حفظ دائم — 706 غير موجودة بعد، لا مستهلك حاليًا؛ النشر
            # نفسه هو السلوك الصحيح المطلوب بغض النظر عن وجود مستهلك
            await self._context.publish(
                "model.persist_requested",
                {"model_name": model_name, "version": version, "data": data},
            )
            await self._context.publish(
                "model.saved",
                {"model_name": model_name, "version": version, "registered_at": self._models[model_name][version]["registered_at"]},
            )

    async def _on_get_requested(self, payload: dict) -> None:
        if self._context is None:
            return
        request_id = payload["request_id"]
        model_name = payload["model_name"]
        version = payload.get("version")  # None = أحدث إصدار مسجَّل بالذاكرة

        versions = self._models.get(model_name, {})
        if not versions:
            await self._context.publish(
                "model.get_response",
                {"request_id": request_id, "model_name": model_name, "version": version, "found": False, "data": None},
            )
            return

        if version is None:
            version = max(versions.keys())  # أحدث إصدار — يفترض ترقيم قابل للمقارنة نصيًا (semver-like)

        entry = versions.get(version)
        await self._context.publish(
            "model.get_response",
            {
                "request_id": request_id, "model_name": model_name, "version": version,
                "found": entry is not None, "data": entry["data"] if entry else None,
            },
        )
