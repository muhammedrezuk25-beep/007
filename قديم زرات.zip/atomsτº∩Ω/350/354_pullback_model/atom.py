"""
354 — نموذج الارتداد الاحتمالي (Pullback Probability Model)

المدخل الموثَّق: market.sweep.detected (254، **قسم 250 — غير مبني
بعد بهذه الدفعة**). الاشتراك مسجَّل مسبقًا (Event Bus لا يتطلب ناشرًا
فعليًا)، مُختبَر بأحداث مُصطنَعة بشكل مُستنتَج معقول: {symbol,
direction: "buy_side"|"sell_side", price} (254 توصف بـ"يشترك: 252/253
+ السعر الحالي" — لا شكل payload دقيق أُعطي حرفيًا).

ينشر: probability.pullback_model_updated. منطق مُستنتَج: احتمال
ارتداد بعد اكتساح سيولة يتصاعد مع تكرار الاكتساح بنفس الجهة (نفس
نمط 353 حرفيًا، ذاكرة مستقلة).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_BASE_PROBABILITY = 0.5
_INCREMENT_PER_STREAK = 0.08
_MAX_PROBABILITY = 0.82


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_direction: dict[str, str] = {}
        self._streak: dict[str, int] = {}
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.sweep.detected", self._on_sweep)
        context.logger.info("PullbackProbabilityModel(354) تمت تهيئته — 254 غير مبنية بعد")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("PullbackProbabilityModel(354) بدأ الاستماع لـ254 (غير مبنية)")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"last_direction": self._last_direction, "streak": self._streak, "updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self._last_direction = state.get("last_direction", {})
        self._streak = state.get("streak", {})
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_sweep(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        direction = payload["direction"]

        if self._last_direction.get(symbol) == direction:
            self._streak[symbol] = self._streak.get(symbol, 1) + 1
        else:
            self._streak[symbol] = 1
        self._last_direction[symbol] = direction

        probability = min(_MAX_PROBABILITY, _BASE_PROBABILITY + (self._streak[symbol] - 1) * _INCREMENT_PER_STREAK)

        self.updates_count += 1
        await self._context.publish(
            "probability.pullback_model_updated",
            {"symbol": symbol, "direction": direction, "streak": self._streak[symbol], "pullback_probability": round(probability, 4)},
        )
