"""
353 — نموذج الاختراق الاحتمالي (Breakout Probability Model)

المدخل: market.bos.detected (204). ينشر:
probability.breakout_model_updated.

منطق مُستنتَج: احتمال استمرار الاختراق (لا ارتداد/Fakeout) يتصاعد
مع تتالي BOS بنفس الاتجاه (نفس مبدأ 208 لنضج الاتجاه، بذاكرة مستقلة
هون تمامًا — قاعدة 0، لا استدعاء). قاعدة: 0.55 (BOS أول) + 0.05 لكل
تأكيد إضافي متتالٍ بنفس الاتجاه، سقف 0.85.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_BASE_PROBABILITY = 0.55
_INCREMENT_PER_STREAK = 0.05
_MAX_PROBABILITY = 0.85


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_direction: dict[str, str] = {}
        self._streak: dict[str, int] = {}
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.bos.detected", self._on_bos)
        context.logger.info("BreakoutProbabilityModel(353) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("BreakoutProbabilityModel(353) بدأ الاستماع لـ204")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"last_direction": self._last_direction, "streak": self._streak, "updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self._last_direction = state.get("last_direction", {})
        self._streak = state.get("streak", {})
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_bos(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        direction = payload["direction"]

        if self._last_direction.get(symbol) == direction:
            self._streak[symbol] = self._streak.get(symbol, 1) + 1
        else:
            self._streak[symbol] = 1
        self._last_direction[symbol] = direction

        probability = min(_MAX_PROBABILITY, _BASE_PROBABILITY + (self._streak[symbol] - 1) * _INCREMENT_PER_STREAK)

        self.updates_count += 1
        await self._context.publish(
            "probability.breakout_model_updated",
            {"symbol": symbol, "direction": direction, "streak": self._streak[symbol], "breakout_probability": round(probability, 4)},
        )
