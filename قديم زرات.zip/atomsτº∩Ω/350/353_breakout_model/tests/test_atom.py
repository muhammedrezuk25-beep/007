import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom353"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=353, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_bos_base_probability():
    print("\n--- test_first_bos_base_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100})
    events = [p for n, p in published if n == "probability.breakout_model_updated"]
    assert events[0]["breakout_probability"] == 0.55 and events[0]["streak"] == 1
    print(f"OK — BOS أول → احتمال أساسي: {events[0]}")


async def test_streak_increases_probability():
    print("\n--- test_streak_increases_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for _ in range(3):
        await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100})
    events = [p for n, p in published if n == "probability.breakout_model_updated"]
    assert events[-1]["streak"] == 3
    assert events[-1]["breakout_probability"] == 0.55 + 2 * 0.05  # 0.65
    print(f"OK — 3 BOS متتالية بنفس الاتجاه → احتمال متصاعد: {events[-1]}")


async def test_direction_change_resets_streak():
    print("\n--- test_direction_change_resets_streak ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100})
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 110})
    await atom._on_bos({"symbol": "NQ", "direction": "low", "price": 90})  # اتجاه معاكس
    events = [p for n, p in published if n == "probability.breakout_model_updated"]
    assert events[-1]["streak"] == 1 and events[-1]["breakout_probability"] == 0.55
    print(f"OK — تغيّر اتجاه صفّر التتالي: {events[-1]}")


async def test_probability_capped_at_maximum():
    print("\n--- test_probability_capped_at_maximum ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for _ in range(20):  # تتالٍ طويل جدًا
        await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100})
    events = [p for n, p in published if n == "probability.breakout_model_updated"]
    assert events[-1]["breakout_probability"] == 0.85
    print(f"OK — احتمال مُقيَّد بسقف 0.85 رغم تتالٍ طويل: {events[-1]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_bos({"symbol": "NQ", "direction": "high", "price": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._streak["NQ"] == 1
    print("OK — restore() نقل التتالي بدقّة")


async def main():
    tests = [
        test_first_bos_base_probability,
        test_streak_increases_probability,
        test_direction_change_resets_streak,
        test_probability_capped_at_maximum,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
