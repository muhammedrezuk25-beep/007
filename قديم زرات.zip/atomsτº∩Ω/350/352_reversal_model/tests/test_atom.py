import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom352"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=352, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_extended_phase_high_reversal_probability():
    print("\n--- test_extended_phase_high_reversal_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_structure_updated({"symbol": "NQ", "state": {"phase": "EXTENDED"}})
    events = [p for n, p in published if n == "probability.reversal_model_updated"]
    assert events[0]["reversal_probability"] == 0.6
    print(f"OK — طور EXTENDED (اتجاه ممتد) → احتمال انعكاس أعلى: {events[0]}")


async def test_early_phase_low_reversal_probability():
    print("\n--- test_early_phase_low_reversal_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_structure_updated({"symbol": "NQ", "state": {"phase": "EARLY"}})
    events = [p for n, p in published if n == "probability.reversal_model_updated"]
    assert events[0]["reversal_probability"] == 0.2
    print(f"OK — طور EARLY (اتجاه جديد) → احتمال انعكاس أقل: {events[0]}")


async def test_missing_phase_uses_default():
    print("\n--- test_missing_phase_uses_default ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_structure_updated({"symbol": "NQ", "state": {}})  # لا phase بالحالة بعد
    events = [p for n, p in published if n == "probability.reversal_model_updated"]
    assert events[0]["reversal_probability"] == 0.4
    print(f"OK — غياب phase → احتمال افتراضي متوسط: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_structure_updated({"symbol": "NQ", "state": {"phase": "EARLY"}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.updates_count == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_extended_phase_high_reversal_probability, test_early_phase_low_reversal_probability, test_missing_phase_uses_default, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
