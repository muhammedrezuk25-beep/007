"""
352 — نموذج الانعكاس الاحتمالي (Reversal Probability Model)

المدخل: market.structure.updated (210). ينشر:
probability.reversal_model_updated.

منطق مُستنتَج: يستخرج حقل "phase" (نضج الاتجاه، من 208 عبر تجميع
210) من الحالة الموحَّدة — EXTENDED (اتجاه طويل الأمد) يُعطى احتمال
انعكاس أعلى (0.6، افتراض تداولي معروف: الاتجاهات الممتدة أكثر عرضة
للانعكاس)، EARLY/ESTABLISHED احتمال أقل (0.2/0.3)، NEUTRAL (بلا
اتجاه أصلًا) احتمال متوسط افتراضي (0.4).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_REVERSAL_PROBABILITY_BY_PHASE = {
    "EARLY": 0.2,
    "ESTABLISHED": 0.3,
    "EXTENDED": 0.6,
    "NEUTRAL": 0.4,
}
_DEFAULT_PROBABILITY = 0.4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.structure.updated", self._on_structure_updated)
        context.logger.info("ReversalProbabilityModel(352) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ReversalProbabilityModel(352) بدأ الاستماع لـ210")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_structure_updated(self, payload: dict) -> None:
        if self._context is None:
            return
        inner_state = payload.get("state", {})
        phase = inner_state.get("phase")
        probability = _REVERSAL_PROBABILITY_BY_PHASE.get(phase, _DEFAULT_PROBABILITY)

        self.updates_count += 1
        await self._context.publish(
            "probability.reversal_model_updated",
            {"symbol": payload.get("symbol"), "phase": phase, "reversal_probability": probability},
        )
