# 352 — Reversal Probability Model (نموذج الانعكاس الاحتمالي)

المدخل: `market.structure.updated` (210 — **معتمَدة فعليًا**). منطق
مُستنتَج: يستخرج `phase` (نضج الاتجاه من 208) — EXTENDED (اتجاه ممتد)
= احتمال انعكاس أعلى (0.6)، EARLY = أقل (0.2)، افتراضي متوسط (0.4).

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
4 اختبارات: EXTENDED (احتمال أعلى)، EARLY (أقل)، phase غائب
(افتراضي)، `snapshot`/`restore`. **نتيجة: 4/4.**
