import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom362"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=362, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_ranking_orders_by_decisiveness_correctly():
    print("\n--- test_ranking_orders_by_decisiveness_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({
        "symbol": "NQ",
        "models": {
            "trend": {"probability_up": 0.51},       # حسم ضئيل جدًا: 0.02
            "breakout": {"breakout_probability": 0.9},  # حسم عالٍ: 0.8
            "range": {"range_probability": 0.6},       # حسم متوسط: 0.2
        },
    })
    events = [p for n, p in published if n == "probability.model_priority_ranked"]
    ranking = events[0]["ranking"]
    assert [r["model"] for r in ranking] == ["breakout", "range", "trend"], ranking
    print(f"OK — الترتيب صحيح تنازليًا حسب الحسم: {[(r['model'], r['decisiveness']) for r in ranking]}")


async def test_decisiveness_calculated_correctly():
    print("\n--- test_decisiveness_calculated_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"trend": {"probability_up": 0.8}}})
    events = [p for n, p in published if n == "probability.model_priority_ranked"]
    assert events[0]["ranking"][0]["decisiveness"] == 0.6  # |0.8-0.5|*2
    print(f"OK — حساب الحسم دقيق: {events[0]['ranking'][0]}")


async def test_missing_models_gracefully_ranked_partial():
    print("\n--- test_missing_models_gracefully_ranked_partial ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"trend": {"probability_up": 0.7}}})  # نموذج واحد بس
    events = [p for n, p in published if n == "probability.model_priority_ranked"]
    assert len(events[0]["ranking"]) == 1
    print(f"OK — نموذج واحد بس متاح → ترتيب جزئي بلا خطأ: {events[0]['ranking']}")


async def test_empty_models_no_publish():
    print("\n--- test_empty_models_no_publish ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {}})
    events = [p for n, p in published if n == "probability.model_priority_ranked"]
    assert len(events) == 0
    print("OK — لا نماذج معروفة إطلاقًا → صفر نشر")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"trend": {"probability_up": 0.7}}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.rankings_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [
        test_ranking_orders_by_decisiveness_correctly,
        test_decisiveness_calculated_correctly,
        test_missing_models_gracefully_ranked_partial,
        test_empty_models_no_publish,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
