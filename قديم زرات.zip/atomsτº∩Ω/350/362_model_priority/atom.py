"""
362 — ترتيب أولوية النماذج (Model Priority Ranking)

لا سبك دقيق للمدخل أُعطي — استُنتِج: يشترك بمخرجات 357
(probability.models_merged، حقيقية ومبنية). منطق: يرتّب النماذج
الستة حسب "حسم الإشارة" الحالية — |قيمة الاحتمال - 0.5| × 2 (بُعد عن
الحياد، مُطبَّع [0,1]) لكل نموذج، الأعلى بُعدًا = أعلى أولوية (يعطي
معلومة أوضح حاليًا). ينشر: probability.model_priority_ranked.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

PROBABILITY_CENTER = 0.5


# كل نموذج له حقل احتمال أساسي مختلف الاسم — تعيين صريح لتوحيد الاستخراج
_MODEL_PROBABILITY_FIELD = {
    "trend": "probability_up",
    "reversal": "reversal_probability",
    "breakout": "breakout_probability",
    "pullback": "pullback_probability",
    "momentum": "continuation_probability",
    "range": "range_probability",
}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.rankings_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("probability.models_merged", self._on_models_merged)
        context.logger.info("ModelPriorityRanking(362) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelPriorityRanking(362) بدأ الاستماع لـ357")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"ترتيبات_منشورة={self.rankings_published}")

    async def snapshot(self) -> dict:
        return {"rankings_published": self.rankings_published}

    async def restore(self, state: dict) -> None:
        self.rankings_published = state.get("rankings_published", 0)

    # ------------------------------------------------------------------

    async def _on_models_merged(self, payload: dict) -> None:
        if self._context is None:
            return
        models = payload["models"]
        scores = []
        for model_name, field_name in _MODEL_PROBABILITY_FIELD.items():
            if model_name not in models:
                continue
            value = models[model_name].get(field_name)
            if value is None:
                continue
            decisiveness = abs(value - PROBABILITY_CENTER) * 2
            scores.append({"model": model_name, "decisiveness": round(decisiveness, 4)})

        if not scores:
            return  # لا نماذج معروفة القيمة بعد — لا شيء لترتيبه

        ranked = sorted(scores, key=lambda s: s["decisiveness"], reverse=True)
        self.rankings_published += 1
        await self._context.publish(
            "probability.model_priority_ranked", {"symbol": payload["symbol"], "ranking": ranked}
        )
