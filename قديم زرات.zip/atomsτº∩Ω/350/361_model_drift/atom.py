"""
361 — كشف انحراف النموذج (Model Drift Detector)

لا سبك دقيق للمدخل أُعطي — استُنتِج: يشترك بمخرجات 360
(probability.model_accuracy_tracked، حقيقية ومبنية). منطق: يقارن
متوسط دقة نافذة حديثة بمتوسط نافذة أقدم — تراجع كبير = انحراف
(النموذج لم يعد يعمل كما كان). ينشر: probability.model_drift_detected.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_WINDOW_SIZE = 10
_DRIFT_THRESHOLD = 0.2  # تراجع دقة أكبر من 20 نقطة مئوية = انحراف


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _WINDOW_SIZE
        self._threshold = _DRIFT_THRESHOLD
        self._correctness_history: dict[str, list[bool]] = {}
        self.drift_events_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _WINDOW_SIZE))
        self._threshold = float(context.config.get("drift_threshold", _DRIFT_THRESHOLD))
        context.subscribe("probability.model_accuracy_tracked", self._on_accuracy)
        context.logger.info("ModelDriftDetector(361) تمت تهيئته (window=%d, threshold=%.2f)", self._window, self._threshold)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelDriftDetector(361) بدأ الاستماع لـ360")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"انحرافات_مكتشَفة={self.drift_events_count}")

    async def snapshot(self) -> dict:
        return {"correctness_history": self._correctness_history, "drift_events_count": self.drift_events_count}

    async def restore(self, state: dict) -> None:
        self._correctness_history = state.get("correctness_history", {})
        self.drift_events_count = state.get("drift_events_count", 0)

    # ------------------------------------------------------------------

    async def _on_accuracy(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        history = self._correctness_history.setdefault(symbol, [])
        history.append(payload["correct"])
        if len(history) > self._window * 2:
            history.pop(0)

        if len(history) < self._window * 2:
            return  # نحتاج نافذتين كاملتين للمقارنة (حديثة + أقدم)

        older_half = history[: self._window]
        recent_half = history[self._window:]
        older_accuracy = sum(older_half) / len(older_half)
        recent_accuracy = sum(recent_half) / len(recent_half)
        degradation = older_accuracy - recent_accuracy

        if degradation > self._threshold:
            self.drift_events_count += 1
            await self._context.publish(
                "probability.model_drift_detected",
                {
                    "symbol": symbol, "older_accuracy": round(older_accuracy, 4),
                    "recent_accuracy": round(recent_accuracy, 4), "degradation": round(degradation, 4),
                },
            )
