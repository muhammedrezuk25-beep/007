import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom361"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=361, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed(atom, symbol, correctness_list):
    for c in correctness_list:
        await atom._on_accuracy({"symbol": symbol, "correct": c, "accuracy": 0.5, "total_predictions": 1})


async def test_stable_accuracy_no_drift():
    print("\n--- test_stable_accuracy_no_drift ---")
    context, published = make_context({"window": 5, "drift_threshold": 0.2})
    atom = Atom()
    await atom.initialize(context)
    # درس مُستفاد: تجنّب فروقات حدّية بالضبط (0.8-0.6=0.2000...07 بسبب
    # دقة الفاصلة العائمة، تتجاوز العتبة "بالصدفة"). هون فرق صريح وواضح
    # تحت العتبة (0.2 بالضبط) — 4/5 مقابل 4/5، صفر تراجع فعلي إطلاقًا.
    await _feed(atom, "NQ", [True, True, False, True, True] + [True, True, True, False, True])
    events = [p for n, p in published if n == "probability.model_drift_detected"]
    assert len(events) == 0
    print("OK — دقة مستقرة (بلا فرق حدّي هش) عبر النافذتين → صفر انحراف")


async def test_degrading_accuracy_triggers_drift():
    print("\n--- test_degrading_accuracy_triggers_drift ---")
    context, published = make_context({"window": 5, "drift_threshold": 0.2})
    atom = Atom()
    await atom.initialize(context)
    # نافذة أقدم: 5/5 صحيح، نافذة حديثة: 0/5 صحيح — تراجع كامل
    await _feed(atom, "NQ", [True, True, True, True, True] + [False, False, False, False, False])
    events = [p for n, p in published if n == "probability.model_drift_detected"]
    assert len(events) == 1
    assert events[0]["older_accuracy"] == 1.0
    assert events[0]["recent_accuracy"] == 0.0
    print(f"OK — تراجع دقة حاد (1.0→0.0) اكتُشِف كانحراف: {events[0]}")


async def test_insufficient_history_no_calculation():
    print("\n--- test_insufficient_history_no_calculation ---")
    context, published = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [True, False, True])  # 3 بس، تحت النافذتين (10)
    events = [p for n, p in published if n == "probability.model_drift_detected"]
    assert len(events) == 0
    print("OK — تاريخ غير كافٍ → صفر حساب بعد")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [True, False])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._correctness_history["NQ"] == [True, False]
    print("OK — restore() نقل تاريخ الصحة بدقّة")


async def main():
    tests = [
        test_stable_accuracy_no_drift,
        test_degrading_accuracy_triggers_drift,
        test_insufficient_history_no_calculation,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
