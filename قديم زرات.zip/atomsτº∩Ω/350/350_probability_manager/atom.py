"""
350 — مدير الاحتمالات (Probability Manager)

جامع نشاط العائلة الكاملة (قاعدة 1) — نفس نمط 150/200 حرفيًا. يشترك
بكل مخرجات 351-367 (17 نوع حدث) لأغراض المراقبة/الصحة فقط. ينشر
حدث حالة عائلة خفيف (probability.family_status)، **لا** ينافس
probability.confidence_aggregated (359، القيمة النهائية الحقيقية).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_FAMILY_EVENTS = [
    "probability.trend_model_updated", "probability.reversal_model_updated",
    "probability.breakout_model_updated", "probability.pullback_model_updated",
    "probability.momentum_model_updated", "probability.range_model_updated",
    "probability.models_merged", "probability.hurst_calculated",
    "probability.confidence_aggregated", "probability.model_accuracy_tracked",
    "probability.model_drift_detected", "probability.model_priority_ranked",
    "model.selection.requested", "model.saved", "model.loaded",
    "probability.models_compared", "model.recalibration.requested",
]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.event_counts: dict[str, int] = {name: 0 for name in _FAMILY_EVENTS}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _FAMILY_EVENTS:
            context.subscribe(event_name, self._make_tracker(event_name))
        context.logger.info("ProbabilityManager(350) تمت تهيئته (يراقب %d نوع حدث عائلي)", len(_FAMILY_EVENTS))

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ProbabilityManager(350) بدأ المراقبة")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total = sum(self.event_counts.values())
        return HealthStatus(state=HealthState.HEALTHY, message=f"إجمالي نشاط العائلة={total}")

    async def snapshot(self) -> dict:
        return {"event_counts": self.event_counts}

    async def restore(self, state: dict) -> None:
        self.event_counts = dict(state.get("event_counts", {name: 0 for name in _FAMILY_EVENTS}))

    # ------------------------------------------------------------------

    def _make_tracker(self, event_name: str):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            self.event_counts[event_name] += 1
            await self._context.publish(
                "probability.family_status", {"last_event": event_name, "total_activity": sum(self.event_counts.values())}
            )

        return handler
