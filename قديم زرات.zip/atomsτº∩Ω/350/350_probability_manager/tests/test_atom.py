import asyncio
import inspect
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom350"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=350, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_all_seventeen_family_events_tracked_no_late_binding():
    print("\n--- test_all_seventeen_family_events_tracked_no_late_binding ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())

    events = [
        "probability.trend_model_updated", "probability.reversal_model_updated",
        "probability.breakout_model_updated", "probability.pullback_model_updated",
        "probability.momentum_model_updated", "probability.range_model_updated",
        "probability.models_merged", "probability.hurst_calculated",
        "probability.confidence_aggregated", "probability.model_accuracy_tracked",
        "probability.model_drift_detected", "probability.model_priority_ranked",
        "model.selection.requested", "model.saved", "model.loaded",
        "probability.models_compared", "model.recalibration.requested",
    ]
    for name in events:
        await bus.publish(name, {})

    assert all(atom.event_counts[name] == 1 for name in events), (
        f"كل نوع حدث لازم يُحسَب بمفتاحه الصحيح، لا كلهم بآخر مفتاح: {atom.event_counts}"
    )
    print(f"OK — الـ17 نوعًا تُتُبِّعوا كل واحد بمفتاحه الصحيح")


async def test_does_not_publish_final_confidence_event():
    print("\n--- test_does_not_publish_final_confidence_event ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("probability.hurst_calculated", {})
    final_events = [p for n, p in bus.published if n == "probability.confidence_aggregated"]
    assert len(final_events) == 0, "350 لا يجب أن تنشر الحدث النهائي — تلك حصرًا مسؤولية 359"
    family_status = [p for n, p in bus.published if n == "probability.family_status"]
    assert len(family_status) == 1
    print("OK — نشرت probability.family_status بس، صفر تدخّل بدور 359")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("probability.hurst_calculated", {})
    await bus.publish("probability.hurst_calculated", {})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.event_counts["probability.hurst_calculated"] == 2
    print("OK — restore() نقل كل عدّادات النشاط العائلي بدقّة")


async def main():
    tests = [
        test_all_seventeen_family_events_tracked_no_late_binding,
        test_does_not_publish_final_confidence_event,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
