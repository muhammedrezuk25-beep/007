import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom355"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=355, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_zero_momentum_base_probability():
    print("\n--- test_zero_momentum_base_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 0, "period": 10})
    events = [p for n, p in published if n == "probability.momentum_model_updated"]
    assert events[0]["continuation_probability"] == 0.5
    assert events[0]["direction"] == "up"
    print(f"OK — زخم صفر → احتمال أساسي، اتجاه up افتراضيًا: {events[0]}")


async def test_strong_positive_momentum_higher_probability():
    print("\n--- test_strong_positive_momentum_higher_probability ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 10, "period": 10})
    events = [p for n, p in published if n == "probability.momentum_model_updated"]
    assert events[0]["direction"] == "up"
    assert events[0]["continuation_probability"] == 0.7  # 0.5 + 10*0.02
    print(f"OK — زخم موجب قوي → احتمال استمرار أعلى: {events[0]}")


async def test_strong_negative_momentum_down_direction():
    print("\n--- test_strong_negative_momentum_down_direction ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": -8, "period": 10})
    events = [p for n, p in published if n == "probability.momentum_model_updated"]
    assert events[0]["direction"] == "down"
    assert events[0]["continuation_probability"] == 0.66  # 0.5 + 8*0.02
    print(f"OK — زخم سالب → اتجاه down، احتمال يعتمد على الحجم المطلق: {events[0]}")


async def test_probability_capped_at_maximum():
    print("\n--- test_probability_capped_at_maximum ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 50, "period": 10})  # زخم ضخم جدًا
    events = [p for n, p in published if n == "probability.momentum_model_updated"]
    assert events[0]["continuation_probability"] == 0.85
    print(f"OK — زخم ضخم مُقيَّد بسقف 0.85: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_momentum({"symbol": "NQ", "momentum_pct": 5, "period": 10})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.updates_count == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [
        test_zero_momentum_base_probability,
        test_strong_positive_momentum_higher_probability,
        test_strong_negative_momentum_down_direction,
        test_probability_capped_at_maximum,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
