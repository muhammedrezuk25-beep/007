"""
355 — نموذج الزخم الاحتمالي (Momentum Probability Model)

المدخل: analysis.momentum_calculated (152). ينشر:
probability.momentum_model_updated.

منطق مُستنتَج: احتمال استمرار الزخم يتصاعد مع حجم الزخم المطلق
(|momentum_pct|) — أساس 0.5، +0.02 لكل 1% زخم إضافي، سقف 0.85.
الاتجاه (up/down) من إشارة momentum_pct.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_BASE_PROBABILITY = 0.5
_INCREMENT_PER_PCT = 0.02
_MAX_PROBABILITY = 0.85


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("analysis.momentum_calculated", self._on_momentum)
        context.logger.info("MomentumProbabilityModel(355) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("MomentumProbabilityModel(355) بدأ الاستماع لـ152")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_momentum(self, payload: dict) -> None:
        if self._context is None:
            return
        momentum_pct = payload["momentum_pct"]
        direction = "up" if momentum_pct >= 0 else "down"
        probability = min(_MAX_PROBABILITY, _BASE_PROBABILITY + abs(momentum_pct) * _INCREMENT_PER_PCT)

        self.updates_count += 1
        await self._context.publish(
            "probability.momentum_model_updated",
            {"symbol": payload.get("symbol"), "direction": direction, "momentum_pct": momentum_pct, "continuation_probability": round(probability, 4)},
        )
