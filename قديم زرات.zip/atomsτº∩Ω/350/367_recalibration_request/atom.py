"""
367 — طلب إعادة معايرة (Recalibration Request)

محسوم: نفس نمط 363 — تنشر model.recalibration.requested بس، 450
(غير مبنية بعد) توافق/ترفض.

المُحفِّز: يشترك بمخرجات 361 (probability.model_drift_detected،
حقيقية ومبنية) — أي انحراف مكتشَف = طلب معايرة فورًا (بعكس 363، لا
Edge-triggered هون؛ كل حدث انحراف حقيقي يستأهل طلبًا، الانحراف نفسه
نادر ومهم بما يكفي، لا داعي لتصفية تكرار).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.requests_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("probability.model_drift_detected", self._on_drift)
        context.logger.info("RecalibrationRequest(367) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("RecalibrationRequest(367) بدأ الاستماع لـ361")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"طلبات_منشورة={self.requests_published}")

    async def snapshot(self) -> dict:
        return {"requests_published": self.requests_published}

    async def restore(self, state: dict) -> None:
        self.requests_published = state.get("requests_published", 0)

    # ------------------------------------------------------------------

    async def _on_drift(self, payload: dict) -> None:
        if self._context is None:
            return
        self.requests_published += 1
        await self._context.publish(
            "model.recalibration.requested",
            {"symbol": payload["symbol"], "reason": "drift_detected", "degradation": payload["degradation"]},
        )
