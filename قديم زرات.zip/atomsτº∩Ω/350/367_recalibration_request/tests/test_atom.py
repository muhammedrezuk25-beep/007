import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom367"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=367, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_drift_triggers_recalibration_request():
    print("\n--- test_drift_triggers_recalibration_request ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_drift({"symbol": "NQ", "older_accuracy": 0.9, "recent_accuracy": 0.3, "degradation": 0.6})
    events = [p for n, p in published if n == "model.recalibration.requested"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "reason": "drift_detected", "degradation": 0.6}
    print(f"OK — انحراف اكتُشِف → طلب معايرة فورًا: {events[0]}")


async def test_every_drift_event_requests_no_edge_filtering():
    print("\n--- test_every_drift_event_requests_no_edge_filtering ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_drift({"symbol": "NQ", "older_accuracy": 0.9, "recent_accuracy": 0.3, "degradation": 0.6})
    await atom._on_drift({"symbol": "NQ", "older_accuracy": 0.8, "recent_accuracy": 0.2, "degradation": 0.6})
    events = [p for n, p in published if n == "model.recalibration.requested"]
    assert len(events) == 2, "بعكس 363 — كل حدث انحراف حقيقي يستأهل طلبًا، بلا تصفية تكرار"
    print(f"OK — حدثا انحراف متتاليان → طلبان منفصلان (بلا Edge-triggered): {len(events)}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_drift({"symbol": "NQ", "older_accuracy": 0.9, "recent_accuracy": 0.3, "degradation": 0.6})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.requests_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [
        test_drift_triggers_recalibration_request,
        test_every_drift_event_requests_no_edge_filtering,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
