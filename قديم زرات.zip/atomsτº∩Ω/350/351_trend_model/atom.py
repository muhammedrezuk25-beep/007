"""
351 — نموذج الاتجاه الاحتمالي (Trend Probability Model)

المدخل: market.trend.changed (207). ينشر:
probability.trend_model_updated.

منطق مُستنتَج: تحويل الحالة الفئوية (UPTREND/DOWNTREND/RANGE/
TRANSITION) لتوزيع احتمالي بسيط {up, down} — UPTREND/DOWNTREND تعطي
ميزة واضحة لاتجاهها (0.7/0.3)، RANGE/TRANSITION تعطي تعادلًا (0.5/0.5،
بلا ميزة لأي جهة، يعكس عدم اليقين الفعلي بهاتين الحالتين).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_PROBABILITY_MAP = {
    "UPTREND": {"up": 0.7, "down": 0.3},
    "DOWNTREND": {"up": 0.3, "down": 0.7},
    "RANGE": {"up": 0.5, "down": 0.5},
    "TRANSITION": {"up": 0.5, "down": 0.5},
}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.trend.changed", self._on_trend_changed)
        context.logger.info("TrendProbabilityModel(351) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TrendProbabilityModel(351) بدأ الاستماع لـ207")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_trend_changed(self, payload: dict) -> None:
        if self._context is None:
            return
        state = payload["state"]
        probabilities = _PROBABILITY_MAP.get(state, {"up": 0.5, "down": 0.5})

        self.updates_count += 1
        await self._context.publish(
            "probability.trend_model_updated",
            {"symbol": payload.get("symbol"), "trend_state": state, "probability_up": probabilities["up"], "probability_down": probabilities["down"]},
        )
