# 351 — Trend Probability Model (نموذج الاتجاه الاحتمالي)

المدخل: `market.trend.changed` (207 — **معتمَدة فعليًا، مبنية**).
منطق مُستنتَج: تحويل الحالة الفئوية لتوزيع احتمالي {up, down} —
UPTREND/DOWNTREND ميزة واضحة (0.7/0.3)، RANGE/TRANSITION تعادل (0.5/0.5).

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
4 اختبارات: UPTREND، DOWNTREND، RANGE+TRANSITION (تعادل)،
`snapshot`/`restore`. **نتيجة: 4/4.**
