"""
366 — مقارنة النماذج (Models Comparison)

لا سبك دقيق للمدخل أُعطي — استُنتِج: يشترك بمخرجات 357
(probability.models_merged، حقيقية ومبنية). منطق: يقيس **توافق
الاتجاه** بين النماذج ذات الدلالة الاتجاهية الواضحة (up/down) فقط —
trend (probability_up>0.5→up)، momentum (direction مباشرة)، breakout
(direction: high→up، low→down). النماذج الأخرى (reversal/pullback/
range) بلا دلالة up/down مباشرة قابلة للمقارنة بنفس المقياس، تُستبعَد
عمدًا من هذا الحساب بالذات. ينشر: probability.models_compared —
نسبة الأغلبية (agreement_ratio) من إجمالي الأصوات المتاحة.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

PROBABILITY_CENTER = 0.5



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.comparisons_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("probability.models_merged", self._on_models_merged)
        context.logger.info("ModelsComparison(366) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelsComparison(366) بدأ الاستماع لـ357")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"مقارنات_منشورة={self.comparisons_published}")

    async def snapshot(self) -> dict:
        return {"comparisons_published": self.comparisons_published}

    async def restore(self, state: dict) -> None:
        self.comparisons_published = state.get("comparisons_published", 0)

    # ------------------------------------------------------------------

    def _collect_directional_votes(self, models: dict) -> list[str]:
        votes = []
        if "trend" in models and "probability_up" in models["trend"]:
            votes.append("up" if models["trend"]["probability_up"] > PROBABILITY_CENTER else "down")
        if "momentum" in models and "direction" in models["momentum"]:
            votes.append(models["momentum"]["direction"])
        if "breakout" in models and "direction" in models["breakout"]:
            votes.append("up" if models["breakout"]["direction"] == "high" else "down")
        return votes

    async def _on_models_merged(self, payload: dict) -> None:
        if self._context is None:
            return
        votes = self._collect_directional_votes(payload["models"])
        if not votes:
            return  # لا نماذج ذات دلالة اتجاهية واضحة وصلت بعد

        up_count = votes.count("up")
        down_count = votes.count("down")
        majority_count = max(up_count, down_count)
        agreement_ratio = majority_count / len(votes)
        majority_direction = "up" if up_count >= down_count else "down"

        self.comparisons_published += 1
        await self._context.publish(
            "probability.models_compared",
            {
                "symbol": payload["symbol"], "votes": votes, "majority_direction": majority_direction,
                "agreement_ratio": round(agreement_ratio, 4),
            },
        )
