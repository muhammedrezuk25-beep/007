import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom366"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=366, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_full_agreement_ratio_one():
    print("\n--- test_full_agreement_ratio_one ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({
        "symbol": "NQ",
        "models": {
            "trend": {"probability_up": 0.7}, "momentum": {"direction": "up"}, "breakout": {"direction": "high"},
        },
    })
    events = [p for n, p in published if n == "probability.models_compared"]
    assert events[0]["agreement_ratio"] == 1.0
    assert events[0]["majority_direction"] == "up"
    print(f"OK — إجماع تام (الثلاثة up) → agreement_ratio=1.0: {events[0]}")


async def test_disagreement_two_thirds():
    print("\n--- test_disagreement_two_thirds ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({
        "symbol": "NQ",
        "models": {
            "trend": {"probability_up": 0.7}, "momentum": {"direction": "up"}, "breakout": {"direction": "low"},
        },
    })
    events = [p for n, p in published if n == "probability.models_compared"]
    assert events[0]["agreement_ratio"] == round(2 / 3, 4), events[0]  # الذرة تقرِّب لـ4 أرقام عشرية عمدًا
    assert events[0]["majority_direction"] == "up"
    print(f"OK — أغلبية 2/3 (up)، خلاف جزئي: {events[0]}")


async def test_single_directional_model_available():
    print("\n--- test_single_directional_model_available ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"trend": {"probability_up": 0.3}}})
    events = [p for n, p in published if n == "probability.models_compared"]
    assert events[0]["agreement_ratio"] == 1.0  # صوت وحيد = إجماع تام بالتعريف
    assert events[0]["majority_direction"] == "down"
    print(f"OK — نموذج اتجاهي واحد بس متاح → agreement_ratio=1.0 (إجماع بديهي): {events[0]}")


async def test_no_directional_models_no_publish():
    print("\n--- test_no_directional_models_no_publish ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"reversal": {"reversal_probability": 0.6}}})  # لا دلالة اتجاهية
    events = [p for n, p in published if n == "probability.models_compared"]
    assert len(events) == 0
    print("OK — نماذج بلا دلالة اتجاهية واضحة بس → صفر نشر")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_models_merged({"symbol": "NQ", "models": {"trend": {"probability_up": 0.7}}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.comparisons_published == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [
        test_full_agreement_ratio_one,
        test_disagreement_two_thirds,
        test_single_directional_model_available,
        test_no_directional_models_no_publish,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
