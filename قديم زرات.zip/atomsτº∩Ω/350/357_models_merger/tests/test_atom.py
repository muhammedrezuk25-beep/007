"""اختبارات الذرة 357 — دمج النماذج وإخراج المقاييس."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"default_max_deviation": 0.20, "neutral_band": 0.02}


def _load():
    spec = importlib.util.spec_from_file_location("_atom357", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom357"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 357
    config = CONFIG
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    def __init__(self):
        self.published = []; self.handlers = {}
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready():
    m = _load(); a = m.Atom(); c = Ctx()
    await a.initialize(c); await a.start()
    return m, a, c


async def _feed(c, model, prob, deviation=None, symbol="BTCUSDT"):
    ev = {"trend": "probability.trend_model_updated",
          "reversal": "probability.reversal_model_updated",
          "breakout": "probability.breakout_model_updated",
          "pullback": "probability.pullback_model_updated",
          "momentum": "probability.momentum_model_updated",
          "range": "probability.range_model_updated"}[model]
    p = {"symbol": symbol, "probability_up": prob}
    if deviation is not None:
        p["probability_max_deviation"] = deviation
    await c.handlers[ev](p)


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


@pytest.mark.asyncio
async def test_subscribes_to_six_models_and_capabilities():
    m, a, c = await _ready()
    assert len(c.handlers) == 7
    assert "market.feed.capabilities" in c.handlers


@pytest.mark.asyncio
async def test_full_agreement_metrics():
    """ستة نماذج صاعدة متفقة."""
    m, a, c = await _ready()
    for model in ("trend", "reversal", "breakout", "pullback", "momentum", "range"):
        await _feed(c, model, 0.70)
    p = c.published[-1][1]
    assert p["probability_up"] == pytest.approx(0.70)
    assert p["agreement_score"] == 1.0
    assert p["coverage"] == 1.0
    assert p["dominant_direction"] == "BUY"
    assert p["bullish_models"] == 6 and p["bearish_models"] == 0


@pytest.mark.asyncio
async def test_neutral_excluded_from_agreement_denominator():
    """المحايد لم يصوّت — لا يُحسب في مقام الاتفاق."""
    m, a, c = await _ready()
    for model in ("trend", "reversal", "breakout"):
        await _feed(c, model, 0.70)
    await _feed(c, "pullback", 0.50)          # محايد
    p = c.published[-1][1]
    assert p["neutral_models"] == 1
    assert p["agreement_score"] == 1.0        # 3/3 لا 3/4
    assert p["participating_models"] == 4     # لكنه يُحسب في التغطية


@pytest.mark.asyncio
async def test_disagreement_lowers_agreement():
    m, a, c = await _ready()
    for model in ("trend", "reversal", "breakout", "pullback", "momentum"):
        await _feed(c, model, 0.70)
    await _feed(c, "range", 0.30)             # مخالف
    p = c.published[-1][1]
    assert p["bullish_models"] == 5 and p["bearish_models"] == 1
    assert p["agreement_score"] == pytest.approx(5 / 6)


@pytest.mark.asyncio
async def test_split_gives_half_agreement_and_neutral_direction():
    m, a, c = await _ready()
    for model in ("trend", "reversal", "breakout"):
        await _feed(c, model, 0.70)
    for model in ("pullback", "momentum", "range"):
        await _feed(c, model, 0.30)
    p = c.published[-1][1]
    assert p["agreement_score"] == 0.5
    assert p["dominant_direction"] == "NEUTRAL"
    assert p["probability_up"] == pytest.approx(0.5)


@pytest.mark.asyncio
async def test_coverage_uses_participating_over_available():
    m, a, c = await _ready()
    for model in ("trend", "reversal", "breakout"):
        await _feed(c, model, 0.70)
    p = c.published[-1][1]
    assert p["participating_models"] == 3
    assert p["available_models"] == 4      # المصوّتون فقط: 6 ناقص غير الاتجاهيين
    assert p["coverage"] == pytest.approx(0.75)


@pytest.mark.asyncio
async def test_capabilities_shrink_available_models():
    """نموذج يحتاج قدرة غائبة لا يُعاقَب عليه في التغطية."""
    m, a, c = await _ready()
    await c.handlers["market.feed.capabilities"]({"provider": "binance", "depth": False})
    await _feed(c, "trend", 0.70)
    await c.handlers["probability.momentum_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "continuation_probability": 0.6})
    p = c.published[-1][1]
    # المصوّتون 4، وbreakout و pullback يحتاجان depth الغائب ⇒ يبقى 2
    assert p["available_models"] == 2
    assert p["coverage"] == 1.0                # 2/2 لا 2/6
    assert p["total_models"] == 6              # للتشخيص فقط


@pytest.mark.asyncio
async def test_declared_deviation_used_when_present():
    """المدى من النموذج لا من هنا."""
    m, a, c = await _ready()
    await _feed(c, "trend", 0.80, deviation=0.30)
    await _feed(c, "reversal", 0.80, deviation=0.30)
    p = c.published[-1][1]
    assert p["probability_max_deviation"] == pytest.approx(0.30)


@pytest.mark.asyncio
async def test_default_deviation_when_model_silent():
    m, a, c = await _ready()
    await _feed(c, "trend", 0.70)
    assert c.published[-1][1]["probability_max_deviation"] == pytest.approx(0.20)


@pytest.mark.asyncio
async def test_mixed_deviations_averaged():
    m, a, c = await _ready()
    await _feed(c, "trend", 0.70, deviation=0.20)
    await _feed(c, "reversal", 0.70, deviation=0.40)
    assert c.published[-1][1]["probability_max_deviation"] == pytest.approx(0.30)


@pytest.mark.asyncio
async def test_symbols_independent():
    m, a, c = await _ready()
    await _feed(c, "trend", 0.70, symbol="BTCUSDT")
    await _feed(c, "trend", 0.30, symbol="ETHUSDT")
    btc = a.build_metrics("BTCUSDT"); eth = a.build_metrics("ETHUSDT")
    assert btc["dominant_direction"] == "BUY"
    assert eth["dominant_direction"] == "SELL"


@pytest.mark.asyncio
async def test_bad_probability_ignored():
    m, a, c = await _ready()
    await c.handlers["probability.trend_model_updated"]({"symbol": "BTCUSDT"})
    await c.handlers["probability.reversal_model_updated"](
        {"symbol": "BTCUSDT", "probability_up": "abc"})
    p = c.published[-1][1]
    assert p["participating_models"] == 0
    assert p["agreement_score"] == 0.0


@pytest.mark.asyncio
async def test_health_progression():
    m, a, c = await _ready()
    assert (await a.health_check()).state.name == "DEGRADED"
    await _feed(c, "trend", 0.70)
    assert (await a.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_capabilities_restored_but_model_values_not():
    m, a, c = await _ready()
    await c.handlers["market.feed.capabilities"]({"depth": False})
    await _feed(c, "trend", 0.70)
    snap = await a.snapshot()
    fresh = m.Atom(); await fresh.initialize(Ctx()); await fresh.restore(snap)
    assert fresh._state == {}                       # القيم لا تُستعاد
    assert fresh.available_models() == 2            # القدرات تُستعاد


@pytest.mark.asyncio
async def test_models_field_preserved_for_existing_consumers():
    """362 و366 يقرآن حقل models — حذفه يكسرهما (المادة 4)."""
    m, a, c = await _ready()
    await _feed(c, "trend", 0.70)
    p = c.published[-1][1]
    assert "models" in p
    assert "trend" in p["models"]
    assert p["models"]["trend"]["probability_up"] == 0.70


# ── توحيد حقول النماذج: كل نموذج ينشر باسمه ومفرداته ──

@pytest.mark.asyncio
async def test_directional_model_converted_to_probability_up():
    """353·354·355 تنشر احتمالاً + اتجاهاً — يُحوَّل لا يُهمَل."""
    m, a, c = await _ready()
    await c.handlers["probability.breakout_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "breakout_probability": 0.8})
    p = c.published[-1][1]
    assert p["probability_up"] == pytest.approx(0.9)   # 0.5 + 0.8/2
    assert p["bullish_models"] == 1


@pytest.mark.asyncio
async def test_down_direction_inverted():
    m, a, c = await _ready()
    await c.handlers["probability.pullback_model_updated"](
        {"symbol": "BTCUSDT", "direction": "sell_side", "pullback_probability": 0.6})
    assert c.published[-1][1]["probability_up"] == pytest.approx(0.2)  # 0.5 − 0.3


@pytest.mark.asyncio
async def test_momentum_vocabulary_accepted():
    m, a, c = await _ready()
    await c.handlers["probability.momentum_model_updated"](
        {"symbol": "BTCUSDT", "direction": "down", "continuation_probability": 0.4})
    assert c.published[-1][1]["probability_up"] == pytest.approx(0.3)


@pytest.mark.asyncio
async def test_non_directional_models_do_not_vote():
    """352 و356 لا تقول صعوداً ولا هبوطاً — فرض اتجاه عليها اختراع."""
    m, a, c = await _ready()
    await c.handlers["probability.reversal_model_updated"](
        {"symbol": "BTCUSDT", "phase": "EARLY", "reversal_probability": 0.9})
    await c.handlers["probability.range_model_updated"](
        {"symbol": "BTCUSDT", "range_probability": 0.85})
    p = c.published[-1][1]
    assert p["participating_models"] == 0
    assert p["bullish_models"] == 0 and p["bearish_models"] == 0


@pytest.mark.asyncio
async def test_unknown_direction_not_guessed():
    m, a, c = await _ready()
    await c.handlers["probability.breakout_model_updated"](
        {"symbol": "BTCUSDT", "direction": "???", "breakout_probability": 0.9})
    assert c.published[-1][1]["participating_models"] == 0


@pytest.mark.asyncio
async def test_four_directional_models_reach_full_coverage():
    """الحالة الواقعية: 351 + 353 + 354 + 355 تصوّت · 352 و356 لا."""
    m, a, c = await _ready()
    await c.handlers["market.feed.capabilities"]({"depth": True})
    await _feed(c, "trend", 0.70)
    await c.handlers["probability.breakout_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "breakout_probability": 0.5})
    await c.handlers["probability.pullback_model_updated"](
        {"symbol": "BTCUSDT", "direction": "buy_side", "pullback_probability": 0.4})
    await c.handlers["probability.momentum_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "continuation_probability": 0.6})
    p = c.published[-1][1]
    assert p["participating_models"] == 4
    assert p["bullish_models"] == 4
    assert p["agreement_score"] == 1.0
    assert p["dominant_direction"] == "BUY"


@pytest.mark.asyncio
async def test_non_voting_models_excluded_from_coverage_denominator():
    """352 و356 لا تصوّت أبداً — عدّها في المقام عقوبة دائمة."""
    m, a, c = await _ready()
    assert a.voting_models() == 4          # 6 ناقص reversal و range
    assert a.available_models() == 4


@pytest.mark.asyncio
async def test_four_voters_reach_full_coverage():
    """الحالة الواقعية المقيسة: أربعة تصوّت ⇒ coverage = 1.0 لا 0.667."""
    m, a, c = await _ready()
    await _feed(c, "trend", 0.70)
    await c.handlers["probability.breakout_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "breakout_probability": 0.5})
    await c.handlers["probability.pullback_model_updated"](
        {"symbol": "BTCUSDT", "direction": "buy_side", "pullback_probability": 0.3})
    await c.handlers["probability.momentum_model_updated"](
        {"symbol": "BTCUSDT", "direction": "up", "continuation_probability": 0.6})
    # النموذجان غير الاتجاهيين يصلان ولا يؤثران
    await c.handlers["probability.reversal_model_updated"](
        {"symbol": "BTCUSDT", "phase": "EARLY", "reversal_probability": 0.2})
    await c.handlers["probability.range_model_updated"](
        {"symbol": "BTCUSDT", "range_probability": 0.4})
    p = c.published[-1][1]
    assert p["participating_models"] == 4
    assert p["available_models"] == 4
    assert p["coverage"] == 1.0
    assert p["voting_models"] == 4


@pytest.mark.asyncio
async def test_timestamp_is_inherited_not_generated():
    """core.event_bus stamps every event via setdefault. An atom writing its
    own timestamp blocks that stamp and puts a second clock reading on a chain
    that already carries one from its origin."""
    m, atom, ctx = await _ready()
    handler = ctx.handlers["probability.trend_model_updated"]
    await handler({"symbol": "NQ", "probability_up": 0.7, "timestamp": 1785600000.0})
    merged = [p for n, p in ctx.published if n == "probability.models_merged"]
    assert merged and merged[0]["timestamp"] == 1785600000.0


@pytest.mark.asyncio
async def test_no_timestamp_upstream_leaves_the_field_to_the_bus():
    m, atom, ctx = await _ready()
    handler = ctx.handlers["probability.trend_model_updated"]
    await handler({"symbol": "XX", "probability_up": 0.6})
    merged = [p for n, p in ctx.published if n == "probability.models_merged"]
    assert merged and "timestamp" not in merged[0]
