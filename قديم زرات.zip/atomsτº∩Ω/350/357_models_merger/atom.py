"""
357 — دمج النماذج (Models Merger)
===================================
يجمع النماذج الاحتمالية الستة (351-356) ويُخرج **مقاييس الدمج** — لا
قيمة واحدة غامضة.

**ما تغيّر**: كان يخزّن آخر قيمة من كل نموذج ويمرّرها كما هي، فيضطر من
بعده لقراءة نموذج بعينه. صار يحسب المقاييس ويُخرجها، **فلا يعرف من بعده
شيئاً عن النماذج**.

**ثلاثة مفاهيم منفصلة لا رقم واحد**:

```
probability_up   →  إلى أين تميل النماذج
agreement_score  →  هل هي متفقة أم متضاربة
coverage         →  كم نموذجاً شارك من المتاح
```

دمجها في رقم واحد يُخفي السبب: ثقة منخفضة قد تعني ضعف اتجاه، أو تضارب
نماذج، أو نقص مصادر — وثلاثتها تُعالَج بطرق مختلفة تماماً.

**المحايد لا يُصوّت**: نموذج يُخرج `RANGE` (احتمال 0.5) ليس مؤيداً ولا
معارضاً — يُستثنى من مقام الاتفاق ويُحسب في التغطية.

**المدى من النماذج لا من هنا**: `probability_max_deviation` يُقرأ من
حمولة كل نموذج إن أعلنه، وإلا يُستعمل الافتراضي من `config`. فلو غيّر
نموذج مداه لاحقاً، لا يُلمس هذا الملف.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_OUT = "probability.models_merged"
EVENT_CAPABILITIES = "market.feed.capabilities"

_SOURCE_EVENTS = {
    "probability.trend_model_updated": "trend",
    "probability.reversal_model_updated": "reversal",
    "probability.breakout_model_updated": "breakout",
    "probability.pullback_model_updated": "pullback",
    "probability.momentum_model_updated": "momentum",
    "probability.range_model_updated": "range",
}

# النماذج التي تحتاج قدرة بيانات غير متوفّرة دائماً. حين تُعلن القدرة
# غائبة، تُستبعد من available_models فلا تُعاقَب التغطية على المستحيل.
_MODEL_REQUIREMENTS = {
    "breakout": "depth",
    "pullback": "depth",
}

PROBABILITY_CENTER = 0.5

# كل نموذج ينشر باسم حقله ومفرداته. التوحيد هنا لا في النماذج —
# تعديلها يكسر التوافق الرجعي (المادة 4)، والدمج مسؤولية هذه الذرة.
#
# ثلاثة أنواع:
#   اتجاهي صريح   → probability_up جاهز                     (351)
#   احتمال+اتجاه  → يُحوَّل: صاعد 0.5+p/2 · هابط 0.5−p/2     (353·354·355)
#   غير اتجاهي    → لا يصوّت ولا يُحسب مشاركاً               (352·356)
_DIRECTIONAL_FIELDS = {
    "breakout": "breakout_probability",
    "pullback": "pullback_probability",
    "momentum": "continuation_probability",
}
# نماذج لا تصوّت بحكم تصميمها: احتمالها لا يقول صعوداً ولا هبوطاً.
# عدّها في مقام التغطية عقوبة دائمة على تصميم لا على نقص بيانات.
_NON_VOTING_MODELS = frozenset({"reversal", "range"})

_UP_WORDS = {"up", "buy", "buy_side", "bullish", "long", "uptrend"}
_DOWN_WORDS = {"down", "sell", "sell_side", "bearish", "short", "downtrend"}

DIR_BUY = "BUY"
DIR_SELL = "SELL"
DIR_NEUTRAL = "NEUTRAL"

REASON_NO_MODELS = "NO_MODELS_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._default_deviation = 0.0
        self._neutral_band = 0.0
        self._total_models = len(_SOURCE_EVENTS)

        self._state: dict[str, dict[str, dict]] = {}
        self._capabilities: dict[str, bool] = {}
        self.published_count = 0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._default_deviation = float(cfg["default_max_deviation"])
        self._neutral_band = float(cfg["neutral_band"])

        for event_name, field_key in _SOURCE_EVENTS.items():
            context.subscribe(event_name, self._make_collector(field_key))
        context.subscribe(EVENT_CAPABILITIES, self._on_capabilities)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d (%d نموذج، المدى الافتراضي %.2f)",
            context.atom_id, self._total_models, self._default_deviation,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (رموز=%d، نُشر=%d)",
                self._context.atom_id, len(self._state), self.published_count,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    async def _on_capabilities(self, payload: dict[str, Any]) -> None:
        """قدرات المصدر — تحدّد أي النماذج ممكن أن يصل أصلاً."""
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        for key in set(_MODEL_REQUIREMENTS.values()):
            if key in inner:
                self._capabilities[key] = bool(inner[key])

    def _make_collector(self, field_key: str):
        async def handler(payload: dict[str, Any]) -> None:
            if not self._running or self._context is None:
                return
            symbol = str(payload.get("symbol", "_global"))
            self._state.setdefault(symbol, {})[field_key] = payload
            self.published_count += 1
            await self._context.publish(
                EVENT_OUT, self.build_metrics(symbol, payload))
        return handler

    # -------------------------------------------------- الحساب --

    def voting_models(self) -> int:
        """النماذج القادرة على التصويت أصلاً — غير الاتجاهية تُستثنى."""
        return self._total_models - len(_NON_VOTING_MODELS)

    def available_models(self) -> int:
        """كم نموذجاً *يمكن* أن يصوّت — لا كم موجود في النظام.

        يُستثنى نوعان:
          • غير الاتجاهي (352 · 356) — لا يصوّت بحكم تصميمه
          • ما يحتاج قدرة أعلنها المصدر غائبة — لن يصل أبداً

        عدّ أيّهما في المقام عقوبة دائمة على المستحيل."""
        blocked = sum(
            1 for model, requirement in _MODEL_REQUIREMENTS.items()
            if model not in _NON_VOTING_MODELS
            and self._capabilities.get(requirement) is False
        )
        return max(1, self.voting_models() - blocked)

    @staticmethod
    def _extract_probability(field_key: str, payload: dict[str, Any]) -> float | None:
        """يحوّل حمولة نموذج إلى احتمال صعود موحّد، أو None إن لم يصوّت.

        النموذج غير الاتجاهي (352 انعكاس · 356 نطاق) يُرجع None: احتماله
        لا يقول صعوداً ولا هبوطاً، وفرض اتجاه عليه اختراع."""
        direct = _to_float(payload.get("probability_up"))
        if direct is not None:
            return direct

        field = _DIRECTIONAL_FIELDS.get(field_key)
        if field is None:
            return None

        probability = _to_float(payload.get(field))
        if probability is None or not 0.0 <= probability <= 1.0:
            return None

        direction = str(payload.get("direction", "")).strip().lower()
        if direction in _UP_WORDS:
            return PROBABILITY_CENTER + probability / 2.0
        if direction in _DOWN_WORDS:
            return PROBABILITY_CENTER - probability / 2.0
        return None   # اتجاه غير معروف — لا يُخمَّن

    def build_metrics(self, symbol: str,
                      source: dict[str, Any] | None = None) -> dict[str, Any]:
        models = self._state.get(symbol, {})

        probabilities: list[float] = []
        deviations: list[float] = []
        bullish = bearish = neutral = 0

        for field_key, payload in models.items():
            probability = self._extract_probability(field_key, payload)
            if probability is None:
                continue
            probabilities.append(probability)

            declared = _to_float(payload.get("probability_max_deviation"))
            deviations.append(declared if declared and declared > 0
                              else self._default_deviation)

            offset = probability - PROBABILITY_CENTER
            if offset > self._neutral_band:
                bullish += 1
            elif offset < -self._neutral_band:
                bearish += 1
            else:
                neutral += 1

        participating = len(probabilities)
        available = self.available_models()

        if participating == 0:
            merged = PROBABILITY_CENTER
            max_deviation = self._default_deviation
        else:
            merged = sum(probabilities) / participating
            # مدى المدموج = متوسط مديات المشاركين، لأن الدمج متوسط
            max_deviation = sum(deviations) / participating

        voting = bullish + bearish
        if voting == 0:
            agreement = 0.0
            direction = DIR_NEUTRAL
        elif bullish >= bearish:
            agreement = bullish / voting
            direction = DIR_BUY if bullish > bearish else DIR_NEUTRAL
        else:
            agreement = bearish / voting
            direction = DIR_SELL

        metrics = {
            "symbol": symbol,
            # الحقل الأصلي يبقى: 362 و366 يقرآنه، وحذفه يكسرهما.
            # المادة 4: يُسمح بإضافة حقول لا بحذفها من حدث نشط.
            "models": dict(models),
            "probability_up": round(merged, 6),
            "probability_center": PROBABILITY_CENTER,
            "probability_max_deviation": round(max_deviation, 6),
            "dominant_direction": direction,
            "agreement_score": round(agreement, 6),
            "coverage": round(min(1.0, participating / available), 6),
            "participating_models": participating,
            "available_models": available,
            "total_models": self._total_models,
            "voting_models": self.voting_models(),
            "bullish_models": bullish,
            "bearish_models": bearish,
            "neutral_models": neutral,
        }
        stamp = (source or {}).get("timestamp")
        if isinstance(stamp, (int, float)):
            metrics["timestamp"] = stamp
        return metrics

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message="لم تبدأ")
        if not self._state:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_MODELS,
                details={"available": self.available_models()},
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"رموز={len(self._state)} نُشر={self.published_count}",
            details={"symbols": len(self._state),
                     "available_models": self.available_models(),
                     "published": self.published_count},
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "published_count": self.published_count,
            "capabilities": dict(self._capabilities),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        """قيم النماذج لا تُستعاد: احتمال من تشغيل سابق يُبنى عليه قرار
        اليوم. القدرات تُستعاد لأنها خاصية المصدر لا حالة سوق."""
        self.published_count = int(state.get("published_count", 0))
        self._capabilities = {str(k): bool(v)
                              for k, v in (state.get("capabilities") or {}).items()}
