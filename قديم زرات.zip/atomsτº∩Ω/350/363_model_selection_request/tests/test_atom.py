import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom363"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=363, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_ranking_publishes_request():
    print("\n--- test_first_ranking_publishes_request ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "breakout", "decisiveness": 0.8}]})
    events = [p for n, p in published if n == "model.selection.requested"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "requested_model": "breakout"}
    print(f"OK — أول ترتيب نشر طلب اختيار: {events[0]}")


async def test_same_top_model_no_republish():
    print("\n--- test_same_top_model_no_republish ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "breakout", "decisiveness": 0.8}]})
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "breakout", "decisiveness": 0.75}]})  # نفس النموذج الأعلى
    events = [p for n, p in published if n == "model.selection.requested"]
    assert len(events) == 1, "نفس النموذج الأعلى — Edge-triggered، بلا طلب مكرَّر"
    print("OK — نفس النموذج الأعلى (بحسم مختلف) لم يُعِد الطلب")


async def test_top_model_change_triggers_new_request():
    print("\n--- test_top_model_change_triggers_new_request ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "breakout", "decisiveness": 0.8}]})
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "range", "decisiveness": 0.9}]})  # نموذج أعلى مختلف
    events = [p for n, p in published if n == "model.selection.requested"]
    assert len(events) == 2
    assert events[1]["requested_model"] == "range"
    print(f"OK — تغيّر النموذج الأعلى أطلق طلبًا جديدًا: {events[1]}")


async def test_empty_ranking_no_request():
    print("\n--- test_empty_ranking_no_request ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_ranking({"symbol": "NQ", "ranking": []})
    events = [p for n, p in published if n == "model.selection.requested"]
    assert len(events) == 0
    print("OK — ترتيب فارغ → صفر طلب")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_ranking({"symbol": "NQ", "ranking": [{"model": "breakout", "decisiveness": 0.8}]})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._last_requested_top["NQ"] == "breakout"
    print("OK — restore() نقل آخر نموذج مطلوب بدقّة")


async def main():
    tests = [
        test_first_ranking_publishes_request,
        test_same_top_model_no_republish,
        test_top_model_change_triggers_new_request,
        test_empty_ranking_no_request,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
