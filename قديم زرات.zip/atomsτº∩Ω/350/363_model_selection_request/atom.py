"""
363 — طلب اختيار نموذج (Model Selection Request)

محسوم (نمط الحدثين المؤكَّد بكل التوثيق السابق): تنشر
model.selection.requested **بس** — **450 توافق/ترفض** (غير مبنية
بعد)، الاستراتيجية المستهدفة تشترك بـ.approved حصرًا. هذه الذرة لا
تقرر، فقط تطلب.

المُحفِّز (Trigger) غير مُحدَّد بالسبك — استُنتِج: يشترك بمخرجات
362 (probability.model_priority_ranked، حقيقية ومبنية). عند تغيّر
النموذج الأعلى ترتيبًا (Top) عن آخر طلب سابق، تنشر طلب تبديل —
Edge-triggered، لا طلب متكرر لنفس النموذج.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_requested_top: dict[str, str] = {}
        self.requests_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("probability.model_priority_ranked", self._on_ranking)
        context.logger.info("ModelSelectionRequest(363) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ModelSelectionRequest(363) بدأ الاستماع لـ362")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"طلبات_منشورة={self.requests_published}")

    async def snapshot(self) -> dict:
        return {"last_requested_top": self._last_requested_top, "requests_published": self.requests_published}

    async def restore(self, state: dict) -> None:
        self._last_requested_top = state.get("last_requested_top", {})
        self.requests_published = state.get("requests_published", 0)

    # ------------------------------------------------------------------

    async def _on_ranking(self, payload: dict) -> None:
        if self._context is None:
            return
        ranking = payload.get("ranking", [])
        if not ranking:
            return
        symbol = payload["symbol"]
        top_model = ranking[0]["model"]

        if self._last_requested_top.get(symbol) == top_model:
            return  # نفس النموذج الأعلى، بلا تغيّر — Edge-triggered
        self._last_requested_top[symbol] = top_model
        self.requests_published += 1
        await self._context.publish(
            "model.selection.requested", {"symbol": symbol, "requested_model": top_model}
        )
