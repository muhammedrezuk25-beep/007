"""Tests for atom 610 - Telegram Control (v3.2.0).

أول اختبارات لهذه الذرة منذ ولادتها: كانت معفاةً «بأمر المالك» وثغرةُ
الإعفاء أخفت سطرَ risk.alert الميت عامًا. الحقن عبر cfg["_test_client"]
مبنيٌّ في الذرة نفسها — هذه الاختبارات تستعمله كما صُمّم.
"""

from __future__ import annotations

import asyncio
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom610"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))

OWNER = 999111


class RecordingClient(MODULE.FakeTelegramClient):
    """Fake الذرة نفسه + تسجيل ما أُرسل."""

    def __init__(self) -> None:
        super().__init__(0.0)
        self.sent: list[tuple[str, dict]] = []

    async def send_payload(self, endpoint, payload, timeout=None):
        self.sent.append((endpoint, dict(payload)))
        return {"ok": True, "result": {}}


class Ctx:
    atom_id = 610

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, client):
        self.config = {
            "allowed_user_ids": [OWNER],
            "allow_all_users": False,
            "_test_client": client,
            "telegram_token": "T:FAKE",
            "heartbeat_interval_s": 3600.0,
        }
        self.published: list[tuple[str, dict]] = []
        self.handlers: dict[str, object] = {}

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        self.handlers[name] = handler

    def of(self, name):
        return [p for n, p in self.published if n == name]


async def build():
    client = RecordingClient()
    atom = MODULE.Atom()
    ctx = Ctx(client)
    await atom.initialize(ctx)
    return atom, ctx, client


def _texts(client):
    return [p.get("text", "") for e, p in client.sent if e == "sendMessage"]


@pytest.mark.asyncio
async def test_slash_command_from_owner_publishes_event():
    atom, ctx, client = await build()
    await atom._handle_telegram_update(
        {"message": {"from": {"id": OWNER}, "text": "/halt now please"}})
    out = ctx.of("telegram.command.received")
    assert len(out) == 1
    cmd = out[0]
    assert cmd["command"] == "/halt"
    assert cmd["args"] == ["now", "please"]
    assert cmd["user_id"] == OWNER
    assert atom._commands_relayed == 1


@pytest.mark.asyncio
async def test_stranger_is_ignored_entirely():
    atom, ctx, client = await build()
    await atom._handle_telegram_update(
        {"message": {"from": {"id": 12345}, "text": "/halt"}})
    assert ctx.of("telegram.command.received") == []
    assert _texts(client) == []


@pytest.mark.asyncio
async def test_outbound_targets_one_owner_or_broadcasts():
    atom, ctx, client = await build()
    await atom._on_outbound({"user_id": OWNER, "text": "مرحبا"})
    await atom._on_outbound({"text": "بثّ عام"})
    await atom._on_outbound({"user_id": 777, "text": "غريب"})  # غير مسموح
    texts = _texts(client)
    assert texts == ["مرحبا", "بثّ عام"]


@pytest.mark.asyncio
async def test_tools_alert_raised_reaches_owner():
    atom, ctx, client = await build()
    await atom._handle_system_event("tools.alert.raised", {
        "severity": "CRITICAL", "source": 516, "count": 3,
        "message": "kill switch fired"})
    texts = _texts(client)
    assert len(texts) == 1
    assert "CRITICAL" in texts[0] and "516" in texts[0] and "x3" in texts[0]


def test_manifest_contract_v32():
    assert MANIFEST["version"].startswith("3.2")
    assert "risk.alert" not in MANIFEST["subscribes"]
    assert "tools.alert.raised" in MANIFEST["subscribes"]
    assert "telegram.outbound" in MANIFEST["subscribes"]
    assert "telegram.command.received" in MANIFEST["publishes"]
