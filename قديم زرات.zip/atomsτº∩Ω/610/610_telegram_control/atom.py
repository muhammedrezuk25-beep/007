"""610 — ذرة التحكم والمراقبة الموحدة لتيليجرام (Telegram Control & Monitoring Atom)"""
from __future__ import annotations
import asyncio, json, os, random, time, urllib.parse
from dataclasses import dataclass
from enum import Enum
from typing import Any, Awaitable, Callable, Protocol

try: import aiohttp
except ImportError: aiohttp = None

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

class IClock(Protocol):
    def now(self) -> float: ...
    def monotonic(self) -> float: ...

class SystemClock(IClock):
    def now(self) -> float: return time.time()
    def monotonic(self) -> float: return time.monotonic()

class ConnectionState(Enum):
    DISCONNECTED = "DISCONNECTED"; CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"; RECONNECTING = "RECONNECTING"
    STOPPING = "STOPPING"; STOPPED = "STOPPED"

class RateLimitError(Exception):
    def __init__(self, retry_after: int): self.retry_after = retry_after

@dataclass(frozen=True, slots=True)
class GenericButton: text: str; callback_data: str

class TelegramClientProtocol(Protocol):
    offset: int
    async def connect(self, token: str) -> None: ...
    async def disconnect(self) -> None: ...
    async def get_updates(self, timeout: int) -> list[dict[str, Any]]: ...
    async def send_payload(self, endpoint: str, payload: dict[str, Any], timeout: int | None = None) -> dict[str, Any]: ...

class TokenBucket:
    def __init__(self, rate: float, capacity: int, clock: IClock):
        self.rate, self.capacity, self.tokens, self.clock = rate, capacity, float(capacity), clock
        self.last_update, self.lock = clock.monotonic(), asyncio.Lock()

    async def consume(self) -> None:
        while True:
            async with self.lock:
                now = self.clock.monotonic()
                self.tokens = min(float(self.capacity), self.tokens + (now - self.last_update) * self.rate)
                self.last_update = now
                if self.tokens >= 1.0: self.tokens -= 1.0; return
                sleep_time = (1.0 - self.tokens) / self.rate
            await asyncio.sleep(sleep_time)

class RealTelegramClient(TelegramClientProtocol):
    def __init__(self, clock: IClock, http_timeout: int, rate_limit: float, capacity: int, poll_offset: int) -> None:
        self.token, self.session, self.offset, self.http_timeout = "", None, 0, http_timeout
        self._poll_offset, self._rate_limiter, self.last_rtt_ms, self.clock = poll_offset, TokenBucket(rate_limit, capacity, clock), 0.0, clock

    async def connect(self, token: str) -> None:
        if not aiohttp: raise RuntimeError("aiohttp مطلوب.")
        self.token = token
        if self.session and not self.session.closed: await self.session.close()
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=self.http_timeout))
        try: await self.send_payload("getMe", {})
        except Exception: await self.session.close(); self.session, self.token = None, ""; raise

    async def disconnect(self) -> None:
        if self.session and not self.session.closed: await self.session.close()
        self.session, self.token = None, ""

    async def get_updates(self, timeout: int) -> list[dict[str, Any]]:
        data = await self.send_payload("getUpdates", {"offset": self.offset, "timeout": timeout, "allowed_updates": ["message", "callback_query"]}, timeout=timeout + self._poll_offset)
        updates = data.get("result", [])
        if updates: self.offset = updates[-1]["update_id"] + 1
        return updates

    async def send_payload(self, endpoint: str, payload: dict[str, Any], timeout: int | None = None) -> dict[str, Any]:
        if not self.session or self.session.closed or not self.token: raise ConnectionError("الجلسة مغلقة.")
        await self._rate_limiter.consume()
        st = self.clock.monotonic()
        kw: dict[str, Any] = {"json": payload}
        if timeout: kw["timeout"] = timeout
        async with self.session.post(f"https://api.telegram.org/bot{self.token}/{endpoint}", **kw) as resp:
            text = await resp.text()
            self.last_rtt_ms = (self.clock.monotonic() - st) * 1000
            data = json.loads(text) if text else {}
            if resp.status == 429: raise RateLimitError(data.get("parameters", {}).get("retry_after", 5))
            if resp.status != 200 or not data.get("ok"): raise ConnectionError(f"خطأ: {data.get('description', text)}")
            return data

class FakeTelegramClient(TelegramClientProtocol):
    def __init__(self, sleep_sec: float) -> None: self.connected, self.offset, self._updates_queue, self._sleep_sec = False, 0, [], sleep_sec
    async def connect(self, token: str) -> None: self.connected = True
    async def disconnect(self) -> None: self.connected = False
    async def get_updates(self, timeout: int) -> list[dict[str, Any]]:
        await asyncio.sleep(self._sleep_sec); return self._updates_queue.pop(0) if self._updates_queue else []
    async def send_payload(self, endpoint: str, payload: dict[str, Any], timeout: int | None = None) -> dict[str, Any]: return {"ok": True, "result": {}}

class ConnectionSupervisor:
    def __init__(self, client: TelegramClientProtocol, token: str, max_delay: float, logger: Any, clock: IClock):
        self.client, self.token, self.max_delay, self.logger, self.clock = client, token, max_delay, logger, clock
        self._state, self.retry_count, self.next_retry_at, self._lock = ConnectionState.DISCONNECTED, 0, 0.0, asyncio.Lock()

    @property
    def state(self) -> ConnectionState: return self._state

    async def ensure_connected(self) -> bool:
        if not self.token: return False
        async with self._lock:
            if self._state == ConnectionState.CONNECTED: return True
            if self.clock.now() < self.next_retry_at: return False
            try:
                is_re = self.retry_count > 0
                self._state = ConnectionState.CONNECTING if not is_re else ConnectionState.RECONNECTING
                await self.client.connect(self.token)
                self._state, self.retry_count, self.next_retry_at = ConnectionState.CONNECTED, 0, 0.0
                self.logger.info("إعادة الاتصال بنجاح." if is_re else "تم الاتصال بنجاح.")
                return True
            except Exception as exc:
                self.retry_count += 1
                self.next_retry_at = self.clock.now() + min(2 ** self.retry_count, self.max_delay) + random.uniform(0.0, 0.5)
                self.logger.error("فشل الاتصال (%s): %s", self.retry_count, exc, exc_info=True)
                return False

    async def disconnect(self) -> None:
        async with self._lock: self._state = ConnectionState.STOPPING
        await self.client.disconnect(); self._state = ConnectionState.STOPPED

    def health(self) -> HealthStatus:
        d = {"state": self._state.value, "retry_count": self.retry_count}
        if not self.token: return HealthStatus(state=HealthState.DEGRADED, message="التوكن مفقود", details=d)
        if self._state == ConnectionState.CONNECTED: return HealthStatus(state=HealthState.HEALTHY, message="متصل", details=d)
        return HealthStatus(state=HealthState.DEGRADED if self._state.name.endswith("ING") else HealthState.UNHEALTHY, message=self._state.value, details=d)

class PollingEngine:
    def __init__(self, client: TelegramClientProtocol, supervisor: ConnectionSupervisor, logger: Any, poll_timeout: int, busy_sleep: float, poll_error_retry: float, on_update: Callable[[dict[str, Any]], Awaitable[None]]):
        self.client, self.supervisor, self.logger, self.poll_timeout, self.busy_sleep, self.poll_error_retry, self.on_update, self._task, self._stop_event = client, supervisor, logger, poll_timeout, busy_sleep, poll_error_retry, on_update, None, asyncio.Event()

    def start(self) -> None: self._stop_event.clear(); self._task = asyncio.create_task(self._poll_loop())
    async def stop(self) -> None:
        self._stop_event.set()
        if self._task and not self._task.done():
            self._task.cancel()
            try: await self._task
            except asyncio.CancelledError: pass

    async def _poll_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                if not await self.supervisor.ensure_connected(): await asyncio.sleep(self.busy_sleep); continue
                updates = await self.client.get_updates(self.poll_timeout)
                for u in updates: await self.on_update(u)
                if not updates: await asyncio.sleep(self.busy_sleep)
            except RateLimitError as rle: self.logger.warning("تقييد تدفق: %ss", rle.retry_after); await asyncio.sleep(rle.retry_after)
            except asyncio.CancelledError: break
            except Exception as exc: self.logger.error("خطأ سحب: %s", exc, exc_info=True); await self.supervisor.disconnect(); await asyncio.sleep(self.poll_error_retry)

    def health(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY if self._task and not self._task.done() else HealthState.UNHEALTHY, message="السحب يعمل" if self._task and not self._task.done() else "محرك السحب متوقف")

MAIN_REPLY_KEYBOARD = [
    ["📊 حالة النظام", "📋 التقرير الصباحي"],
    ["🏥 الصحة", "إعادة الفحص"],
    ["ℹ️ المساعدة", "👥 المستخدمون"]
]

class Atom(AtomBase):
    def __init__(self) -> None:
        self.atom_id, self._context, self._client, self.supervisor, self.polling_engine, self.clock = 610, None, None, None, None, SystemClock()
        self._atom_matrix: dict[int, str] = {610: "HEALTHY"}; self._event_counts: dict[int, int] = {}; self._total_events, self._allowed_users, self._allow_all = 0, set(), False; self._commands_relayed = 0
        self._heartbeat_task: asyncio.Task | None = None
        self._heartbeat_interval_s: float = 3600.0

    def _load_token(self, context: AtomContext) -> str:
        try:
            from security import get_secret_provider
            t = get_secret_provider().get_secret("telegram_bot_token")
            if t: return t
        except Exception: pass
        t = os.environ.get("QUANT_SECRET_TELEGRAM_BOT_TOKEN") or os.environ.get("TELEGRAM_BOT_TOKEN")
        if t: return t
        context.logger.warning("[610]: توكن البوت مفقود بالأسرار والبيئة."); return ""

    async def initialize(self, context: AtomContext) -> None:
        self._context, cfg = context, context.config
        context.logger.info("[610]: بدء تهيئة ذرة التحكم والمراقبة...")
        self._allowed_users, self._allow_all = {int(u) for u in cfg.get("allowed_user_ids", [])}, cfg.get("allow_all_users", False)
        self._heartbeat_interval_s = float(cfg.get("heartbeat_interval_s", 3600.0))
        inj = cfg.get("_test_client")
        self._client = inj if inj else RealTelegramClient(self.clock, cfg.get("transport_timeout", 20), cfg.get("rate_limit_rate", 30.0), cfg.get("rate_limit_capacity", 30), cfg.get("poll_http_offset_sec", 5))
        self.supervisor = ConnectionSupervisor(self._client, self._load_token(context), cfg.get("max_backoff_delay", 60.0), context.logger, self.clock)
        self.polling_engine = PollingEngine(self._client, self.supervisor, context.logger, cfg.get("poll_timeout", 30), cfg.get("busy_loop_sleep", 0.1), cfg.get("poll_error_retry_sec", 5.0), self._handle_telegram_update)
        
        context.subscribe("telegram.outbound", self._on_outbound)
        for t in ["core.atom.started", "core.atom.registered", "core.atom.status", "core.atom.failed", "core.atom.unhealthy", "core.critical_atom.unhealthy", "trade.opened", "trade.closed", "tools.alert.raised"]:
            context.subscribe(t, lambda p, topic_name=t: self._handle_system_event(topic_name, p))
            
        context.logger.info("[610]: مكتمل ومربوط مع جميع الأحداث ومحرك النبض.")

    async def start(self) -> None:
        if self._context:
            self._context.logger.info("[610]: تشغيل المحرك ونبض النظام وطلب كشف كامل الذرات...")
            await self._context.publish("core.system.rescan_requested", {"requested_by": 610, "timestamp": self.clock.now()})
        if self.polling_engine: self.polling_engine.start()
        if self._heartbeat_task is None:
            self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())

    async def stop(self) -> None:
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            try: await self._heartbeat_task
            except asyncio.CancelledError: pass
            self._heartbeat_task = None
        if self.polling_engine: await self.polling_engine.stop()
        if self.supervisor: await self.supervisor.disconnect()

    async def shutdown(self) -> None: await self.stop()

    async def health_check(self) -> HealthStatus:
        if not self.supervisor or not self.polling_engine: return HealthStatus(state=HealthState.UNHEALTHY, message="غير مهيأة")
        sh = self.supervisor.health()
        return sh if sh.state != HealthState.HEALTHY else self.polling_engine.health()

    async def snapshot(self) -> dict[str, Any] | None:
        return {"atom_id": 610, "matrix": self._atom_matrix, "event_counts": self._event_counts, "total_events": self._total_events, "offset": self._client.offset if self._client else 0, "timestamp": self.clock.now()}

    async def restore(self, state: dict[str, Any]) -> None:
        self._atom_matrix = state.get("matrix", self._atom_matrix)
        self._event_counts = state.get("event_counts", self._event_counts)
        self._total_events = state.get("total_events", self._total_events)
        if self._client and "offset" in state: self._client.offset = state.get("offset", 0)

    async def _heartbeat_loop(self) -> None:
        """ترسل تقريراً دورياً مطمئناً للمستخدمين، حتى في أوقات الهدوء وعدم وجود أحداث."""
        while True:
            try:
                await asyncio.sleep(self._heartbeat_interval_s)
                if not self._context or not self._allowed_users: continue
                tot, f, un, h = len(self._atom_matrix), sum(1 for s in self._atom_matrix.values() if s == "FAILED"), sum(1 for s in self._atom_matrix.values() if "UNHEALTHY" in s), sum(1 for s in self._atom_matrix.values() if s == "HEALTHY")
                sup = self.supervisor.state.value if self.supervisor else "N/A"
                msg = (
                    f"<b>نبض النظام - التقرير الدوري:</b>\n\n"
                    f" <b>المُنظم:</b> {sup}\n"
                    f"📦 <b>الذرات المرصودة:</b> {tot} ( {h} | 🟡 {un} |  {f})\n"
                    f"⚡ <b>الأحداث المعالجة:</b> {self._total_events}\n\n"
                    f"<i>النظام يعمل بسلام واستقرار تام.</i>"
                )
                for uid in self._allowed_users:
                    await self._send_message(uid, msg)
            except asyncio.CancelledError: break
            except Exception as exc:
                if self._context: self._context.logger.error("خطأ حلقة نبض النظام: %s", exc, exc_info=True)

    async def _send_message(self, chat_id: int, text: str, inline_buttons: list[list[GenericButton]] | None = None, show_reply_keyboard: bool = True) -> None:
        if not self._client: return
        body: dict[str, Any] = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
        if inline_buttons:
            body["reply_markup"] = {"inline_keyboard": [[{"text": b.text, "callback_data": b.callback_data} for b in r] for r in inline_buttons]}
        elif show_reply_keyboard:
            body["reply_markup"] = {"keyboard": [[{"text": btn} for btn in row] for row in MAIN_REPLY_KEYBOARD], "resize_keyboard": True}
        try: await self._client.send_payload("sendMessage", body)
        except Exception as exc:
            if self._context: self._context.logger.error("فشل إرسال للمستخدم %s: %s", chat_id, exc, exc_info=True)

    async def _on_outbound(self, payload: dict[str, Any]) -> None:
        """قناة ردّ النظام: 901 وغيرها ترسل نصًّا لمالكٍ مسموح دون أن تعرف
        شيئًا عن تيليجرام — 610 وحده يمسك القناة."""
        text = payload.get("text")
        if not text: return
        uid = payload.get("user_id")
        targets = [int(uid)] if uid is not None else sorted(self._allowed_users)
        for u in targets:
            if self._allow_all or u in self._allowed_users:
                await self._send_message(u, str(text))

    async def _handle_telegram_update(self, update: dict[str, Any]) -> None:
        if not self._context: return
        uid, text, data, cb_id = 0, "", "", ""
        if "message" in update: uid, text = update["message"].get("from", {}).get("id", 0), update["message"].get("text", "")
        elif "callback_query" in update:
            uid, data, cb_id = update["callback_query"].get("from", {}).get("id", 0), update["callback_query"].get("data", ""), update["callback_query"].get("id", "")
            if cb_id and self._client:
                try: await self._client.send_payload("answerCallbackQuery", {"callback_query_id": cb_id})
                except Exception: pass
        if not uid or not (True if self._allow_all else uid in self._allowed_users): return
        
        if text and text.startswith("/"):
            # منقول من 610 القديم: الزرّ يعرض والأمرُ يفعل. النشر هنا فقط —
            # الصلاحية والتنفيذ عند بوّابة الأوامر 901، فتتعدّد القنوات
            # ويبقى التحكّم في مكانٍ واحد.
            parts = text.strip().split()
            await self._context.publish("telegram.command.received", {"command": parts[0].lower(), "args": parts[1:], "user_id": uid, "timestamp": self.clock.now()})
            self._commands_relayed += 1
            return
        if text:
            if text in ["📊 حالة النظام", "الحالة", "🏥 الصحة", "الصحة"]: await self._render_view(uid, "health")
            elif text in ["إعادة الفحص", "إعادة الفحص"]: await self._render_view(uid, "rescan")
            elif text in ["👥 المستخدمون", "المستخدمون"]: await self._send_message(uid, f"👥 <b>قائمة المستخدمين المسموح لهم:</b>\n<code>{list(self._allowed_users)}</code>")
            elif text in ["ℹ️ المساعدة", "المساعدة"]: await self._send_message(uid, "ℹ️ <b>مركز المساعدة:</b>\nاستخدم الأزرار أسفل الشاشة للتحكم الكامل بالنظام.")
            elif text in ["📋 التقرير الصباحي", "التقرير"]: await self._render_view(uid, "health")
            else: await self._render_view(uid, "main")
        elif data:
            if ":" in data:
                ns, rest = data.split(":", 1)
                act = rest.split("?", 1)[0] if "?" in rest else rest
                if ns == "menu": await self._render_view(uid, act)

    async def _render_view(self, user_id: int, view_type: str) -> None:
        if view_type == "rescan" and self._context:
            await self._context.publish("core.system.rescan_requested", {"requested_by": user_id, "timestamp": self.clock.now()})
            await self._send_message(user_id, "<b>تم إرسال طلب إعادة فحص النظام (Rescan) بالنواة بنجاح! ستتم إضافة جميع الذرات المكتشفة فوراً.</b>")
            return
        if view_type == "health":
            tot, f, un, h = len(self._atom_matrix), sum(1 for s in self._atom_matrix.values() if s == "FAILED"), sum(1 for s in self._atom_matrix.values() if "UNHEALTHY" in s), sum(1 for s in self._atom_matrix.values() if s == "HEALTHY")
            dt = "".join(f"\n  • <b>ذرة {aid}:</b> {'' if st == 'HEALTHY' else ('🟡' if 'UNHEALTHY' in st else '')} {st} (أحداث: {self._event_counts.get(aid, 0)})" for aid, st in sorted(self._atom_matrix.items())) or "\n  <i>لا أحداث مسجلة بعد.</i>"
            msg = f"📊 <b>تقرير حالة النواة والذرات الحية:</b>\n\n <b>المُنظم:</b> {self.supervisor.state.value if self.supervisor else 'N/A'}\n📦 <b>إجمالي الذرات المرصودة:</b> {tot} ( {h} | 🟡 {un} |  {f})\n⚡ <b>إجمالي الأحداث:</b> {self._total_events}\n\n<b>تفاصيل الذرات المرصودة:</b>{dt}"
            btns = [[GenericButton("طلب إعادة الفحص (Rescan)", "menu:rescan")], [GenericButton("تحديث", "menu:health")]]
            await self._send_message(user_id, msg, inline_buttons=btns)
        else:
            msg = "📱 <b>مركز التحكم المؤسسي</b>\n\nأهلاً بك! شريط الأزرار جاهز أسفل الشاشة للتحكم الفوري:"
            await self._send_message(user_id, msg, show_reply_keyboard=True)

    async def _handle_system_event(self, topic: str, payload: dict[str, Any]) -> None:
        if not self._context: return
        self._total_events += 1
        aid = payload.get("atom_id") or payload.get("source_atom")
        
        if aid and aid not in self._atom_matrix:
            self._atom_matrix[aid] = "HEALTHY"
            
        if aid: self._event_counts[aid] = self._event_counts.get(aid, 0) + 1
        
        if ("started" in topic or "registered" in topic or "status" in topic) and aid:
            self._atom_matrix[aid] = payload.get("state", "HEALTHY")
        elif "critical_atom.unhealthy" in topic and aid:
            self._atom_matrix[aid] = "CRITICAL_UNHEALTHY"
            for u in self._allowed_users: await self._send_message(u, f"🚨 <b>تنبيه حرج!</b> الذرة الحرجة <code>{aid}</code> متدهورة!")
        elif "unhealthy" in topic and aid: self._atom_matrix[aid] = "UNHEALTHY"
        elif "failed" in topic and aid:
            self._atom_matrix[aid] = "FAILED"
            for u in self._allowed_users: await self._send_message(u, f"🚨 <b>فشل الذرة {aid}!</b>\n<b>السبب:</b> {payload.get('error', 'غير معروف')}")
        elif "trade.opened" in topic:
            for u in self._allowed_users: await self._send_message(u, f" <b>فتح صفقة!</b> {payload.get('symbol', 'N/A')} | {payload.get('side', 'N/A')} @ {payload.get('price', 'N/A')}")
        elif "trade.closed" in topic:
            for u in self._allowed_users: await self._send_message(u, f" <b>إغلاق صفقة!</b> {payload.get('symbol', 'N/A')} | PnL: {payload.get('pnl', 'N/A')}")
        elif "tools.alert.raised" in topic:
            # كان الاشتراك على risk.alert — اسمٌ لا ينشره أحد، فصمت تيليجرام
            # عن كل تنبيهات 766. المصحَّح هنا: عقد 766 الحقيقي بحقوله.
            for u in self._allowed_users: await self._send_message(u, f"⚠️ <b>تنبيه [{payload.get('severity', 'WARN')}] من {payload.get('source', '?')}</b>\n{payload.get('message', payload.get('reason', ''))} <code>x{payload.get('count', 1)}</code>")