"""
106 — مستقبل عمق السوق (Market Depth Receiver)
================================================
يستقبل دفتر الأوامر من البوابة (613)، يتحقق من بنيته، ويحسب المشتقّات
الأساسية منه.

**لا يتصل بمصدر خارجي.** المدخل من الناقل حصراً — عبر 613.

**مرهون بمصدر يوفّر Level 2 حقيقي** (ريثمك). مع MT5 أو وسيط CFD لا يصل
دفتر أوامر إطلاقاً، فتُعلن الحالة `UNAVAILABLE` صراحةً — **لا تخمين ولا
حساب محلي بديل**.

**التحقق من البنية إلزامي**: دفتر أوامر مقلوب أو متقاطع يعني بيانات
فاسدة. تمريره كما هو يُسمّم كل ما بعده — 256 و257 و258 تبني عليه.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "market_data.depth_updated"

REASON_NO_SOURCE = "UNAVAILABLE_NO_DEPTH_SOURCE"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
BAD_CROSSED = "crossed_book"
BAD_ORDER = "unsorted"
BAD_EMPTY = "empty_side"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None  # يرفض NaN


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._source_event = ""
        self._max_levels = 0
        self._silence_grace_s = 0.0

        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}
        self._last_ok_mono = 0.0
        self._last_by_symbol: dict[str, dict[str, Any]] = {}

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._source_event = str(cfg["source_event"])
        self._max_levels = int(cfg["max_levels"])
        self._silence_grace_s = float(cfg["silence_grace_s"])

        context.subscribe(self._source_event, self._on_depth)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d — المصدر %s، %d مستوى",
            context.atom_id, self._source_event, self._max_levels,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (استُقبل=%d، نُشر=%d، مرفوض=%s)",
                self._context.atom_id, self._received, self._published,
                {k: v for k, v in self._rejected.items() if v} or "لا شيء",
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str, symbol: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1
        if self._context is not None:
            self._context.logger.warning(
                "رُفض دفتر %s — %s", symbol or "?", reason,
            )

    @staticmethod
    def _levels(raw: Any, limit: int) -> list[tuple[float, float]] | None:
        """يحوّل جانباً واحداً من الدفتر إلى أزواج (سعر، حجم) صالحة.

        يقبل الشكلين: [[سعر, حجم], ...] و [{"price":.., "size":..}, ...]
        — لأن كل مزوّد يرسل بشكله، والتحويل هنا لا في المستهلكين."""
        if not isinstance(raw, list):
            return None
        out: list[tuple[float, float]] = []
        for item in raw[:limit]:
            if isinstance(item, dict):
                price = _to_float(item.get("price"))
                size = _to_float(item.get("size", item.get("volume")))
            elif isinstance(item, (list, tuple)) and len(item) >= 2:
                price, size = _to_float(item[0]), _to_float(item[1])
            else:
                return None
            if price is None or size is None or price <= 0 or size < 0:
                return None
            out.append((price, size))
        return out

    async def _on_depth(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = str(inner.get("symbol") or "")
        self._received += 1

        bids = self._levels(inner.get("bids"), self._max_levels)
        asks = self._levels(inner.get("asks"), self._max_levels)

        if not symbol or bids is None or asks is None:
            self._reject(BAD_SHAPE, symbol)
            return
        if not bids or not asks:
            self._reject(BAD_EMPTY, symbol)
            return

        # الطلبات تنازلياً والعروض تصاعدياً — أي غير ذلك بيانات فاسدة
        if any(bids[i][0] < bids[i + 1][0] for i in range(len(bids) - 1)):
            self._reject(BAD_ORDER, symbol)
            return
        if any(asks[i][0] > asks[i + 1][0] for i in range(len(asks) - 1)):
            self._reject(BAD_ORDER, symbol)
            return

        best_bid, best_ask = bids[0][0], asks[0][0]
        if best_bid >= best_ask:
            self._reject(BAD_CROSSED, symbol)
            return

        bid_volume = sum(size for _, size in bids)
        ask_volume = sum(size for _, size in asks)
        total = bid_volume + ask_volume

        state = {
            "symbol": symbol,
            "bids": [[p, s] for p, s in bids],
            "asks": [[p, s] for p, s in asks],
            "levels": min(len(bids), len(asks)),
            "best_bid": best_bid,
            "best_ask": best_ask,
            "spread": round(best_ask - best_bid, 10),
            "mid": round((best_bid + best_ask) / 2, 10),
            "bid_volume": bid_volume,
            "ask_volume": ask_volume,
            # ميل الدفتر: +1 كل الحجم طلبات، −1 كله عروض، 0 متوازن
            "imbalance": round((bid_volume - ask_volume) / total, 6) if total else 0.0,
            "provider": inner.get("provider"),
            "exchange_timestamp": inner.get("exchange_timestamp"),
            "received_at": inner.get("received_at"),
        }

        self._last_by_symbol[symbol] = state
        self._last_ok_mono = time.monotonic()
        self._published += 1
        await self._context.publish(EVENT_OUT, state)

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self._received, "published": self._published,
            "rejected": {k: v for k, v in self._rejected.items() if v},
            "symbols": len(self._last_by_symbol),
        }

        # مصدر لا يوفّر Level 2 لا يُعدّ عطلاً — يُعلَن غيابه صراحةً
        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details,
            )

        age = time.monotonic() - self._last_ok_mono if self._last_ok_mono else None
        if age is not None and age > self._silence_grace_s:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"صمت الدفتر {age:.0f}ث", details=details,
            )

        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._last_by_symbol)} رمز · نُشر {self._published}",
            details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        """العدّادات فقط. الدفتر نفسه لا يُستعاد: عمق سوق من تشغيل سابق
        بيانات ميتة تُضلّل من يقرأها."""
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
