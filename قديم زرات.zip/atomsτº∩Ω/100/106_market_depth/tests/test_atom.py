"""اختبارات الذرة 106 — مستقبل عمق السوق."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"source_event": "market.depth", "max_levels": 10, "silence_grace_s": 30.0}


def _load():
    spec = importlib.util.spec_from_file_location("_atom106", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom106"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 106
    config = CONFIG
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    def __init__(self):
        self.published = []; self.handlers = {}
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready():
    m = _load(); a = m.Atom(); c = Ctx()
    await a.initialize(c); await a.start()
    return m, a, c


def _book(bids, asks, symbol="US100"):
    return {"symbol": symbol, "bids": bids, "asks": asks, "provider": "rithmic"}


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_no_network():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for banned in ("print(", "import socket", "import urllib", "import requests"):
        assert banned not in src


@pytest.mark.asyncio
async def test_valid_book_publishes_derived_values():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book(
        [[100.0, 5.0], [99.0, 3.0]], [[101.0, 4.0], [102.0, 2.0]]))
    name, p = c.published[0]
    assert name == "market_data.depth_updated"
    assert p["best_bid"] == 100.0 and p["best_ask"] == 101.0
    assert p["spread"] == 1.0 and p["mid"] == 100.5
    assert p["bid_volume"] == 8.0 and p["ask_volume"] == 6.0
    assert p["imbalance"] == pytest.approx(2 / 14, abs=1e-6)


@pytest.mark.asyncio
async def test_dict_level_shape_accepted():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book(
        [{"price": 100.0, "size": 5.0}], [{"price": 101.0, "volume": 4.0}]))
    assert c.published and c.published[0][1]["best_bid"] == 100.0


@pytest.mark.asyncio
async def test_crossed_book_rejected():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book([[102.0, 5.0]], [[101.0, 4.0]]))
    assert c.published == []
    assert a._rejected["crossed_book"] == 1


@pytest.mark.asyncio
async def test_unsorted_sides_rejected():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book([[99.0, 1.0], [100.0, 1.0]], [[101.0, 1.0]]))
    await c.handlers["market.depth"](_book([[100.0, 1.0]], [[102.0, 1.0], [101.0, 1.0]]))
    assert c.published == []
    assert a._rejected["unsorted"] == 2


@pytest.mark.asyncio
async def test_empty_side_rejected():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book([], [[101.0, 1.0]]))
    assert c.published == []
    assert a._rejected["empty_side"] == 1


@pytest.mark.asyncio
async def test_malformed_and_nan_rejected():
    m, a, c = await _ready()
    await c.handlers["market.depth"]({})
    await c.handlers["market.depth"](_book("nope", []))
    await c.handlers["market.depth"](_book([[float("nan"), 1.0]], [[101.0, 1.0]]))
    await c.handlers["market.depth"](_book([[-1.0, 1.0]], [[101.0, 1.0]]))
    assert c.published == []
    assert a._rejected["shape"] >= 3


@pytest.mark.asyncio
async def test_max_levels_truncates():
    m, a, c = await _ready()
    bids = [[100.0 - i, 1.0] for i in range(20)]
    asks = [[101.0 + i, 1.0] for i in range(20)]
    await c.handlers["market.depth"](_book(bids, asks))
    assert len(c.published[0][1]["bids"]) == CONFIG["max_levels"]


@pytest.mark.asyncio
async def test_health_declares_unavailable_not_broken():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED"
    assert "UNAVAILABLE" in s.message


@pytest.mark.asyncio
async def test_health_healthy_after_book():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book([[100.0, 1.0]], [[101.0, 1.0]]))
    assert (await a.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_book_not_restored_from_snapshot():
    m, a, c = await _ready()
    await c.handlers["market.depth"](_book([[100.0, 1.0]], [[101.0, 1.0]]))
    snap = await a.snapshot()
    fresh = m.Atom(); await fresh.initialize(Ctx()); await fresh.restore(snap)
    assert fresh._last_by_symbol == {}
    assert fresh._received == snap["received"]


@pytest.mark.asyncio
async def test_stop_is_reversible():
    m, a, c = await _ready()
    await a.stop(); assert a._running is False
    await a.start(); assert a._running is True
