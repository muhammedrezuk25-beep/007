"""
اختبارات فردية معزولة للذرة 116 (Feed Interruption Detector).
"""

from __future__ import annotations

import asyncio
import inspect
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from core.contracts.atom import AtomContext, HealthState
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom116"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class FakeEventBus:
    def __init__(self) -> None:
        self.published: list[tuple[str, dict]] = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name: str, handler) -> None:
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name: str, payload: dict) -> None:
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self, config=None, atom_id=116) -> AtomContext:
        return AtomContext(
            atom_id=atom_id,
            config=config or {},
            logger=self,
            publish=self.publish,
            subscribe=self.subscribe,
        )

    def debug(self, msg, *args, **kwargs) -> None: pass
    def info(self, msg, *args, **kwargs) -> None: pass
    def warning(self, msg, *args, **kwargs) -> None: pass
    def error(self, msg, *args, **kwargs) -> None: pass
    def critical(self, msg, *args, **kwargs) -> None: pass


async def test_feed_detector_healthy_state() -> None:
    print("\n--- test_feed_detector_healthy_state ---")
    bus = FakeEventBus()
    context = bus.make_context({"max_silence_seconds": 1.0})
    atom = Atom()

    await atom.initialize(context)
    await atom.start()

    # محاكاة ورود حدث سوق حديث
    await bus.publish("market.tick", {"symbol": "NQ", "price": 18000})

    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert "البيانات متصلة" in health.message

    await atom.stop()
    print("OK — الحالة سليمة عند ورود البيانات حديثاً")


async def test_feed_detector_interruption_trigger() -> None:
    print("\n--- test_feed_detector_interruption_trigger ---")
    bus = FakeEventBus()
    context = bus.make_context({"max_silence_seconds": 0.05})  # مهلة قصيرة جداً للاختبار
    atom = Atom()

    await atom.initialize(context)
    await atom.start()

    # محاكاة مرور وقت أطول من الحد المسموح دون أي نشاط
    atom._last_tick_time = time.time() - 0.2

    health = await atom.health_check()
    assert health.state == HealthState.UNHEALTHY
    assert "لا tick منذ" in health.message

    # التحقق من نشر حدث الانقطاع لمرة واحدة (Edge-triggered)
    interrupted_events = [p for n, p in bus.published if n == "market_data.feed_interrupted"]
    assert len(interrupted_events) == 1

    # فحص أن استدعاء health_check مرة أخرى لا يكرر نشر الحدث (تجنب الإزعاج)
    await atom.health_check()
    interrupted_events_second = [p for n, p in bus.published if n == "market_data.feed_interrupted"]
    assert len(interrupted_events_second) == 1

    await atom.stop()
    print("OK — تم اكتشاف الانقطاع ونشر الحدث edge-triggered بنجاح")


async def main() -> None:
    await test_feed_detector_healthy_state()
    await test_feed_detector_interruption_trigger()
    print("\nنجحت جميع اختبارات الذرة 116 بنجاح تام!")


if __name__ == "__main__":
    asyncio.run(main())