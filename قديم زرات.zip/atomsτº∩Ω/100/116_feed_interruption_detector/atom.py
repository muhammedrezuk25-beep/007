"""
116 — كشف انقطاع البيانات (Feed Interruption Detector)
يفحص من خلال الفحص الصحي (health_check) ما إذا كان قد وصل أي تحديث للبيانات
خلال الفترة الزمنية المحددة (max_silence_seconds)، وينشر حدث انقطاع عند تجاوزه.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


_FEED_EVENTS = (
    "feed.binance.tick",
    "feed.yahoo.tick",
    "feed.mt5.tick",
    "feed.rithmic.tick",
)


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence_seconds: float = 10.0
        self._last_tick_time: float = time.time()
        self._is_interrupted: bool = False
        self._interruption_count: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        config = context.config
        self._max_silence_seconds = float(config.get("max_silence_seconds", 10.0))
        self._last_tick_time = time.time()

        # الاشتراك في أحداث بيانات السوق لتحديث طابع الزمن للنشاط الأخير
        # العقد الموحّد الرسمي من 650. الأسماء القديمة تبقى للتوافق مع
        # أي مصدر ينشر مباشرة، لكن source.feed.tick هو المصدر الأساسي.
        # اسم واحد فقط عمداً: أي اسم إضافي يخلق نقطة عمياء — وصول
        # source.feed.tick كان يُسكت الكاشف رغم سقوط 613 نفسه.
        # يسمع المصادر مباشرة لا عبر 613.
        #
        # قبل هذا كان يسمع market.tick — أي مخرج البوابة. فسقوط البوابة
        # يُسكت الكاشف نفسه: يموت النظام ولا يُبلّغ أحد.
        #
        # الآن يبقى حيّاً حتى لو ماتت 613، فيميّز بين انقطاع المصدر
        # الحقيقي وسقوط البوابة.
        for feed_event in _FEED_EVENTS:
            context.subscribe(feed_event, self._on_market_activity)

        context.logger.info(
            "FeedInterruptionDetector تمت تهيئته (max_silence_seconds=%.1f)",
            self._max_silence_seconds
        )

    async def start(self) -> None:
        self._last_tick_time = time.time()  # إعادة تعيين عند البدء
        if self._context:
            self._context.logger.info("FeedInterruptionDetector بدأ المراقبة الصحية لانقطاع البيانات")

    async def stop(self) -> None:
        if self._context:
            self._context.logger.info("FeedInterruptionDetector توقف")

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        now = time.time()
        elapsed = now - self._last_tick_time

        if elapsed > self._max_silence_seconds:
            if not self._is_interrupted:
                self._is_interrupted = True
                self._interruption_count += 1
                if self._context:
                    await self._context.publish(
                        "market_data.feed_interrupted",
                        {
                            "elapsed_seconds": elapsed,
                            "threshold_seconds": self._max_silence_seconds,
                            "interruption_count": self._interruption_count
                        }
                    )
                    self._context.logger.warning(
                        "انقطاع بيانات السوق: لم يصل أي تحديث منذ %.1f ثانية (الحد: %.1f)",
                        elapsed, self._max_silence_seconds
                    )

            return HealthStatus(
                state=HealthState.UNHEALTHY,
                message=f"لا tick منذ {elapsed:.1f}s (الحد {self._max_silence_seconds}s)"
            )
        else:
            if self._is_interrupted:
                self._is_interrupted = False
                if self._context:
                    self._context.logger.info("استعادة اتصال بيانات السوق بعد انقطاع")

            return HealthStatus(
                state=HealthState.HEALTHY,
                message=f"البيانات متصلة (آخر تحديث منذ {elapsed:.1f}s)"
            )

    async def snapshot(self) -> dict[str, Any]:
        return {
            "last_tick_time": self._last_tick_time,
            "is_interrupted": self._is_interrupted,
            "interruption_count": self._interruption_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._last_tick_time = state.get("last_tick_time", time.time())
        self._is_interrupted = state.get("is_interrupted", False)
        self._interruption_count = state.get("interruption_count", 0)

    async def _on_market_activity(self, payload: dict[str, Any]) -> None:
        """تحديث وقت آخر نشاط عند ورود أي بيانات سوق"""
        self._last_tick_time = time.time()