"""اختبارات الذرة 107 — شريط الصفقات المنفَّذة."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"source_event": "market.trade", "window_size": 500,
          "publish_every_n_trades": 10, "silence_grace_s": 30.0}


def _load():
    spec = importlib.util.spec_from_file_location("_atom107", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom107"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 107
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready(config=None):
    m = _load(); a = m.Atom(); c = Ctx(config)
    await a.initialize(c); await a.start()
    return m, a, c


def _trade(price=100.0, size=1.0, side=None, symbol="US100"):
    t = {"symbol": symbol, "price": price, "size": size}
    if side is not None: t["side"] = side
    return t


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_no_network():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for banned in ("print(", "import socket", "import urllib"):
        assert banned not in src


@pytest.mark.asyncio
async def test_publishes_every_n_trades_only():
    """الشريط يتحرّك أسرع من أي مستهلك — النشر كل N صفقة."""
    m, a, c = await _ready()
    for _ in range(9):
        await c.handlers["market.trade"](_trade())
    assert c.published == []
    await c.handlers["market.trade"](_trade())
    assert len(c.published) == 1


@pytest.mark.asyncio
async def test_buy_sell_volumes_separated():
    cfg = {**CONFIG, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    await c.handlers["market.trade"](_trade(size=3.0, side="BUY"))
    await c.handlers["market.trade"](_trade(size=2.0, side="SELL"))
    p = c.published[-1][1]
    assert p["buy_volume"] == 3.0 and p["sell_volume"] == 2.0
    assert p["buy_ratio"] == pytest.approx(0.6)


@pytest.mark.asyncio
async def test_unknown_side_not_guessed():
    """اتجاه غير معلَن يبقى UNKNOWN — استنتاجه من السعر تخمين."""
    cfg = {**CONFIG, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    await c.handlers["market.trade"](_trade(size=5.0))
    p = c.published[-1][1]
    assert p["unknown_volume"] == 5.0
    assert p["buy_volume"] == 0.0 and p["sell_volume"] == 0.0
    assert p["buy_ratio"] is None


@pytest.mark.asyncio
async def test_side_aliases_accepted():
    cfg = {**CONFIG, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    for alias, expect in (("b", "BUY"), ("ask", "SELL"), ("bid", "BUY")):
        c.published.clear()
        await c.handlers["market.trade"](_trade(side=alias))
        assert c.published[-1][1]["recent"][-1]["side"] == expect


@pytest.mark.asyncio
async def test_window_capped_per_symbol():
    cfg = {**CONFIG, "window_size": 5, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    for i in range(20):
        await c.handlers["market.trade"](_trade(price=100.0 + i))
    assert c.published[-1][1]["trades_in_window"] == 5


@pytest.mark.asyncio
async def test_symbols_tracked_independently():
    """حالة لكل رمز — لا شريط مشترك."""
    cfg = {**CONFIG, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    await c.handlers["market.trade"](_trade(price=100.0, symbol="US100"))
    await c.handlers["market.trade"](_trade(price=2500.0, symbol="ETHUSDT"))
    assert a.build_state("US100")["last_price"] == 100.0
    assert a.build_state("ETHUSDT")["last_price"] == 2500.0


@pytest.mark.asyncio
async def test_malformed_rejected():
    m, a, c = await _ready()
    await c.handlers["market.trade"]({})
    await c.handlers["market.trade"]({"symbol": "X"})
    await c.handlers["market.trade"](_trade(price=-1.0))
    await c.handlers["market.trade"](_trade(price=float("nan")))
    assert c.published == []
    assert sum(a._rejected.values()) == 4


@pytest.mark.asyncio
async def test_health_declares_unavailable_not_broken():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "UNAVAILABLE" in s.message


@pytest.mark.asyncio
async def test_tape_not_restored_from_snapshot():
    """صفقات تشغيل سابق تُحسب في نافذة اليوم فتفسد كل نسبة."""
    cfg = {**CONFIG, "publish_every_n_trades": 1}
    m, a, c = await _ready(cfg)
    await c.handlers["market.trade"](_trade(side="BUY"))
    snap = await a.snapshot()
    fresh = m.Atom(); await fresh.initialize(Ctx(cfg)); await fresh.restore(snap)
    assert fresh._tape == {}
    assert fresh._received == snap["received"]


@pytest.mark.asyncio
async def test_stop_is_reversible():
    m, a, c = await _ready()
    await a.stop(); assert a._running is False
    await a.start(); assert a._running is True
