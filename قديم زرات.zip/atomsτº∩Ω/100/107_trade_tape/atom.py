"""
107 — مستقبل الصفقات المنفَّذة (Trade Tape Receiver)
=====================================================
يستقبل الصفقات التي تمّت **في السوق** ويبني منها شريطاً متحرّكاً.

**⚠ ليست صفقاتنا.** هذه Time & Sales — ما نفّذه المشاركون في السوق كلهم.
صفقاتنا الخاصة مسؤولية قسم التنفيذ (550) وجسر العقل (601). خلط الاثنين
يُفسد كل إحصاء مبني عليهما.

**لا يتصل بمصدر خارجي.** المدخل من الناقل حصراً — عبر 613.

**مرهون بمصدر يوفّر شريط الصفقات.** أغلب وسطاء CFD لا يوفّرونه، فتُعلن
الحالة `UNAVAILABLE` صراحةً بلا تخمين.
"""

from __future__ import annotations

import time
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "market_data.trade_tape_updated"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"
SIDE_UNKNOWN = "UNKNOWN"

REASON_NO_SOURCE = "UNAVAILABLE_NO_TRADE_SOURCE"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
BAD_PRICE = "bad_price"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._source_event = ""
        self._window_size = 0
        self._publish_every = 0
        self._silence_grace_s = 0.0

        # شريط لكل رمز — حالة مستقلة تماماً، لا قيمة مشتركة
        self._tape: dict[str, deque] = {}
        self._since_publish: dict[str, int] = {}

        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}
        self._last_ok_mono = 0.0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._source_event = str(cfg["source_event"])
        self._window_size = int(cfg["window_size"])
        self._publish_every = int(cfg["publish_every_n_trades"])
        self._silence_grace_s = float(cfg["silence_grace_s"])

        context.subscribe(self._source_event, self._on_trade)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d — المصدر %s، نافذة %d صفقة",
            context.atom_id, self._source_event, self._window_size,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (استُقبل=%d، نُشر=%d، مرفوض=%s)",
                self._context.atom_id, self._received, self._published,
                {k: v for k, v in self._rejected.items() if v} or "لا شيء",
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str, symbol: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1
        if self._context is not None:
            self._context.logger.warning("رُفضت صفقة %s — %s", symbol or "?", reason)

    @staticmethod
    def _side(value: Any) -> str:
        """اتجاه الصفقة. غير المعروف يبقى UNKNOWN — لا يُخمَّن.

        كثير من المصادر لا تعلن الاتجاه، واستنتاجه من السعر تخمين يفسد
        كل حساب عدوانية مبني عليه."""
        if not isinstance(value, str):
            return SIDE_UNKNOWN
        upper = value.strip().upper()
        if upper in (SIDE_BUY, "B", "BID"):
            return SIDE_BUY
        if upper in (SIDE_SELL, "S", "ASK"):
            return SIDE_SELL
        return SIDE_UNKNOWN

    async def _on_trade(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = str(inner.get("symbol") or "")
        price = _to_float(inner.get("price"))
        size = _to_float(inner.get("size", inner.get("volume")))

        self._received += 1

        if not symbol or price is None or size is None:
            self._reject(BAD_SHAPE, symbol)
            return
        if price <= 0 or size < 0:
            self._reject(BAD_PRICE, symbol)
            return

        tape = self._tape.setdefault(symbol, deque(maxlen=self._window_size))
        tape.append({
            "price": price, "size": size,
            "side": self._side(inner.get("side")),
            "at": inner.get("exchange_timestamp") or inner.get("received_at"),
        })

        self._last_ok_mono = time.monotonic()
        self._since_publish[symbol] = self._since_publish.get(symbol, 0) + 1

        # النشر كل N صفقة — الشريط يتحرّك أسرع من أي مستهلك
        if self._since_publish[symbol] >= self._publish_every:
            self._since_publish[symbol] = 0
            self._published += 1
            await self._context.publish(EVENT_OUT, self.build_state(symbol))

    def build_state(self, symbol: str) -> dict[str, Any]:
        tape = self._tape.get(symbol) or deque()
        trades = list(tape)

        buy_volume = sum(t["size"] for t in trades if t["side"] == SIDE_BUY)
        sell_volume = sum(t["size"] for t in trades if t["side"] == SIDE_SELL)
        unknown_volume = sum(t["size"] for t in trades if t["side"] == SIDE_UNKNOWN)
        known = buy_volume + sell_volume

        return {
            "symbol": symbol,
            "trades_in_window": len(trades),
            "last_price": trades[-1]["price"] if trades else None,
            "last_size": trades[-1]["size"] if trades else None,
            "total_volume": buy_volume + sell_volume + unknown_volume,
            "buy_volume": buy_volume,
            "sell_volume": sell_volume,
            # حجم بلا اتجاه معروف — يُعلَن ولا يُوزَّع بالتخمين
            "unknown_volume": unknown_volume,
            # عدوانية المشترين: تُحسب من المعروف فقط، و null إن كان كله مجهولاً
            "buy_ratio": round(buy_volume / known, 6) if known else None,
            "recent": trades[-10:],
        }

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self._received, "published": self._published,
            "rejected": {k: v for k, v in self._rejected.items() if v},
            "symbols": len(self._tape),
        }

        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details,
            )

        age = time.monotonic() - self._last_ok_mono if self._last_ok_mono else None
        if age is not None and age > self._silence_grace_s:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"صمت الشريط {age:.0f}ث", details=details,
            )

        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._tape)} رمز · نُشر {self._published}",
            details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        """العدّادات فقط. الشريط لا يُستعاد: صفقات من تشغيل سابق تُحسب
        في نافذة اليوم فتفسد كل نسبة مبنية عليها."""
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
