"""
111 — مدير المزامنة الزمنية (Time Sync Manager)

محسوم سابقًا: يشترك بمخرجات 608 (قسم 600) بس، ما ينشئ وقتًا خاصًا
فيه إطلاقًا. تنشر نفس اسمي الحدثين اللي تستقبلهم من 608 حرفيًا
(market.time.drift, market.time.synced) — تمرير نقي، نفس نمط 101
نفسها (نقطة وصول رسمية موحَّدة داخل عائلة 101 لمزامنة الوقت، بدل ما
يشترك كل من 102-116 بـ608 مباشرة كل واحدة لحالها).

ملاحظة تكرار محتملة (موثَّقة، لا مُخفاة): بما إن أسماء الأحداث
الصادرة مطابقة حرفيًا لأسماء 608 الداخلة، هذا تمرير شفاف بالكامل —
لو كان القصد الفعلي "استهلاك داخلي بس بلا إعادة نشر"، فهالذرة أبسط
من المطلوب. نفّذت السبك حرفيًا كما ورد.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.drift_count = 0
        self.synced_count = 0
        self.last_drift: dict | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        # المصدر الرسمي للوقت هو الذرة 4 (NTP). قبل هذا كان يسمع
        # market.time.* وهي أحداثه هو — فكان يسمع نفسه ولا يصله شيء.
        context.subscribe("time.utc.drift", self._on_drift)
        context.subscribe("time.utc.synced", self._on_synced)
        context.logger.info("TimeSyncManager(111) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TimeSyncManager(111) بدأ الاستماع لمخرجات 608")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"drift_events={self.drift_count} synced_events={self.synced_count}",
        )

    async def snapshot(self) -> dict:
        return {"drift_count": self.drift_count, "synced_count": self.synced_count, "last_drift": self.last_drift}

    async def restore(self, state: dict) -> None:
        self.drift_count = state.get("drift_count", 0)
        self.synced_count = state.get("synced_count", 0)
        self.last_drift = state.get("last_drift")

    # ------------------------------------------------------------------

    async def _on_drift(self, payload: dict) -> None:
        if self._context is None:
            return
        self.drift_count += 1
        self.last_drift = payload
        await self._context.publish("market.time.drift", payload)

    async def _on_synced(self, payload: dict) -> None:
        if self._context is None:
            return
        self.synced_count += 1
        await self._context.publish("market.time.synced", payload)
