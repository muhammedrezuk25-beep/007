import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom111"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=111, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_drift_relayed_and_counted():
    print("\n--- test_drift_relayed_and_counted ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_drift({"drift_ms": 250})
    events = [p for n, p in published if n == "market.time.drift"]
    assert events == [{"drift_ms": 250}]
    assert atom.drift_count == 1
    print(f"OK — drift مُرَحَّل بلا تعديل: {events[0]}")


async def test_synced_relayed_and_counted():
    print("\n--- test_synced_relayed_and_counted ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_synced({"offset_ms": 0})
    events = [p for n, p in published if n == "market.time.synced"]
    assert events == [{"offset_ms": 0}]
    assert atom.synced_count == 1
    print(f"OK — synced مُرَحَّل بلا تعديل: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_drift({"drift_ms": 100})
    await atom._on_synced({})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.drift_count == 1 and atom2.synced_count == 1
    print("OK — restore() نقل كل العدّادات بدقّة")


async def main():
    tests = [test_drift_relayed_and_counted, test_synced_relayed_and_counted, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
