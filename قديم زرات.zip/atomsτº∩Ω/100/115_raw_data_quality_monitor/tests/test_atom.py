"""اختبارات الذرة 115 — مراقب جودة البيانات الخام."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path

ATOM_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))


def _load():
    spec = importlib.util.spec_from_file_location("_a115", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec)
    sys.modules["_a115"] = m
    spec.loader.exec_module(m)
    return m


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_class_exists():
    m = _load()
    assert hasattr(m, "Atom"), "الصنف يجب أن يُسمى Atom كبقية المشروع"


import pytest
import yaml

MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]


class Ctx:
    atom_id = 115

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def _alerts(ctx, kind=None):
    events = [p.get("payload", p) for n, p in ctx.published
              if n == "market_data.quality_alert"]
    return [e for e in events if kind is None or e.get("kind") == kind]


async def _tick(atom, symbol="NQ", bid=100.0, ask=100.1, at=1000.0, ex=1):
    handler = None
    return await atom._on_tick({"symbol": symbol, "bid": bid, "ask": ask,
                                "received_at": at, "exchange_timestamp": ex,
                                "timestamp": at})


@pytest.mark.asyncio
async def test_a_repeated_tick_is_flagged_duplicate():
    atom, ctx = await _ready()
    await _tick(atom, ex=7)
    await _tick(atom, ex=7)
    assert _alerts(ctx, "duplicate")
    assert atom._duplicates == 1


@pytest.mark.asyncio
async def test_a_changed_tick_is_not_a_duplicate():
    atom, ctx = await _ready()
    await _tick(atom, ex=1)
    await _tick(atom, bid=100.5, ask=100.6, ex=2)
    assert _alerts(ctx, "duplicate") == []


@pytest.mark.asyncio
async def test_two_symbols_do_not_shadow_each_other():
    """A single shared last-price produced 2132 false spikes out of 4553 checks
    in a live run, because BTC at 63900 and ETH at 2500 alternate. State is
    per symbol for exactly this reason."""
    atom, ctx = await _ready()
    await _tick(atom, symbol="BTCUSD", bid=63900.0, ask=63901.0, at=1000.0)
    await _tick(atom, symbol="ETHUSD", bid=2500.0, ask=2500.5, at=1000.0)
    assert _alerts(ctx, "price_spike") == []


@pytest.mark.asyncio
async def test_a_time_gap_is_flagged():
    atom, ctx = await _ready(gap_threshold_s=5.0)
    await _tick(atom, at=1000.0, ex=1)
    await _tick(atom, at=1010.0, ex=2)
    gaps = _alerts(ctx, "time_gap")
    assert gaps and gaps[0]["gap_s"] == 10.0


@pytest.mark.asyncio
async def test_a_gap_within_the_threshold_is_silent():
    atom, ctx = await _ready(gap_threshold_s=5.0)
    await _tick(atom, at=1000.0, ex=1)
    await _tick(atom, at=1002.0, ex=2)
    assert _alerts(ctx, "time_gap") == []


@pytest.mark.asyncio
async def test_a_price_spike_is_flagged():
    atom, ctx = await _ready(spike_pct=5.0)
    await _tick(atom, bid=100.0, ask=100.0, at=1000.0, ex=1)
    await _tick(atom, bid=120.0, ask=120.0, at=1001.0, ex=2)
    spikes = _alerts(ctx, "price_spike")
    assert spikes and spikes[0]["change_pct"] == 20.0


@pytest.mark.asyncio
async def test_a_small_move_is_not_a_spike():
    atom, ctx = await _ready(spike_pct=5.0)
    await _tick(atom, bid=100.0, ask=100.0, at=1000.0, ex=1)
    await _tick(atom, bid=101.0, ask=101.0, at=1001.0, ex=2)
    assert _alerts(ctx, "price_spike") == []


@pytest.mark.asyncio
async def test_a_malformed_tick_is_reported_not_swallowed():
    atom, ctx = await _ready()
    await atom._on_tick({"symbol": "NQ", "bid": "abc"})
    assert _alerts(ctx, "malformed")


@pytest.mark.asyncio
async def test_a_tick_without_received_at_is_malformed():
    atom, ctx = await _ready()
    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.1})
    assert _alerts(ctx, "malformed")


@pytest.mark.asyncio
async def test_nothing_is_checked_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.1,
                         "received_at": 1.0})
    assert atom._checked == 0


@pytest.mark.asyncio
async def test_health_reports_the_counters():
    atom, ctx = await _ready()
    await _tick(atom, ex=1)
    status = await atom.health_check()
    assert status is not None


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _tick(atom, ex=1)
    snap = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    if snap is not None:
        await fresh.restore(snap)
    assert True


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert True


# ── الاستعادة تُكمل ما حفظته اللقطة ─────────────────────────────────

@pytest.mark.asyncio
async def test_every_counter_in_the_snapshot_comes_back():
    """اللقطة تحفظ ستّة عدّادات والاستعادة تُرجع اثنين: التكرار والفجوات
    والقفزات والاسبريد المشوّه تُصفَّر صامتةً، فتظهر تقارير الجودة سليمة
    وهي ليست كذلك."""
    atom, ctx = await _ready()
    atom._checked = 100
    atom._alerts = 7
    atom._duplicates = 3
    atom._gaps = 2
    atom._spikes = 5
    atom._bad_spreads = 4
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    await fresh.initialize(Ctx(CONFIG))
    await fresh.restore(state)
    for name in ("_checked", "_alerts", "_duplicates", "_gaps",
                 "_spikes", "_bad_spreads"):
        assert getattr(fresh, name) == getattr(atom, name), name
