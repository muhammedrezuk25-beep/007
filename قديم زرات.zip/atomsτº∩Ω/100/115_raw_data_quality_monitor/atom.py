"""
115 — مراقب جودة البيانات الخام (Raw Data Quality Monitor)
============================================================
يراقب تدفق القسم 100: فجوات زمنية، تكرار، شذوذ سعري، سبريد غير طبيعي.
ينشر تنبيه market_data.quality_alert عند أي خلل — كما يعد توثيقه تمامًا.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._gap_threshold_s = 5.0
        self._spike_pct = 5.0
        self._spread_pct = 1.0

        # حالة مستقلة لكل رمز: قيمة واحدة مشتركة كانت تحسب كل تناوب
        # بين رمزين (BTC~63900 ↔ ETH~2500) قفزةً سعرية وهمية —
        # 2132 تنبيهاً كاذباً من 4553 فحصاً في تشغيل حقيقي.
        self._last_price: dict[str, float] = {}
        self._last_ts: dict[str, float] = {}
        self._last_seen_key: dict[str, tuple] = {}

        self._checked = 0
        self._alerts = 0
        self._duplicates = 0
        self._gaps = 0
        self._spikes = 0
        self._bad_spreads = 0

    async def initialize(self, context: AtomContext) -> None:
        context.logger.info("[الذرة %d]: بدء تهيئة الذرة...", context.atom_id)
        self._context = context
        cfg = context.config
        self._gap_threshold_s = float(cfg.get("gap_threshold_s", 5.0))
        self._spike_pct = float(cfg.get("spike_pct", 5.0))
        self._spread_pct = float(cfg.get("spread_pct", 1.0))

        # خلف البوابة 613 حصراً — مسار واحد بلا ازدواج
        context.subscribe("market.tick", self._on_tick)

        self._initialized = True
        context.logger.info("[الذرة %d]: اكتملت التهيئة بنجاح.", context.atom_id)

    async def start(self) -> None:
        if not self._initialized or self._running:
            return
        self._running = True
        self._context.logger.info("[الذرة %d]: تم التشغيل بنجاح.", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context:
            self._context.logger.info("[الذرة %d]: تم الإيقاف (فُحص=%d، تنبيهات=%d).",
                                      self._context.atom_id, self._checked, self._alerts)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_tick(self, event: dict[str, Any]) -> None:
        if not self._running or not self._context:
            return
        inner = event.get("payload", event)
        try:
            bid = float(inner.get("bid", inner.get("price", 0.0)) or 0.0)
            ask = float(inner.get("ask", bid) or bid)
            price = (bid + ask) / 2.0 if (bid or ask) else 0.0
            # عقد واحد لا بديل: المصدر الوحيد لهذه الذرة هو market.tick
            # من البوابة 613، وحقله received_at. اسم ثانٍ احتياطي يعني
            # عقدين، وهو ما يخالف مبدأ البوابة الواحدة.
            ts = float(inner["received_at"])
        except (KeyError, TypeError, ValueError):
            await self._alert("malformed", {"raw": str(inner)[:200]}, event.get("timestamp"))
            return

        self._checked += 1
        now = time.time()

        # 1) تكرار متطابق
        sym = str(inner.get("symbol") or "?")
        key = (bid, ask, inner.get("exchange_timestamp"))
        if key == self._last_seen_key.get(sym):
            self._duplicates += 1
            await self._alert("duplicate", {"symbol": inner.get("symbol")}, event.get("timestamp"))
        self._last_seen_key[sym] = key

        # 2) فجوة زمنية
        prev_ts = self._last_ts.get(sym)
        if prev_ts and (ts - prev_ts) > self._gap_threshold_s:
            self._gaps += 1
            await self._alert("time_gap", {"symbol": sym, "gap_s": round(ts - prev_ts, 2)}, event.get("timestamp"))
        self._last_ts[sym] = ts

        # 3) شذوذ سعري
        prev_price = self._last_price.get(sym)
        if prev_price and price:
            change = abs(price - prev_price) / prev_price * 100.0
            if change > self._spike_pct:
                self._spikes += 1
                await self._alert("price_spike", {"symbol": sym, "change_pct": round(change, 2)}, event.get("timestamp"))
        if price:
            self._last_price[sym] = price

        # 4) سبريد غير طبيعي
        if bid and ask and price:
            spread = (ask - bid) / price * 100.0
            if spread > self._spread_pct or ask < bid:
                self._bad_spreads += 1
                await self._alert("abnormal_spread", {"spread_pct": round(spread, 3)}, event.get("timestamp"))
        _ = now

    async def _alert(self, kind: str, details: dict[str, Any],
                     inbound_ts: float | None = None) -> None:
        """Publish a quality alert stamped with the tick that caused it.

        The alert is *about* that tick, so re-reading the clock here would
        place the alert at a different instant than its own evidence.
        With no inbound stamp the key is omitted and core.event_bus fills
        it via setdefault - stamped once, never invented here.
        """
        self._alerts += 1
        stamp = {"timestamp": inbound_ts} if isinstance(inbound_ts, (int, float)) else {}
        try:
            await self._context.publish("market_data.quality_alert", {
                "event_name": "market_data.quality_alert",
                **stamp,
                "payload": {"kind": kind, **details},
            })
        except Exception as exc:  # noqa: BLE001
            self._context.logger.error("[atom %d]: failed to publish quality alert: %s",
                                       self._context.atom_id, exc)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message="لم يبدأ")
        if self._checked == 0:
            return HealthStatus(state=HealthState.DEGRADED, message="لم تصل بيانات للفحص بعد")
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"فُحص={self._checked} تنبيهات={self._alerts} "
                    f"(تكرار={self._duplicates} فجوات={self._gaps} "
                    f"شذوذ={self._spikes} سبريد={self._bad_spreads})")

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "checked": self._checked, "alerts": self._alerts,
            "duplicates": self._duplicates, "gaps": self._gaps,
            "spikes": self._spikes, "bad_spreads": self._bad_spreads,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        # الستّة كلّها: اللقطة تحفظها والاستعادة كانت تُرجع اثنين، فتُصفَّر
        # الأربعة الباقية صامتةً وتظهر تقارير الجودة سليمة وهي ليست كذلك.
        self._checked = int(state.get("checked", 0))
        self._alerts = int(state.get("alerts", 0))
        self._duplicates = int(state.get("duplicates", 0))
        self._gaps = int(state.get("gaps", 0))
        self._spikes = int(state.get("spikes", 0))
        self._bad_spreads = int(state.get("bad_spreads", 0))
