# الذرة 115 - مراقب جودة البيانات الخام (Raw Data Quality Monitor)

## الوظيفة
تقوم هذه الذرة بمراقبة تدفق بيانات السوق الخام (الأسعار والسبريد) بشكل لحظي لاكتشاف أي شذوذ أو مشاكل في جودة البيانات، مثل:
- **Missing Ticks / Time Gaps**: الفجوات الزمنية بين التكات.
- **Outliers**: القفزات السعرية غير المنطقية.
- **Duplicate Ticks**: التكات المكررة.
- **Spread Spikes**: اتساع السبريد بشكل غير طبيعي.
- **Timestamp Validation**: التحقق من صحة الطوابع الزمنية.

## الاعتماديات
- لا توجد اعتماديات مباشرة (تعمل بنظام Event-Driven).

## الأحداث (Events)
- **تشترك في**: 
  - `market_data.price_received`
  - `market_data.spread_updated`
- **تنشر**: 
  - `market_data.quality_alert` (عند اكتشاف خلل).