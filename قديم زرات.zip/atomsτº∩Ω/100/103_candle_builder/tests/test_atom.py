import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom103"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(
        atom_id=103, config=config or {}, logger=_NullLogger(),
        publish=publish, subscribe=lambda n, h: None,
    ), published


async def test_ohlc_tracked_correctly_within_same_period():
    print("\n--- test_ohlc_tracked_correctly_within_same_period ---")
    context, published = make_context({"period_s": 60})
    atom = Atom()
    await atom.initialize(context)
    base = 1784600000.0  # ضمن نفس دقيقة الفترة (60s) بالكامل مع التكات التالية
    period_start = base - (base % 60)

    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.2, "timestamp": period_start + 1})  # mid=100.1 (open)
    await atom._on_tick({"symbol": "NQ", "bid": 105.0, "ask": 105.2, "timestamp": period_start + 10})  # mid=105.1 (high)
    await atom._on_tick({"symbol": "NQ", "bid": 95.0, "ask": 95.2, "timestamp": period_start + 20})   # mid=95.1 (low)
    await atom._on_tick({"symbol": "NQ", "bid": 102.0, "ask": 102.2, "timestamp": period_start + 30})  # mid=102.1 (سيصير close)

    candle = atom._candles["NQ"]
    assert candle["open"] == 100.1
    assert candle["high"] == 105.1
    assert candle["low"] == 95.1
    assert candle["close"] == 102.1
    assert candle["tick_count"] == 4
    assert len(published) == 0, "لسا بنفس الفترة — ما لازم تُغلَق الشمعة"
    print(f"OK — OHLC صحيح بعد 4 تكات بنفس الفترة: O={candle['open']} H={candle['high']} L={candle['low']} C={candle['close']}")


async def test_new_period_closes_previous_candle():
    print("\n--- test_new_period_closes_previous_candle ---")
    context, published = make_context({"period_s": 60})
    atom = Atom()
    await atom.initialize(context)
    base = 1784600000.0
    period_start = base - (base % 60)

    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.2, "timestamp": period_start + 5})
    await atom._on_tick({"symbol": "NQ", "bid": 101.0, "ask": 101.2, "timestamp": period_start + 65})  # فترة تالية

    closed = [p for n, p in published if n == "market_data.candle_closed"]
    assert len(closed) == 1
    assert closed[0]["open"] == 100.1 and closed[0]["close"] == 100.1  # tick واحد بس بالفترة الأولى
    assert closed[0]["volume"] == 1
    assert closed[0]["timeframe"] == "60s"
    assert atom.candles_closed_count == 1
    # الشمعة الجديدة (الفترة الثانية) صارت هي الحالية الآن، لسا مفتوحة
    assert atom._candles["NQ"]["open"] == 101.1
    print(f"OK — الفترة الجديدة أغلقت السابقة ونشرتها بدقّة: {closed[0]}")


async def test_multiple_symbols_tracked_independently():
    print("\n--- test_multiple_symbols_tracked_independently ---")
    context, published = make_context({"period_s": 60})
    atom = Atom()
    await atom.initialize(context)
    base = 1784600000.0
    period_start = base - (base % 60)

    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.2, "timestamp": period_start + 1})
    await atom._on_tick({"symbol": "ES", "bid": 5000.0, "ask": 5000.5, "timestamp": period_start + 1})

    assert "NQ" in atom._candles and "ES" in atom._candles
    assert atom._candles["NQ"]["open"] != atom._candles["ES"]["open"]
    print(f"OK — NQ وES بشمعتين مستقلتين تمامًا: NQ={atom._candles['NQ']['open']} ES={atom._candles['ES']['open']}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"period_s": 60})
    atom = Atom()
    await atom.initialize(context)
    base = 1784600000.0
    period_start = base - (base % 60)
    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.2, "timestamp": period_start + 1})
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._candles["NQ"]["open"] == 100.1
    print("OK — restore() نقل الشموع الجارية بدقّة")


async def main():
    tests = [
        test_ohlc_tracked_correctly_within_same_period,
        test_new_period_closes_previous_candle,
        test_multiple_symbols_tracked_independently,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
