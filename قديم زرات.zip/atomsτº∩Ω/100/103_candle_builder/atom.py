"""
103 — مستقبل الشموع (Candle Builder)

يشترك: market.tick. يبني شمعة OHLC من التكات (فترة قابلة للإعداد،
1m افتراضي)، محاذاة على حدود زمنية حقيقية (نفس أسلوب CLOCK/TIME_TICK:
period_start = timestamp - (timestamp % period_s)). ينشر
market_data.candle_closed عند إغلاق كل شمعة.

السعر المرجعي للـOHLC = midpoint ((bid+ask)/2) — لا سعر "صفقة" مفرد
بالـtick الخام (bid/ask فقط، لا "trade price"). افتراض صريح.

حجم الشمعة (volume) = عدد التكات ضمن الفترة (Tick Volume) —
market.tick لا يحمل حجمًا فعليًا (ذاك market.volume، مصدر 104 منفصل).
افتراض صريح يستأهل تأكيدًا لو المقصود دمج market.volume هنا فعليًا.

قيد معماري معروف: بلا حلقة داخلية — إغلاق الشمعة مرهون بوصول أول
Tick بالفترة التالية. فجوة بيانات (لا تكات لفترة) تعني تأخر إغلاق
الشمعة الحالية لحد وصول Tick جديد، لا خطأ لكنه قيد التصميم
event-driven البحت هنا. 116 (كشف انقطاع التغذية) تكتشف الانقطاع نفسه
بشكل منفصل — لا تعويض تلقائي هنا.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._period_s = 60.0
        self._candles: dict[str, dict] = {}
        self.candles_closed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._period_s = float(context.config.get("period_s", 60.0))
        context.subscribe("market.tick", self._on_tick)
        context.logger.info("CandleBuilder(103) تمت تهيئته (period_s=%.0f)", self._period_s)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("CandleBuilder(103) بدأ الاستماع لـmarket.tick")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"شموع مغلَقة={self.candles_closed_count} رموز نشطة={list(self._candles.keys())}",
        )

    async def snapshot(self) -> dict:
        return {"candles": self._candles, "candles_closed_count": self.candles_closed_count}

    async def restore(self, state: dict) -> None:
        self._candles = state.get("candles", {})
        self.candles_closed_count = state.get("candles_closed_count", 0)

    # ------------------------------------------------------------------

    def _period_start(self, timestamp: float) -> float:
        return timestamp - (timestamp % self._period_s)

    async def _on_tick(self, payload: dict) -> None:
        payload = payload.get("payload", payload) if isinstance(payload, dict) else payload
        if self._context is None:
            return
        symbol = payload["symbol"]
        bid = float(payload["bid"])
        ask = float(payload["ask"])
        timestamp = payload.get("timestamp", time.time())
        mid = (bid + ask) / 2
        period_start = self._period_start(timestamp)

        current = self._candles.get(symbol)
        if current is not None and current["period_start"] != period_start:
            await self._close_candle(symbol, current)
            current = None

        if current is None:
            self._candles[symbol] = {
                "period_start": period_start, "open": mid, "high": mid,
                "low": mid, "close": mid, "tick_count": 1,
            }
        else:
            current["high"] = max(current["high"], mid)
            current["low"] = min(current["low"], mid)
            current["close"] = mid
            current["tick_count"] += 1

    async def _close_candle(self, symbol: str, candle: dict) -> None:
        self.candles_closed_count += 1
        await self._context.publish(
            "market_data.candle_closed",
            {
                "symbol": symbol, "open": candle["open"], "high": candle["high"],
                "low": candle["low"], "close": candle["close"], "volume": candle["tick_count"],
                "timeframe": f"{int(self._period_s)}s",
            },
        )
