"""
108 — مستقبل الأخبار (News Receiver)
======================================
يستقبل الأخبار من موصّل خارجي، يوحّد شكلها، ويبثّها للنظام.

**لا يتصل بأي API.** الاتصال مسؤولية قسم 600 حصراً — وموصّل الأخبار غير
مبني بعد. لذلك **اسم حدث المدخل من `config`**: حين تبني الموصّل، تكتب
اسم حدثه في سطر واحد بلا تعديل كود.

**لا يخترع تقييماً.** الخبر الذي يصل بلا `sentiment` أو `impact` يُنشر
بحقول `null` — ولا يُستنتج شيء من العنوان. الاستنتاج تخمين، والتخمين في
منظومة قرار خطر.

**من ينتظره**: 411 (استراتيجية الأخبار) — ومنها 458 و463 في سلسلة القرار.
"""

from __future__ import annotations

import time
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "market_data.news_received"

IMPACT_HIGH = "HIGH"
IMPACT_MEDIUM = "MEDIUM"
IMPACT_LOW = "LOW"
IMPACT_UNKNOWN = "UNKNOWN"

REASON_NO_SOURCE = "UNAVAILABLE_NO_NEWS_SOURCE"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
DUPLICATE = "duplicate"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._source_event = ""
        self._recent_size = 0
        self._silence_grace_s = 0.0

        self._recent: deque = deque()
        self._seen_keys: deque = deque()

        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}
        self._last_ok_mono = 0.0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._source_event = str(cfg["source_event"])
        self._recent_size = int(cfg["recent_size"])
        self._silence_grace_s = float(cfg["silence_grace_s"])

        self._recent = deque(maxlen=self._recent_size)
        self._seen_keys = deque(maxlen=self._recent_size * 4)

        context.subscribe(self._source_event, self._on_news)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d — المصدر %s", context.atom_id, self._source_event,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (استُقبل=%d، نُشر=%d، مرفوض=%s)",
                self._context.atom_id, self._received, self._published,
                {k: v for k, v in self._rejected.items() if v} or "لا شيء",
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1

    @staticmethod
    def _impact(value: Any) -> str:
        """درجة الأثر. غير المعروف يبقى UNKNOWN — لا يُخمَّن من العنوان."""
        if not isinstance(value, str):
            return IMPACT_UNKNOWN
        upper = value.strip().upper()
        if upper in (IMPACT_HIGH, "3", "H"):
            return IMPACT_HIGH
        if upper in (IMPACT_MEDIUM, "MED", "2", "M"):
            return IMPACT_MEDIUM
        if upper in (IMPACT_LOW, "1", "L"):
            return IMPACT_LOW
        return IMPACT_UNKNOWN

    @staticmethod
    def _sentiment(value: Any) -> float | None:
        """درجة الاتجاه في [-1, +1]. خارج النطاق أو غير رقمية ⇒ None."""
        score = _to_float(value)
        if score is None or not -1.0 <= score <= 1.0:
            return None
        return round(score, 4)

    async def _on_news(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        headline = inner.get("headline") or inner.get("title")
        self._received += 1

        if not isinstance(headline, str) or not headline.strip():
            self._reject(BAD_SHAPE)
            return
        headline = headline.strip()

        # نفس الخبر يصل من مصادر متعددة — المفتاح يمنع تكراره للمستهلكين
        key = (inner.get("id") or f"{headline[:120]}|{inner.get('published_at')}")
        if key in self._seen_keys:
            self._reject(DUPLICATE)
            return
        self._seen_keys.append(key)

        item = {
            "headline": headline,
            "source": inner.get("source"),
            "symbols": inner.get("symbols") or [],
            "sentiment_score": self._sentiment(inner.get("sentiment_score")),
            "impact_level": self._impact(inner.get("impact_level")),
            "published_at": inner.get("published_at"),
            "received_at": time.time(),
        }

        self._recent.appendleft(item)
        self._last_ok_mono = time.monotonic()
        self._published += 1
        await self._context.publish(EVENT_OUT, item)

    def recent_items(self) -> list[dict[str, Any]]:
        return list(self._recent)

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self._received, "published": self._published,
            "rejected": {k: v for k, v in self._rejected.items() if v},
            "recent": len(self._recent), "source_event": self._source_event,
        }

        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details,
            )

        age = time.monotonic() - self._last_ok_mono if self._last_ok_mono else None
        if age is not None and age > self._silence_grace_s:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"لا خبر جديد منذ {age / 60:.0f} دقيقة", details=details,
            )

        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"نُشر {self._published} خبراً", details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
            # المفاتيح تُحفظ لمنع إعادة نشر خبر قديم بعد إعادة التشغيل
            "seen_keys": [str(k) for k in list(self._seen_keys)[-200:]],
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
        for key in (state.get("seen_keys") or []):
            self._seen_keys.append(key)
