"""اختبارات الذرة 108 — مستقبل الأخبار."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"source_event": "market.news", "recent_size": 50, "silence_grace_s": 3600.0}


def _load():
    spec = importlib.util.spec_from_file_location("_atom108", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom108"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 108
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready(config=None):
    m = _load(); a = m.Atom(); c = Ctx(config)
    await a.initialize(c); await a.start()
    return m, a, c


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_network_at_all():
    """الاتصال مسؤولية قسم 600 حصراً."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for banned in ("print(", "import socket", "import urllib", "import requests",
                   "import aiohttp", "import feedparser"):
        assert banned not in src


@pytest.mark.asyncio
async def test_publishes_normalized_item():
    m, a, c = await _ready()
    await c.handlers["market.news"]({
        "headline": "  Fed holds rates  ", "source": "reuters",
        "sentiment_score": 0.4, "impact_level": "high", "symbols": ["US100"]})
    name, p = c.published[0]
    assert name == "market_data.news_received"
    assert p["headline"] == "Fed holds rates"
    assert p["sentiment_score"] == 0.4
    assert p["impact_level"] == "HIGH"


@pytest.mark.asyncio
async def test_missing_rating_stays_null_not_guessed():
    """خبر بلا تقييم يُنشر بحقول null — الاستنتاج من العنوان تخمين."""
    m, a, c = await _ready()
    await c.handlers["market.news"]({"headline": "Market crashes hard"})
    p = c.published[0][1]
    assert p["sentiment_score"] is None
    assert p["impact_level"] == "UNKNOWN"


@pytest.mark.asyncio
async def test_out_of_range_sentiment_becomes_null():
    m, a, c = await _ready()
    for bad in (5.0, -3.0, "abc", None):
        c.published.clear()
        await c.handlers["market.news"]({"headline": f"X {bad}",
                                         "sentiment_score": bad})
        assert c.published[0][1]["sentiment_score"] is None


@pytest.mark.asyncio
async def test_impact_aliases():
    m, a, c = await _ready()
    for alias, expect in (("3", "HIGH"), ("med", "MEDIUM"), ("1", "LOW"),
                          ("weird", "UNKNOWN")):
        c.published.clear()
        await c.handlers["market.news"]({"headline": f"H {alias}",
                                         "impact_level": alias})
        assert c.published[0][1]["impact_level"] == expect


@pytest.mark.asyncio
async def test_duplicate_by_id_rejected():
    """نفس الخبر يصل من مصادر متعددة — لا يُكرَّر للمستهلكين."""
    m, a, c = await _ready()
    await c.handlers["market.news"]({"id": "abc", "headline": "One"})
    await c.handlers["market.news"]({"id": "abc", "headline": "One again"})
    assert len(c.published) == 1
    assert a._rejected["duplicate"] == 1


@pytest.mark.asyncio
async def test_duplicate_by_headline_and_time_rejected():
    m, a, c = await _ready()
    item = {"headline": "Same story", "published_at": 1785000000}
    await c.handlers["market.news"](dict(item))
    await c.handlers["market.news"](dict(item))
    assert len(c.published) == 1


@pytest.mark.asyncio
async def test_empty_headline_rejected():
    m, a, c = await _ready()
    await c.handlers["market.news"]({})
    await c.handlers["market.news"]({"headline": "   "})
    await c.handlers["market.news"]({"headline": 123})
    assert c.published == []
    assert a._rejected["shape"] == 3


@pytest.mark.asyncio
async def test_recent_window_capped():
    cfg = {**CONFIG, "recent_size": 3}
    m, a, c = await _ready(cfg)
    for i in range(10):
        await c.handlers["market.news"]({"id": str(i), "headline": f"N{i}"})
    assert len(a.recent_items()) == 3
    assert a.recent_items()[0]["headline"] == "N9"


@pytest.mark.asyncio
async def test_health_declares_unavailable_not_broken():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "UNAVAILABLE" in s.message


@pytest.mark.asyncio
async def test_seen_keys_survive_restart():
    """خبر قديم لا يُعاد نشره بعد إعادة التشغيل."""
    m, a, c = await _ready()
    await c.handlers["market.news"]({"id": "k1", "headline": "First"})
    snap = await a.snapshot()

    fresh = m.Atom(); fc = Ctx()
    await fresh.initialize(fc); await fresh.restore(snap); await fresh.start()
    await fc.handlers["market.news"]({"id": "k1", "headline": "First"})
    assert fc.published == []


@pytest.mark.asyncio
async def test_stop_is_reversible():
    m, a, c = await _ready()
    await a.stop(); assert a._running is False
    await a.start(); assert a._running is True
