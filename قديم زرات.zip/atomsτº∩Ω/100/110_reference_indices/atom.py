"""
110 — مستقبل المؤشرات المرجعية (Reference Indices Receiver)
=============================================================
يستقبل قيم المؤشرات المرجعية (VIX · DXY · TNX وما شابه)، يتتبّع تغيّرها،
ويعلن السياق العام للسوق.

**الفرق عن 102**: 102 يستقبل سعر الأداة التي نتداولها. هذه تستقبل مؤشرات
**لا نتداولها** — قيمتها في السياق: خوف السوق، قوة الدولار، عائد السندات.

**لا يتصل بأي API.** المدخل من الناقل حصراً، واسم حدثه من `config` لأن
الموصّل (ياهو أو غيره) غير مبني بعد.

**لا يفسّر ولا يقيّم.** يبثّ القيمة ونسبة التغيّر. أما «VIX مرتفع يعني
خوفاً» فتفسير يخصّ الاستراتيجية لا المستقبل.

**كل مؤشر حالة مستقلة تماماً** — VIX عند 18 و DXY عند 104، وقيمة مشتركة
بينهما تُنتج نسب تغيّر وهمية.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "market_data.reference_index_updated"

REASON_NO_SOURCE = "UNAVAILABLE_NO_REFERENCE_SOURCE"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
BAD_VALUE = "bad_value"
NOT_WATCHED = "not_watched"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._source_event = ""
        self._watched: list[str] = []
        self._min_change_pct = 0.0
        self._silence_grace_s = 0.0

        # حالة مستقلة لكل مؤشر — لا قيمة مشتركة
        self._last: dict[str, float] = {}
        self._session_open: dict[str, float] = {}
        self._seen_at: dict[str, float] = {}

        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}
        self._last_ok_mono = 0.0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._source_event = str(cfg["source_event"])
        self._watched = [str(s).upper() for s in cfg["watched_symbols"]]
        self._min_change_pct = float(cfg["min_change_pct"])
        self._silence_grace_s = float(cfg["silence_grace_s"])

        context.subscribe(self._source_event, self._on_index)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d — %d مؤشر من %s",
            context.atom_id, len(self._watched), self._source_event,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (استُقبل=%d، نُشر=%d، مؤشرات=%d)",
                self._context.atom_id, self._received, self._published,
                len(self._last),
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1

    async def _on_index(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        value = _to_float(inner.get("value", inner.get("price")))
        self._received += 1

        if not isinstance(symbol, str) or not symbol.strip():
            self._reject(BAD_SHAPE)
            return
        symbol = symbol.strip().upper()

        if value is None or value <= 0:
            self._reject(BAD_VALUE)
            return

        # قائمة صريحة: مؤشر غير معلَن لا يُتتبَّع — يمنع تسرّب رموز غير مقصودة
        if self._watched and symbol not in self._watched:
            self._reject(NOT_WATCHED)
            return

        previous = self._last.get(symbol)
        self._last[symbol] = value
        self._seen_at[symbol] = time.time()
        self._session_open.setdefault(symbol, value)
        self._last_ok_mono = time.monotonic()

        change_pct = None
        if previous is not None and previous > 0:
            change_pct = round((value - previous) / previous * 100.0, 6)
            # تغيّر أصغر من العتبة ليس خبراً — يُحدَّث ولا يُنشر
            if abs(change_pct) < self._min_change_pct:
                return

        open_value = self._session_open[symbol]
        self._published += 1
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol,
            "value": value,
            "previous": previous,
            "change_pct": change_pct,
            "session_open": open_value,
            "change_from_open_pct": round((value - open_value) / open_value * 100.0, 6)
            if open_value > 0 else None,
            "provider": inner.get("provider"),
            "exchange_timestamp": inner.get("exchange_timestamp"),
            "received_at": self._seen_at[symbol],
        })

    def snapshot_values(self) -> dict[str, Any]:
        return {
            symbol: {
                "value": value,
                "session_open": self._session_open.get(symbol),
                "age_s": round(time.time() - self._seen_at[symbol], 1)
                if symbol in self._seen_at else None,
            }
            for symbol, value in self._last.items()
        }

    def reset_session(self) -> None:
        """يُستدعى عند بداية جلسة جديدة لإعادة أساس المقارنة.

        غير موصول بحدث تلقائياً: حدث بداية الجلسة مسؤولية ذرة أخرى (158
        أو 5)، والربط قرار معماري لا يُفترض هنا."""
        self._session_open = dict(self._last)

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self._received, "published": self._published,
            "tracked": len(self._last), "watched": len(self._watched),
            "rejected": {k: v for k, v in self._rejected.items() if v},
        }

        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details,
            )

        age = time.monotonic() - self._last_ok_mono if self._last_ok_mono else None
        if age is not None and age > self._silence_grace_s:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"صمت المؤشرات {age / 60:.0f} دقيقة", details=details,
            )

        missing = [s for s in self._watched if s not in self._last]
        if missing:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"لم تصل بعد: {', '.join(missing)}", details=details,
            )

        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._last)} مؤشر · نُشر {self._published}",
            details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
            # أساس الجلسة يُحفظ: إعادة تشغيل وسط الجلسة لا تُصفّر المقارنة
            "session_open": dict(self._session_open),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        """القيم الأخيرة لا تُستعاد — قيمة مؤشر من تشغيل سابق قد تكون
        قديمة بساعات، ونسبة التغيّر المحسوبة عليها كاذبة."""
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
        for symbol, value in (state.get("session_open") or {}).items():
            parsed = _to_float(value)
            if parsed is not None and parsed > 0:
                self._session_open[str(symbol).upper()] = parsed
