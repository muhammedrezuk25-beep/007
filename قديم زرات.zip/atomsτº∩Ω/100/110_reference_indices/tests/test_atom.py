"""اختبارات الذرة 110 — مستقبل المؤشرات المرجعية."""
from __future__ import annotations
import ast, importlib.util, re, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"source_event": "market.reference",
          "watched_symbols": ["^VIX", "DX-Y.NYB", "^TNX"],
          "min_change_pct": 0.01, "silence_grace_s": 900.0}


def _load():
    spec = importlib.util.spec_from_file_location("_atom110", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom110"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 110
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready(config=None):
    m = _load(); a = m.Atom(); c = Ctx(config)
    await a.initialize(c); await a.start()
    return m, a, c


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_network():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    code = re.sub(r'"""[\s\S]*?"""', "", src)
    for banned in ("print(", "import socket", "import urllib", "import requests"):
        assert banned not in code


@pytest.mark.asyncio
async def test_first_value_published_with_null_change():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 18.5})
    name, p = c.published[0]
    assert name == "market_data.reference_index_updated"
    assert p["value"] == 18.5
    assert p["previous"] is None and p["change_pct"] is None
    assert p["session_open"] == 18.5


@pytest.mark.asyncio
async def test_change_pct_computed_against_previous():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 20.0})
    c.published.clear()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 22.0})
    p = c.published[0][1]
    assert p["previous"] == 20.0
    assert p["change_pct"] == pytest.approx(10.0)


@pytest.mark.asyncio
async def test_tiny_change_updates_without_publishing():
    """تغيّر أصغر من العتبة ليس خبراً."""
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 20.0})
    c.published.clear()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 20.0001})
    assert c.published == []
    assert a._last["^VIX"] == 20.0001


@pytest.mark.asyncio
async def test_symbols_independent():
    """VIX عند 18 و DXY عند 104 — قيمة مشتركة تُنتج نسباً وهمية."""
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 18.0})
    await c.handlers["market.reference"]({"symbol": "DX-Y.NYB", "value": 104.0})
    c.published.clear()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 19.0})
    p = c.published[0][1]
    assert p["symbol"] == "^VIX" and p["previous"] == 18.0


@pytest.mark.asyncio
async def test_unwatched_symbol_rejected():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^GSPC", "value": 5000.0})
    assert c.published == []
    assert a._rejected["not_watched"] == 1


@pytest.mark.asyncio
async def test_symbol_case_normalized():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^vix", "value": 18.0})
    assert c.published[0][1]["symbol"] == "^VIX"


@pytest.mark.asyncio
async def test_bad_values_rejected():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({})
    await c.handlers["market.reference"]({"symbol": "^VIX"})
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": -1})
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": float("nan")})
    assert c.published == []
    assert sum(a._rejected.values()) == 4


@pytest.mark.asyncio
async def test_change_from_open_tracked():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 20.0})
    c.published.clear()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 25.0})
    assert c.published[0][1]["change_from_open_pct"] == pytest.approx(25.0)


@pytest.mark.asyncio
async def test_reset_session_rebases_open():
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 20.0})
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 25.0})
    a.reset_session()
    assert a._session_open["^VIX"] == 25.0


@pytest.mark.asyncio
async def test_health_unavailable_then_missing_then_healthy():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "UNAVAILABLE" in s.message

    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 18.0})
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "DX-Y.NYB" in s.message

    for sym, val in (("DX-Y.NYB", 104.0), ("^TNX", 4.2)):
        await c.handlers["market.reference"]({"symbol": sym, "value": val})
    assert (await a.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_values_not_restored_but_session_open_is():
    """قيمة مؤشر من تشغيل سابق قد تكون قديمة بساعات."""
    m, a, c = await _ready()
    await c.handlers["market.reference"]({"symbol": "^VIX", "value": 18.0})
    snap = await a.snapshot()

    fresh = m.Atom(); await fresh.initialize(Ctx()); await fresh.restore(snap)
    assert fresh._last == {}
    assert fresh._session_open["^VIX"] == 18.0


@pytest.mark.asyncio
async def test_stop_is_reversible():
    m, a, c = await _ready()
    await a.stop(); assert a._running is False
    await a.start(); assert a._running is True
