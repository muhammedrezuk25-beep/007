"""اختبارات الذرة 109 — مستقبل التقويم الاقتصادي."""
from __future__ import annotations
import ast, importlib.util, re, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
CONFIG = {"source_event": "market.calendar", "alert_before_seconds": 900.0,
          "keep_past_seconds": 3600.0, "min_impact": "LOW"}
NOW = 1785000000.0


def _load():
    spec = importlib.util.spec_from_file_location("_atom109", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom109"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 109
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready(config=None):
    m = _load(); a = m.Atom(); c = Ctx(config)
    await a.initialize(c); await a.start()
    return m, a, c


async def _tick(c, offset=0.0):
    await c.handlers["SYS_SECOND"]({"official_time": NOW + offset})


def _event(at_offset, impact="HIGH", title="NFP", eid=None):
    e = {"title": title, "scheduled_at": NOW + at_offset, "impact_level": impact}
    if eid: e["id"] = eid
    return e


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_system_clock_no_network():
    """الوقت من الذرة 4 حصراً — ساعة جهاز منحرفة تعطي عدّاً خاطئاً."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    # يُفحص الكود وحده — الذكر في التوثيق مقصود ولا يُحتسب
    code = re.sub(r'"""[\s\S]*?"""', "", src)
    for banned in ("print(", "import socket", "import urllib",
                   "time.time()", "datetime.now()"):
        assert banned not in code, f"وجد {banned} في الكود"


@pytest.mark.asyncio
async def test_subscribes_to_source_and_time():
    m, a, c = await _ready()
    assert set(c.handlers) == {"market.calendar", "SYS_SECOND"}


@pytest.mark.asyncio
async def test_announces_once_when_entering_window():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(600, eid="e1"))   # بعد 10 دقائق
    await _tick(c)
    announced = [p for n, p in c.published if n == "market_data.calendar_event"]
    assert len(announced) == 1
    assert announced[0]["seconds_until"] == pytest.approx(600.0)

    c.published.clear()
    await _tick(c, 60)
    assert not [p for n, p in c.published if n == "market_data.calendar_event"]


@pytest.mark.asyncio
async def test_far_event_not_announced():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(7200, eid="far"))  # بعد ساعتين
    await _tick(c)
    assert not [p for n, p in c.published if n == "market_data.calendar_event"]


@pytest.mark.asyncio
async def test_window_flag_toggles_once_each_way():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(600, eid="w1"))
    await _tick(c)
    windows = [p for n, p in c.published if n == "market_data.calendar_window"]
    assert windows and windows[-1]["in_event_window"] is True

    c.published.clear()
    await _tick(c, 700)      # الموعد مضى
    windows = [p for n, p in c.published if n == "market_data.calendar_window"]
    assert windows and windows[-1]["in_event_window"] is False


@pytest.mark.asyncio
async def test_past_event_pruned():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(-100, eid="old"))
    await _tick(c, 4000)     # تجاوز keep_past_seconds
    assert a._events == {}


@pytest.mark.asyncio
async def test_impact_filter_drops_below_threshold():
    cfg = {**CONFIG, "min_impact": "HIGH"}
    m, a, c = await _ready(cfg)
    await c.handlers["market.calendar"](_event(600, impact="LOW", eid="low"))
    assert a._events == {}
    await c.handlers["market.calendar"](_event(600, impact="HIGH", eid="high"))
    assert len(a._events) == 1


@pytest.mark.asyncio
async def test_unknown_impact_always_passes():
    """إسقاط UNKNOWN قد يُسقط حدثاً مهماً وصل بلا تصنيف."""
    cfg = {**CONFIG, "min_impact": "HIGH"}
    m, a, c = await _ready(cfg)
    await c.handlers["market.calendar"](_event(600, impact="???", eid="u"))
    assert len(a._events) == 1


@pytest.mark.asyncio
async def test_bad_shape_and_time_rejected():
    m, a, c = await _ready()
    await c.handlers["market.calendar"]({})
    await c.handlers["market.calendar"]({"title": "X"})
    await c.handlers["market.calendar"]({"title": "X", "scheduled_at": -5})
    assert a._events == {}
    assert a._rejected["shape"] == 1 and a._rejected["bad_scheduled_at"] == 2


@pytest.mark.asyncio
async def test_duplicate_rejected():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(600, eid="dup"))
    await c.handlers["market.calendar"](_event(600, eid="dup"))
    assert len(a._events) == 1
    assert a._rejected["duplicate"] == 1


@pytest.mark.asyncio
async def test_upcoming_sorted_by_nearest():
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(5000, title="Far", eid="f"))
    await c.handlers["market.calendar"](_event(300, title="Near", eid="n"))
    await _tick(c)
    assert [e["title"] for e in a.upcoming()] == ["Near", "Far"]


@pytest.mark.asyncio
async def test_health_degraded_without_time_then_source():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "NO_TIME_INPUT" in s.message
    await _tick(c)
    s = await a.health_check()
    assert "UNAVAILABLE" in s.message


@pytest.mark.asyncio
async def test_events_survive_restart_without_double_announce():
    """حدث بعد ساعة يبقى بعد ساعة — ولا يُعلَن مرتين."""
    m, a, c = await _ready()
    await c.handlers["market.calendar"](_event(600, eid="keep"))
    await _tick(c)
    snap = await a.snapshot()

    fresh = m.Atom(); fc = Ctx()
    await fresh.initialize(fc); await fresh.restore(snap); await fresh.start()
    assert len(fresh._events) == 1
    await fc.handlers["SYS_SECOND"]({"official_time": NOW + 10})
    assert not [p for n, p in fc.published if n == "market_data.calendar_event"]
