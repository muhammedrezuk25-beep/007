"""
109 — مستقبل التقويم الاقتصادي (Economic Calendar Receiver)
=============================================================
يستقبل مواعيد الأحداث الاقتصادية، يرتّبها، ويُعلن قربها.

**الفرق عن 108**: الأخبار حدث **وقع**، والتقويم حدث **سيقع**. فهذه الذرة
تحتفظ بالمواعيد وتحسب الزمن المتبقّي — لا تكتفي بالتمرير.

**لا يتصل بأي API.** موصّل التقويم غير مبني بعد، فاسم حدث المدخل من
`config`.

**الوقت من الذرة 4 حصراً** — لا `time.time()`. مقارنة موعد بساعة جهاز
منحرفة تعطي عدّاً تنازلياً خاطئاً، وقراراً بالمنع أو السماح في اللحظة
الخطأ.

**من ينتظره**: 463 (فلتر الأحداث) — الذي يمنع التداول قرب خبر عالي الأثر.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_TIME = "SYS_SECOND"          # 806 TIME_TICK — the only clock owner
EVENT_UPCOMING = "market_data.calendar_event"
EVENT_WINDOW = "market_data.calendar_window"

IMPACT_HIGH = "HIGH"
IMPACT_MEDIUM = "MEDIUM"
IMPACT_LOW = "LOW"
IMPACT_UNKNOWN = "UNKNOWN"

REASON_NO_SOURCE = "UNAVAILABLE_NO_CALENDAR_SOURCE"
REASON_NO_TIME = "NO_TIME_INPUT"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SHAPE = "shape"
BAD_TIME = "bad_scheduled_at"
DUPLICATE = "duplicate"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._source_event = ""
        self._alert_before_s = 0.0
        self._keep_past_s = 0.0
        self._min_impact = ""

        self._events: dict[str, dict[str, Any]] = {}
        self._announced: set[str] = set()
        self._now_utc = 0.0
        self._in_window = False

        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config

        self._source_event = str(cfg["source_event"])
        self._alert_before_s = float(cfg["alert_before_seconds"])
        self._keep_past_s = float(cfg["keep_past_seconds"])
        self._min_impact = str(cfg["min_impact"]).upper()

        context.subscribe(self._source_event, self._on_calendar)
        context.subscribe(EVENT_TIME, self._on_time)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d — المصدر %s، تنبيه قبل %.0f ثانية",
            context.atom_id, self._source_event, self._alert_before_s,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (استُقبل=%d، نُشر=%d، مواعيد=%d)",
                self._context.atom_id, self._received, self._published,
                len(self._events),
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    def _reject(self, reason: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1

    @staticmethod
    def _impact(value: Any) -> str:
        if not isinstance(value, str):
            return IMPACT_UNKNOWN
        upper = value.strip().upper()
        if upper in (IMPACT_HIGH, "3", "H"):
            return IMPACT_HIGH
        if upper in (IMPACT_MEDIUM, "MED", "2", "M"):
            return IMPACT_MEDIUM
        if upper in (IMPACT_LOW, "1", "L"):
            return IMPACT_LOW
        return IMPACT_UNKNOWN

    def _passes_impact(self, impact: str) -> bool:
        """مرشّح الأثر. UNKNOWN يمرّ دائماً — إسقاطه قد يُسقط حدثاً مهماً
        وصل بلا تصنيف، وهذا أخطر من تمرير حدث ثانوي."""
        if impact == IMPACT_UNKNOWN:
            return True
        order = {IMPACT_LOW: 1, IMPACT_MEDIUM: 2, IMPACT_HIGH: 3}
        return order.get(impact, 3) >= order.get(self._min_impact, 1)

    async def _on_calendar(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        title = inner.get("title") or inner.get("event")
        scheduled_at = _to_float(inner.get("scheduled_at"))
        self._received += 1

        if not isinstance(title, str) or not title.strip():
            self._reject(BAD_SHAPE)
            return
        if scheduled_at is None or scheduled_at <= 0:
            self._reject(BAD_TIME)
            return

        impact = self._impact(inner.get("impact_level"))
        if not self._passes_impact(impact):
            return  # دون العتبة — تُهمَل بصمت، ليست خطأً

        key = str(inner.get("id") or f"{title.strip()[:80]}|{int(scheduled_at)}")
        if key in self._events:
            self._reject(DUPLICATE)
            return

        self._events[key] = {
            "id": key,
            "title": title.strip(),
            "country": inner.get("country"),
            "currency": inner.get("currency"),
            "impact_level": impact,
            "scheduled_at": scheduled_at,
        }

    async def _on_time(self, payload: dict[str, Any]) -> None:
        """UTC comes from 806 (TIME_TICK) only — never the machine clock."""
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time"))
        if now is None:
            return
        self._now_utc = now

        # Drop the past: an event whose time has passed is no longer awaited.
        for key in [k for k, e in self._events.items()
                    if now - e["scheduled_at"] > self._keep_past_s]:
            self._events.pop(key, None)
            self._announced.discard(key)

        # Announce every event that entered the alert window, once each.
        for key, event in sorted(self._events.items(),
                                 key=lambda kv: kv[1]["scheduled_at"]):
            remaining = event["scheduled_at"] - now
            if 0 <= remaining <= self._alert_before_s and key not in self._announced:
                self._announced.add(key)
                self._published += 1
                await self._context.publish(EVENT_UPCOMING, {
                    **event, "seconds_until": round(remaining, 1),
                })
                self._context.logger.info(
                    "حدث اقتصادي بعد %.0f ثانية: %s (%s)",
                    remaining, event["title"], event["impact_level"],
                )

        # حالة النطاق: تُنشر عند التغيّر فقط — 463 يبني عليها منعه
        inside = any(
            0 <= e["scheduled_at"] - now <= self._alert_before_s
            for e in self._events.values()
        )
        if inside != self._in_window:
            self._in_window = inside
            self._published += 1
            await self._context.publish(EVENT_WINDOW, {
                "in_event_window": inside,
                "alert_before_seconds": self._alert_before_s,
                "utc": now,
            })

    def upcoming(self, limit: int = 10) -> list[dict[str, Any]]:
        if not self._now_utc:
            return []
        future = [
            {**e, "seconds_until": round(e["scheduled_at"] - self._now_utc, 1)}
            for e in self._events.values() if e["scheduled_at"] >= self._now_utc
        ]
        return sorted(future, key=lambda e: e["seconds_until"])[:limit]

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self._received, "published": self._published,
            "tracked": len(self._events), "in_window": self._in_window,
            "rejected": {k: v for k, v in self._rejected.items() if v},
        }

        if not self._now_utc:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_TIME, details=details,
            )
        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details,
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{len(self._events)} موعداً متتبَّعاً", details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        """المواعيد تُحفظ: حدث بعد ساعة يبقى بعد ساعة رغم إعادة التشغيل.
        والمُعلَن عنه يُحفظ كي لا يُعلَن مرتين."""
        return {
            "version": ATOM_VERSION,
            "received": self._received,
            "published": self._published,
            "rejected": dict(self._rejected),
            "events": list(self._events.values()),
            "announced": sorted(self._announced),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._received = int(state.get("received", 0))
        self._published = int(state.get("published", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
        for event in (state.get("events") or []):
            key = event.get("id")
            if isinstance(key, str) and _to_float(event.get("scheduled_at")):
                self._events[key] = event
        self._announced = {k for k in (state.get("announced") or [])
                           if isinstance(k, str)}
