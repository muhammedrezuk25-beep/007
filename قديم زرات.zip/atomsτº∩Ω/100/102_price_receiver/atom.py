"""
102 — مستقبل الأسعار (Price Receiver)

يشترك: market.tick (613). ينشر: market_data.price_received
{symbol, bid, ask, timestamp} — إعادة تشكيل بس، بلا حساب إضافي
(ذاك دور 105 للسبريد مثلًا).

بلا حلقة داخلية — رد فعل بحت.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.received_count = 0
        self.last_price: dict | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.tick", self._on_tick)
        context.logger.info("PriceReceiver(102) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("PriceReceiver(102) بدأ الاستماع لـmarket.tick")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"استُقبل {self.received_count} سعر")

    async def snapshot(self) -> dict:
        return {"received_count": self.received_count, "last_price": self.last_price}

    async def restore(self, state: dict) -> None:
        self.received_count = state.get("received_count", 0)
        self.last_price = state.get("last_price")

    # ------------------------------------------------------------------

    async def _on_tick(self, payload: dict) -> None:
        payload = payload.get("payload", payload) if isinstance(payload, dict) else payload
        if self._context is None:
            return
        price_event = {
            "symbol": payload.get("symbol"),
            "bid": payload.get("bid"),
            "ask": payload.get("ask"),
            "timestamp": payload.get("timestamp", time.time()),
        }
        self.last_price = price_event
        self.received_count += 1
        await self._context.publish("market_data.price_received", price_event)
