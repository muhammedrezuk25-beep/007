# 102 — Price Receiver (مستقبل الأسعار)

## المسؤولية

تشترك بـ`market.tick` (من 613)، تعيد تشكيله لـ`market_data.price_received`
— `{symbol, bid, ask, timestamp}`. إعادة تشكيل بس، بلا حساب إضافي
(السبريد مثلًا مسؤولية 105).

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

3 اختبارات: إعادة تشكيل دقيقة، تعبئة `timestamp` افتراضيًا لو غائب،
وجولة `snapshot`/`restore`. **نتيجة آخر تشغيل: 3/3.**
