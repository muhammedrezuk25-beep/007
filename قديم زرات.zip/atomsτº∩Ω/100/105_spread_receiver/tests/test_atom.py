import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom105"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=105, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_spread_computed_correctly():
    print("\n--- test_spread_computed_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_tick({"symbol": "NQ", "bid": 21000.25, "ask": 21000.75, "timestamp": 1.0})
    events = [p for n, p in published if n == "market_data.spread_updated"]
    assert abs(events[0]["spread"] - 0.5) < 1e-9
    assert atom.last_spread == events[0]["spread"]
    print(f"OK — spread = ask - bid = {events[0]['spread']}")


async def test_zero_spread_handled():
    print("\n--- test_zero_spread_handled ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.0, "timestamp": 1.0})
    events = [p for n, p in published if n == "market_data.spread_updated"]
    assert events[0]["spread"] == 0.0
    print(f"OK — سبريد صفر (سوق نشط جدًا) يُحتسَب ويُنشَر بشكل طبيعي: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_tick({"symbol": "NQ", "bid": 100.0, "ask": 100.5, "timestamp": 1.0})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.last_spread == 0.5 and atom2.updates_count == 1
    print("OK — restore() نقل آخر سبريد والعدّاد بدقّة")


async def main():
    tests = [test_spread_computed_correctly, test_zero_spread_handled, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
