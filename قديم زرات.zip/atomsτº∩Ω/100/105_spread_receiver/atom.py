"""
105 — مستقبل السبريد (Spread Receiver)

يشترك: market.tick. منطق: spread = ask - bid. ينشر:
market_data.spread_updated.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.updates_count = 0
        self.last_spread: float | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.tick", self._on_tick)
        context.logger.info("SpreadReceiver(105) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SpreadReceiver(105) بدأ الاستماع لـmarket.tick")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count} آخر_سبريد={self.last_spread}")

    async def snapshot(self) -> dict:
        return {"updates_count": self.updates_count, "last_spread": self.last_spread}

    async def restore(self, state: dict) -> None:
        self.updates_count = state.get("updates_count", 0)
        self.last_spread = state.get("last_spread")

    # ------------------------------------------------------------------

    async def _on_tick(self, payload: dict) -> None:
        payload = payload.get("payload", payload) if isinstance(payload, dict) else payload
        if self._context is None:
            return
        bid = float(payload["bid"])
        ask = float(payload["ask"])
        spread = ask - bid
        self.last_spread = spread
        self.updates_count += 1
        await self._context.publish(
            "market_data.spread_updated",
            {"symbol": payload.get("symbol"), "spread": spread, **_ts_from(payload)},
        )
