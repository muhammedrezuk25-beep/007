# 105 — Spread Receiver (مستقبل السبريد)

تشترك بـ`market.tick`، تحسب `spread = ask - bid`، تنشر
`market_data.spread_updated`.

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

3 اختبارات: حساب صحيح، سبريد صفر يُعامَل بشكل طبيعي، وجولة
`snapshot`/`restore`. **نتيجة آخر تشغيل: 3/3.**
