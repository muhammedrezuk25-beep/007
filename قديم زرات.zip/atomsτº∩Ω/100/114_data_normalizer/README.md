# 114 — Data Normalizer (توحيد البيانات)

تشترك بـ`market_data.cleaned` (113)، تنشر `market_data.normalized`
— صيغة موحَّدة `{type, data, normalized_at}` بغض النظر عن المصدر
الأصلي. `type` مُشتقّ من اسم الحدث المصدر (إزالة بادئة `market_data.`
فقط، بلا تقصير إضافي اعتباطي).

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

3 اختبارات: توحيد صحيح لحدث واحد، أنواع مختلفة بوسوم مميَّزة، وجولة
`snapshot`/`restore`. **نتيجة آخر تشغيل: 3/3.**
