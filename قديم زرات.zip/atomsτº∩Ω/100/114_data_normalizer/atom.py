"""
114 — توحيد البيانات (Data Normalizer)

يشترك: مخرجات 113 (market_data.cleaned). ينشر: market_data.normalized
— صيغة موحَّدة بغض النظر عن مصدر البيانات الأصلي (Rithmic/Binance/
Yahoo) أو نوع الحدث بالضبط: {type, data, normalized_at}.

"type" مُشتقّ من اسم الحدث المصدر بإزالة بادئة market_data. فقط
(مثلًا price_received، spread_updated) — لا تقصير إضافي للاسم، تفاديًا
لغموض التقصير الاعتباطي.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_PREFIX = "market_data."


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.normalized_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market_data.cleaned", self._on_cleaned)
        context.logger.info("DataNormalizer(114) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("DataNormalizer(114) بدأ التوحيد")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"مُوحَّد={self.normalized_count}")

    async def snapshot(self) -> dict:
        return {"normalized_count": self.normalized_count}

    async def restore(self, state: dict) -> None:
        self.normalized_count = state.get("normalized_count", 0)

    # ------------------------------------------------------------------

    async def _on_cleaned(self, payload: dict) -> None:
        if self._context is None:
            return
        source_event = payload.get("source_event", "")
        data_type = source_event.removeprefix(_PREFIX) if source_event.startswith(_PREFIX) else source_event

        self.normalized_count += 1
        await self._context.publish(
            "market_data.normalized",
            {"type": data_type, "data": payload.get("payload", {}), **_ts_from(payload)},
        )
