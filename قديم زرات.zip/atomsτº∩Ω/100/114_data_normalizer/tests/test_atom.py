import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom114"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=114, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_cleaned_event_normalized_correctly():
    print("\n--- test_cleaned_event_normalized_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_cleaned({"source_event": "market_data.price_received",
                            "payload": {"symbol": "NQ", "bid": 100.0},
                            "timestamp": 1700000000.5})
    events = [p for n, p in published if n == "market_data.normalized"]
    assert events[0]["type"] == "price_received"
    assert events[0]["data"] == {"symbol": "NQ", "bid": 100.0}
    # normalized_at used to be a fresh clock reading. The atom now propagates
    # the upstream stamp verbatim so the whole chain shares one reading.
    assert events[0]["timestamp"] == 1700000000.5

    # No inbound stamp -> the atom invents none. core.event_bus fills it in
    # via setdefault, so the event is stamped exactly once, at its origin.
    published.clear()
    await atom._on_cleaned({"source_event": "market_data.price_received",
                            "payload": {"symbol": "NQ", "bid": 100.0}})
    bare = [p for n, p in published if n == "market_data.normalized"][0]
    assert "timestamp" not in bare
    print(f"OK - type derived correctly, data preserved: {events[0]}")


async def test_different_source_types_get_distinct_type_tags():
    print("\n--- test_different_source_types_get_distinct_type_tags ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_cleaned({"source_event": "market_data.spread_updated", "payload": {"spread": 0.5}})
    await atom._on_cleaned({"source_event": "market_data.candle_closed", "payload": {"open": 1}})
    events = [p for n, p in published if n == "market_data.normalized"]
    assert events[0]["type"] == "spread_updated"
    assert events[1]["type"] == "candle_closed"
    print(f"OK — أنواع مختلفة، وسوم مختلفة بدقّة: {[e['type'] for e in events]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_cleaned({"source_event": "market_data.price_received", "payload": {}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.normalized_count == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_cleaned_event_normalized_correctly, test_different_source_types_get_distinct_type_tags, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
