"""
113 — تنظيف البيانات (Data Cleaner)

يشترك: نفس مدخلات 112 (التسعة). يستبعد Duplicate Ticks — حدث مطابق
حرفيًا لآخر حدث من نفس النوع لنفس الرمز يُعتبَر تكرارًا، لا يُنشَر.
ينشر market_data.cleaned لغير المكرَّر بس.

تعريف "تكرار" هنا: تطابق حرفي كامل للـpayload (نفس القيم بالضبط)
لآخر حدث بنفس (نوع الحدث، الرمز) — لا سبك أدق وصل لتعريف بديل.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_WATCHED_EVENTS = [
    "market_data.price_received", "market_data.spread_updated", "market_data.candle_closed",
    "market_data.volume_received", "market_data.depth_updated", "market_data.trade_tape_updated",
    "market_data.news_received", "market_data.calendar_event", "market_data.reference_index_updated",
]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_seen: dict[tuple, dict] = {}  # (event_name, symbol) -> آخر payload
        self.processed_count = 0
        self.duplicates_dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _WATCHED_EVENTS:
            context.subscribe(event_name, self._make_cleaner(event_name))
        context.logger.info("DataCleaner(113) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("DataCleaner(113) بدأ التنظيف")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"مُعالَج={self.processed_count} مكرَّر_مستبعَد={self.duplicates_dropped}",
        )

    async def snapshot(self) -> dict:
        return {
            "last_seen": {f"{k[0]}|{k[1]}": v for k, v in self._last_seen.items()},
            "processed_count": self.processed_count,
            "duplicates_dropped": self.duplicates_dropped,
        }

    async def restore(self, state: dict) -> None:
        self._last_seen = {}
        for key, value in state.get("last_seen", {}).items():
            event_name, symbol = key.split("|", 1)
            self._last_seen[(event_name, symbol)] = value
        self.processed_count = state.get("processed_count", 0)
        self.duplicates_dropped = state.get("duplicates_dropped", 0)

    # ------------------------------------------------------------------

    def _make_cleaner(self, event_name: str):
        async def handler(payload: dict) -> None:
            self.processed_count += 1
            symbol = str(payload.get("symbol", ""))
            key = (event_name, symbol)

            if self._last_seen.get(key) == payload:
                self.duplicates_dropped += 1
                return

            self._last_seen[key] = payload
            if self._context is not None:
                await self._context.publish("market_data.cleaned", {"source_event": event_name, "payload": payload})

        return handler
