import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom113"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=113, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_identical_consecutive_tick_dropped_as_duplicate():
    print("\n--- test_identical_consecutive_tick_dropped_as_duplicate ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    tick = {"symbol": "NQ", "bid": 100.0, "ask": 100.5, "timestamp": 1.0}
    await bus.publish("market_data.price_received", tick)
    await bus.publish("market_data.price_received", dict(tick))  # نفس القيم بالضبط، حرفيًا

    cleaned = [p for n, p in bus.published if n == "market_data.cleaned"]
    assert len(cleaned) == 1, "الحدث الثاني مطابق حرفيًا — لازم يُستبعَد كمكرَّر"
    assert atom.duplicates_dropped == 1
    print(f"OK — تك مكرَّر حرفيًا اسُتبعِد، نُشِر مرة وحدة فقط: {cleaned[0]}")


async def test_different_values_both_pass_through():
    print("\n--- test_different_values_both_pass_through ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100.0, "ask": 100.5, "timestamp": 1.0})
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100.1, "ask": 100.6, "timestamp": 2.0})
    cleaned = [p for n, p in bus.published if n == "market_data.cleaned"]
    assert len(cleaned) == 2, "قيم مختلفة — كلاهما حقيقي، لا تكرار"
    print(f"OK — تكّان مختلفان مرّا كلاهما: {len(cleaned)}")


async def test_different_symbols_not_treated_as_duplicates():
    print("\n--- test_different_symbols_not_treated_as_duplicates ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100.0, "ask": 100.5})
    await bus.publish("market_data.price_received", {"symbol": "ES", "bid": 100.0, "ask": 100.5})  # قيم مطابقة، رمز مختلف
    cleaned = [p for n, p in bus.published if n == "market_data.cleaned"]
    assert len(cleaned) == 2, "رمزان مختلفان — لا يُعتبَران تكرارًا رغم تطابق القيم"
    print("OK — تطابق القيم بين رمزين مختلفين لا يُعامَل كتكرار")


async def test_snapshot_restore_preserves_dedup_state():
    print("\n--- test_snapshot_restore_preserves_dedup_state ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    tick = {"symbol": "NQ", "bid": 100.0, "ask": 100.5}
    await bus.publish("market_data.price_received", tick)
    snap = await atom.snapshot()

    atom2 = Atom()
    await atom2.initialize(bus.make_context())
    await atom2.restore(snap)
    # نفس التك يوصل تاني بعد استرجاع الحالة — لازم يُعتبَر مكرَّرًا كمان
    await bus.publish("market_data.price_received", dict(tick))
    cleaned_after = [p for n, p in bus.published if n == "market_data.cleaned"]
    assert len(cleaned_after) == 1, "الاسترجاع يحفظ آخر قيمة معروفة — نفس التك بعد Restart لازم يُعتبَر مكرَّرًا"
    print("OK — restore() حافظ على حالة كشف التكرار عبر Restart محاكى")


async def main():
    tests = [
        test_identical_consecutive_tick_dropped_as_duplicate,
        test_different_values_both_pass_through,
        test_different_symbols_not_treated_as_duplicates,
        test_snapshot_restore_preserves_dedup_state,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
