"""
104 — مستقبل أحجام التداول (Volume Receiver)

يشترك: market.volume (613). ينشر: market_data.volume_received —
تمرير نقي، بلا تحويل.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.received_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.volume", self._on_volume)
        context.logger.info("VolumeReceiver(104) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("VolumeReceiver(104) بدأ الاستماع لـmarket.volume")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"استُقبل {self.received_count} حدث حجم")

    async def snapshot(self) -> dict:
        return {"received_count": self.received_count}

    async def restore(self, state: dict) -> None:
        self.received_count = state.get("received_count", 0)

    # ------------------------------------------------------------------

    async def _on_volume(self, payload: dict) -> None:
        if self._context is None:
            return
        self.received_count += 1
        await self._context.publish("market_data.volume_received", payload)
