# 104 — Volume Receiver (مستقبل أحجام التداول)

تشترك بـ`market.volume` (613)، تعيد نشره كـ`market_data.volume_received`
— تمرير نقي بلا تحويل.

## طريقة الاختبار

```bash
python3 tests/test_atom.py
```

اختباران: تمرير نقي بلا تعديل، وجولة `snapshot`/`restore`. **نتيجة
آخر تشغيل: 2/2.**
