"""
112 — مدقق البيانات (Data Validator)

يشترك: كل أحداث 102-110 (التسعة). يتحقق من صحة القيم (أسعار موجبة،
سبريد غير سالب، OHLC متّسقة high>=low، timestamp حديث). ينشر
market_data.validation_failed لو فيه مشكلة، **بلا نشر لو سليم**
(Edge-triggered — صمت = كل شيء سليم، عكس الفحوصات الأمنية بالمشروع
مثل 805 عمدًا، لأن هذا فحص جودة بيانات لا أمان).

106-110 غير مبنية بعد بهذه الدفعة — الاشتراك بأحداثها مسجَّل هنا
مسبقًا (Event Bus لا يتطلب وجود ناشر فعلي)، الاختبارات تستخدم أحداثًا
مُصطنَعة بنفس الشكل الموثَّق لكل حدث.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_MAX_TIMESTAMP_AGE_S = 60.0
_PRICE_FIELDS_BY_EVENT = {
    "market_data.price_received": ["bid", "ask"],
    "market_data.spread_updated": ["spread"],
    # الحجم مع أسعار الشمعة: 103 ينشره معها، وإغفاله هنا يمرّر حجمًا
    # سالبًا صامتًا إلى ذرّات الضوضاء والحجم الحقيقي فيفسد نتائجها.
    "market_data.candle_closed": ["open", "high", "low", "close", "volume"],
    "market_data.volume_received": ["volume"],
    "market_data.depth_updated": [],
    "market_data.trade_tape_updated": [],
    "market_data.news_received": [],
    "market_data.calendar_event": [],
    "market_data.reference_index_updated": [],
}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.checked_count = 0
        self.failed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _PRICE_FIELDS_BY_EVENT:
            context.subscribe(event_name, self._make_validator(event_name))
        context.logger.info("DataValidator(112) تمت تهيئته (يراقب %d نوع حدث)", len(_PRICE_FIELDS_BY_EVENT))

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("DataValidator(112) بدأ التحقق")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"فُحِص={self.checked_count} فشل={self.failed_count}")

    async def snapshot(self) -> dict:
        return {"checked_count": self.checked_count, "failed_count": self.failed_count}

    async def restore(self, state: dict) -> None:
        self.checked_count = state.get("checked_count", 0)
        self.failed_count = state.get("failed_count", 0)

    # ------------------------------------------------------------------

    def _make_validator(self, source_event: str):
        price_fields = _PRICE_FIELDS_BY_EVENT[source_event]

        async def handler(payload: dict) -> None:
            self.checked_count += 1
            problems = self._validate(source_event, payload, price_fields)
            if problems:
                self.failed_count += 1
                if self._context is not None:
                    await self._context.publish(
                        "market_data.validation_failed",
                        {"source_event": source_event, "problems": problems, "payload": payload},
                    )

        return handler

    def _validate(self, source_event: str, payload: dict, price_fields: list[str]) -> list[str]:
        problems: list[str] = []
        for field in price_fields:
            value = payload.get(field)
            if value is not None and value < 0:
                problems.append(f"{field} سالب: {value}")

        if source_event == "market_data.candle_closed":
            high, low = payload.get("high"), payload.get("low")
            if high is not None and low is not None and high < low:
                problems.append(f"high < low: {high} < {low}")

        timestamp = payload.get("timestamp")
        if timestamp is not None:
            age = time.time() - timestamp
            if age > _MAX_TIMESTAMP_AGE_S:
                problems.append(f"timestamp قديم: عمره {age:.1f}s (الحد {_MAX_TIMESTAMP_AGE_S}s)")

        return problems
