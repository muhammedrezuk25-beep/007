import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
import time

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom112"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=112, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_valid_data_silent_edge_triggered():
    print("\n--- test_valid_data_silent_edge_triggered ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100.0, "ask": 100.5, "timestamp": time.time()})
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert len(failed) == 0, "بيانات سليمة — صمت تام، بلا نشر"
    assert atom.checked_count == 1 and atom.failed_count == 0
    print("OK — بيانات سليمة → صمت تام (Edge-triggered)")


async def test_negative_price_flagged():
    print("\n--- test_negative_price_flagged ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": -5.0, "ask": 100.5, "timestamp": time.time()})
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert len(failed) == 1
    assert "bid سالب" in failed[0]["problems"][0]
    print(f"OK — سعر سالب اكتُشِف: {failed[0]['problems']}")


async def test_ohlc_high_less_than_low_flagged():
    print("\n--- test_ohlc_high_less_than_low_flagged ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.candle_closed", {
        "symbol": "NQ", "open": 100, "high": 90, "low": 95, "close": 92, "volume": 10, "timeframe": "60s",
    })
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert len(failed) == 1
    assert "high < low" in failed[0]["problems"][0]
    print(f"OK — تناقض OHLC (high<low) اكتُشِف: {failed[0]['problems']}")


async def test_stale_timestamp_flagged():
    print("\n--- test_stale_timestamp_flagged ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    old_timestamp = time.time() - 3600  # ساعة كاملة — أقدم من الحد (60s)
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100.0, "ask": 100.5, "timestamp": old_timestamp})
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert len(failed) == 1
    assert "timestamp قديم" in failed[0]["problems"][0]
    print(f"OK — timestamp قديم اكتُشِف: {failed[0]['problems']}")


async def test_covers_all_nine_event_types_even_unbuilt_sources():
    print("\n--- test_covers_all_nine_event_types_even_unbuilt_sources ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    # محاكاة حدث من مصدر غير مبني بعد (108 مثلًا) — الاشتراك مسجَّل مسبقًا
    await bus.publish("market_data.news_received", {"headline": "x", "sentiment_score": 0.5, "impact_level": "high"})
    assert atom.checked_count == 1, "الاشتراك بأحداث 106-110 مسجَّل حتى لو الذرات نفسها غير مبنية بعد"
    print("OK — حدث من مصدر غير مبني بعد (news) اتفحَّص بلا مشكلة")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.price_received", {"bid": -1.0, "ask": 1.0})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.checked_count == 1 and atom2.failed_count == 1
    print("OK — restore() نقل العدّادين بدقّة")


async def main():
    tests = [
        test_valid_data_silent_edge_triggered,
        test_negative_price_flagged,
        test_ohlc_high_less_than_low_flagged,
        test_stale_timestamp_flagged,
        test_covers_all_nine_event_types_even_unbuilt_sources,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


# ── حجم الشمعة يُفحص كما يُفحص سعرها ────────────────────────────────

async def test_a_negative_candle_volume_is_caught():
    """103 ينشر الحجم مع الشمعة، والمدقّق لا يدرجه في حقول الفحص: حجم
    سالب يمرّ صامتًا إلى ذرّات الضوضاء والحجم الحقيقي فيفسد نتائجها."""
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.candle_closed", {
        "symbol": "NQ", "open": 28400.0, "high": 28410.0, "low": 28390.0,
        "close": 28405.0, "volume": -5.0, "timestamp": time.time()})
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert failed, "حجم سالب يجب أن يُرصَد"


async def test_a_sound_candle_still_passes():
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market_data.candle_closed", {
        "symbol": "NQ", "open": 28400.0, "high": 28410.0, "low": 28390.0,
        "close": 28405.0, "volume": 12.0, "timestamp": time.time()})
    failed = [p for n, p in bus.published if n == "market_data.validation_failed"]
    assert not failed
