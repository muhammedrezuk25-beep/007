"""
اختبارات الذرة 460 — فلتر الثقة
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom460"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_CHECKED = _mod.EVENT_CHECKED
BASE_TS = 1785200000.0
BASE_CONFIG = dict(min_confidence=0.75)


def make_context(max_silence=1e12, **overrides):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 460
    config = dict(BASE_CONFIG)
    config["voice_repeat_seconds"] = 60.0
    config.update(overrides)
    config["max_input_silence_seconds"] = max_silence
    context.config = config
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def filtered(**overrides):
    payload = dict(
        symbol="NQ", direction="BUY", score=0.85, confidence=0.9,
        agreement=0.8, signal_count=3, timestamp=BASE_TS,
    )
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_passes_clean_decision():
    atom, context = await build_atom()
    await atom._on_filtered(filtered())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_CHECKED
    assert payload["passed"] is True
    assert payload["reasons"] == []
    assert payload["direction"] == "BUY"
    assert payload["timestamp"] == BASE_TS
    assert atom._passed == 1


FAIL_CASE = dict(confidence=0.1)


@pytest.mark.asyncio
async def test_blocks_low_confidence():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(confidence=0.1))
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is False
    assert payload["reasons"] == ["CONFIDENCE_BELOW_THRESHOLD"]


@pytest.mark.asyncio
async def test_blocks_missing_confidence():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(confidence=None))
    _n, payload = context.publish.await_args.args
    assert payload["reasons"] == ["CONFIDENCE_MISSING"]


@pytest.mark.asyncio
async def test_publishes_even_when_blocked():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(**FAIL_CASE))
    context.publish.assert_awaited_once()
    assert atom._blocked == 1


@pytest.mark.asyncio
async def test_missing_header_is_dropped():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(symbol=""))
    await atom._on_filtered(filtered(timestamp="غير-رقم"))
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_declares_starvation_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"] == ["decision.filtered"]
    context.logger.warning.assert_called_once()

    await atom._on_filtered(filtered())
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_filtered(filtered())
    assert atom._passed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_filtered(filtered())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._passed == 1
