"""
اختبارات الذرة 455 — قرار الشراء
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom455"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_ISSUED = _mod.EVENT_ISSUED
BASE_TS = 1734567890.0


def make_context(require_price=True, max_dropped=2, max_silence=60.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 455
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_input_silence_seconds": max_silence,
        "require_price": require_price,
        "max_dropped_before_degraded": max_dropped,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def filtered(**overrides):
    payload = {
        "symbol": "NQ",
        "direction": "BUY",
        "score": 0.8,
        "confidence": 0.9,
        "price": 20000.0,
        "timestamp": BASE_TS,
    }
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_issues_on_matching_direction():
    atom, context = await build_atom()
    await atom._on_filtered(filtered())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_ISSUED
    assert payload == {"symbol": "NQ", "price": 20000.0, "timestamp": BASE_TS}
    assert atom._issued == 1


@pytest.mark.asyncio
async def test_ignores_other_directions():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(direction="SELL"))
    context.publish.assert_not_awaited()
    assert atom._dropped == 0


@pytest.mark.asyncio
async def test_missing_price_is_dropped_when_required():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(price=None))
    context.publish.assert_not_awaited()
    assert atom._dropped == 1


@pytest.mark.asyncio
async def test_missing_price_allowed_when_not_required():
    atom, context = await build_atom(require_price=False)
    await atom._on_filtered(filtered(price=None))
    _name, payload = context.publish.await_args.args
    assert payload["price"] is None


@pytest.mark.asyncio
async def test_invalid_header_degrades_health():
    atom, _ = await build_atom(max_dropped=1)
    await atom._on_filtered(filtered(symbol=""))
    await atom._on_filtered(filtered(timestamp="غير-رقم"))
    assert (await atom.health_check()).state == HealthState.DEGRADED


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_filtered(filtered())
    assert atom._issued == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_filtered(filtered())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._issued == 1


@pytest.mark.asyncio
async def test_declares_input_starvation_without_stopping():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"]
    assert atom._starving is True
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_starvation_declared_once_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    warned = context.logger.warning.call_count
    await atom.health_check()
    assert context.logger.warning.call_count == warned

    atom._max_silence = 3600.0
    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()
