"""
467 — إرسال القرار
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_APPROVED = "decision.approved"
EVENT_ORDER_REQUESTED = "execution.order.requested"

WATCHED_INPUTS = (EVENT_APPROVED,)

ACTIONABLE_DIRECTIONS = ("BUY", "SELL")

STARVATION_QUORUM = len(WATCHED_INPUTS)
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_ORDER_REQUESTED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """جسر قسم القرار إلى قسم التنفيذ (550) — لا أكثر.

    لا يبني `size` ولا `stop_loss` ولا `take_profit`: تلك مسؤولية 551
    حصراً، الذي يدمج هذا الحدث مع `risk.validation.completed` (512).
    يمرّر القرار المعتمد فقط، ويتجاهل صمتاً كل ما ليس قرار تداول.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._dispatched: int = 0
        self._skipped: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_APPROVED, self._on_approved)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"dispatched": self._dispatched, "skipped": self._skipped},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"dispatched": self._dispatched, "skipped": self._skipped,
                      "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._dispatched = inner.get("dispatched", 0)
        self._skipped = inner.get("skipped", 0)
        self._dropped = inner.get("dropped", 0)

    async def _on_approved(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_APPROVED)
        if self._context is None:
            return
        if not payload.get("approved"):
            self._skipped += 1
            return
        direction = payload.get("direction")
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        if not symbol or direction not in ACTIONABLE_DIRECTIONS:
            self._skipped += 1
            return
        self._note(LABEL_MINE)
        timestamp = _to_float(payload.get("timestamp"))
        if timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("قرار معتمد بلا طابع زمني صالح")
            return
        await self._context.publish(
            EVENT_ORDER_REQUESTED,
            {
                "request_id": payload.get("request_id"),
                "account_id": account_id,
                "symbol": symbol,
                "side": direction,
                "timestamp": timestamp,
                # تمرير شفاف: أي حقول ثقة تصل من السلسلة مستقبلًا تعبر
                # تلقائيًا للجسر دون تعديل هنا.
                **{k: payload[k] for k in ("confidence", "score", "stability") if k in payload},
            },
        )
        self._note(EVENT_ORDER_REQUESTED)
        self._dispatched += 1

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
