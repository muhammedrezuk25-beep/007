"""
اختبارات الذرة 467 — إرسال القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom467"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_ORDER_REQUESTED = _mod.EVENT_ORDER_REQUESTED
BASE_TS = 1785200000.0


def make_context(max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 467
    context.config = {"max_input_silence_seconds": max_silence,
                      "voice_repeat_seconds": 60.0}
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def approved(**overrides):
    payload = {"request_id": "d-1", "approved": True, "reason": "ALL_CHECKS_PASSED",
               "symbol": "NQ", "direction": "BUY", "timestamp": BASE_TS}
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_dispatches_minimal_payload_only():
    atom, context = await build_atom()
    await atom._on_approved(approved())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_ORDER_REQUESTED
    assert payload == {"request_id": "d-1", "symbol": "NQ",
                       "side": "BUY", "timestamp": BASE_TS,
                       "account_id": None}
    assert "size" not in payload
    assert "stop_loss" not in payload
    assert "take_profit" not in payload
    assert atom._dispatched == 1


@pytest.mark.asyncio
async def test_dispatches_sell_side():
    atom, context = await build_atom()
    await atom._on_approved(approved(direction="SELL"))
    _n, payload = context.publish.await_args.args
    assert payload["side"] == "SELL"


@pytest.mark.asyncio
async def test_ignores_denied_decision():
    atom, context = await build_atom()
    await atom._on_approved(approved(approved=False))
    context.publish.assert_not_awaited()
    assert atom._skipped == 1


@pytest.mark.asyncio
async def test_ignores_request_approvals():
    atom, context = await build_atom()
    await atom._on_approved({"request_id": "r-1", "approved": True,
                             "reason": "APPROVED",
                             "source_request": "strategy.switch.requested",
                             "timestamp": BASE_TS})
    context.publish.assert_not_awaited()
    assert atom._skipped == 1


@pytest.mark.asyncio
async def test_ignores_non_actionable_direction():
    atom, context = await build_atom()
    await atom._on_approved(approved(direction="NEUTRAL"))
    context.publish.assert_not_awaited()
    assert atom._skipped == 1


@pytest.mark.asyncio
async def test_missing_timestamp_is_dropped():
    atom, context = await build_atom()
    await atom._on_approved(approved(timestamp="غير-رقم"))
    context.publish.assert_not_awaited()
    assert atom._dropped == 1
    context.logger.warning.assert_called_once()


@pytest.mark.asyncio
async def test_silence_degrades_then_recovers():
    atom, _ = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"] == ["decision.approved"]

    await atom._on_approved(approved())
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_approved(approved())
    assert atom._dispatched == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_approved(approved())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._dispatched == 1
