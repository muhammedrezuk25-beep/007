"""
453 — حساب درجة القرار
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_EVALUATED = "decision.signals_evaluated"
INPUT_LABEL = "decision.signals_evaluated"
WATCHED_INPUTS = (INPUT_LABEL,)
EVENT_SCORED = "decision.score_calculated"

FACTOR_KEYS = ("agreement", "avg_strength", "confidence", "stability")
WEIGHT_KEYS = (
    "weight_agreement",
    "weight_strength",
    "weight_confidence",
    "weight_stability",
)

STARVATION_QUORUM = 1   # صمت أي مدخل يكفي لإخراج الصوت
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_SCORED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يحسب درجة قرار موحّدة (0.0–1.0) كمتوسط مرجّح لعوامل التقييم."""

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._weights: list[float] = []
        self._weight_total: float = 0.0
        self._max_dropped: int = 0
        self._dropped: int = 0
        self._scored: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._weights = [float(context.config[key]) for key in WEIGHT_KEYS]
        self._weight_total = sum(self._weights)
        self._max_dropped = int(context.config["max_dropped_before_degraded"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_EVALUATED, self._on_evaluated)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        if self._weight_total <= 0:
            return HealthStatus(
                state=HealthState.UNHEALTHY,
                message="مجموع الأوزان صفر — لا يمكن حساب الدرجة",
            )
        if self._dropped > self._max_dropped:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="تجاوز عدد الحمولات المرفوضة الحد المسموح",
                details={"dropped": self._dropped},
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"scored": self._scored},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"dropped": self._dropped, "scored": self._scored},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._dropped = inner.get("dropped", 0)
        self._scored = inner.get("scored", 0)

    def _score(self, payload: dict[str, Any]) -> float | None:
        """المتوسط المرجّح للعوامل الأربعة، أو None إذا نقص أي عامل."""
        if self._weight_total <= 0:
            return None
        weighted = 0.0
        for key, weight in zip(FACTOR_KEYS, self._weights):
            factor = _to_float(payload.get(key))
            if factor is None:
                return None
            weighted += factor * weight
        return weighted / self._weight_total

    async def _on_evaluated(self, payload: dict[str, Any]) -> None:
        self._note(INPUT_LABEL)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        score = self._score(payload)
        if not symbol or timestamp is None or score is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("تعذّر حساب درجة القرار — حمولة ناقصة")
            return
        scored = dict(payload)
        scored["score"] = score
        scored["timestamp"] = timestamp
        await self._context.publish(EVENT_SCORED, scored)
        self._scored += 1

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
