"""
اختبارات الذرة 453 — حساب درجة القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom453"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_SCORED = _mod.EVENT_SCORED
BASE_TS = 1734567890.0


def make_context(weights=(0.25, 0.25, 0.25, 0.25), max_dropped=2, max_silence=60.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 453
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_input_silence_seconds": max_silence,
        "weight_agreement": weights[0],
        "weight_strength": weights[1],
        "weight_confidence": weights[2],
        "weight_stability": weights[3],
        "max_dropped_before_degraded": max_dropped,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def evaluated(**overrides):
    payload = {
        "symbol": "NQ",
        "direction": "BUY",
        "agreement": 1.0,
        "avg_strength": 0.5,
        "confidence": 0.5,
        "stability": 0.0,
        "timestamp": BASE_TS,
    }
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_weighted_score():
    atom, context = await build_atom()
    await atom._on_evaluated(evaluated())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_SCORED
    assert payload["score"] == pytest.approx(0.5)
    assert payload["direction"] == "BUY"


@pytest.mark.asyncio
async def test_weights_change_the_score():
    atom, context = await build_atom(weights=(1.0, 0.0, 0.0, 0.0))
    await atom._on_evaluated(evaluated())
    _name, payload = context.publish.await_args.args
    assert payload["score"] == pytest.approx(1.0)


@pytest.mark.asyncio
async def test_missing_factor_is_dropped():
    atom, context = await build_atom()
    await atom._on_evaluated(evaluated(stability=None))
    context.publish.assert_not_awaited()
    assert atom._dropped == 1


@pytest.mark.asyncio
async def test_invalid_header_is_dropped():
    atom, context = await build_atom(max_dropped=1)
    await atom._on_evaluated(evaluated(symbol=""))
    await atom._on_evaluated(evaluated(timestamp="غير-رقم"))
    context.publish.assert_not_awaited()
    assert (await atom.health_check()).state == HealthState.DEGRADED


@pytest.mark.asyncio
async def test_zero_weights_is_unhealthy():
    atom, context = await build_atom(weights=(0.0, 0.0, 0.0, 0.0))
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom._on_evaluated(evaluated())
    context.publish.assert_not_awaited()


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_evaluated(evaluated())
    assert atom._scored == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    atom._scored = 4
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._scored == 4


@pytest.mark.asyncio
async def test_declares_input_starvation_without_stopping():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"]
    assert atom._starving is True
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_starvation_declared_once_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    warned = context.logger.warning.call_count
    await atom.health_check()
    assert context.logger.warning.call_count == warned

    atom._max_silence = 3600.0
    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()
