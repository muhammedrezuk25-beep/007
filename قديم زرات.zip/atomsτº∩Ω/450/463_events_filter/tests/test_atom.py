"""
اختبارات الذرة 463 — فلتر الأحداث
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom463"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_CHECKED = _mod.EVENT_CHECKED
WATCHED_INPUTS = _mod.WATCHED_INPUTS
BASE_TS = 1785200000.0


def make_context(blackout=300.0, strength=0.7, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 463
    context.config = {
        "voice_repeat_seconds": 60.0,
        "news_blackout_seconds": blackout,
        "blocking_strength": strength,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def news(strength=0.9, ts=BASE_TS, symbol="NQ"):
    return {"symbol": symbol, "direction": "SELL", "strength": strength, "timestamp": ts}


def filtered(**overrides):
    payload = {"symbol": "NQ", "direction": "BUY", "timestamp": BASE_TS}
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    assert {c.args[0] for c in context.subscribe.call_args_list} == set(WATCHED_INPUTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._news == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_passes_when_no_news_at_all():
    atom, context = await build_atom()
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is True
    assert payload["reasons"] == []


@pytest.mark.asyncio
async def test_blocks_during_strong_news_window():
    atom, context = await build_atom()
    await atom._on_news(news(strength=0.9, ts=BASE_TS - 10.0))
    await atom._on_filtered(filtered())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_CHECKED
    assert payload["passed"] is False
    assert payload["reasons"] == ["NEWS_BLACKOUT_ACTIVE"]
    assert atom._blocked == 1


@pytest.mark.asyncio
async def test_passes_when_news_too_weak():
    atom, context = await build_atom(strength=0.8)
    await atom._on_news(news(strength=0.2))
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is True


@pytest.mark.asyncio
async def test_passes_after_blackout_expires():
    atom, context = await build_atom(blackout=60.0)
    await atom._on_news(news(ts=BASE_TS - 600.0))
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is True


@pytest.mark.asyncio
async def test_news_is_per_symbol():
    atom, context = await build_atom()
    await atom._on_news(news(symbol="ES"))
    await atom._on_filtered(filtered(symbol="NQ"))
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is True


@pytest.mark.asyncio
async def test_malformed_news_ignored():
    atom, _ = await build_atom()
    await atom._on_news({"symbol": "NQ", "strength": None, "timestamp": BASE_TS})
    await atom._on_news({"strength": 0.9, "timestamp": BASE_TS})
    assert atom._news == {}


@pytest.mark.asyncio
async def test_missing_header_is_dropped():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(symbol=""))
    await atom._on_filtered(filtered(timestamp="غير-رقم"))
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_only_both_silent_degrades():
    atom, _ = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert set(health.details["missing_inputs"]) == set(WATCHED_INPUTS)

    await atom._on_filtered(filtered())
    assert (await atom.health_check()).state == HealthState.HEALTHY


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_filtered(filtered())
    assert atom._passed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_news(news())
    await atom._on_filtered(filtered())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._news["NQ"]["strength"] == 0.9
