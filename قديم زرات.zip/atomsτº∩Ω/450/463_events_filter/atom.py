"""
463 — فلتر الأحداث (أخبار ممنوعة)
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_FILTERED = "decision.filtered"
EVENT_NEWS = "strategy.news.signal"
EVENT_CHECKED = "decision.events_checked"

WATCHED_INPUTS = (EVENT_FILTERED, EVENT_NEWS)

CHECK_NAME = "events"

REASON_BLACKOUT = "NEWS_BLACKOUT_ACTIVE"

STARVATION_QUORUM = len(WATCHED_INPUTS)   # النقص = صمت المدخلين معاً
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_CHECKED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يمنع التداول أثناء نافذة خبر عالي التأثير.

    يقرأ `strategy.news.signal` (411) لا `market_data.news_received` (108) —
    مخرج استراتيجية لا بيانات سوق، فقاعدة القسم محفوظة.

    **يمرّر افتراضياً (Fail-Open) عمداً**: صمت الأخبار هو الحالة الطبيعية
    لسوق هادئ، فلا يمكن لهذه الذرة تمييز "لا أخبار" عن "مصدر الأخبار متعطل".
    مراقبة حياة 411 مسؤولية 766، لا مسؤولية فلتر القرار.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._news: dict[str, dict[str, float]] = {}
        self._blackout: float = 0.0
        self._blocking_strength: float = 0.0
        self._passed: int = 0
        self._blocked: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._blackout = float(context.config["news_blackout_seconds"])
        self._blocking_strength = float(context.config["blocking_strength"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_FILTERED, self._on_filtered)
        context.subscribe(EVENT_NEWS, self._on_news)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._news.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"passed": self._passed, "blocked": self._blocked},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"news": self._news, "passed": self._passed,
                      "blocked": self._blocked, "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._news = inner.get("news", {})
        self._passed = inner.get("passed", 0)
        self._blocked = inner.get("blocked", 0)
        self._dropped = inner.get("dropped", 0)

    async def _on_news(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_NEWS)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        strength = _to_float(payload.get("strength"))
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or strength is None or timestamp is None:
            return
        self._news[symbol] = {"strength": strength, "timestamp": timestamp}

    def _evaluate(self, symbol: str, timestamp: float) -> list[str]:
        latest = self._news.get(symbol)
        if latest is None:
            return []
        if timestamp - latest["timestamp"] > self._blackout:
            return []
        if latest["strength"] >= self._blocking_strength:
            return [REASON_BLACKOUT]
        return []

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_FILTERED)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("قرار بلا رمز أو طابع زمني صالح")
            return
        reasons = self._evaluate(symbol, timestamp)
        passed = not reasons
        if passed:
            self._passed += 1
        else:
            self._blocked += 1
        await self._context.publish(
            EVENT_CHECKED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "check": CHECK_NAME,
                "passed": passed,
                "reasons": reasons,
                "direction": payload.get("direction"),
                "timestamp": timestamp,
            },
        )
        self._note(EVENT_CHECKED)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
