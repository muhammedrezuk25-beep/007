"""
466 — اعتماد القرار
"""

from __future__ import annotations

import time
import uuid
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _new_request_id() -> str:
    """An identifier of its own, never a string built from context.

    It used to be assembled from the event name, the symbol and the stamp:

        decision.approved:XAUUSD:1785713853.121333

    Two landed 0.00025 seconds apart on a measured live run, and a tied stamp
    would have made them one id — 554 would merge two order lifecycles under
    it and 562 would retry one trade's order for another.

    The context still travels, in fields of its own: account_id, symbol,
    strategy. Read and queried directly, without parsing a string.
    """
    return uuid.uuid4().hex


EVENT_REVIEWED = "decision.reviewed"
EVENT_APPROVED = "decision.approved"
EVENT_HALT_PAIR = "risk.halt.pair"
EVENT_HALT_ACCOUNT = "risk.halt.account"
EVENT_HALT_RESET = "risk.kill_switch.reset_completed"

REQ_MODEL_SELECTION = "model.selection.requested"
APR_MODEL_SELECTION = "model.selection.approved"
REQ_MODEL_RECALIBRATION = "model.recalibration.requested"
APR_MODEL_RECALIBRATION = "model.recalibration.approved"
REQ_FILTERS_UPDATE = "strategy.filters.update_requested"
APR_FILTERS_UPDATE = "strategy.filters.update_approved"
REQ_STRATEGY_SELECTION = "strategy.selection.requested"
APR_STRATEGY_SELECTION = "strategy.selection.approved"
REQ_STRATEGY_SWITCH = "strategy.switch.requested"
APR_STRATEGY_SWITCH = "strategy.switch.approved"

WATCHED_INPUTS = (EVENT_REVIEWED,)

REASON_PASSED = "ALL_CHECKS_PASSED"
REASON_DISABLED = "REQUESTS_DISABLED"
REASON_COOLDOWN = "COOLDOWN_ACTIVE"
REASON_APPROVED = "APPROVED"

STARVATION_QUORUM = len(WATCHED_INPUTS)
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_APPROVED, APR_MODEL_SELECTION, APR_MODEL_RECALIBRATION, APR_FILTERS_UPDATE, APR_STRATEGY_SELECTION, APR_STRATEGY_SWITCH)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """نقطة الاعتماد النهائية لقسم القرار (Decision Engine).

    مساران منفصلان تماماً بنمط الحدثين:
      * سلسلة التداول: 465 → `decision.approved` (يستهلكها 467 و707).
      * طلبات 363/367/403/415/417: لكل طلب حدث موافقة **باسمه**، فلا
        تلتبس موافقة "تبديل استراتيجية" بأمر تداول عند 467.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._last_approved: dict[str, float] = {}
        self._auto_approve: bool = False
        self._cooldown: float = 0.0
        self._decision_cooldown: float = 0.0
        self._decision_at: dict[tuple[str, str], float] = {}
        self._cooled = 0
        # مرآة إيقافات 516 — (حساب، رمز) → سبب، وحساب → سبب.
        self._halted_pairs: dict[tuple[str, str], str] = {}
        self._halted_accounts: dict[str, str] = {}
        self._halt_vetoed = 0
        self._approved: int = 0
        self._denied: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._auto_approve = bool(context.config["auto_approve_requests"])
        self._cooldown = float(context.config["request_cooldown_seconds"])
        self._decision_cooldown = float(
            context.config["decision_cooldown_seconds"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_REVIEWED, self._on_reviewed)
        context.subscribe(EVENT_HALT_PAIR, self._on_halt_pair)
        context.subscribe(EVENT_HALT_ACCOUNT, self._on_halt_account)
        context.subscribe(EVENT_HALT_RESET, self._on_halt_reset)
        context.subscribe(REQ_MODEL_SELECTION, self._on_model_selection)
        context.subscribe(REQ_MODEL_RECALIBRATION, self._on_model_recalibration)
        context.subscribe(REQ_FILTERS_UPDATE, self._on_filters_update)
        context.subscribe(REQ_STRATEGY_SELECTION, self._on_strategy_selection)
        context.subscribe(REQ_STRATEGY_SWITCH, self._on_strategy_switch)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._last_approved.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"approved": self._approved, "denied": self._denied},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"last_approved": self._last_approved, "approved": self._approved,
                      "denied": self._denied, "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._last_approved = inner.get("last_approved", {})
        self._approved = inner.get("approved", 0)
        self._denied = inner.get("denied", 0)
        self._dropped = inner.get("dropped", 0)

    async def _on_reviewed(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_REVIEWED)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("مراجعة بلا رمز أو طابع زمني صالح")
            return
        failed = payload.get("failed_checks") or []
        approved = bool(payload.get("approved")) and not failed

        # ── مرآة الإيقاف المتدرّج من 516: كان يُنشَر ولا يُطاع ──
        # الحجب هنا يقطع القرار قبل بنائه أمرًا (551/553) — أرخص نقطة
        # قطع، والحدث المعتمد يخرج approved=False بسببٍ مسمّى فتراه
        # اللوحات والمخازن بدل صمتٍ لا يفسّره أحد.
        if approved:
            acct = str(account_id) if account_id not in (None, "") else None
            if acct is not None:
                if acct in self._halted_accounts:
                    approved = False
                    self._halt_vetoed += 1
                    failed = ["HALTED_ACCOUNT:%s"
                              % self._halted_accounts[acct]]
                elif (acct, str(symbol)) in self._halted_pairs:
                    approved = False
                    self._halt_vetoed += 1
                    failed = ["HALTED_PAIR:%s"
                              % self._halted_pairs[(acct, str(symbol))]]

        # الموافقة تُهدّئ زوجها لحظة. وبلا ذلك يُعتمد الزوج مع كل تكّة:
        # 113 أمرًا متطابقًا على XAUUSD في أربعين ثانية على تشغيل مقيس،
        # بنفس الوقف والهدف، ولا واحد يُلغي الآخر — والإكسبرت ينفّذها
        # كلّها بمال حقيقي.
        #
        # والتهدئة لكل (حساب، رمز): قرار حساب لا يُسكت حسابًا آخر على
        # الرمز نفسه. والرفض لا يُهدَّأ — تكراره لا يكلّف شيئًا، وسببه قد
        # يتغيّر مع التكّة التالية.
        key = (str(account_id), str(symbol))
        if approved:
            last = self._decision_at.get(key)
            if last is not None and timestamp - last < self._decision_cooldown:
                self._cooled += 1
                return
            self._decision_at[key] = timestamp

        self._tally(approved)
        await self._context.publish(
            EVENT_APPROVED,
            {
                "request_id": _new_request_id(),
                "approved": approved,
                "reason": REASON_PASSED if approved else ",".join(sorted(failed)),
                "account_id": account_id,
                "symbol": symbol,
                "direction": payload.get("direction"),
                "timestamp": timestamp,
                **{k: payload[k] for k in ("confidence", "score", "stability")
                   if payload.get(k) is not None},
            },
        )
        self._note(EVENT_APPROVED)

    async def _on_halt_pair(self, payload) -> None:
        acct, sym = payload.get("account_id"), payload.get("symbol")
        if acct in (None, "") or not sym:
            return
        self._halted_pairs[(str(acct), str(sym))] = str(payload.get("reason", ""))

    async def _on_halt_account(self, payload) -> None:
        acct = payload.get("account_id")
        if acct in (None, ""):
            return
        self._halted_accounts[str(acct)] = str(payload.get("reason", ""))

    async def _on_halt_reset(self, payload) -> None:
        # 516 يمسح مفصّلاته عند التصفير — المرآة تُمسح معه.
        self._halted_pairs.clear()
        self._halted_accounts.clear()

    def _judge(self, request_event: str, payload: dict[str, Any]) -> dict[str, Any] | None:
        """سياسة الاعتماد للطلبات: تفعيل + تهدئة لكل نطاق على حدة."""
        if self._context is None:
            return None
        timestamp = _to_float(payload.get("timestamp"))
        if timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("طلب بلا طابع زمني صالح: %s", request_event)
            return None
        last = self._last_approved.get(request_event)
        if not self._auto_approve:
            approved, reason = False, REASON_DISABLED
        elif last is not None and timestamp - last < self._cooldown:
            approved, reason = False, REASON_COOLDOWN
        else:
            approved, reason = True, REASON_APPROVED
            self._last_approved[request_event] = timestamp
        self._tally(approved)
        verdict = {
            "request_id": payload.get("request_id") or _new_request_id(),
            "approved": approved,
            "reason": reason,
            "source_request": request_event,
            "timestamp": timestamp,
        }
        for key in ("strategy", "model_name", "symbol", "filter"):
            if payload.get(key) is not None:
                verdict[key] = payload[key]
        return verdict

    def _tally(self, approved: bool) -> None:
        if approved:
            self._approved += 1
        else:
            self._denied += 1

    async def _on_model_selection(self, payload: dict[str, Any]) -> None:
        verdict = self._judge(REQ_MODEL_SELECTION, payload)
        if verdict is not None and self._context is not None:
            await self._context.publish(APR_MODEL_SELECTION, verdict)
            self._note(APR_MODEL_SELECTION)

    async def _on_model_recalibration(self, payload: dict[str, Any]) -> None:
        verdict = self._judge(REQ_MODEL_RECALIBRATION, payload)
        if verdict is not None and self._context is not None:
            await self._context.publish(APR_MODEL_RECALIBRATION, verdict)
            self._note(APR_MODEL_RECALIBRATION)

    async def _on_filters_update(self, payload: dict[str, Any]) -> None:
        verdict = self._judge(REQ_FILTERS_UPDATE, payload)
        if verdict is not None and self._context is not None:
            await self._context.publish(APR_FILTERS_UPDATE, verdict)
            self._note(APR_FILTERS_UPDATE)

    async def _on_strategy_selection(self, payload: dict[str, Any]) -> None:
        verdict = self._judge(REQ_STRATEGY_SELECTION, payload)
        if verdict is not None and self._context is not None:
            await self._context.publish(APR_STRATEGY_SELECTION, verdict)
            self._note(APR_STRATEGY_SELECTION)

    async def _on_strategy_switch(self, payload: dict[str, Any]) -> None:
        verdict = self._judge(REQ_STRATEGY_SWITCH, payload)
        if verdict is not None and self._context is not None:
            await self._context.publish(APR_STRATEGY_SWITCH, verdict)
            self._note(APR_STRATEGY_SWITCH)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
