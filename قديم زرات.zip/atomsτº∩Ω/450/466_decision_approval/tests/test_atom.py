"""
اختبارات الذرة 466 — اعتماد القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom466"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
APR_FILTERS_UPDATE = _mod.APR_FILTERS_UPDATE
APR_MODEL_RECALIBRATION = _mod.APR_MODEL_RECALIBRATION
APR_MODEL_SELECTION = _mod.APR_MODEL_SELECTION
APR_STRATEGY_SELECTION = _mod.APR_STRATEGY_SELECTION
APR_STRATEGY_SWITCH = _mod.APR_STRATEGY_SWITCH
EVENT_APPROVED = _mod.EVENT_APPROVED
Atom = _mod.Atom

BASE_TS = 1785200000.0


def make_context(auto=True, cooldown=300.0, max_silence=1e12,
                 decision_cooldown=5.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 466
    context.config = {
        "voice_repeat_seconds": 60.0,
        "auto_approve_requests": auto,
        "request_cooldown_seconds": cooldown,
        "max_input_silence_seconds": max_silence,
        # تهدئة القرار: بلا ذلك يُعتمد الزوج مع كل تكّة — 113 أمرًا
        # متطابقًا في أربعين ثانية على تشغيل مقيس.
        "decision_cooldown_seconds": decision_cooldown,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def reviewed(**overrides):
    payload = {"symbol": "NQ", "direction": "BUY", "approved": True,
               "failed_checks": [], "timestamp": BASE_TS}
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle_subscribes_to_review_and_five_requests():
    atom, context = await build_atom()
    assert context.subscribe.call_count == 9
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_approves_clean_review():
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_APPROVED
    assert payload["approved"] is True
    assert payload["reason"] == "ALL_CHECKS_PASSED"
    assert payload["symbol"] == "NQ"
    assert payload["direction"] == "BUY"
    assert payload["timestamp"] == BASE_TS
    assert "request_id" in payload


@pytest.mark.asyncio
async def test_denies_review_with_failed_checks():
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed(approved=False, failed_checks=["liquidity", "timing"]))
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is False
    assert payload["reason"] == "liquidity,timing"
    assert atom._denied == 1


@pytest.mark.asyncio
async def test_malformed_review_is_dropped():
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed(symbol=""))
    await atom._on_reviewed(reviewed(timestamp="غير-رقم"))
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_each_request_gets_its_own_approved_event():
    atom, context = await build_atom(cooldown=0.0)
    handlers = [
        (atom._on_model_selection, APR_MODEL_SELECTION),
        (atom._on_model_recalibration, APR_MODEL_RECALIBRATION),
        (atom._on_filters_update, APR_FILTERS_UPDATE),
        (atom._on_strategy_selection, APR_STRATEGY_SELECTION),
        (atom._on_strategy_switch, APR_STRATEGY_SWITCH),
    ]
    for handler, expected in handlers:
        context.publish.reset_mock()
        await handler({"request_id": "r-1", "timestamp": BASE_TS})
        name, payload = context.publish.await_args.args
        assert name == expected
        assert payload["approved"] is True
        assert payload["request_id"] == "r-1"


@pytest.mark.asyncio
async def test_request_approval_never_emits_decision_approved():
    atom, context = await build_atom()
    await atom._on_strategy_switch({"timestamp": BASE_TS})
    names = [call.args[0] for call in context.publish.await_args_list]
    assert EVENT_APPROVED not in names


@pytest.mark.asyncio
async def test_cooldown_blocks_second_request():
    atom, context = await build_atom(cooldown=100.0)
    await atom._on_model_selection({"timestamp": BASE_TS})
    await atom._on_model_selection({"timestamp": BASE_TS + 1.0})
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is False
    assert payload["reason"] == "COOLDOWN_ACTIVE"


@pytest.mark.asyncio
async def test_cooldown_expires():
    atom, context = await build_atom(cooldown=10.0)
    await atom._on_model_selection({"timestamp": BASE_TS})
    await atom._on_model_selection({"timestamp": BASE_TS + 1000.0})
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is True


@pytest.mark.asyncio
async def test_cooldown_is_per_domain():
    atom, context = await build_atom(cooldown=1000.0)
    await atom._on_model_selection({"timestamp": BASE_TS})
    await atom._on_strategy_switch({"timestamp": BASE_TS})
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is True


@pytest.mark.asyncio
async def test_disabled_denies_every_request():
    atom, context = await build_atom(auto=False)
    await atom._on_filters_update({"timestamp": BASE_TS})
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is False
    assert payload["reason"] == "REQUESTS_DISABLED"
    assert payload["source_request"] == "strategy.filters.update_requested"


@pytest.mark.asyncio
async def test_request_without_timestamp_is_dropped():
    atom, context = await build_atom()
    await atom._on_strategy_selection({"request_id": "r-9"})
    context.publish.assert_not_awaited()
    assert atom._dropped == 1


@pytest.mark.asyncio
async def test_review_silence_degrades():
    atom, _ = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"] == ["decision.reviewed"]


@pytest.mark.asyncio
async def test_handlers_ignored_without_context():
    atom = Atom()
    await atom._on_reviewed(reviewed())
    await atom._on_model_selection({"timestamp": BASE_TS})
    assert atom._approved == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_reviewed(reviewed())
    await atom._on_model_selection({"timestamp": BASE_TS})
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._approved == 2
    assert "model.selection.requested" in restored._last_approved



@pytest.mark.asyncio
async def test_the_verdict_carries_the_identity_of_the_request():
    """Without it a requester cannot tell which of its own requests was
    answered, and 417 would wait forever on a strategy 450 already cleared."""
    atom, context = await build_atom()
    verdict = atom._judge("strategy.switch.requested",
                          {"strategy": 404, "request_id": "r1",
                           "timestamp": BASE_TS})
    assert verdict["strategy"] == 404
    assert verdict["request_id"] == "r1"


@pytest.mark.asyncio
async def test_a_request_without_identity_still_gets_a_verdict():
    atom, context = await build_atom()
    verdict = atom._judge("strategy.switch.requested", {"timestamp": BASE_TS})
    assert "strategy" not in verdict
    assert verdict["approved"] in (True, False)


@pytest.mark.asyncio
async def test_a_model_request_carries_its_model_name():
    atom, context = await build_atom()
    verdict = atom._judge("model.selection.requested",
                          {"model_name": "trend_v2", "timestamp": BASE_TS})
    assert verdict["model_name"] == "trend_v2"


# ── المعرّف مستقلّ لا سلسلة نصّية ────────────────────────────────────

@pytest.mark.asyncio
async def test_the_request_id_is_independent_of_the_context():
    """كان يُبنى من اسم الحدث والرمز والطابع:

        decision.approved:XAUUSD:1785713853.121333

    وقيس على تشغيل حيّ معرّفان بفارق 0.00025 ثانية — ولو تساوى الطابع
    لصارا واحدًا، فيخلط 554 دورتَي حياة و562 يعيد أمر صفقة لأخرى.

    والسياق يسافر حقولًا منفصلة: يُقرأ ويُستعلَم عنه بلا تحليل نصّ."""
    # حسابان مختلفان: التهدئة لكل (حساب، رمز) فلا تمنع الثاني.
    atom, context = await build_atom(decision_cooldown=0.0)
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="A"))
    _, first = context.publish.await_args.args
    context.publish.reset_mock()
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="B"))
    _, second = context.publish.await_args.args

    assert first["request_id"] != second["request_id"]
    assert ":" not in str(first["request_id"])
    assert first["symbol"] == "XAUUSD"
    assert first["account_id"] == "A"
    assert second["account_id"] == "B"


@pytest.mark.asyncio
async def test_the_same_pair_is_not_approved_twice_in_a_breath():
    """قيس على تشغيل حيّ: 113 أمرًا متطابقًا على XAUUSD في أربعين ثانية،
    كلّها بنفس الوقف والهدف، ولا واحد يُلغي الآخر — فينفّذها الإكسبرت
    كلّها بمال حقيقي.

    والتبريد كان للطلبات الإدارية وحدها ولم يمسّ القرار."""
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="A",
                                     timestamp=BASE_TS))
    first = len(_approved_events(context))
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="A",
                                     timestamp=BASE_TS + 0.5))
    assert len(_approved_events(context)) == first


@pytest.mark.asyncio
async def test_a_different_account_is_not_blocked_by_the_cooldown():
    """قرار حساب لا يُسكت حساباً آخر على الرمز نفسه."""
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="A",
                                     timestamp=BASE_TS))
    before = len(_approved_events(context))
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="B",
                                     timestamp=BASE_TS + 0.5))
    assert len(_approved_events(context)) == before + 1


@pytest.mark.asyncio
async def test_the_pair_reopens_after_the_cooldown():
    atom, context = await build_atom()
    await atom._on_reviewed(reviewed(symbol="XAUUSD", account_id="A",
                                     timestamp=BASE_TS))
    before = len(_approved_events(context))
    await atom._on_reviewed(reviewed(
        symbol="XAUUSD", account_id="A",
        timestamp=BASE_TS + atom._decision_cooldown + 1.0))
    assert len(_approved_events(context)) == before + 1


def _approved_events(context):
    return [c.args[1] for c in context.publish.await_args_list
            if c.args[0] == "decision.approved"]


# ─── v2.1.0: مرآة الإيقاف المتدرّج ──────────────────────────────────────

def _published(context, name):
    return [c.args[1] for c in context.publish.call_args_list
            if c.args[0] == name]


@pytest.mark.asyncio
async def test_pair_halt_vetoes_only_its_pair():
    atom, context = await build_atom(decision_cooldown=0.0)
    await atom._on_halt_pair({"account_id": "111", "symbol": "NQ",
                              "reason": "STRATEGY_LIMIT"})
    await atom._on_reviewed(reviewed(account_id="111"))
    await atom._on_reviewed(reviewed(account_id="111", symbol="ES",
                                     timestamp=BASE_TS + 1))
    out = _published(context, "decision.approved")
    assert out[0]["approved"] is False
    assert out[0]["reason"] == "HALTED_PAIR:STRATEGY_LIMIT"
    assert out[1]["approved"] is True
    assert atom._halt_vetoed == 1


@pytest.mark.asyncio
async def test_account_halt_vetoes_every_symbol_until_reset():
    atom, context = await build_atom(decision_cooldown=0.0)
    await atom._on_halt_account({"account_id": "111", "reason": "DAILY_LOSS"})
    await atom._on_reviewed(reviewed(account_id="111"))
    await atom._on_reviewed(reviewed(account_id="111", symbol="ES",
                                     timestamp=BASE_TS + 1))
    out = _published(context, "decision.approved")
    assert [p["approved"] for p in out] == [False, False]
    assert out[0]["reason"] == "HALTED_ACCOUNT:DAILY_LOSS"

    await atom._on_halt_reset({"operator": "test"})
    await atom._on_reviewed(reviewed(account_id="111",
                                     timestamp=BASE_TS + 2))
    assert _published(context, "decision.approved")[-1]["approved"] is True


@pytest.mark.asyncio
async def test_other_account_untouched_by_halt():
    atom, context = await build_atom(decision_cooldown=0.0)
    await atom._on_halt_account({"account_id": "222", "reason": "X"})
    await atom._on_reviewed(reviewed(account_id="111"))
    assert _published(context, "decision.approved")[0]["approved"] is True
