"""
اختبارات الذرة 454 — فلتر القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom454"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_FILTERED = _mod.EVENT_FILTERED
EVENT_REJECTED = _mod.EVENT_REJECTED
BASE_TS = 1734567890.0


def make_context(min_score=0.6, min_confidence=0.7, max_ratio=0.9, min_samples=20, max_silence=60.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 454
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_input_silence_seconds": max_silence,
        "min_score": min_score,
        "min_confidence": min_confidence,
        "max_reject_ratio": max_ratio,
        "min_samples_for_ratio": min_samples,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def scored(**overrides):
    payload = {
        "symbol": "NQ",
        "direction": "BUY",
        "score": 0.8,
        "confidence": 0.9,
        "price": 20000.0,
        "timestamp": BASE_TS,
    }
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_passes_when_above_thresholds():
    atom, context = await build_atom()
    await atom._on_scored(scored())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_FILTERED
    assert payload["direction"] == "BUY"
    assert atom._passed == 1


@pytest.mark.asyncio
async def test_low_confidence_reason():
    atom, context = await build_atom()
    await atom._on_scored(scored(confidence=0.1))
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_REJECTED
    assert payload["reason"] == "RISK_LOW_CONFIDENCE"


@pytest.mark.asyncio
async def test_low_score_reason():
    atom, context = await build_atom()
    await atom._on_scored(scored(score=0.1))
    _name, payload = context.publish.await_args.args
    assert payload["reason"] == "RISK_LOW_SCORE"


@pytest.mark.asyncio
async def test_malformed_numbers_reason():
    atom, context = await build_atom()
    await atom._on_scored(scored(score=None))
    _name, payload = context.publish.await_args.args
    assert payload["reason"] == "RISK_MALFORMED_PAYLOAD"


@pytest.mark.asyncio
async def test_missing_header_is_silently_rejected():
    atom, context = await build_atom()
    await atom._on_scored(scored(symbol=""))
    context.publish.assert_not_awaited()
    assert atom._rejected == 1


@pytest.mark.asyncio
async def test_health_degrades_on_high_reject_ratio():
    atom, _ = await build_atom(max_ratio=0.5, min_samples=2)
    await atom._on_scored(scored(score=0.1))
    await atom._on_scored(scored(score=0.1))
    assert (await atom.health_check()).state == HealthState.DEGRADED


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_scored(scored())
    assert atom._passed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_scored(scored())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._passed == 1


@pytest.mark.asyncio
async def test_declares_input_starvation_without_stopping():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"]
    assert atom._starving is True
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_starvation_declared_once_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    warned = context.logger.warning.call_count
    await atom.health_check()
    assert context.logger.warning.call_count == warned

    atom._max_silence = 3600.0
    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()
