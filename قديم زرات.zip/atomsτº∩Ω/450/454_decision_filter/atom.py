"""
454 — فلتر القرار
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SCORED = "decision.score_calculated"
EVENT_FILTERED = "decision.filtered"
INPUT_LABEL = "decision.score_calculated"
WATCHED_INPUTS = (INPUT_LABEL,)
EVENT_REJECTED = "decision.rejected"

REASON_LOW_CONFIDENCE = "RISK_LOW_CONFIDENCE"
REASON_LOW_SCORE = "RISK_LOW_SCORE"
REASON_MALFORMED = "RISK_MALFORMED_PAYLOAD"

STARVATION_QUORUM = 1   # صمت أي مدخل يكفي لإخراج الصوت
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_FILTERED, EVENT_REJECTED)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """بوابة العتبات: يمرّر القرار أو يرفضه مع سبب صريح."""

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._min_score: float = 0.0
        self._min_confidence: float = 0.0
        self._max_reject_ratio: float = 0.0
        self._min_samples: int = 0
        self._passed: int = 0
        self._rejected: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_score = float(context.config["min_score"])
        self._min_confidence = float(context.config["min_confidence"])
        self._max_reject_ratio = float(context.config["max_reject_ratio"])
        self._min_samples = int(context.config["min_samples_for_ratio"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_SCORED, self._on_scored)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        total = self._passed + self._rejected
        if total >= self._min_samples and self._rejected / total > self._max_reject_ratio:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="نسبة الرفض تجاوزت الحد المسموح",
                details={"passed": self._passed, "rejected": self._rejected},
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"passed": self._passed, "rejected": self._rejected},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"passed": self._passed, "rejected": self._rejected},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._passed = inner.get("passed", 0)
        self._rejected = inner.get("rejected", 0)

    def _verdict(self, payload: dict[str, Any]) -> str | None:
        """يُرجع سبب الرفض، أو None إذا اجتاز القرار كل العتبات."""
        score = _to_float(payload.get("score"))
        confidence = _to_float(payload.get("confidence"))
        if score is None or confidence is None:
            return REASON_MALFORMED
        if confidence < self._min_confidence:
            return REASON_LOW_CONFIDENCE
        if score < self._min_score:
            return REASON_LOW_SCORE
        return None

    async def _on_scored(self, payload: dict[str, Any]) -> None:
        self._note(INPUT_LABEL)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None:
            self._rejected += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("حمولة درجة بلا رمز أو طابع زمني صالح")
            return
        reason = self._verdict(payload)
        if reason is not None:
            self._rejected += 1
            self._note(LABEL_MINE)
            self._context.logger.info("رُفض قرار %s بسبب %s", symbol, reason)
            await self._context.publish(
                EVENT_REJECTED,
                {
                    "account_id": account_id,
                    "symbol": symbol,
                    "reason": reason,
                    "score": payload.get("score"),
                    "confidence": payload.get("confidence"),
                    "timestamp": timestamp,
                },
            )
            return
        passed = dict(payload)
        passed["timestamp"] = timestamp
        await self._context.publish(EVENT_FILTERED, passed)
        self._passed += 1

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
