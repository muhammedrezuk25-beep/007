"""
اختبارات الذرة 462 — فلتر التوقيت
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom462"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_CHECKED = _mod.EVENT_CHECKED
WATCHED_INPUTS = _mod.WATCHED_INPUTS
BASE_TS = 1785200000.0


def make_context(max_age=5.0, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 462
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_decision_age_seconds": max_age,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def tick(official=BASE_TS):
    return {"sys_tick": 7, "official_time": official}


def filtered(**overrides):
    payload = {"symbol": "NQ", "direction": "BUY", "timestamp": BASE_TS}
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle_subscribes_to_decision_and_clock():
    atom, context = await build_atom()
    assert {c.args[0] for c in context.subscribe.call_args_list} == set(WATCHED_INPUTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_passes_fresh_decision():
    atom, context = await build_atom()
    await atom._on_clock(tick(BASE_TS + 1.0))
    await atom._on_filtered(filtered())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_CHECKED
    assert payload["passed"] is True
    assert payload["official_time"] == BASE_TS + 1.0
    assert atom._passed == 1


@pytest.mark.asyncio
async def test_blocks_stale_decision():
    atom, context = await build_atom(max_age=2.0)
    await atom._on_clock(tick(BASE_TS + 60.0))
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is False
    assert payload["reasons"] == ["DECISION_STALE"]


@pytest.mark.asyncio
async def test_blocks_when_clock_never_arrived():
    atom, context = await build_atom()
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["reasons"] == ["CLOCK_UNAVAILABLE"]
    assert atom._blocked == 1


@pytest.mark.asyncio
async def test_malformed_clock_is_ignored():
    atom, _ = await build_atom()
    await atom._on_clock({"sys_tick": 1, "official_time": "غير-رقم"})
    assert atom._official_time is None


@pytest.mark.asyncio
async def test_missing_header_is_dropped():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(symbol=""))
    await atom._on_filtered(filtered(timestamp=None))
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_clock_silence_alone_degrades():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert set(health.details["missing_inputs"]) == set(WATCHED_INPUTS)

    await atom._on_clock(tick())
    await atom._on_filtered(filtered())
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_filtered(filtered())
    assert atom._passed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_clock(tick())
    await atom._on_filtered(filtered())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._passed == 1
