"""
450 — سجل أرشيف ومراقبة القسم
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SIGNALS_COLLECTED = "decision.signals_collected"
EVENT_SIGNALS_EVALUATED = "decision.signals_evaluated"
EVENT_SCORE_CALCULATED = "decision.score_calculated"
EVENT_FILTERED = "decision.filtered"
EVENT_REJECTED = "decision.rejected"
EVENT_BUY_ISSUED = "decision.buy_issued"
EVENT_SELL_ISSUED = "decision.sell_issued"
EVENT_WAIT_ISSUED = "decision.wait_issued"
EVENT_CONFLICT_RESOLVED = "decision.conflict_resolved"
EVENT_PRIORITY_ORDERED = "decision.priority_ordered"
EVENT_CONFIDENCE_CHECKED = "decision.confidence_checked"
EVENT_CONDITIONS_CHECKED = "decision.conditions_checked"
EVENT_TIMING_CHECKED = "decision.timing_checked"
EVENT_EVENTS_CHECKED = "decision.events_checked"
EVENT_LIQUIDITY_CHECKED = "decision.liquidity_checked"
EVENT_REVIEWED = "decision.reviewed"
EVENT_APPROVED = "decision.approved"
EVENT_MODEL_SELECTION_APPROVED = "model.selection.approved"
EVENT_MODEL_RECALIB_APPROVED = "model.recalibration.approved"
EVENT_FILTERS_UPDATE_APPROVED = "strategy.filters.update_approved"
EVENT_STRATEGY_SELECTION_APPROVED = "strategy.selection.approved"
EVENT_STRATEGY_SWITCH_APPROVED = "strategy.switch.approved"
EVENT_ORDER_REQUESTED = "execution.order.requested"

WATCHED_EVENTS = (
    EVENT_SIGNALS_COLLECTED,
    EVENT_SIGNALS_EVALUATED,
    EVENT_SCORE_CALCULATED,
    EVENT_FILTERED,
    EVENT_REJECTED,
    EVENT_BUY_ISSUED,
    EVENT_SELL_ISSUED,
    EVENT_WAIT_ISSUED,
    EVENT_CONFLICT_RESOLVED,
    EVENT_PRIORITY_ORDERED,
    EVENT_CONFIDENCE_CHECKED,
    EVENT_CONDITIONS_CHECKED,
    EVENT_TIMING_CHECKED,
    EVENT_EVENTS_CHECKED,
    EVENT_LIQUIDITY_CHECKED,
    EVENT_REVIEWED,
    EVENT_APPROVED,
    EVENT_MODEL_SELECTION_APPROVED,
    EVENT_MODEL_RECALIB_APPROVED,
    EVENT_FILTERS_UPDATE_APPROVED,
    EVENT_STRATEGY_SELECTION_APPROVED,
    EVENT_STRATEGY_SWITCH_APPROVED,
    EVENT_ORDER_REQUESTED,
)

INPUT_LABEL = "decision.chain"
WATCHED_INPUTS = (INPUT_LABEL,)

STARVATION_QUORUM = len(WATCHED_INPUTS)
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = ()

class Atom(AtomBase):
    """سجل أرشيف ومراقبة لمسار القرار — صامت بالكامل.

    القاعدة 1 بصيغتها القصوى: لا ينشر أي حدث إطلاقاً (`publishes: []`)، ولا
    يدخل سلسلة القرار، ولا يفاضل ولا يرجّح. يراقب ويؤرشف ويصرّح عن حاله فقط.
    مخرجه الوحيد هو اللقطة (تحفظها النواة) والحالة الصحية.

    يغطي مخرجات القسم كاملة (23 حدثاً) — الذرة الوحيدة التي ترى الصورة كلها.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._archive: dict[str, list[dict[str, Any]]] = {}
        self._counters: dict[str, int] = {}
        self._archive_size: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._archive_size = int(context.config["archive_size_per_event"])
        self._max_silence = float(context.config["max_chain_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_SIGNALS_COLLECTED, self._on_signals_collected)
        context.subscribe(EVENT_SIGNALS_EVALUATED, self._on_signals_evaluated)
        context.subscribe(EVENT_SCORE_CALCULATED, self._on_score_calculated)
        context.subscribe(EVENT_FILTERED, self._on_filtered)
        context.subscribe(EVENT_REJECTED, self._on_rejected)
        context.subscribe(EVENT_BUY_ISSUED, self._on_buy_issued)
        context.subscribe(EVENT_SELL_ISSUED, self._on_sell_issued)
        context.subscribe(EVENT_WAIT_ISSUED, self._on_wait_issued)
        context.subscribe(EVENT_CONFLICT_RESOLVED, self._on_conflict_resolved)
        context.subscribe(EVENT_PRIORITY_ORDERED, self._on_priority_ordered)
        context.subscribe(EVENT_CONFIDENCE_CHECKED, self._on_confidence_checked)
        context.subscribe(EVENT_CONDITIONS_CHECKED, self._on_conditions_checked)
        context.subscribe(EVENT_TIMING_CHECKED, self._on_timing_checked)
        context.subscribe(EVENT_EVENTS_CHECKED, self._on_events_checked)
        context.subscribe(EVENT_LIQUIDITY_CHECKED, self._on_liquidity_checked)
        context.subscribe(EVENT_REVIEWED, self._on_reviewed)
        context.subscribe(EVENT_APPROVED, self._on_approved)
        context.subscribe(EVENT_MODEL_SELECTION_APPROVED, self._on_model_selection_approved)
        context.subscribe(EVENT_MODEL_RECALIB_APPROVED, self._on_model_recalib_approved)
        context.subscribe(EVENT_FILTERS_UPDATE_APPROVED, self._on_filters_update_approved)
        context.subscribe(EVENT_STRATEGY_SELECTION_APPROVED, self._on_strategy_selection_approved)
        context.subscribe(EVENT_STRATEGY_SWITCH_APPROVED, self._on_strategy_switch_approved)
        context.subscribe(EVENT_ORDER_REQUESTED, self._on_order_requested)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._archive.clear()
        self._counters.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="مسار القرار متحرك ومؤرشف",
            details={"counters": dict(self._counters), "tracked_events": len(self._archive)},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"archive": self._archive, "counters": self._counters},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._archive = inner.get("archive", {})
        self._counters = inner.get("counters", {})

    def _record(self, event_name: str, payload: dict[str, Any]) -> None:
        """يؤرشف الحمولة كما وصلت، ضمن حلقة محدودة الطول لكل حدث."""
        self._note(INPUT_LABEL)
        self._counters[event_name] = self._counters.get(event_name, 0) + 1
        entries = self._archive.setdefault(event_name, [])
        entries.append(dict(payload))
        del entries[: -self._archive_size]

    async def _on_signals_collected(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_SIGNALS_COLLECTED, payload)

    async def _on_signals_evaluated(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_SIGNALS_EVALUATED, payload)

    async def _on_score_calculated(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_SCORE_CALCULATED, payload)

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_FILTERED, payload)

    async def _on_rejected(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_REJECTED, payload)

    async def _on_buy_issued(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_BUY_ISSUED, payload)

    async def _on_sell_issued(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_SELL_ISSUED, payload)

    async def _on_wait_issued(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_WAIT_ISSUED, payload)

    async def _on_conflict_resolved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_CONFLICT_RESOLVED, payload)

    async def _on_priority_ordered(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_PRIORITY_ORDERED, payload)

    async def _on_confidence_checked(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_CONFIDENCE_CHECKED, payload)

    async def _on_conditions_checked(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_CONDITIONS_CHECKED, payload)

    async def _on_timing_checked(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_TIMING_CHECKED, payload)

    async def _on_events_checked(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_EVENTS_CHECKED, payload)

    async def _on_liquidity_checked(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_LIQUIDITY_CHECKED, payload)

    async def _on_reviewed(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_REVIEWED, payload)

    async def _on_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_APPROVED, payload)

    async def _on_model_selection_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_MODEL_SELECTION_APPROVED, payload)

    async def _on_model_recalib_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_MODEL_RECALIB_APPROVED, payload)

    async def _on_filters_update_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_FILTERS_UPDATE_APPROVED, payload)

    async def _on_strategy_selection_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_STRATEGY_SELECTION_APPROVED, payload)

    async def _on_strategy_switch_approved(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_STRATEGY_SWITCH_APPROVED, payload)

    async def _on_order_requested(self, payload: dict[str, Any]) -> None:
        self._record(EVENT_ORDER_REQUESTED, payload)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
