"""
اختبارات الذرة 450 — سجل أرشيف ومراقبة القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom450"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
WATCHED_EVENTS = _mod.WATCHED_EVENTS
BASE_TS = 1734567890.0


def make_context(archive_size=3, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 450
    context.config = {
        "voice_repeat_seconds": 60.0,
        "archive_size_per_event": archive_size,
        "max_chain_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


@pytest.mark.asyncio
async def test_lifecycle_subscribes_to_whole_chain():
    atom, context = await build_atom()
    assert context.subscribe.call_count == len(WATCHED_EVENTS)
    subscribed = {call.args[0] for call in context.subscribe.call_args_list}
    assert subscribed == set(WATCHED_EVENTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._archive == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_never_publishes_anything():
    atom, context = await build_atom()
    await atom._on_signals_collected({"symbol": "NQ", "timestamp": BASE_TS})
    await atom._on_score_calculated({"symbol": "NQ", "score": 0.9, "timestamp": BASE_TS})
    await atom._on_buy_issued({"symbol": "NQ", "price": 1.0, "timestamp": BASE_TS})
    context.publish.assert_not_awaited()


@pytest.mark.asyncio
async def test_archives_every_chain_event():
    atom, _ = await build_atom()
    handlers = [
        atom._on_signals_collected,
        atom._on_signals_evaluated,
        atom._on_score_calculated,
        atom._on_filtered,
        atom._on_rejected,
        atom._on_buy_issued,
        atom._on_sell_issued,
        atom._on_wait_issued,
        atom._on_conflict_resolved,
        atom._on_priority_ordered,
        atom._on_confidence_checked,
        atom._on_conditions_checked,
        atom._on_timing_checked,
        atom._on_events_checked,
        atom._on_liquidity_checked,
        atom._on_reviewed,
        atom._on_approved,
        atom._on_model_selection_approved,
        atom._on_model_recalib_approved,
        atom._on_filters_update_approved,
        atom._on_strategy_selection_approved,
        atom._on_strategy_switch_approved,
        atom._on_order_requested,
    ]
    for handler in handlers:
        await handler({"symbol": "NQ", "timestamp": BASE_TS})
    assert set(atom._archive) == set(WATCHED_EVENTS)
    assert sum(atom._counters.values()) == len(WATCHED_EVENTS)


@pytest.mark.asyncio
async def test_ring_buffer_is_bounded():
    atom, _ = await build_atom(archive_size=3)
    for index in range(10):
        await atom._on_filtered({"symbol": "NQ", "score": index, "timestamp": BASE_TS})
    entries = atom._archive["decision.filtered"]
    assert len(entries) == 3
    assert [entry["score"] for entry in entries] == [7, 8, 9]
    assert atom._counters["decision.filtered"] == 10


@pytest.mark.asyncio
async def test_archive_is_an_independent_copy():
    atom, _ = await build_atom()
    payload = {"symbol": "NQ", "timestamp": BASE_TS}
    await atom._on_filtered(payload)
    payload["symbol"] = "ES"
    assert atom._archive["decision.filtered"][0]["symbol"] == "NQ"


@pytest.mark.asyncio
async def test_declares_chain_silence_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert atom._starving is True
    context.logger.warning.assert_called_once()

    await atom.health_check()
    context.logger.warning.assert_called_once()

    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()


@pytest.mark.asyncio
async def test_malformed_timestamp_still_archived():
    atom, _ = await build_atom()
    await atom._on_rejected({"symbol": "NQ", "timestamp": "غير-رقم"})
    assert atom._counters["decision.rejected"] == 1
    assert atom._arrivals["decision.chain"] == 1


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_wait_issued({"symbol": "NQ", "timestamp": BASE_TS})
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._counters["decision.wait_issued"] == 1
    assert restored._archive["decision.wait_issued"][0]["symbol"] == "NQ"
