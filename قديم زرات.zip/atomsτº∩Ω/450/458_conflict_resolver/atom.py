"""
458 — حل التعارض
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_TREND = "strategy.trend.signal"
EVENT_REVERSAL = "strategy.reversal.signal"
EVENT_BREAKOUT = "strategy.breakout.signal"
EVENT_PULLBACK = "strategy.pullback.signal"
EVENT_MOMENTUM = "strategy.momentum.signal"
EVENT_RANGE = "strategy.range.signal"
EVENT_LIQUIDITY = "strategy.liquidity.signal"
EVENT_NEWS = "strategy.news.signal"
EVENT_SESSION = "strategy.session.signal"
EVENT_RESOLVED = "decision.conflict_resolved"

STRATEGY_EVENTS = (
    EVENT_TREND, EVENT_REVERSAL, EVENT_BREAKOUT, EVENT_PULLBACK, EVENT_MOMENTUM,
    EVENT_RANGE, EVENT_LIQUIDITY, EVENT_NEWS, EVENT_SESSION,
)
WATCHED_INPUTS = STRATEGY_EVENTS

DIRECTION_BUY = "BUY"
DIRECTION_SELL = "SELL"
DIRECTION_NEUTRAL = "NEUTRAL"

STARVATION_QUORUM = 1   # صمت أي مدخل يكفي لإخراج الصوت
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_RESOLVED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يكشف تعارض إشارات الاستراتيجيات المتزامنة (BUY و SELL معاً) ويحسمه.

    يقرأ مخرجات 404-412 مباشرة — وهي مخرجات استراتيجيات، لا بيانات سوق ولا
    تحليل ولا سيولة، فقاعدة القسم محفوظة. ينشر فقط عند وجود تعارض فعلي.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._latest: dict[str, dict[str, dict[str, Any]]] = {}
        self._window: float = 0.0
        # عدّادا التقدّم: كم إشارة دخلت بوزن مقيس، وكم بصوت فقط. النسبة
        # بينهما هي مقياس اكتمال المرحلة الثانية — كلما كسبت استراتيجية
        # قوّتها بمصدرها انتقل عدّادها من الثاني إلى الأول.
        self._weighted_signals: int = 0
        self._unweighted_signals: int = 0
        self._unweighted_sources: set[str] = set()
        self._tie_epsilon: float = 0.0
        self._resolved: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = float(context.config["conflict_window_seconds"])
        self._tie_epsilon = float(context.config["tie_epsilon"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_TREND, self._on_trend)
        context.subscribe(EVENT_REVERSAL, self._on_reversal)
        context.subscribe(EVENT_BREAKOUT, self._on_breakout)
        context.subscribe(EVENT_PULLBACK, self._on_pullback)
        context.subscribe(EVENT_MOMENTUM, self._on_momentum)
        context.subscribe(EVENT_RANGE, self._on_range)
        context.subscribe(EVENT_LIQUIDITY, self._on_liquidity)
        context.subscribe(EVENT_NEWS, self._on_news)
        context.subscribe(EVENT_SESSION, self._on_session)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._latest.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="حُسم %d · موزون %d · بلا وزن %d" % (
                self._resolved, self._weighted_signals, self._unweighted_signals),
            # نسبة الموزون إلى غير الموزون هي مقياس تقدّم المرحلة الثانية:
            # كلما كسبت استراتيجية قوّتها بمصدرها، انتقل عدّادها إلى الموزون.
            details={"resolved": self._resolved, "dropped": self._dropped,
                     "weighted_signals": self._weighted_signals,
                     "unweighted_signals": self._unweighted_signals,
                     "pending_strength": sorted(self._unweighted_sources)},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"latest": {"%s|%s" % k: v for k, v in self._latest.items()},
                      "resolved": self._resolved, "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._latest = {tuple(k.split("|", 1)): v
                        for k, v in (inner.get("latest") or {}).items()}
        self._resolved = inner.get("resolved", 0)
        self._dropped = inner.get("dropped", 0)

    async def _ingest(self, source: str, payload: dict[str, Any]) -> None:
        self._note(source)
        if self._context is None:
            return
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        # direction هو الحقل القانوني في العقد الموحّد؛ signal يبقى مقبولًا
        # لمن لم يُحدَّث بعد. وsignal في 452 له الاحتياط نفسه.
        direction = payload.get("direction") or payload.get("signal")
        strength = _to_float(payload.get("strength"))
        timestamp = _to_float(payload.get("timestamp"))

        # الإلزامي: رمز واتجاه وطابع. غيابها خللٌ في العقد، لا نقص بيانات.
        if not symbol or timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning(
                "إشارة بلا رمز أو طابع زمني من %s — العقد يفرضهما", source)
            return

        if direction not in (DIRECTION_BUY, DIRECTION_SELL):
            return   # سياقية لا اتجاهية: REVERSAL_WATCH و RANGE والجاهزية

        # strength اختيارية في هذه المرحلة. خمس استراتيجيات لا تملك بعد ما
        # تُحسب منه: 406 و407 ينتظران level من 204 و254، و409 ينتظر حدّي
        # النطاق، و404 و405 يحتاجان حالة عبر الزمن.
        #
        # فلا تُسقَط إشارتها ولا يُخترع لها وزن. تُحفظ بلا وزن، وتُعدّ على
        # حدة — فيظهر تقدّم المشروع رقمًا لا تخمينًا.
        weighted = strength is not None
        if weighted:
            self._weighted_signals += 1
        else:
            self._unweighted_signals += 1
            self._unweighted_sources.add(source)

        if account_id in (None, ""):
            self._dropped += 1
            return
        key = (str(account_id), str(symbol))
        self._latest.setdefault(key, {})[source] = {
            "direction": direction, "strength": strength,
            "weighted": weighted, "timestamp": timestamp,
        }
        await self._resolve(key, timestamp)

    async def _resolve(self, key: tuple[str, str], now_ts: float) -> None:
        """يحسم التعارض بمجموع القوى؛ التعادل ضمن هامش يعني NEUTRAL.

        المفتاح زوج: إشارتان لرمز واحد من حسابين تُحسمان معًا تعطيان
        اتجاهًا لا يخصّ أيًّا منهما.
        """
        if self._context is None:
            return
        account_id, symbol = key
        fresh = {
            source: entry for source, entry in self._latest[key].items()
            if now_ts - entry["timestamp"] <= self._window
        }
        self._latest[key] = fresh
        sides = {entry["direction"] for entry in fresh.values()}
        if not (DIRECTION_BUY in sides and DIRECTION_SELL in sides):
            return
        self._note(LABEL_MINE)
        # مجموعتان منفصلتان: الموزونة تُجمع بأوزانها، وغير الموزونة تُعدّ
        # عددًا. خلطهما بإعطاء وزن افتراضي يحوّل الترجيح إلى عدّ أصوات
        # ويخفي أن نصف المصادر بلا قياس.
        weighted_entries = [e for e in fresh.values() if e["weighted"]]
        plain_entries = [e for e in fresh.values() if not e["weighted"]]

        buy = sum(e["strength"] for e in weighted_entries if e["direction"] == DIRECTION_BUY)
        sell = sum(e["strength"] for e in weighted_entries if e["direction"] == DIRECTION_SELL)
        buy_votes = sum(1 for e in plain_entries if e["direction"] == DIRECTION_BUY)
        sell_votes = sum(1 for e in plain_entries if e["direction"] == DIRECTION_SELL)

        # الوزن يحسم أولًا. لا يُلجأ إلى العدّ إلا حين لا وزن أصلًا على
        # الجانبين — وإلا لغلب صوتٌ بلا قياس وزنًا مقيسًا.
        if abs(buy - sell) <= self._tie_epsilon and (buy or sell) == 0:
            if buy_votes != sell_votes:
                resolved = DIRECTION_BUY if buy_votes > sell_votes else DIRECTION_SELL
            else:
                resolved = DIRECTION_NEUTRAL
        elif abs(buy - sell) <= self._tie_epsilon:
            # الوزن تعادل ضمن الهامش: لم يعد هناك وزن مقيس ليُغلَب، فالعدّ
            # يكسر التعادل بدل إهدار أصوات صريحة. كان القرار NEUTRAL دائمًا:
            # خمس استراتيجيات تصوّت BUY بلا وزن كانت تُرمى لأن 0.80 مقابل
            # 0.82 تعادلا ضمن الهامش — وعلى إطار الدقيقة يتكرّر هذا كثيرًا.
            if buy_votes != sell_votes:
                resolved = DIRECTION_BUY if buy_votes > sell_votes else DIRECTION_SELL
            else:
                resolved = DIRECTION_NEUTRAL
        else:
            resolved = DIRECTION_BUY if buy > sell else DIRECTION_SELL
        await self._context.publish(
            EVENT_RESOLVED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "direction": resolved,
                "buy_strength": buy,
                "sell_strength": sell,
                # الأرقام التي تُري تقدّم المشروع: كم مصدرًا دخل بوزن حقيقي
                # وكم دخل بصوت فقط، ومن هم.
                "buy_votes_unweighted": buy_votes,
                "sell_votes_unweighted": sell_votes,
                "weighted_sources": sorted(
                    s for s, e in fresh.items() if e["weighted"]),
                "unweighted_sources": sorted(
                    s for s, e in fresh.items() if not e["weighted"]),
                "conflicting_sources": sorted(fresh),
                "timestamp": now_ts,
            },
        )
        self._note(EVENT_RESOLVED)
        self._resolved += 1

    async def _on_trend(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_TREND, payload)

    async def _on_reversal(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_REVERSAL, payload)

    async def _on_breakout(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_BREAKOUT, payload)

    async def _on_pullback(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_PULLBACK, payload)

    async def _on_momentum(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_MOMENTUM, payload)

    async def _on_range(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_RANGE, payload)

    async def _on_liquidity(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_LIQUIDITY, payload)

    async def _on_news(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_NEWS, payload)

    async def _on_session(self, payload: dict[str, Any]) -> None:
        await self._ingest(EVENT_SESSION, payload)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
