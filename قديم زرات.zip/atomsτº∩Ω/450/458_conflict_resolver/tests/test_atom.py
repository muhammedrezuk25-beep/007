"""
اختبارات الذرة 458 — حل التعارض
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom458"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_RESOLVED = _mod.EVENT_RESOLVED
STRATEGY_EVENTS = _mod.STRATEGY_EVENTS
BASE_TS = 1785200000.0


def make_context(window=3.0, epsilon=0.05, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 458
    context.config = {
        "voice_repeat_seconds": 60.0,
        "conflict_window_seconds": window,
        "tie_epsilon": epsilon,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def signal(direction, strength, ts=BASE_TS, symbol="NQ", account_id="A"):
    # 413 يفنّي على الحسابات النشطة، فتصل الإشارة بهويّة حسابها. وحسمُ
    # إشارتين من حسابين معًا يعطي اتجاهًا لا يخصّ أيًّا منهما.
    return {"account_id": account_id, "symbol": symbol, "direction": direction,
            "strength": strength, "timestamp": ts}


@pytest.mark.asyncio
async def test_lifecycle_subscribes_to_nine_strategies():
    atom, context = await build_atom()
    assert context.subscribe.call_count == len(STRATEGY_EVENTS)
    assert {c.args[0] for c in context.subscribe.call_args_list} == set(STRATEGY_EVENTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._latest == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_silent_when_no_conflict():
    atom, context = await build_atom()
    await atom._on_trend(signal("BUY", 0.8))
    await atom._on_momentum(signal("BUY", 0.6))
    context.publish.assert_not_awaited()
    assert atom._resolved == 0


@pytest.mark.asyncio
async def test_resolves_conflict_by_total_strength():
    atom, context = await build_atom()
    await atom._on_trend(signal("BUY", 0.9))
    await atom._on_momentum(signal("BUY", 0.5))
    await atom._on_reversal(signal("SELL", 0.7))

    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_RESOLVED
    assert payload["direction"] == "BUY"
    assert payload["buy_strength"] == pytest.approx(1.4)
    assert payload["sell_strength"] == pytest.approx(0.7)
    assert payload["conflicting_sources"] == [
        "strategy.momentum.signal", "strategy.reversal.signal", "strategy.trend.signal"]
    assert payload["timestamp"] == BASE_TS


@pytest.mark.asyncio
async def test_sell_wins_when_stronger():
    atom, context = await build_atom()
    await atom._on_trend(signal("BUY", 0.2))
    await atom._on_reversal(signal("SELL", 0.9))
    _name, payload = context.publish.await_args.args
    assert payload["direction"] == "SELL"


@pytest.mark.asyncio
async def test_tie_within_epsilon_is_neutral():
    atom, context = await build_atom(epsilon=0.1)
    await atom._on_trend(signal("BUY", 0.50))
    await atom._on_reversal(signal("SELL", 0.55))
    _name, payload = context.publish.await_args.args
    assert payload["direction"] == "NEUTRAL"


@pytest.mark.asyncio
async def test_stale_signal_leaves_the_window():
    atom, context = await build_atom(window=1.0)
    await atom._on_trend(signal("BUY", 0.9, ts=BASE_TS))
    await atom._on_reversal(signal("SELL", 0.9, ts=BASE_TS + 10.0))
    context.publish.assert_not_awaited()
    assert "strategy.trend.signal" not in atom._latest[("A", "NQ")]


@pytest.mark.asyncio
async def test_neutral_direction_is_ignored():
    atom, context = await build_atom()
    await atom._on_session(signal("NEUTRAL", 0.9))
    await atom._on_trend(signal("BUY", 0.9))
    context.publish.assert_not_awaited()


@pytest.mark.asyncio
async def test_malformed_signal_is_dropped():
    """الإلزامي فقط يُسقط الإشارة: رمز وطابع زمني.

    كان غياب strength يُسقطها أيضًا — فتضيع سبع استراتيجيات من ثمانٍ.
    صارت اختيارية: الإشارة تُحفظ بلا وزن وتُعدّ على حدة.
    """
    atom, context = await build_atom()
    await atom._on_news({"direction": "BUY", "strength": 0.5, "timestamp": BASE_TS})
    context.publish.assert_not_awaited()
    assert atom._dropped == 1          # بلا رمز

    await atom._on_range(signal("SELL", None))
    assert atom._dropped == 1          # بلا وزن — لم تُسقَط
    assert atom._unweighted_signals == 1


@pytest.mark.asyncio
async def test_symbols_are_isolated():
    atom, context = await build_atom()
    await atom._on_trend(signal("BUY", 0.9, symbol="NQ"))
    await atom._on_reversal(signal("SELL", 0.9, symbol="ES"))
    context.publish.assert_not_awaited()


@pytest.mark.asyncio
async def test_starvation_needs_all_nine_silent():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert len(health.details["missing_inputs"]) == len(STRATEGY_EVENTS)

    await atom._on_trend(signal("BUY", 0.5))
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False


@pytest.mark.asyncio
async def test_ingest_ignored_without_context():
    atom = Atom()
    await atom._on_trend(signal("BUY", 0.5))
    assert atom._resolved == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_trend(signal("BUY", 0.9))
    await atom._on_reversal(signal("SELL", 0.5))
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._resolved == 1
    assert ("A", "NQ") in restored._latest


# ═══ العقد الموحّد للاستراتيجيات — المرحلة الأولى ═══

@pytest.mark.asyncio
async def test_signal_without_strength_is_kept_not_dropped():
    """السبب المباشر لهذا التعديل.

    كل الاستراتيجيات الثماني كانت تنشر signal بلا direction ولا strength
    ولا timestamp، فيُسقطها 458 جميعًا ويسجّل "إشارة ناقصة" بلا أن يُحسم
    شيء. الآن: الإلزامي رمز واتجاه وطابع، وstrength اختيارية.
    """
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.trend.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "timestamp": 100.0})
    assert atom._unweighted_signals == 1
    assert atom._dropped == 0


@pytest.mark.asyncio
async def test_missing_symbol_or_timestamp_is_still_refused():
    """الإلزامي يبقى إلزاميًا: غيابه خللٌ في العقد لا نقص بيانات."""
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.trend.signal"]({"direction": "BUY", "timestamp": 100.0})
    await handlers["strategy.trend.signal"]({"account_id": "A", "symbol": "NQ", "direction": "BUY"})
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_weight_decides_over_unweighted_votes():
    """الوزن المقيس يسبق الصوت بلا قياس: صوتان بلا وزن لا يغلبان وزنًا
    حقيقيًا، وإلا صار الترجيح عدّ أصوات وأُخفي أن نصف المصادر بلا قياس."""
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.liquidity.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "strength": 0.9, "timestamp": 100.0})
    await handlers["strategy.trend.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "SELL", "timestamp": 100.0})
    await handlers["strategy.breakout.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "SELL", "timestamp": 100.0})
    resolved = [c.args[1] for c in context.publish.await_args_list
                if c.args[0] == EVENT_RESOLVED]
    assert resolved[-1]["direction"] == "BUY"
    assert resolved[-1]["sell_votes_unweighted"] == 2


@pytest.mark.asyncio
async def test_votes_decide_only_when_no_side_has_weight():
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.trend.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "timestamp": 100.0})
    await handlers["strategy.breakout.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "timestamp": 100.0})
    await handlers["strategy.pullback.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "SELL", "timestamp": 100.0})
    resolved = [c.args[1] for c in context.publish.await_args_list
                if c.args[0] == EVENT_RESOLVED]
    assert resolved[-1]["direction"] == "BUY"


@pytest.mark.asyncio
async def test_payload_names_who_is_weighted_and_who_is_not():
    """رقم يُري تقدّم المرحلة الثانية بدل تخمينه."""
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.momentum.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "strength": 0.6, "timestamp": 100.0})
    await handlers["strategy.trend.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "SELL", "timestamp": 100.0})
    resolved = [c.args[1] for c in context.publish.await_args_list
                if c.args[0] == EVENT_RESOLVED]
    assert resolved[-1]["weighted_sources"] == ["strategy.momentum.signal"]
    assert resolved[-1]["unweighted_sources"] == ["strategy.trend.signal"]


@pytest.mark.asyncio
async def test_health_reports_the_weighted_ratio():
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.momentum.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "BUY", "strength": 0.6, "timestamp": 100.0})
    await handlers["strategy.trend.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "SELL", "timestamp": 100.0})
    details = (await atom.health_check()).details or {}
    assert details["weighted_signals"] == 1
    assert details["unweighted_signals"] == 1
    assert "strategy.trend.signal" in details["pending_strength"]


@pytest.mark.asyncio
async def test_contextual_signals_do_not_enter_arbitration():
    """REVERSAL_WATCH و RANGE والجاهزية ليست اتجاهات، فلا تُعدّ أصواتًا."""
    atom, context = await build_atom()
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["strategy.reversal.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "REVERSAL_WATCH", "timestamp": 100.0})
    await handlers["strategy.range.signal"](
        {"account_id": "A", "symbol": "NQ", "direction": "RANGE", "timestamp": 100.0})
    assert atom._weighted_signals == 0
    assert atom._unweighted_signals == 0
    assert atom._dropped == 0
