"""
464 — فلتر السيولة
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_FILTERED = "decision.filtered"
EVENT_LIQUIDITY = "strategy.liquidity.signal"
EVENT_CHECKED = "decision.liquidity_checked"

WATCHED_INPUTS = (EVENT_FILTERED, EVENT_LIQUIDITY)

CHECK_NAME = "liquidity"

REASON_INSUFFICIENT = "LIQUIDITY_INSUFFICIENT"
REASON_UNAVAILABLE = "LIQUIDITY_SOURCE_UNAVAILABLE"

STARVATION_QUORUM = 1   # السيولة تدفّق مستمر — صمتها وحده يكفي للتصريح
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_CHECKED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يتحقق من توفر سيولة كافية قبل السماح بالقرار.

    يقرأ `strategy.liquidity.signal` (410) لا `market.liquidity.updated` (260) —
    مخرج استراتيجية لا بيانات سيولة خام، فقاعدة القسم محفوظة.

    **يمنع افتراضياً (Fail-Closed) عمداً**: خلافاً للأخبار، تدفّق السيولة
    مستمر من 410، فصمته يعني تعطّل المصدر لا "لا سيولة". التداول بلا معرفة
    السيولة خطر مالي مباشر، فالغياب يُعامَل منعاً لا تمريراً.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._liquidity: dict[str, dict[str, float]] = {}
        self._min_strength: float = 0.0
        self._source_max_age: float = 0.0
        self._require_source: bool = True
        self._passed: int = 0
        self._blocked: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_strength = float(context.config["min_liquidity_strength"])
        self._source_max_age = float(context.config["source_max_age_seconds"])
        self._require_source = bool(context.config["require_liquidity_source"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_FILTERED, self._on_filtered)
        context.subscribe(EVENT_LIQUIDITY, self._on_liquidity)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._liquidity.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"passed": self._passed, "blocked": self._blocked},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"liquidity": self._liquidity, "passed": self._passed,
                      "blocked": self._blocked, "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._liquidity = inner.get("liquidity", {})
        self._passed = inner.get("passed", 0)
        self._blocked = inner.get("blocked", 0)
        self._dropped = inner.get("dropped", 0)

    async def _on_liquidity(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_LIQUIDITY)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        strength = _to_float(payload.get("strength"))
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or strength is None or timestamp is None:
            return
        self._liquidity[symbol] = {"strength": strength, "timestamp": timestamp}

    def _evaluate(self, symbol: str, timestamp: float) -> list[str]:
        latest = self._liquidity.get(symbol)
        stale = latest is not None and timestamp - latest["timestamp"] > self._source_max_age
        if latest is None or stale:
            return [REASON_UNAVAILABLE] if self._require_source else []
        if latest["strength"] < self._min_strength:
            return [REASON_INSUFFICIENT]
        return []

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_FILTERED)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("قرار بلا رمز أو طابع زمني صالح")
            return
        reasons = self._evaluate(symbol, timestamp)
        passed = not reasons
        if passed:
            self._passed += 1
        else:
            self._blocked += 1
        await self._context.publish(
            EVENT_CHECKED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "check": CHECK_NAME,
                "passed": passed,
                "reasons": reasons,
                "direction": payload.get("direction"),
                "timestamp": timestamp,
            },
        )
        self._note(EVENT_CHECKED)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
