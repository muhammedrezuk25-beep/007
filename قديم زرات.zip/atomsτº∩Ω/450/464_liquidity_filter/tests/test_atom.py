"""
اختبارات الذرة 464 — فلتر السيولة
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom464"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_CHECKED = _mod.EVENT_CHECKED
WATCHED_INPUTS = _mod.WATCHED_INPUTS
BASE_TS = 1785200000.0


def make_context(min_strength=0.4, source_age=30.0, require=True, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 464
    context.config = {
        "voice_repeat_seconds": 60.0,
        "min_liquidity_strength": min_strength,
        "source_max_age_seconds": source_age,
        "require_liquidity_source": require,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def liquidity(strength=0.8, ts=BASE_TS, symbol="NQ"):
    return {"symbol": symbol, "direction": "BUY", "strength": strength, "timestamp": ts}


def filtered(**overrides):
    payload = {"symbol": "NQ", "direction": "BUY", "timestamp": BASE_TS}
    payload.update(overrides)
    return payload


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    assert {c.args[0] for c in context.subscribe.call_args_list} == set(WATCHED_INPUTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._liquidity == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_passes_with_sufficient_liquidity():
    atom, context = await build_atom()
    await atom._on_liquidity(liquidity(strength=0.9))
    await atom._on_filtered(filtered())
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_CHECKED
    assert payload["passed"] is True
    assert atom._passed == 1


@pytest.mark.asyncio
async def test_blocks_insufficient_liquidity():
    atom, context = await build_atom(min_strength=0.6)
    await atom._on_liquidity(liquidity(strength=0.1))
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["reasons"] == ["LIQUIDITY_INSUFFICIENT"]


@pytest.mark.asyncio
async def test_fails_closed_when_source_absent():
    atom, context = await build_atom()
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is False
    assert payload["reasons"] == ["LIQUIDITY_SOURCE_UNAVAILABLE"]


@pytest.mark.asyncio
async def test_fails_closed_when_source_stale():
    atom, context = await build_atom(source_age=10.0)
    await atom._on_liquidity(liquidity(ts=BASE_TS - 600.0))
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["reasons"] == ["LIQUIDITY_SOURCE_UNAVAILABLE"]


@pytest.mark.asyncio
async def test_fail_open_when_not_required():
    atom, context = await build_atom(require=False)
    await atom._on_filtered(filtered())
    _n, payload = context.publish.await_args.args
    assert payload["passed"] is True


@pytest.mark.asyncio
async def test_malformed_liquidity_ignored():
    atom, _ = await build_atom()
    await atom._on_liquidity({"symbol": "NQ", "strength": "س", "timestamp": BASE_TS})
    assert atom._liquidity == {}


@pytest.mark.asyncio
async def test_missing_header_is_dropped():
    atom, context = await build_atom()
    await atom._on_filtered(filtered(symbol=""))
    await atom._on_filtered(filtered(timestamp=None))
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_any_silent_source_degrades():
    atom, _ = await build_atom(max_silence=0.0)
    assert (await atom.health_check()).state == HealthState.DEGRADED
    await atom._on_liquidity(liquidity())
    await atom._on_filtered(filtered())
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_filtered(filtered())
    assert atom._passed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_liquidity(liquidity())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._liquidity["NQ"]["strength"] == 0.8
