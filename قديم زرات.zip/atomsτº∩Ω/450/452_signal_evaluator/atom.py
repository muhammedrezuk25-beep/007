"""
452 — تقييم الإشارات
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_COLLECTED = "decision.signals_collected"
INPUT_LABEL = "decision.signals_collected"
WATCHED_INPUTS = (INPUT_LABEL,)
EVENT_EVALUATED = "decision.signals_evaluated"

DIRECTION_BUY = "BUY"
DIRECTION_SELL = "SELL"
DIRECTION_NEUTRAL = "NEUTRAL"
VALID_DIRECTIONS = (DIRECTION_BUY, DIRECTION_SELL, DIRECTION_NEUTRAL)

STARVATION_QUORUM = 1   # صمت أي مدخل يكفي لإخراج الصوت
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_EVALUATED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يقيّم حزمة الإشارات المجمّعة ويستخرج الاتجاه السائد ونسبة التوافق."""

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._drop_voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._min_signals: int = 0
        self._min_strength: float = 0.0
        self._max_dropped: int = 0
        self._dropped: int = 0
        self._evaluated: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_signals = int(context.config["min_signals_count"])
        self._min_strength = float(context.config["min_signal_strength"])
        self._max_dropped = int(context.config["max_dropped_before_degraded"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_COLLECTED, self._on_collected)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        if self._dropped > self._max_dropped:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="تجاوز عدد الحزم المرفوضة الحد المسموح",
                details={"dropped": self._dropped},
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"evaluated": self._evaluated},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"dropped": self._dropped, "evaluated": self._evaluated},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._dropped = inner.get("dropped", 0)
        self._evaluated = inner.get("evaluated", 0)

    def _extract(self, payload: dict[str, Any]) -> list[tuple[str, float]]:
        """يستخرج أصوات الاتجاه الصالحة من حزمة الإشارات المدموجة.

        الحزمة تصل من 413 عبر 451 **كقاموس** {اسم_الاستراتيجية: حمولتها}
        (وكانت هنا تُعامل كقائمة فتنهار على أول مفتاح نصي — 131 انهيارًا
        في تشغيل واحد، التقطها عزل الناقل). كما أن الاستراتيجيات تسمّي
        اتجاهها `signal` (مثل 404) لا `direction`، ولا تصرّح بقوة.

        السياسة هنا صريحة:
          * الاتجاه من `direction` أو `signal` أو `side` — أول موجود.
          * القوة من `strength` أو `confidence`، وإلا 1.0 — صوت
            استراتيجية اتجاهية بلا قوة معلنة = صوت كامل.
          * حمولة سياقية بلا اتجاه (range condition، session readiness)
            **ليست صوتًا** وتُتجاهل بصمت — بنص توثيق 409 نفسه:
            "بلا اتجاه، فرض اتجاه هنا تخمين كاذب".
        """
        raw = payload.get("signals")
        if isinstance(raw, dict):
            items = list(raw.values())
        elif isinstance(raw, list):
            items = raw
        else:
            items = []

        valid: list[tuple[str, float]] = []
        for signal in items:
            if not isinstance(signal, dict):
                continue
            direction = signal.get("direction") or signal.get("signal") or signal.get("side")
            if not isinstance(direction, str):
                continue  # حمولة سياقية — ليست صوتًا
            direction = direction.upper()
            declared = signal.get("strength", signal.get("confidence"))
            if declared is None:
                # A side without a magnitude is the weakest acceptable vote,
                # not a full one.
                #
                # Four of the six directional strategies publish no strength
                # at all, and 406 drops it whenever 204 sends a break with no
                # level. Counting those as 1.0 inflated avg_strength, which
                # feeds 453 straight into the decision score: two measured
                # signals at 0.30 and 0.25 scored 0.275, but replacing one of
                # them with an unmeasured vote scored 0.65 -- more than double,
                # on less evidence.
                #
                # The floor is min_signal_strength: the vote still counts
                # towards agreement, and carries the least weight this atom
                # is willing to act on.
                strength = self._min_strength
            else:
                strength = _to_float(declared)
                if strength is None:
                    # Strength was declared but is unparsable. This is corrupt
                    # payload, not an undeclared magnitude — it must not inherit
                    # the full-vote default and reach the decision chain at
                    # maximum weight. Drop the vote.
                    self._dropped += 1
                    continue
            if direction in VALID_DIRECTIONS and strength >= self._min_strength:
                valid.append((direction, strength))
        return valid

    async def _on_collected(self, payload: dict[str, Any]) -> None:
        self._note(INPUT_LABEL)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        valid = self._extract(payload)
        if not symbol or timestamp is None or len(valid) < self._min_signals:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._voice_drop(timestamp)
            return
        counts: dict[str, int] = {}
        for direction, _strength in valid:
            counts[direction] = counts.get(direction, 0) + 1
        ordered = sorted(counts.items(), key=lambda item: item[1], reverse=True)
        dominant, top = ordered[0]
        if len(ordered) > 1 and ordered[1][1] == top:
            dominant = DIRECTION_NEUTRAL
        total = len(valid)
        await self._context.publish(
            EVENT_EVALUATED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "direction": dominant,
                "agreement": top / total,
                "avg_strength": sum(item[1] for item in valid) / total,
                "signal_count": total,
                "bias": payload.get("bias"),
                "confidence": payload.get("confidence"),
                "stability": payload.get("stability"),
                "price": payload.get("price"),
                "analysis": payload.get("analysis"),
                "timestamp": timestamp,
            },
        )
        self._note(EVENT_EVALUATED)
        self._evaluated += 1

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice_drop(self, now: float | None) -> None:
        """The drop warning, spoken on a beat rather than per bundle.

        Every bundle below quorum wrote a line: 74 of them in one run for
        perfectly normal behaviour — a single directional signal does not
        make a quorum of two. And the noise buries what deserves reading:
        this atom announced its own recovery after five seconds of fault in
        the middle of seventy-four identical warnings.

        The count is kept regardless; only the speaking is rate-limited, and
        the total is spoken with it so the silence is not mistaken for
        absence.
        """
        if self._context is None or now is None:
            return
        if now - self._drop_voiced_at < self._voice_repeat:
            return
        self._drop_voiced_at = now
        self._context.logger.warning(
            "حزم دون النصاب: %d منذ الإقلاع (النصاب %d)",
            self._dropped, self._min_signals)

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
