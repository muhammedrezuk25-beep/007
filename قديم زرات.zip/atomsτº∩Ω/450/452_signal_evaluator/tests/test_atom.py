"""
اختبارات الذرة 452 — تقييم الإشارات
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom452"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_EVALUATED = _mod.EVENT_EVALUATED
BASE_TS = 1734567890.0


def make_context(min_signals=2, min_strength=0.2, max_dropped=2, max_silence=60.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 452
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_input_silence_seconds": max_silence,
        "min_signals_count": min_signals,
        "min_signal_strength": min_strength,
        "max_dropped_before_degraded": max_dropped,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def collected(signals, symbol="NQ", ts=BASE_TS):
    return {
        "symbol": symbol,
        "signals": signals,
        "bias": "BUY",
        "confidence": 0.9,
        "stability": 0.8,
        "price": 20000.0,
        "timestamp": ts,
    }


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_dominant_direction_and_agreement():
    atom, context = await build_atom()
    await atom._on_collected(collected([
        {"direction": "BUY", "strength": 0.8},
        {"direction": "BUY", "strength": 0.6},
        {"direction": "SELL", "strength": 0.4},
    ]))
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_EVALUATED
    assert payload["direction"] == "BUY"
    assert payload["signal_count"] == 3
    assert payload["agreement"] == pytest.approx(2 / 3)
    assert payload["avg_strength"] == pytest.approx(0.6)
    assert payload["price"] == 20000.0
    assert payload["timestamp"] == BASE_TS


@pytest.mark.asyncio
async def test_tie_resolves_to_neutral():
    atom, context = await build_atom()
    await atom._on_collected(collected([
        {"direction": "BUY", "strength": 0.9},
        {"direction": "SELL", "strength": 0.9},
    ]))
    _name, payload = context.publish.await_args.args
    assert payload["direction"] == "NEUTRAL"


@pytest.mark.asyncio
async def test_weak_and_malformed_signals_are_filtered():
    atom, context = await build_atom(min_signals=1)
    await atom._on_collected(collected([
        {"direction": "BUY", "strength": 0.05},
        {"direction": "HOLD", "strength": 0.9},
        {"direction": "SELL", "strength": "نص"},
        None,
        {"direction": "SELL", "strength": 0.7},
    ]))
    _name, payload = context.publish.await_args.args
    assert payload["signal_count"] == 1
    assert payload["direction"] == "SELL"


@pytest.mark.asyncio
async def test_below_quorum_is_dropped():
    atom, context = await build_atom()
    await atom._on_collected(collected([{"direction": "BUY", "strength": 0.9}]))
    context.publish.assert_not_awaited()
    assert atom._dropped == 1


@pytest.mark.asyncio
async def test_missing_symbol_or_timestamp_is_dropped():
    atom, context = await build_atom(max_dropped=1)
    await atom._on_collected({"signals": [], "timestamp": BASE_TS})
    await atom._on_collected(collected([], ts="غير-رقم"))
    context.publish.assert_not_awaited()
    assert (await atom.health_check()).state == HealthState.DEGRADED


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_collected(collected([]))
    assert atom._evaluated == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    atom._evaluated = 7
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._evaluated == 7


@pytest.mark.asyncio
async def test_declares_input_starvation_without_stopping():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"]
    assert atom._starving is True
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_starvation_declared_once_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    warned = context.logger.warning.call_count
    await atom.health_check()
    assert context.logger.warning.call_count == warned

    atom._max_silence = 3600.0
    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()


@pytest.mark.asyncio
async def test_the_drop_warning_is_rate_limited():
    """كل حزمة دون النصاب كانت تكتب تحذيرًا: 74 سطرًا في تشغيل واحد
    لسلوك طبيعي تمامًا — إشارة واحدة اتجاهية لا تبلغ نصاب اثنتين.

    والضجيج يدفن ما يستحقّ القراءة: 452 نفسه أعلن عودة الوضع بعد خمس
    ثوانٍ عطل وسط أربعة وسبعين تحذيرًا متطابقًا."""
    atom, context = await build_atom()
    for i in range(30):
        await atom._on_collected(collected(
            {"trend": {"direction": "BUY", "strength": 0.9}},
            ts=BASE_TS + i * 0.1))
    assert atom._dropped == 30
    lines = [c for c in context.logger.warning.call_args_list]
    assert len(lines) <= 2, "التحذير يجب أن يُكتَم: %d سطرًا" % len(lines)
