"""
اختبارات الذرة 465 — مراجعة القرار
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom465"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_REVIEWED = _mod.EVENT_REVIEWED
WATCHED_INPUTS = _mod.WATCHED_INPUTS
BASE_TS = 1785200000.0
ALL_CHECKS = ["confidence", "conditions", "timing", "events", "liquidity"]


def make_context(required=None, max_age=10.0, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 465
    context.config = {
        "voice_repeat_seconds": 60.0,
        "voice_repeat_seconds": 60.0,
        "required_checks": list(ALL_CHECKS if required is None else required),
        "max_check_age_seconds": max_age,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def check(name, passed=True, reasons=None, ts=BASE_TS, symbol="NQ",
          account_id="A"):
    # الفحوص تصل بهويّة حسابها: خمسة فلاتر تجيب عن حسابين تحت مفتاح واحد
    # تجعل رفضَ أحدهما يُغلق قرار الآخر.
    return {"account_id": account_id, "symbol": symbol, "check": name,
            "passed": passed, "reasons": reasons or [], "direction": "BUY",
            "timestamp": ts}


async def feed_all(atom, **overrides):
    handlers = [atom._on_confidence, atom._on_conditions, atom._on_timing,
                atom._on_events, atom._on_liquidity]
    for name, handler in zip(ALL_CHECKS, handlers):
        await handler(check(name, **overrides.get(name, {})))


@pytest.mark.asyncio
async def test_lifecycle_subscribes_to_five_filters():
    atom, context = await build_atom()
    assert {c.args[0] for c in context.subscribe.call_args_list} == set(WATCHED_INPUTS)
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._pending == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_waits_until_all_required_arrive():
    atom, context = await build_atom()
    await atom._on_confidence(check("confidence"))
    await atom._on_conditions(check("conditions"))
    context.publish.assert_not_awaited()

    await atom._on_timing(check("timing"))
    await atom._on_events(check("events"))
    await atom._on_liquidity(check("liquidity"))

    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_REVIEWED
    assert payload["approved"] is True
    assert payload["failed_checks"] == []
    assert payload["direction"] == "BUY"
    assert payload["checks"] == {name: True for name in ALL_CHECKS}
    assert atom._reviewed == 1
    assert atom._pending == {}


@pytest.mark.asyncio
async def test_single_failure_blocks_approval():
    atom, context = await build_atom()
    await feed_all(atom, liquidity={"passed": False, "reasons": ["LIQ_X"]})
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is False
    assert payload["failed_checks"] == ["liquidity"]
    assert payload["reasons"] == ["LIQ_X"]


@pytest.mark.asyncio
async def test_reduced_required_list_works():
    atom, context = await build_atom(required=["confidence", "conditions"])
    await atom._on_confidence(check("confidence"))
    await atom._on_conditions(check("conditions"))
    _n, payload = context.publish.await_args.args
    assert payload["approved"] is True
    assert set(payload["checks"]) == {"confidence", "conditions"}


@pytest.mark.asyncio
async def test_stale_check_leaves_the_window():
    atom, context = await build_atom(max_age=1.0)
    await atom._on_confidence(check("confidence", ts=BASE_TS))
    await feed_all(atom, **{name: {"ts": BASE_TS + 100.0} for name in ALL_CHECKS[1:]})
    context.publish.assert_not_awaited()
    assert "confidence" not in atom._pending[("A", "NQ")]


@pytest.mark.asyncio
async def test_conflicting_directions_yield_none():
    atom, context = await build_atom(required=["confidence", "conditions"])
    await atom._on_confidence(check("confidence"))
    payload = check("conditions")
    payload["direction"] = "SELL"
    await atom._on_conditions(payload)
    _n, out = context.publish.await_args.args
    assert out["direction"] is None


@pytest.mark.asyncio
async def test_symbols_are_isolated():
    atom, context = await build_atom(required=["confidence", "conditions"])
    await atom._on_confidence(check("confidence", symbol="NQ"))
    await atom._on_conditions(check("conditions", symbol="ES"))
    context.publish.assert_not_awaited()


@pytest.mark.asyncio
async def test_malformed_check_is_dropped():
    atom, context = await build_atom()
    await atom._on_timing({"account_id": "A", "check": "timing", "timestamp": BASE_TS})
    await atom._on_timing({"symbol": "NQ", "timestamp": BASE_TS})
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_all_filters_silent_degrades():
    atom, _ = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert set(health.details["missing_inputs"]) == set(WATCHED_INPUTS)


@pytest.mark.asyncio
async def test_collect_ignored_without_context():
    atom = Atom()
    await atom._on_confidence(check("confidence"))
    assert atom._reviewed == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_confidence(check("confidence"))
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert "confidence" in restored._pending[("A", "NQ")]
