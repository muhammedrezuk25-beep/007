"""
465 — مراجعة القرار
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_CONFIDENCE = "decision.confidence_checked"
EVENT_CONDITIONS = "decision.conditions_checked"
EVENT_TIMING = "decision.timing_checked"
EVENT_EVENTS = "decision.events_checked"
EVENT_LIQUIDITY = "decision.liquidity_checked"
EVENT_REVIEWED = "decision.reviewed"

WATCHED_INPUTS = (
    EVENT_CONFIDENCE, EVENT_CONDITIONS, EVENT_TIMING, EVENT_EVENTS, EVENT_LIQUIDITY,
)

STARVATION_QUORUM = len(WATCHED_INPUTS)
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_REVIEWED,)

def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """يجمع نتائج فلاتر التحقق (460-464) ويصدر مراجعة موحّدة لكل رمز.

    لا يعيد الفحص ولا يرجّح فلتراً على آخر — يشترط اجتياز كل الفحوص
    المطلوبة في `required_checks`. القائمة قابلة للتهيئة حتى يعمل القسم
    قبل نشر الفلاتر الخمسة كلها.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._pending: dict[str, dict[str, dict[str, Any]]] = {}
        self._required: list[str] = []
        self._max_check_age: float = 0.0
        self._reviewed: int = 0
        self._dropped: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._required = list(context.config["required_checks"])
        self._max_check_age = float(context.config["max_check_age_seconds"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_CONFIDENCE, self._on_confidence)
        context.subscribe(EVENT_CONDITIONS, self._on_conditions)
        context.subscribe(EVENT_TIMING, self._on_timing)
        context.subscribe(EVENT_EVENTS, self._on_events)
        context.subscribe(EVENT_LIQUIDITY, self._on_liquidity)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._pending.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"reviewed": self._reviewed, "awaiting": len(self._pending)},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {"pending": {"%s|%s" % k: v for k, v in self._pending.items()},
                      "reviewed": self._reviewed,
                      "dropped": self._dropped},
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._pending = {tuple(k.split("|", 1)): v
                         for k, v in (inner.get("pending") or {}).items()}
        self._reviewed = inner.get("reviewed", 0)
        self._dropped = inner.get("dropped", 0)

    async def _collect(self, event_name: str, payload: dict[str, Any]) -> None:
        self._note(event_name)
        if self._context is None:
            return
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        check = payload.get("check")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or not check or timestamp is None or account_id in (None, ""):
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("نتيجة فحص ناقصة من %s", event_name)
            return
        key = (str(account_id), str(symbol))
        self._pending.setdefault(key, {})[check] = {
            "passed": bool(payload.get("passed")),
            "reasons": payload.get("reasons") or [],
            "direction": payload.get("direction"),
            "timestamp": timestamp,
            "confidence": payload.get("confidence"),
            "score": payload.get("score"),
            "stability": payload.get("stability"),
        }
        await self._review(key, timestamp)

    async def _review(self, key: tuple[str, str], now_ts: float) -> None:
        """Publishes the review once every required check is in and fresh.

        Keyed by pair and account together: five filters answering for two
        accounts under one key would let one account's rejection close the
        other's decision.
        """
        if self._context is None:
            return
        account_id, symbol = key
        fresh = {
            name: entry for name, entry in self._pending.get(key, {}).items()
            if now_ts - entry["timestamp"] <= self._max_check_age
        }
        self._pending[key] = fresh
        if not all(name in fresh for name in self._required):
            return
        self._note(LABEL_MINE)
        considered = {name: fresh[name] for name in self._required}
        failed = sorted(name for name, e in considered.items() if not e["passed"])
        reasons = sorted({r for e in considered.values() for r in e["reasons"]})
        directions = {e["direction"] for e in considered.values() if e["direction"]}
        await self._context.publish(
            EVENT_REVIEWED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "direction": directions.pop() if len(directions) == 1 else None,
                "approved": not failed,
                "checks": {name: e["passed"] for name, e in considered.items()},
                "failed_checks": failed,
                "reasons": reasons,
                # أول فحص يحمل قيمة يفوز — عملياً 460 (فلتر الثقة).
                **{k: next((e[k] for e in considered.values()
                            if e.get(k) is not None), None)
                   for k in ("confidence", "score", "stability")},
                "timestamp": max(e["timestamp"] for e in considered.values()),
            },
        )
        self._note(EVENT_REVIEWED)
        self._reviewed += 1
        # النشر أعلاه نقطة تعليق (await): معالج فحص آخر لنفس الرمز قد
        # يكتمل خلالها ويحذف المفتاح قبلنا — الحذف الآمن يمنع KeyError
        # (495 انهيارًا في تشغيل واحد التقطها عزل الناقل).
        self._pending.pop(key, None)

    async def _on_confidence(self, payload: dict[str, Any]) -> None:
        await self._collect(EVENT_CONFIDENCE, payload)

    async def _on_conditions(self, payload: dict[str, Any]) -> None:
        await self._collect(EVENT_CONDITIONS, payload)

    async def _on_timing(self, payload: dict[str, Any]) -> None:
        await self._collect(EVENT_TIMING, payload)

    async def _on_events(self, payload: dict[str, Any]) -> None:
        await self._collect(EVENT_EVENTS, payload)

    async def _on_liquidity(self, payload: dict[str, Any]) -> None:
        await self._collect(EVENT_LIQUIDITY, payload)

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
