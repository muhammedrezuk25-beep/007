"""
اختبارات الذرة 451 — مجمع الإشارات
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom451"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_COLLECTED = _mod.EVENT_COLLECTED
BASE_TS = 1734567890.0


def make_context(max_pair_age=5.0, max_dropped=2, max_silence=60.0):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 451
    context.config = {
        "voice_repeat_seconds": 60.0,
        "max_input_silence_seconds": max_silence,
        "max_pair_age_seconds": max_pair_age,
        "max_dropped_before_degraded": max_dropped,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def signal_payload(ts=BASE_TS, symbol="NQ", account_id="A"):
    # 413 يفنّي الإشارة على الحسابات النشطة، فتصل هنا بهويّة حسابها.
    return {
        "account_id": account_id,
        "symbol": symbol,
        "signals": [{"direction": "BUY", "strength": 0.8}],
        "price": 20000.0,
        "timestamp": ts,
    }


def probability_payload(ts=BASE_TS, symbol="NQ"):
    # الثقة تصل من 359 بلا حساب، وهذا صحيح: هي قول عن السوق لا عن مالٍ
    # بعينه. و451 يقيّدها على كل حساب يحمل إشارة لذلك الرمز.
    return {
        "symbol": symbol,
        "bias": "BUY",
        "confidence": 0.9,
        "stability": 0.7,
        "timestamp": ts,
    }


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    # العدد يُقرأ من المانيفست لا يُكتب رقمًا هنا — الذرة صارت تشترك في
    # ثلاثة أحداث والاختبار بقي على اثنين.
    import yaml
    from pathlib import Path as _P
    _m = yaml.safe_load((_P(__file__).resolve().parents[1] / "manifest.yaml")
                        .read_text(encoding="utf-8"))
    assert context.subscribe.call_count == len(_m["subscribes"])

    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY

    await atom.stop()
    await atom.shutdown()
    assert atom._signals == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    health = await atom.health_check()
    assert health.state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_publishes_when_both_sources_arrive():
    atom, context = await build_atom()

    await atom._on_merged_signal(signal_payload())
    context.publish.assert_not_awaited()

    await atom._on_confidence(probability_payload())
    context.publish.assert_awaited_once()

    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_COLLECTED
    assert payload["symbol"] == "NQ"
    assert payload["confidence"] == 0.9
    assert payload["price"] == 20000.0
    assert payload["timestamp"] == BASE_TS


@pytest.mark.asyncio
async def test_stale_pair_is_dropped():
    atom, context = await build_atom(max_pair_age=1.0)

    await atom._on_merged_signal(signal_payload(ts=BASE_TS))
    await atom._on_confidence(probability_payload(ts=BASE_TS + 10.0))

    context.publish.assert_not_awaited()
    assert atom._dropped == 1
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_invalid_payload_is_dropped():
    atom, context = await build_atom()

    await atom._on_merged_signal({"signals": [], "timestamp": BASE_TS})
    await atom._on_confidence({"symbol": "NQ", "timestamp": "غير-رقم"})

    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_health_degrades_after_threshold():
    # صمت كبير جداً حتى لا يطغى تصريح نقص المدخلات على سبب الرفض
    atom, _ = await build_atom(max_dropped=1, max_silence=1e12)

    await atom._on_merged_signal({"timestamp": BASE_TS})
    await atom._on_merged_signal({"timestamp": BASE_TS})

    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["dropped"] == 2


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_merged_signal(signal_payload())

    snap = await atom.snapshot()
    assert "state" in snap and "timestamp" in snap

    restored = Atom()
    await restored.restore(snap)
    assert restored._signals[("A", "NQ")]["price"] == 20000.0
    assert restored._published == 0


@pytest.mark.asyncio
async def test_emit_ignored_without_context():
    atom = Atom()
    await atom._try_emit("NQ")
    assert atom._published == 0


@pytest.mark.asyncio
async def test_declares_input_starvation_without_stopping():
    atom, context = await build_atom(max_silence=0.0)
    health = await atom.health_check()
    assert health.state == HealthState.DEGRADED
    assert health.details["missing_inputs"]
    assert atom._starving is True
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_starvation_declared_once_then_recovers():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    warned = context.logger.warning.call_count
    await atom.health_check()
    assert context.logger.warning.call_count == warned

    atom._max_silence = 3600.0
    health = await atom.health_check()
    assert health.state == HealthState.HEALTHY
    assert atom._starving is False
    context.logger.info.assert_called()


@pytest.mark.asyncio
async def test_stale_pairs_are_evicted():
    """max_pair_age_seconds يُقرأ للمقارنة ولا يُنظّف: المفتاح (حساب،
    رمز) وكلاهما يتبدّل، فتتراكم الأزواج القديمة في الذاكرة إلى الأبد
    على تشغيل بأيام."""
    atom, context = await build_atom()
    await atom._on_merged_signal(signal_payload(ts=BASE_TS, symbol="OLD"))
    assert ("A", "OLD") in atom._signals

    # التنظيف يقع بعد محاولة الاقتران: إشارة أحدث تُخزَّن، ثم يُكنَس ما
    # تجاوز النافذة — والقديم يخرج وقتها لا قبله.
    fresh_ts = BASE_TS + atom._max_pair_age + 60.0
    await atom._on_merged_signal(signal_payload(ts=fresh_ts, symbol="NEW"))
    assert ("A", "NEW") in atom._signals
    assert ("A", "OLD") not in atom._signals
    assert atom._evicted >= 1


@pytest.mark.asyncio
async def test_a_fresh_pair_is_not_evicted():
    atom, context = await build_atom()
    await atom._on_merged_signal(signal_payload(ts=BASE_TS, symbol="ONE"))
    await atom._on_merged_signal(signal_payload(ts=BASE_TS + 1.0, symbol="TWO"))
    assert ("A", "ONE") in atom._signals
    assert ("A", "TWO") in atom._signals
