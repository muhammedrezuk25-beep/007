"""
451 — مجمع الإشارات
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_MERGED_SIGNAL = "strategy.merged_signal"
EVENT_CONFIDENCE = "probability.confidence_aggregated"
EVENT_COLLECTED = "decision.signals_collected"
WATCHED_INPUTS = (EVENT_MERGED_SIGNAL, EVENT_CONFIDENCE)

STARVATION_QUORUM = 1   # صمت أي مدخل يكفي لإخراج الصوت
LABEL_MINE = "atom.addressed_to_me"
OUTPUTS = (EVENT_COLLECTED,)

def _to_float(value: Any) -> float | None:
    """تحويل آمن إلى عدد عشري دون الاعتماد على فحص الأنواع."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return None

class Atom(AtomBase):
    """جامع صامت (القاعدة 1): يضم مخرجات الاستراتيجيات والاحتمالات في حزمة
    واحدة لكل رمز، ويمرّرها كما هي. هو المصدر الرسمي لـ"سعر القرار" (يعتمده 560).

    لا يفاضل بين المصادر، ولا يرجّح إشارة على أخرى، ولا يُسقط مصدراً انتقائياً.
    أي منطق تحكيمي هنا يحوّل الجامع إلى محلل، وهو محظور دستورياً.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._max_silence: float = 0.0
        self._started_at: float = 0.0
        self._starving: bool = False
        self._since: float = 0.0
        self._voiced_at: float = 0.0
        self._voice_repeat: float = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._signals: dict[tuple[str, str], dict[str, Any]] = {}
        # مانيفست هذه الذرة يعلنها "المصدر الرسمي لسعر القرار" — آخر
        # سعر لكل رمز يُلتقط من العقد الموحّد ويُختم به كل قرار مجمَّع.
        self._last_price: dict[str, float] = {}
        self._probability: dict[tuple[str, str], dict[str, Any]] = {}
        self._max_pair_age: float = 0.0
        self._evicted: int = 0
        self._max_dropped: int = 0
        self._dropped: int = 0
        self._published: int = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_pair_age = float(context.config["max_pair_age_seconds"])
        self._max_dropped = int(context.config["max_dropped_before_degraded"])
        self._max_silence = float(context.config["max_input_silence_seconds"])
        self._voice_repeat = float(context.config["voice_repeat_seconds"])
        context.subscribe(EVENT_MERGED_SIGNAL, self._on_merged_signal)
        context.subscribe("market.tick", self._on_price_tick)
        context.subscribe(EVENT_CONFIDENCE, self._on_confidence)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d", self._context.atom_id)

    async def shutdown(self) -> None:
        self._signals.clear()
        self._probability.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        starved = self._declare_starvation(time.time())
        if starved is not None:
            return starved
        if self._dropped > self._max_dropped:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="تجاوز عدد الحمولات المرفوضة الحد المسموح",
                details={"dropped": self._dropped, "published": self._published},
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="يعمل بشكل طبيعي",
            details={"published": self._published},
        )

    async def snapshot(self) -> dict[str, Any] | None:
        return {
            "state": {
                "signals": {"%s|%s" % k: v for k, v in self._signals.items()},
                "probability": {"%s|%s" % k: v for k, v in self._probability.items()},
                "dropped": self._dropped,
                "published": self._published,
            },
            "timestamp": time.time(),
        }

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        # المفتاح زوج، ويُسلسَل نصًّا في اللقطة ثم يعود زوجًا.
        self._signals = {tuple(k.split("|", 1)): v
                         for k, v in (inner.get("signals") or {}).items()}
        self._probability = {tuple(k.split("|", 1)): v
                             for k, v in (inner.get("probability") or {}).items()}
        self._dropped = inner.get("dropped", 0)
        self._published = inner.get("published", 0)

    async def _on_price_tick(self, payload: dict[str, Any]) -> None:
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        account_id = inner.get("account_id")
        price = inner.get("price", inner.get("mid"))
        if symbol and isinstance(price, (int, float)):
            self._last_price[str(symbol)] = float(price)

    async def _sweep(self, now: float) -> None:
        """Eviction runs after the pairing attempt, never before it.

        Cleaning first swallowed the very state the attempt needed to
        compare: a signal older than the window was gone before _try_emit
        could measure the gap, so the drop went uncounted and the reason
        unlogged.
        """
        self._evict_stale(now)

    async def _on_merged_signal(self, payload: dict[str, Any]) -> None:
        self._note(EVENT_MERGED_SIGNAL)
        key = self._store(self._signals, payload)
        await self._try_emit(key)
        stamp = _to_float(payload.get("timestamp"))
        if stamp is not None:
            await self._sweep(stamp)

    async def _on_confidence(self, payload: dict[str, Any]) -> None:
        """Confidence arrives from 359 without an account, and rightly so:
        it is a statement about the market, not about whose money is at risk.

        It is filed against every account already holding a signal for that
        symbol — the same reading, read by each of them.
        """
        self._note(EVENT_CONFIDENCE)
        symbol = payload.get("symbol")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None:
            self._dropped += 1
            self._note(LABEL_MINE)
            return
        touched = []
        for account_id, held_symbol in list(self._signals):
            if held_symbol != str(symbol):
                continue
            key = self._store(self._probability,
                              {**payload, "account_id": account_id})
            if key is not None:
                touched.append(key)
        for key in touched:
            await self._try_emit(key)
        if timestamp is not None:
            await self._sweep(timestamp)

    def _store(self, bucket: dict[tuple[str, str], dict[str, Any]],
               payload: dict[str, Any]) -> tuple[str, str] | None:
        """Keeps the last sound payload per pair-and-account.

        Keyed by symbol alone, one account's signal overwrote the other's:
        two accounts trading USTEC produced one decision belonging to
        neither.

        A payload with no account has no destination, so it is dropped rather
        than filed under a default — sizing from one account's equity into
        another moves real money with no fault visible.
        """
        symbol = payload.get("symbol")
        account_id = payload.get("account_id")
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or timestamp is None or account_id in (None, ""):
            self._dropped += 1
            self._note(LABEL_MINE)
            if self._context is not None:
                self._context.logger.warning(
                    "حمولة بلا رمز أو حساب أو طابع زمني صالح")
            return None
        key = (str(account_id), str(symbol))
        stored = dict(payload)
        stored["timestamp"] = timestamp
        bucket[key] = stored
        return key

    def _evict_stale(self, now: float) -> None:
        """Drops pairs nothing has touched within the pairing window.

        max_pair_age_seconds was read to compare two stamps and never to
        clear anything. The key is (account, symbol) and both sides change
        over time, so on a run measured in days the two dictionaries grew
        without bound — every symbol ever seen, under every account ever
        active, held forever.
        """
        cutoff = now - self._max_pair_age
        for bucket in (self._signals, self._probability):
            for key in [k for k, v in bucket.items()
                        if float(v.get("timestamp", now)) < cutoff]:
                bucket.pop(key, None)
                self._evicted += 1

    async def _try_emit(self, key: tuple[str, str] | None) -> None:
        if self._context is None or key is None:
            return
        account_id, symbol = key
        signal = self._signals.get(key)
        probability = self._probability.get(key)
        if signal is None or probability is None:
            return
        self._note(LABEL_MINE)
        signal_ts = signal["timestamp"]
        probability_ts = probability["timestamp"]
        if abs(signal_ts - probability_ts) > self._max_pair_age:
            self._dropped += 1
            self._note(LABEL_MINE)
            self._context.logger.warning("فارق زمني تجاوز الحد للرمز %s", symbol)
            return
        await self._context.publish(
            EVENT_COLLECTED,
            {
                "account_id": account_id,
                "symbol": symbol,
                "signals": signal.get("signals", []),
                "bias": probability.get("bias"),
                "confidence": probability.get("confidence"),
                "stability": probability.get("stability"),
                "price": signal.get("price", self._last_price.get(symbol)),
                "timestamp": max(signal_ts, probability_ts),
            },
        )
        self._note(EVENT_COLLECTED)
        self._published += 1

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare_starvation(self, now: float) -> HealthStatus | None:
        """الإفصاح الذاتي الكامل: صمتي يعني نجاحي.

        حالتان تُخرجان صوتي، وأكشفهما بنفسي دون انتظار جارتي:
          1. لم أستقبل مدخلاتي  -> INPUT_STARVED
          2. استقبلت ولم أُخرج شيئاً -> OUTPUT_STALLED
        ما عدا ذلك أصمت، والصمت هنا إقرار بالنجاح لا غياب خبر.
        """
        starved = [label for label in WATCHED_INPUTS if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "لم أستقبل مدخلاتي", starved)
        if OUTPUTS and not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(
                    now, "OUTPUT_STALLED", "وصلني ما يخصّني ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل", int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        """الصوت لا يُقال مرة ويُنسى — يتكرر ما دام العطل قائماً، ومعه مدته."""
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED,
            message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in WATCHED_INPUTS if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "counters": dict(self._arrivals)},
        )

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
