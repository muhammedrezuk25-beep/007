"""
اختبارات الذرة 459 — مدير الأولويات
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom459"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_ORDERED = _mod.EVENT_ORDERED
BASE_TS = 1785200000.0


def make_context(w_conf=0.7, w_stab=0.3, max_symbols=50, max_silence=1e12):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 459
    context.config = {
        "voice_repeat_seconds": 60.0,
        "weight_confidence": w_conf,
        "weight_stability": w_stab,
        "max_tracked_symbols": max_symbols,
        "max_input_silence_seconds": max_silence,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def collected(symbol="NQ", confidence=0.9, stability=0.8, ts=BASE_TS):
    return {"symbol": symbol, "confidence": confidence,
            "stability": stability, "timestamp": ts}


@pytest.mark.asyncio
async def test_lifecycle():
    atom, context = await build_atom()
    context.subscribe.assert_called_once()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    await atom.stop()
    await atom.shutdown()
    assert atom._scores == {}


@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_publishes_weighted_priority():
    atom, context = await build_atom(w_conf=1.0, w_stab=0.0)
    await atom._on_collected(collected(confidence=0.9))
    event_name, payload = context.publish.await_args.args
    assert event_name == EVENT_ORDERED
    assert payload["symbols"] == ["NQ"]
    assert payload["priorities"]["NQ"] == pytest.approx(0.9)
    assert payload["timestamp"] == BASE_TS


@pytest.mark.asyncio
async def test_orders_highest_priority_first():
    atom, context = await build_atom(w_conf=1.0, w_stab=0.0)
    await atom._on_collected(collected(symbol="ES", confidence=0.2))
    await atom._on_collected(collected(symbol="NQ", confidence=0.9))
    _n, payload = context.publish.await_args.args
    assert payload["symbols"] == ["NQ", "ES"]


@pytest.mark.asyncio
async def test_ties_break_alphabetically():
    atom, context = await build_atom()
    await atom._on_collected(collected(symbol="NQ"))
    await atom._on_collected(collected(symbol="ES"))
    _n, payload = context.publish.await_args.args
    assert payload["symbols"] == ["ES", "NQ"]


@pytest.mark.asyncio
async def test_tracked_symbols_are_capped():
    atom, _ = await build_atom(max_symbols=2)
    for index, name in enumerate(("A", "B", "C", "D")):
        await atom._on_collected(collected(symbol=name, ts=BASE_TS + index))
    assert len(atom._scores) == 2
    assert set(atom._scores) == {"C", "D"}


@pytest.mark.asyncio
async def test_incomplete_payload_is_dropped():
    atom, context = await build_atom()
    await atom._on_collected(collected(confidence=None))
    await atom._on_collected({"confidence": 0.5, "stability": 0.5, "timestamp": BASE_TS})
    context.publish.assert_not_awaited()
    assert atom._dropped == 2


@pytest.mark.asyncio
async def test_silence_degrades_then_recovers():
    atom, _ = await build_atom(max_silence=0.0)
    assert (await atom.health_check()).state == HealthState.DEGRADED
    await atom._on_collected(collected())
    atom._max_silence = 1e12
    assert (await atom.health_check()).state == HealthState.HEALTHY


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_collected(collected())
    assert atom._published == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_collected(collected())
    snap = await atom.snapshot()
    restored = Atom()
    await restored.restore(snap)
    assert restored._published == 1
    assert "NQ" in restored._scores
