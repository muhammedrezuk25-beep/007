from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "stats.regression_calculated"
EVENT_OUT = "stats.r_squared_calculated"

LINEARITY_STRONG = "STRONG"
LINEARITY_MODERATE = "MODERATE"
LINEARITY_WEAK = "WEAK"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_REGRESSION_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._strong_threshold = 0.0
        self._moderate_threshold = 0.0
        self._latest: dict[str, float] = {}
        self.calculations = 0
        self.skipped_flat = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._strong_threshold = float(cfg["strong_linearity"])
        self._moderate_threshold = float(cfg["moderate_linearity"])
        context.subscribe(EVENT_IN, self._on_regression)
        self._initialized = True
        context.logger.info("309 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("309 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("309 stopped (calculations=%d)", self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    def linearity_of(self, r_squared: float) -> str:
        if r_squared >= self._strong_threshold:
            return LINEARITY_STRONG
        if r_squared >= self._moderate_threshold:
            return LINEARITY_MODERATE
        return LINEARITY_WEAK

    async def _on_regression(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        sse = _to_float(payload.get("sse"))
        sst = _to_float(payload.get("sst"))
        if not symbol or sse is None or sst is None:
            return
        if sst <= 0:
            self.skipped_flat += 1
            return

        r_squared = max(0.0, min(1.0, 1.0 - sse / sst))
        self._latest[str(symbol)] = round(r_squared, 8)
        self.calculations += 1

        body: dict[str, Any] = {
            "symbol": symbol, "r_squared": round(r_squared, 8),
            "trend_linearity_score": self.linearity_of(r_squared),
            "slope": _to_float(payload.get("slope")),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"calculations": self.calculations, "skipped_flat": self.skipped_flat,
                   "latest": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="calculations=%d" % self.calculations,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "calculations": self.calculations,
                "latest": dict(self._latest)}

    async def restore(self, state: dict[str, Any]) -> None:
        self.calculations = int(state.get("calculations", 0))
        self._latest = dict(state.get("latest") or {})
