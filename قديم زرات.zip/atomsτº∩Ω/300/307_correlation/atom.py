from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "stats.correlation_calculated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_WARMING_UP = "PAIRS_NOT_READY"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._window_size = 0
        self._pairs: list[tuple[str, str]] = []
        self._windows: dict[str, deque] = {}
        self._latest: dict[str, float] = {}
        self.calculations = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._window_size = int(cfg["window_size"])
        self._pairs = [(str(p["symbol_a"]).upper(), str(p["symbol_b"]).upper())
                       for p in cfg["pairs"]]
        context.subscribe(EVENT_CANDLE, self._on_candle)
        self._initialized = True
        context.logger.info("307 initialised with %d pairs", len(self._pairs))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("307 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("307 stopped (calculations=%d)", self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def pearson(left: list[float], right: list[float]) -> float | None:
        count = min(len(left), len(right))
        if count < 2:
            return None
        left, right = left[-count:], right[-count:]
        mean_left = sum(left) / count
        mean_right = sum(right) / count
        covariance = sum((a - mean_left) * (b - mean_right)
                         for a, b in zip(left, right))
        spread_left = sum((a - mean_left) ** 2 for a in left)
        spread_right = sum((b - mean_right) ** 2 for b in right)
        if spread_left <= 0 or spread_right <= 0:
            return None
        return covariance / math.sqrt(spread_left * spread_right)

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        close = _to_float(inner.get("close"))
        if not symbol or close is None:
            return
        key = str(symbol).upper()
        if not any(key in pair for pair in self._pairs):
            return

        window = self._windows.get(key)
        if window is None:
            window = deque(maxlen=self._window_size)
            self._windows[key] = window
        window.append(close)

        stamp = inner.get("timestamp", payload.get("timestamp"))
        for symbol_a, symbol_b in self._pairs:
            if key not in (symbol_a, symbol_b):
                continue
            left = self._windows.get(symbol_a)
            right = self._windows.get(symbol_b)
            if left is None or right is None:
                continue
            if len(left) < self._window_size or len(right) < self._window_size:
                continue
            score = self.pearson(list(left), list(right))
            if score is None:
                continue
            self._latest["%s/%s" % (symbol_a, symbol_b)] = round(score, 6)
            self.calculations += 1
            body: dict[str, Any] = {
                "symbol_a": symbol_a, "symbol_b": symbol_b,
                "correlation_score": round(score, 6),
                "window_size": self._window_size,
            }
            if isinstance(stamp, (int, float)):
                body["timestamp"] = stamp
            await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"pairs": len(self._pairs), "tracked": len(self._windows),
                   "calculations": self.calculations, "latest": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_WARMING_UP, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="calculations=%d" % self.calculations,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "windows": {k: list(v) for k, v in self._windows.items()},
                "calculations": self.calculations}

    async def restore(self, state: dict[str, Any]) -> None:
        size = self._window_size or None
        self._windows = {k: deque(v, maxlen=size or len(v))
                         for k, v in (state.get("windows") or {}).items()}
        self.calculations = int(state.get("calculations", 0))
