from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "stats.unified"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRAFFIC = "NO_STATISTICS_YET"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._watch: list[str] = []
        self._max_symbols = 0
        self._per_symbol: dict[str, dict[str, Any]] = {}
        self._counts: dict[str, int] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._watch = [str(e) for e in cfg["watch_events"]]
        self._max_symbols = int(cfg["max_symbols"])
        for event_name in self._watch:
            context.subscribe(event_name, self._make_collector(event_name))
        self._initialized = True
        context.logger.info("300 initialised watching %d events", len(self._watch))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("300 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("300 stopped (published=%d)",
                                      self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _make_collector(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._collect(event_name, payload)
        return handler

    async def _collect(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol") or payload.get("symbol_a")
        if not symbol:
            return
        key = str(symbol)

        bucket = self._per_symbol.get(key)
        if bucket is None:
            if len(self._per_symbol) >= self._max_symbols:
                self._per_symbol.pop(next(iter(self._per_symbol)))
            bucket = {}
            self._per_symbol[key] = bucket

        bucket[event_name] = {k: v for k, v in payload.items() if k != "symbol"}
        self._counts[event_name] = self._counts.get(event_name, 0) + 1
        self.published_count += 1

        body: dict[str, Any] = {
            "symbol": symbol,
            "latest": event_name,
            "stats_payload": {k: dict(v) for k, v in bucket.items()},
            "sections_seen": len(bucket),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        silent = [e for e in self._watch if e not in self._counts]
        details = {"watching": len(self._watch), "symbols": len(self._per_symbol),
                   "published": self.published_count, "silent": silent,
                   "counts": dict(self._counts)}
        if not self._counts:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRAFFIC, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="seen %d/%d events on %d symbols" % (
                                len(self._counts), len(self._watch),
                                len(self._per_symbol)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "per_symbol": dict(self._per_symbol),
                "counts": dict(self._counts), "published": self.published_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._per_symbol = dict(state.get("per_symbol") or {})
        self._counts = {str(k): int(v) for k, v in (state.get("counts") or {}).items()}
        self.published_count = int(state.get("published", 0))
