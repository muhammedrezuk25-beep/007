from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom300"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 300

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name=None):
    target = name or MODULE.EVENT_OUT
    return [p for n, p in ctx.published if n == target]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    """The whole section stamps from the candle it derives from. A stat read
    at publish time would be dated later than its own evidence, and 318
    measures period gaps on those stamps."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 300


def test_it_makes_no_trading_decision():
    """Article 4 of the section paper: zero trading logic here. Checked on
    whole words, because 'ordered' is a sorted list and not an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("BUY", "SELL", "execution.", "decision.",
                      "trading.", "risk."):
        assert forbidden not in src
    import re as _re
    assert not _re.search(r"\border\b", src)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_it_gathers_readings_per_symbol():
    atom, ctx = await _ready()
    await ctx.handlers["stats.mean_calculated"]({"symbol": "NQ", "mean": 100.0,
                                                  "timestamp": TS})
    await ctx.handlers["stats.std_dev_calculated"]({"symbol": "NQ", "std_dev": 5.0,
                                                     "timestamp": TS})
    unified = out(ctx)[-1]
    assert unified["symbol"] == "NQ"
    assert set(unified["stats_payload"]) == {"stats.mean_calculated",
                                             "stats.std_dev_calculated"}


@pytest.mark.asyncio
async def test_it_is_the_only_outward_voice_of_the_section():
    """Every other section hears stats.unified from here and applies its own
    rule. The individual readings stay inside 300."""
    assert MANIFEST["publishes"] == ["stats.unified"]
    assert all(e.startswith("stats.") for e in MANIFEST["subscribes"])


@pytest.mark.asyncio
async def test_it_computes_nothing_of_its_own():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for maths in ("sqrt", "** 2", "** 3", "sum("):
        assert maths not in src


@pytest.mark.asyncio
async def test_two_symbols_stay_apart():
    atom, ctx = await _ready()
    await ctx.handlers["stats.mean_calculated"]({"symbol": "A", "mean": 1.0})
    await ctx.handlers["stats.mean_calculated"]({"symbol": "B", "mean": 2.0})
    values = {p["symbol"]: p["stats_payload"]["stats.mean_calculated"]["mean"]
              for p in out(ctx)}
    assert values == {"A": 1.0, "B": 2.0}


@pytest.mark.asyncio
async def test_a_correlation_reading_is_filed_under_its_first_symbol():
    atom, ctx = await _ready()
    await ctx.handlers["stats.correlation_calculated"](
        {"symbol_a": "A", "symbol_b": "B", "correlation_score": 0.9})
    assert out(ctx)[-1]["symbol"] == "A"


@pytest.mark.asyncio
async def test_health_names_the_silent_readings():
    atom, ctx = await _ready()
    await ctx.handlers["stats.mean_calculated"]({"symbol": "NQ", "mean": 1.0})
    details = (await atom.health_check()).details
    assert "stats.kurtosis_calculated" in details["silent"]


@pytest.mark.asyncio
async def test_snapshot_carries_the_readings():
    atom, ctx = await _ready()
    await ctx.handlers["stats.mean_calculated"]({"symbol": "NQ", "mean": 42.0})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh._per_symbol["NQ"]["stats.mean_calculated"]["mean"] == 42.0
