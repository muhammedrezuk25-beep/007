from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_MEAN = "stats.mean_calculated"
EVENT_STD = "stats.std_dev_calculated"
EVENT_OUT = "stats.z_score_calculated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_BASE = "AWAITING_MEAN_AND_STD"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._max_symbols = 0
        self._means: dict[str, float] = {}
        self._std_devs: dict[str, float] = {}
        self._latest: dict[str, float] = {}
        self.calculations = 0
        self.skipped_flat = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_symbols = int(context.config["max_symbols"])
        context.subscribe(EVENT_MEAN, self._on_mean)
        context.subscribe(EVENT_STD, self._on_std)
        context.subscribe(EVENT_CANDLE, self._on_candle)
        self._initialized = True
        context.logger.info("310 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("310 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("310 stopped (calculations=%d)", self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    def _trim(self, store: dict) -> None:
        while len(store) > self._max_symbols:
            store.pop(next(iter(store)))

    async def _on_mean(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        mean = _to_float(payload.get("mean"))
        if symbol and mean is not None:
            self._means[str(symbol)] = mean
            self._trim(self._means)

    async def _on_std(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        std_dev = _to_float(payload.get("std_dev"))
        if symbol and std_dev is not None:
            self._std_devs[str(symbol)] = std_dev
            self._trim(self._std_devs)

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        close = _to_float(inner.get("close"))
        if not symbol or close is None:
            return
        key = str(symbol)
        mean = self._means.get(key)
        std_dev = self._std_devs.get(key)
        if mean is None or std_dev is None:
            return
        if std_dev <= 0:
            self.skipped_flat += 1
            return

        z_score = (close - mean) / std_dev
        self._latest[key] = round(z_score, 8)
        self.calculations += 1

        body: dict[str, Any] = {"symbol": symbol, "z_score": round(z_score, 8),
                                "close_price": close, "mean": mean,
                                "std_dev": std_dev}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"calculations": self.calculations, "skipped_flat": self.skipped_flat,
                   "symbols": len(self._means), "latest": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_BASE, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="calculations=%d" % self.calculations,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "means": dict(self._means),
                "std_devs": dict(self._std_devs), "calculations": self.calculations}

    async def restore(self, state: dict[str, Any]) -> None:
        self._means = dict(state.get("means") or {})
        self._std_devs = dict(state.get("std_devs") or {})
        self.calculations = int(state.get("calculations", 0))
