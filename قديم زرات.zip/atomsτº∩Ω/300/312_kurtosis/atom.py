from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "stats.kurtosis_calculated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_WARMING_UP = "WINDOW_NOT_FULL"

_MIN_SAMPLE = 4
_FOURTH_MOMENT = 4
_NORMAL_KURTOSIS = 3.0


_PRIMARY = "kurtosis"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


TAIL_HEAVY = "HEAVY_TAILS"
TAIL_LIGHT = "LIGHT_TAILS"
TAIL_NORMAL = "NORMAL_TAILS"



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._window_size = 0
        self._max_symbols = 0
        self._windows: dict[str, deque] = {}
        self._latest: dict[str, Any] = {}
        self.calculations = 0
        self._heavy_threshold = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._window_size = int(cfg["window_size"])
        self._max_symbols = int(cfg["max_symbols"])
        self._heavy_threshold = float(cfg["heavy_tail_threshold"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        self._initialized = True
        context.logger.info("312 initialised (window=%d)", self._window_size)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("312 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("312 stopped (calculations=%d)",
                                      self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    def _window_for(self, symbol: str) -> deque:
        window = self._windows.get(symbol)
        if window is None:
            if len(self._windows) >= self._max_symbols:
                oldest = next(iter(self._windows))
                self._windows.pop(oldest)
                self._latest.pop(oldest, None)
            window = deque(maxlen=self._window_size)
            self._windows[symbol] = window
        return window

    def compute(self, values: list[float]) -> dict[str, Any] | None:
        count = len(values)
        if count < _MIN_SAMPLE:
            return None
        mean = sum(values) / count
        variance = sum((v - mean) ** 2 for v in values) / count
        if variance <= 0:
            return None
        fourth = sum((v - mean) ** _FOURTH_MOMENT for v in values) / count
        excess = fourth / (variance ** 2) - _NORMAL_KURTOSIS
        if excess > self._heavy_threshold:
            risk = TAIL_HEAVY
        elif excess < -self._heavy_threshold:
            risk = TAIL_LIGHT
        else:
            risk = TAIL_NORMAL
        return {"kurtosis": round(excess, 8), "fat_tail_risk": risk}

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        close = _to_float(inner.get("close"))
        if not symbol or close is None:
            return

        window = self._window_for(str(symbol))
        window.append(close)
        if len(window) < self._window_size:
            return

        result = self.compute(list(window))
        if result is None:
            return
        self._latest[str(symbol)] = result.get(_PRIMARY)
        self.calculations += 1

        body: dict[str, Any] = {"symbol": symbol, **result,
                                "window_size": self._window_size}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"symbols": len(self._windows), "calculations": self.calculations,
                   "window_size": self._window_size, "latest": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_WARMING_UP, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="symbols=%d calculations=%d" % (
                                len(self._windows), self.calculations),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "windows": {k: list(v) for k, v in self._windows.items()},
                "calculations": self.calculations}

    async def restore(self, state: dict[str, Any]) -> None:
        size = self._window_size or None
        self._windows = {k: deque(v, maxlen=size or len(v))
                         for k, v in (state.get("windows") or {}).items()}
        self.calculations = int(state.get("calculations", 0))
