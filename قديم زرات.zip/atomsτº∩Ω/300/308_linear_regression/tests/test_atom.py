from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom308"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 308

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name=None):
    target = name or MODULE.EVENT_OUT
    return [p for n, p in ctx.published if n == target]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    """The whole section stamps from the candle it derives from. A stat read
    at publish time would be dated later than its own evidence, and 318
    measures period gaps on those stamps."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 308


def test_it_makes_no_trading_decision():
    """Article 4 of the section paper: zero trading logic here. Checked on
    whole words, because 'ordered' is a sorted list and not an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("BUY", "SELL", "execution.", "decision.",
                      "trading.", "risk."):
        assert forbidden not in src
    import re as _re
    assert not _re.search(r"\border\b", src)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _feed(ctx, values, symbol="NQ", start=TS):
    for i, value in enumerate(values):
        await ctx.handlers[MODULE.EVENT_CANDLE]({
            "symbol": symbol, "close": value, "timestamp": start + i * 60})


@pytest.mark.asyncio
async def test_nothing_is_published_before_the_window_fills():
    """A statistic on three of twenty candles is not the statistic asked for."""
    atom, ctx = await _ready(window_size=5)
    await _feed(ctx, [10.0, 11.0, 12.0])
    assert out(ctx) == []
    await _feed(ctx, [13.0, 14.0], start=TS + 300)
    assert len(out(ctx)) == 1


@pytest.mark.asyncio
async def test_the_timestamp_comes_from_the_candle():
    atom, ctx = await _ready(window_size=3)
    await ctx.handlers[MODULE.EVENT_CANDLE]({"symbol": "NQ", "close": 1.0, "timestamp": 11.0})
    await ctx.handlers[MODULE.EVENT_CANDLE]({"symbol": "NQ", "close": 2.0, "timestamp": 22.0})
    await ctx.handlers[MODULE.EVENT_CANDLE]({"symbol": "NQ", "close": 3.0, "timestamp": 33.0})
    assert out(ctx)[0]["timestamp"] == 33.0


@pytest.mark.asyncio
async def test_two_symbols_keep_separate_windows():
    atom, ctx = await _ready(window_size=3)
    await _feed(ctx, [10.0, 10.0, 10.0], symbol="A")
    await _feed(ctx, [99.0, 99.0, 99.0], symbol="B")
    symbols = {p["symbol"] for p in out(ctx)}
    assert symbols == {"A", "B"}


@pytest.mark.asyncio
async def test_a_candle_without_a_close_is_ignored():
    atom, ctx = await _ready(window_size=2)
    await ctx.handlers[MODULE.EVENT_CANDLE]({"symbol": "NQ", "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_CANDLE]({"symbol": "NQ", "close": "abc", "timestamp": TS})
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_tracked_symbols_are_capped():
    atom, ctx = await _ready(window_size=2, max_symbols=3)
    for i in range(6):
        await _feed(ctx, [1.0, 2.0], symbol=f"S{i}")
    assert len(atom._windows) == 3


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready(window_size=3)
    await _feed(ctx, [1.0, 2.0, 3.0])
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.calculations == atom.calculations


@pytest.mark.asyncio
async def test_a_perfect_line_gives_its_exact_slope():
    atom, ctx = await _ready(window_size=5)
    await _feed(ctx, [10.0, 12.0, 14.0, 16.0, 18.0])
    result = out(ctx)[0]
    assert result["slope"] == pytest.approx(2.0, abs=1e-9)
    assert result["predicted_next_price"] == pytest.approx(20.0, abs=1e-6)


@pytest.mark.asyncio
async def test_a_falling_line_has_a_negative_slope():
    atom, ctx = await _ready(window_size=4)
    await _feed(ctx, [20.0, 15.0, 10.0, 5.0])
    assert out(ctx)[0]["slope"] < 0


@pytest.mark.asyncio
async def test_it_publishes_the_sums_of_squares_309_needs():
    """309 computes R-squared from sse and sst. The slope alone cannot give
    them, so without these fields 309 has nothing to work with."""
    atom, ctx = await _ready(window_size=5)
    await _feed(ctx, [10.0, 12.0, 14.0, 16.0, 18.0])
    result = out(ctx)[0]
    assert "sse" in result and "sst" in result
    assert result["sse"] == pytest.approx(0.0, abs=1e-9)
    assert result["sst"] > 0
