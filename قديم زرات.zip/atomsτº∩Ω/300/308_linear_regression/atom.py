from __future__ import annotations

from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "stats.regression_calculated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_WARMING_UP = "WINDOW_NOT_FULL"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._window_size = 0
        self._max_symbols = 0
        self._windows: dict[str, deque] = {}
        self._latest: dict[str, float] = {}
        self.calculations = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._window_size = int(cfg["window_size"])
        self._max_symbols = int(cfg["max_symbols"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        self._initialized = True
        context.logger.info("308 initialised (window=%d)", self._window_size)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("308 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("308 stopped (calculations=%d)", self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    def _window_for(self, symbol: str) -> deque:
        window = self._windows.get(symbol)
        if window is None:
            if len(self._windows) >= self._max_symbols:
                oldest = next(iter(self._windows))
                self._windows.pop(oldest)
                self._latest.pop(oldest, None)
            window = deque(maxlen=self._window_size)
            self._windows[symbol] = window
        return window

    def compute(self, values: list[float]) -> dict[str, Any] | None:
        count = len(values)
        if count < 2:
            return None
        times = list(range(1, count + 1))
        sum_t = sum(times)
        sum_x = sum(values)
        sum_tt = sum(t * t for t in times)
        sum_tx = sum(t * x for t, x in zip(times, values))

        denominator = count * sum_tt - sum_t * sum_t
        if denominator == 0:
            return None
        slope = (count * sum_tx - sum_t * sum_x) / denominator
        intercept = (sum_x - slope * sum_t) / count

        mean = sum_x / count
        residual_sum = sum((x - (slope * t + intercept)) ** 2
                           for t, x in zip(times, values))
        total_sum = sum((x - mean) ** 2 for x in values)

        return {
            "slope": round(slope, 10),
            "intercept": round(intercept, 8),
            "predicted_next_price": round(slope * (count + 1) + intercept, 8),
            "sse": round(residual_sum, 10),
            "sst": round(total_sum, 10),
        }

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        close = _to_float(inner.get("close"))
        if not symbol or close is None:
            return

        window = self._window_for(str(symbol))
        window.append(close)
        if len(window) < self._window_size:
            return

        result = self.compute(list(window))
        if result is None:
            return
        self._latest[str(symbol)] = result["slope"]
        self.calculations += 1

        body: dict[str, Any] = {"symbol": symbol, **result,
                                "window_size": self._window_size}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"symbols": len(self._windows), "calculations": self.calculations,
                   "window_size": self._window_size, "latest_slope": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_WARMING_UP, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="calculations=%d" % self.calculations,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "windows": {k: list(v) for k, v in self._windows.items()},
                "calculations": self.calculations}

    async def restore(self, state: dict[str, Any]) -> None:
        size = self._window_size or None
        self._windows = {k: deque(v, maxlen=size or len(v))
                         for k, v in (state.get("windows") or {}).items()}
        self.calculations = int(state.get("calculations", 0))
