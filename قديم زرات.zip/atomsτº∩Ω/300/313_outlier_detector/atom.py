from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "stats.z_score_calculated"
EVENT_OUT = "stats.outlier_detected"

SEVERITY_MODERATE = "MODERATE"
SEVERITY_SEVERE = "SEVERE"
SEVERITY_EXTREME = "EXTREME"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_Z_SCORES_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._threshold = 0.0
        self._severe_multiple = 0.0
        self._extreme_multiple = 0.0
        self._checked = 0
        self._per_symbol: dict[str, int] = {}
        self.outliers_detected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._threshold = float(cfg["outlier_threshold"])
        self._severe_multiple = float(cfg["severe_multiple"])
        self._extreme_multiple = float(cfg["extreme_multiple"])
        context.subscribe(EVENT_IN, self._on_z_score)
        self._initialized = True
        context.logger.info("313 initialised (threshold=%.2f)", self._threshold)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("313 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("313 stopped (outliers=%d)",
                                      self.outliers_detected)

    async def shutdown(self) -> None:
        await self.stop()

    def severity_of(self, z_score: float) -> str:
        magnitude = abs(z_score)
        if magnitude >= self._threshold * self._extreme_multiple:
            return SEVERITY_EXTREME
        if magnitude >= self._threshold * self._severe_multiple:
            return SEVERITY_SEVERE
        return SEVERITY_MODERATE

    async def _on_z_score(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        z_score = _to_float(payload.get("z_score"))
        if not symbol or z_score is None:
            return
        self._checked += 1
        if abs(z_score) <= self._threshold:
            return

        severity = self.severity_of(z_score)
        self.outliers_detected += 1
        key = str(symbol)
        self._per_symbol[key] = self._per_symbol.get(key, 0) + 1

        body: dict[str, Any] = {
            "symbol": symbol, "price": _to_float(payload.get("close_price")),
            "z_score": z_score, "threshold": self._threshold,
            "severity": severity,
            "direction": "ABOVE" if z_score > 0 else "BELOW",
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        self._context.logger.warning("313 outlier on %s: z=%.2f (%s)",
                                     symbol, z_score, severity)
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"checked": self._checked, "outliers": self.outliers_detected,
                   "threshold": self._threshold, "per_symbol": dict(self._per_symbol)}
        if self._checked == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="checked=%d outliers=%d" % (
                                self._checked, self.outliers_detected),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "checked": self._checked,
                "outliers": self.outliers_detected,
                "per_symbol": dict(self._per_symbol)}

    async def restore(self, state: dict[str, Any]) -> None:
        self._checked = int(state.get("checked", 0))
        self.outliers_detected = int(state.get("outliers", 0))
        self._per_symbol = {str(k): int(v)
                            for k, v in (state.get("per_symbol") or {}).items()}
