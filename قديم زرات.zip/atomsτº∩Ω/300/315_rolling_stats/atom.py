from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "stats.rolling_stats_updated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_INCOMPLETE = "AWAITING_FULL_SET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._sources: dict[str, list[str]] = {}
        self._required: list[str] = []
        self._max_symbols = 0
        self._bundles: dict[str, dict[str, Any]] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._sources = {str(k): [str(f) for f in v]
                         for k, v in dict(cfg["sources"]).items()}
        self._required = [str(f) for f in cfg["required_fields"]]
        self._max_symbols = int(cfg["max_symbols"])
        for event_name in self._sources:
            context.subscribe(event_name, self._make_collector(event_name))
        self._initialized = True
        context.logger.info("315 initialised over %d sources", len(self._sources))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("315 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("315 stopped (published=%d)",
                                      self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _make_collector(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._collect(event_name, payload)
        return handler

    async def _collect(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        key = str(symbol)

        bundle = self._bundles.get(key)
        if bundle is None:
            if len(self._bundles) >= self._max_symbols:
                self._bundles.pop(next(iter(self._bundles)))
            bundle = {}
            self._bundles[key] = bundle

        for field in self._sources.get(event_name, ()):
            value = _to_float(payload.get(field))
            if value is not None:
                bundle[field] = value

        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            bundle["timestamp"] = stamp

        missing = [f for f in self._required if f not in bundle]
        if missing:
            return

        self.published_count += 1
        body: dict[str, Any] = {"symbol": symbol,
                                **{f: bundle[f] for f in self._required}}
        if "timestamp" in bundle:
            body["timestamp"] = bundle["timestamp"]
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        incomplete = {k: [f for f in self._required if f not in v]
                      for k, v in self._bundles.items()}
        incomplete = {k: v for k, v in incomplete.items() if v}
        details = {"symbols": len(self._bundles), "published": self.published_count,
                   "sources": len(self._sources), "incomplete": incomplete}
        if self.published_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_INCOMPLETE, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="symbols=%d published=%d" % (
                                len(self._bundles), self.published_count),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "bundles": dict(self._bundles),
                "published": self.published_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._bundles = dict(state.get("bundles") or {})
        self.published_count = int(state.get("published", 0))
