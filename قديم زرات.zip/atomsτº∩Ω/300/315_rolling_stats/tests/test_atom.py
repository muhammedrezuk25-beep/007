from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom315"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 315

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name=None):
    target = name or MODULE.EVENT_OUT
    return [p for n, p in ctx.published if n == target]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    """The whole section stamps from the candle it derives from. A stat read
    at publish time would be dated later than its own evidence, and 318
    measures period gaps on those stamps."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 315


def test_it_makes_no_trading_decision():
    """Article 4 of the section paper: zero trading logic here. Checked on
    whole words, because 'ordered' is a sorted list and not an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("BUY", "SELL", "execution.", "decision.",
                      "trading.", "risk."):
        assert forbidden not in src
    import re as _re
    assert not _re.search(r"\border\b", src)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


_FULL = {"mean": 100.0, "std_dev": 5.0, "z_score": 1.2, "skewness": 0.3,
         "kurtosis": 0.1, "r_squared": 0.8, "slope": 2.0}

_SOURCE_OF = {"mean": "stats.mean_calculated", "std_dev": "stats.std_dev_calculated",
              "z_score": "stats.z_score_calculated",
              "skewness": "stats.skewness_calculated",
              "kurtosis": "stats.kurtosis_calculated",
              "r_squared": "stats.r_squared_calculated",
              "slope": "stats.regression_calculated"}


async def _send(ctx, field, value, symbol="NQ", at=TS):
    await ctx.handlers[_SOURCE_OF[field]]({"symbol": symbol, field: value,
                                            "timestamp": at})


async def _complete(ctx, symbol="NQ", at=TS, **over):
    values = {**_FULL, **over}
    for field, value in values.items():
        await _send(ctx, field, value, symbol, at)


@pytest.mark.asyncio
async def test_it_publishes_only_when_the_set_is_complete():
    atom, ctx = await _ready()
    for field in ("mean", "std_dev", "z_score"):
        await _send(ctx, field, _FULL[field])
    assert out(ctx) == []
    await _complete(ctx)
    assert len(out(ctx)) >= 1


@pytest.mark.asyncio
async def test_the_bundle_carries_every_required_field():
    atom, ctx = await _ready()
    await _complete(ctx)
    bundle = out(ctx)[-1]
    for field in CONFIG["required_fields"]:
        assert field in bundle


@pytest.mark.asyncio
async def test_it_collects_and_never_recomputes():
    """Recomputing here would duplicate nine atoms. Every number it emits
    arrived in an event."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for maths in ("sqrt", "** 2", "** 3", "** 4", "sum("):
        assert maths not in src


@pytest.mark.asyncio
async def test_two_symbols_keep_separate_bundles():
    atom, ctx = await _ready()
    await _complete(ctx, symbol="A")
    await _complete(ctx, symbol="B", mean=999.0)
    values = {p["symbol"]: p["mean"] for p in out(ctx)}
    assert values["A"] == 100.0 and values["B"] == 999.0


@pytest.mark.asyncio
async def test_a_payload_without_a_symbol_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers["stats.mean_calculated"]({"mean": 100.0})
    assert out(ctx) == []
