from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom316"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 316

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name=None):
    target = name or MODULE.EVENT_OUT
    return [p for n, p in ctx.published if n == target]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    """The whole section stamps from the candle it derives from. A stat read
    at publish time would be dated later than its own evidence, and 318
    measures period gaps on those stamps."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 316


def test_it_makes_no_trading_decision():
    """Article 4 of the section paper: zero trading logic here. Checked on
    whole words, because 'ordered' is a sorted list and not an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("BUY", "SELL", "execution.", "decision.",
                      "trading.", "risk."):
        assert forbidden not in src
    import re as _re
    assert not _re.search(r"\border\b", src)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _std(ctx, value, symbol="NQ", at=TS):
    await ctx.handlers[MODULE.EVENT_STD]({"symbol": symbol, "std_dev": value,
                                           "timestamp": at})


@pytest.mark.asyncio
async def test_a_variance_jump_is_reported():
    atom, ctx = await _ready(history_size=4, variance_ratio_limit=2.0)
    for _ in range(3):
        await _std(ctx, 1.0)
    await _std(ctx, 10.0)
    alerts = out(ctx)
    assert alerts
    assert alerts[0]["alert_type"] == MODULE.ALERT_VARIANCE_UNSTABLE


@pytest.mark.asyncio
async def test_a_steady_variance_raises_nothing():
    atom, ctx = await _ready(history_size=4, variance_ratio_limit=2.0)
    for _ in range(6):
        await _std(ctx, 1.0)
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_a_weak_model_fit_is_reported():
    atom, ctx = await _ready(min_r_squared=0.2)
    await ctx.handlers[MODULE.EVENT_R2]({"symbol": "NQ", "r_squared": 0.05,
                                          "timestamp": TS})
    assert out(ctx)[0]["alert_type"] == MODULE.ALERT_MODEL_WEAK


@pytest.mark.asyncio
async def test_a_distribution_change_is_reported_once_per_shape():
    atom, ctx = await _ready()
    for kind in ("NORMAL", "LEPTOKURTIC", "LEPTOKURTIC"):
        await ctx.handlers[MODULE.EVENT_DISTRIBUTION](
            {"symbol": "NQ", "distribution_type": kind, "timestamp": TS})
    shifts = [a for a in out(ctx) if a["alert_type"] == MODULE.ALERT_DISTRIBUTION_SHIFT]
    assert len(shifts) == 1


@pytest.mark.asyncio
async def test_a_standing_problem_is_reported_once():
    """Edge triggered: an unstable variance that persists must not fill the
    log with the same line every candle."""
    atom, ctx = await _ready(min_r_squared=0.2)
    for _ in range(5):
        await ctx.handlers[MODULE.EVENT_R2]({"symbol": "NQ", "r_squared": 0.05,
                                              "timestamp": TS})
    assert len(out(ctx)) == 1


@pytest.mark.asyncio
async def test_a_recovered_metric_can_alert_again():
    atom, ctx = await _ready(min_r_squared=0.2)
    await ctx.handlers[MODULE.EVENT_R2]({"symbol": "NQ", "r_squared": 0.05, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_R2]({"symbol": "NQ", "r_squared": 0.9, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_R2]({"symbol": "NQ", "r_squared": 0.05, "timestamp": TS})
    assert len(out(ctx)) == 2
