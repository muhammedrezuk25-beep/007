from __future__ import annotations

from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_STD = "stats.std_dev_calculated"
EVENT_R2 = "stats.r_squared_calculated"
EVENT_DISTRIBUTION = "stats.distribution_type_identified"
EVENT_OUT = "stats.quality_alert"

ALERT_VARIANCE_UNSTABLE = "VARIANCE_UNSTABLE"
ALERT_MODEL_WEAK = "MODEL_FIT_WEAK"
ALERT_DISTRIBUTION_SHIFT = "DISTRIBUTION_SHIFT"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_STATISTICS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._history_size = 0
        self._variance_ratio_limit = 0.0
        self._min_r_squared = 0.0
        self._std_history: dict[str, deque] = {}
        self._distribution: dict[str, str] = {}
        self._raised: set[str] = set()
        self._checked = 0
        self.alerts_raised = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._history_size = int(cfg["history_size"])
        self._variance_ratio_limit = float(cfg["variance_ratio_limit"])
        self._min_r_squared = float(cfg["min_r_squared"])
        context.subscribe(EVENT_STD, self._on_std)
        context.subscribe(EVENT_R2, self._on_r_squared)
        context.subscribe(EVENT_DISTRIBUTION, self._on_distribution)
        self._initialized = True
        context.logger.info("316 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("316 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("316 stopped (alerts=%d)", self.alerts_raised)

    async def shutdown(self) -> None:
        await self.stop()

    async def _raise(self, key: str, alert_type: str, symbol: str, metric: str,
                     current: float | str, threshold: float | str,
                     payload: dict[str, Any]) -> None:
        if self._context is None or key in self._raised:
            return
        self._raised.add(key)
        self.alerts_raised += 1
        body: dict[str, Any] = {
            "alert_type": alert_type, "symbol": symbol, "metric": metric,
            "current_value": current, "threshold": threshold,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        self._context.logger.warning("316 %s on %s: %s=%s", alert_type, symbol,
                                     metric, current)
        await self._context.publish(EVENT_OUT, body)

    async def _on_std(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        std_dev = _to_float(payload.get("std_dev"))
        if not symbol or std_dev is None:
            return
        key = str(symbol)
        history = self._std_history.get(key)
        if history is None:
            history = deque(maxlen=self._history_size)
            self._std_history[key] = history
        history.append(std_dev)
        self._checked += 1

        if len(history) < self._history_size:
            return
        baseline = sum(list(history)[:-1]) / (len(history) - 1)
        if baseline <= 0:
            return
        ratio = std_dev / baseline
        alert_key = "%s:%s" % (ALERT_VARIANCE_UNSTABLE, key)
        if ratio > self._variance_ratio_limit or ratio < 1.0 / self._variance_ratio_limit:
            await self._raise(alert_key, ALERT_VARIANCE_UNSTABLE, key,
                              "std_dev_ratio", round(ratio, 4),
                              self._variance_ratio_limit, payload)
        else:
            self._raised.discard(alert_key)

    async def _on_r_squared(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        r_squared = _to_float(payload.get("r_squared"))
        if not symbol or r_squared is None:
            return
        self._checked += 1
        alert_key = "%s:%s" % (ALERT_MODEL_WEAK, symbol)
        if r_squared < self._min_r_squared:
            await self._raise(alert_key, ALERT_MODEL_WEAK, str(symbol),
                              "r_squared", round(r_squared, 6),
                              self._min_r_squared, payload)
        else:
            self._raised.discard(alert_key)

    async def _on_distribution(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        kind = payload.get("distribution_type")
        if not symbol or not kind:
            return
        key = str(symbol)
        self._checked += 1
        previous = self._distribution.get(key)
        self._distribution[key] = str(kind)
        if previous is not None and previous != kind:
            self._raised.discard("%s:%s" % (ALERT_DISTRIBUTION_SHIFT, key))
            await self._raise("%s:%s:%s" % (ALERT_DISTRIBUTION_SHIFT, key, kind),
                              ALERT_DISTRIBUTION_SHIFT, key, "distribution_type",
                              str(kind), previous, payload)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"checked": self._checked, "alerts": self.alerts_raised,
                   "open_alerts": sorted(self._raised),
                   "distributions": dict(self._distribution)}
        if self._checked == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        if self._raised:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="%d open quality alerts" % len(self._raised),
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="checked=%d" % self._checked, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "checked": self._checked,
                "alerts": self.alerts_raised, "raised": sorted(self._raised),
                "distribution": dict(self._distribution)}

    async def restore(self, state: dict[str, Any]) -> None:
        self._checked = int(state.get("checked", 0))
        self.alerts_raised = int(state.get("alerts", 0))
        self._raised = set(state.get("raised") or [])
        self._distribution = dict(state.get("distribution") or {})
