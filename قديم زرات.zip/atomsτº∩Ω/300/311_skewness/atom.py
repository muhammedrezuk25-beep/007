from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "stats.skewness_calculated"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_WARMING_UP = "WINDOW_NOT_FULL"

_MIN_SAMPLE = 3
_THIRD_MOMENT = 3


_PRIMARY = "skewness"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


BIAS_POSITIVE = "POSITIVE_TAIL"
BIAS_NEGATIVE = "NEGATIVE_TAIL"
BIAS_SYMMETRIC = "SYMMETRIC"



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._window_size = 0
        self._max_symbols = 0
        self._windows: dict[str, deque] = {}
        self._latest: dict[str, Any] = {}
        self.calculations = 0
        self._symmetry_band = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._window_size = int(cfg["window_size"])
        self._max_symbols = int(cfg["max_symbols"])
        self._symmetry_band = float(cfg["symmetry_band"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        self._initialized = True
        context.logger.info("311 initialised (window=%d)", self._window_size)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("311 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("311 stopped (calculations=%d)",
                                      self.calculations)

    async def shutdown(self) -> None:
        await self.stop()

    def _window_for(self, symbol: str) -> deque:
        window = self._windows.get(symbol)
        if window is None:
            if len(self._windows) >= self._max_symbols:
                oldest = next(iter(self._windows))
                self._windows.pop(oldest)
                self._latest.pop(oldest, None)
            window = deque(maxlen=self._window_size)
            self._windows[symbol] = window
        return window

    def compute(self, values: list[float]) -> dict[str, Any] | None:
        count = len(values)
        if count < _MIN_SAMPLE:
            return None
        mean = sum(values) / count
        variance = sum((v - mean) ** 2 for v in values) / count
        if variance <= 0:
            return None
        std_dev = math.sqrt(variance)
        skewness = sum((v - mean) ** _THIRD_MOMENT for v in values) / count / (std_dev ** _THIRD_MOMENT)
        if skewness > self._symmetry_band:
            bias = BIAS_POSITIVE
        elif skewness < -self._symmetry_band:
            bias = BIAS_NEGATIVE
        else:
            bias = BIAS_SYMMETRIC
        return {"skewness": round(skewness, 8), "distribution_bias": bias}

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        close = _to_float(inner.get("close"))
        if not symbol or close is None:
            return

        window = self._window_for(str(symbol))
        window.append(close)
        if len(window) < self._window_size:
            return

        result = self.compute(list(window))
        if result is None:
            return
        self._latest[str(symbol)] = result.get(_PRIMARY)
        self.calculations += 1

        body: dict[str, Any] = {"symbol": symbol, **result,
                                "window_size": self._window_size}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"symbols": len(self._windows), "calculations": self.calculations,
                   "window_size": self._window_size, "latest": dict(self._latest)}
        if self.calculations == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_WARMING_UP, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="symbols=%d calculations=%d" % (
                                len(self._windows), self.calculations),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION,
                "windows": {k: list(v) for k, v in self._windows.items()},
                "calculations": self.calculations}

    async def restore(self, state: dict[str, Any]) -> None:
        size = self._window_size or None
        self._windows = {k: deque(v, maxlen=size or len(v))
                         for k, v in (state.get("windows") or {}).items()}
        self.calculations = int(state.get("calculations", 0))
