from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "stats.rolling_stats_updated"
EVENT_OUT = "stats.period_comparison"

SHIFT_NONE = "STABLE"
SHIFT_MINOR = "MINOR_SHIFT"
SHIFT_STRUCTURAL = "STRUCTURAL_SHIFT"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_PREVIOUS = "AWAITING_SECOND_PERIOD"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._compared_fields: list[str] = []
        self._minor_change_pct = 0.0
        self._structural_change_pct = 0.0
        self._period_gap_s = 0.0
        self._max_symbols = 0
        self._previous: dict[str, dict[str, Any]] = {}
        self._latest_verdict: dict[str, str] = {}
        self.comparisons = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._compared_fields = [str(f) for f in cfg["compared_fields"]]
        self._minor_change_pct = float(cfg["minor_change_pct"])
        self._structural_change_pct = float(cfg["structural_change_pct"])
        self._period_gap_s = float(cfg["period_gap_s"])
        self._max_symbols = int(cfg["max_symbols"])
        context.subscribe(EVENT_IN, self._on_rolling)
        self._initialized = True
        context.logger.info("318 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("318 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("318 stopped (comparisons=%d)", self.comparisons)

    async def shutdown(self) -> None:
        await self.stop()

    def verdict_for(self, changes: dict[str, float]) -> str:
        if not changes:
            return SHIFT_NONE
        worst = max(abs(v) for v in changes.values())
        if worst >= self._structural_change_pct:
            return SHIFT_STRUCTURAL
        if worst >= self._minor_change_pct:
            return SHIFT_MINOR
        return SHIFT_NONE

    async def _on_rolling(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        stamp = _to_float(payload.get("timestamp"))
        if not symbol or stamp is None:
            return
        key = str(symbol)

        previous = self._previous.get(key)
        if previous is None:
            if len(self._previous) >= self._max_symbols:
                self._previous.pop(next(iter(self._previous)))
            self._previous[key] = dict(payload)
            return

        elapsed = stamp - _to_float(previous.get("timestamp"))
        if elapsed < self._period_gap_s:
            return

        changes: dict[str, float] = {}
        for field in self._compared_fields:
            now_value = _to_float(payload.get(field))
            past_value = _to_float(previous.get(field))
            if now_value is None or past_value is None or past_value == 0:
                continue
            changes[field] = round((now_value - past_value) / abs(past_value) * 100.0, 4)

        verdict = self.verdict_for(changes)
        self._latest_verdict[key] = verdict
        self._previous[key] = dict(payload)
        self.comparisons += 1

        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "verdict": verdict, "changes_pct": changes,
            "period_seconds": round(elapsed, 3), "timestamp": stamp})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"comparisons": self.comparisons, "tracked": len(self._previous),
                   "verdicts": dict(self._latest_verdict)}
        if self.comparisons == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_PREVIOUS, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="comparisons=%d" % self.comparisons,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "previous": dict(self._previous),
                "comparisons": self.comparisons}

    async def restore(self, state: dict[str, Any]) -> None:
        self._previous = dict(state.get("previous") or {})
        self.comparisons = int(state.get("comparisons", 0))
