from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_SKEW = "stats.skewness_calculated"
EVENT_KURT = "stats.kurtosis_calculated"
EVENT_OUT = "stats.distribution_type_identified"

TYPE_NORMAL = "NORMAL"
TYPE_LEPTOKURTIC = "LEPTOKURTIC"
TYPE_PLATYKURTIC = "PLATYKURTIC"
TYPE_SKEWED_POSITIVE = "SKEWED_POSITIVE"
TYPE_SKEWED_NEGATIVE = "SKEWED_NEGATIVE"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_PAIR = "AWAITING_SKEW_AND_KURTOSIS"

_EPSILON = 1e-9


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._skew_band = 0.0
        self._kurtosis_band = 0.0
        self._max_symbols = 0
        self._skewness: dict[str, float] = {}
        self._kurtosis: dict[str, float] = {}
        self._latest: dict[str, str] = {}
        self.classifications = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._skew_band = float(cfg["symmetry_band"])
        self._kurtosis_band = float(cfg["normal_kurtosis_band"])
        self._max_symbols = int(cfg["max_symbols"])
        context.subscribe(EVENT_SKEW, self._on_skewness)
        context.subscribe(EVENT_KURT, self._on_kurtosis)
        self._initialized = True
        context.logger.info("314 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("314 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("314 stopped (classifications=%d)",
                                      self.classifications)

    async def shutdown(self) -> None:
        await self.stop()

    def _trim(self, store: dict) -> None:
        while len(store) > self._max_symbols:
            store.pop(next(iter(store)))

    def classify(self, skewness: float, kurtosis: float) -> tuple[str, float]:
        symmetric = abs(skewness) <= self._skew_band
        mesokurtic = abs(kurtosis) <= self._kurtosis_band
        if symmetric and mesokurtic:
            return TYPE_NORMAL, 1.0 - max(abs(skewness) / max(self._skew_band, _EPSILON),
                                          abs(kurtosis) / max(self._kurtosis_band, _EPSILON))
        if not symmetric and abs(skewness) >= abs(kurtosis):
            kind = TYPE_SKEWED_POSITIVE if skewness > 0 else TYPE_SKEWED_NEGATIVE
            return kind, min(abs(skewness) / max(self._skew_band, _EPSILON) - 1.0, 1.0)
        kind = TYPE_LEPTOKURTIC if kurtosis > 0 else TYPE_PLATYKURTIC
        return kind, min(abs(kurtosis) / max(self._kurtosis_band, _EPSILON) - 1.0, 1.0)

    async def _on_skewness(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        value = _to_float(payload.get("skewness"))
        if not symbol or value is None:
            return
        self._skewness[str(symbol)] = value
        self._trim(self._skewness)
        await self._emit(str(symbol), payload)

    async def _on_kurtosis(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        symbol = payload.get("symbol")
        value = _to_float(payload.get("kurtosis"))
        if not symbol or value is None:
            return
        self._kurtosis[str(symbol)] = value
        self._trim(self._kurtosis)
        await self._emit(str(symbol), payload)

    async def _emit(self, symbol: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        skewness = self._skewness.get(symbol)
        kurtosis = self._kurtosis.get(symbol)
        if skewness is None or kurtosis is None:
            return

        kind, confidence = self.classify(skewness, kurtosis)
        self._latest[symbol] = kind
        self.classifications += 1

        body: dict[str, Any] = {
            "symbol": symbol, "distribution_type": kind,
            "confidence": round(max(0.0, min(confidence, 1.0)), 6),
            "skewness": skewness, "kurtosis": kurtosis,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"classifications": self.classifications,
                   "symbols": len(self._latest), "latest": dict(self._latest)}
        if self.classifications == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_PAIR, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="classifications=%d" % self.classifications,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "skewness": dict(self._skewness),
                "kurtosis": dict(self._kurtosis),
                "classifications": self.classifications}

    async def restore(self, state: dict[str, Any]) -> None:
        self._skewness = dict(state.get("skewness") or {})
        self._kurtosis = dict(state.get("kurtosis") or {})
        self.classifications = int(state.get("classifications", 0))
