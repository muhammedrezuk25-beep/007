from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom314"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 314

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name=None):
    target = name or MODULE.EVENT_OUT
    return [p for n, p in ctx.published if n == target]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    """The whole section stamps from the candle it derives from. A stat read
    at publish time would be dated later than its own evidence, and 318
    measures period gaps on those stamps."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 314


def test_it_makes_no_trading_decision():
    """Article 4 of the section paper: zero trading logic here. Checked on
    whole words, because 'ordered' is a sorted list and not an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("BUY", "SELL", "execution.", "decision.",
                      "trading.", "risk."):
        assert forbidden not in src
    import re as _re
    assert not _re.search(r"\border\b", src)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _shape(ctx, skewness, kurtosis, symbol="NQ", at=TS):
    await ctx.handlers[MODULE.EVENT_SKEW]({"symbol": symbol, "skewness": skewness,
                                            "timestamp": at})
    await ctx.handlers[MODULE.EVENT_KURT]({"symbol": symbol, "kurtosis": kurtosis,
                                            "timestamp": at})


@pytest.mark.asyncio
async def test_a_symmetric_thin_shape_is_normal():
    atom, ctx = await _ready(symmetry_band=0.5, normal_kurtosis_band=1.0)
    await _shape(ctx, 0.1, 0.2)
    assert out(ctx)[-1]["distribution_type"] == MODULE.TYPE_NORMAL


@pytest.mark.asyncio
async def test_fat_tails_read_leptokurtic():
    atom, ctx = await _ready(symmetry_band=0.5, normal_kurtosis_band=1.0)
    await _shape(ctx, 0.1, 4.0)
    assert out(ctx)[-1]["distribution_type"] == MODULE.TYPE_LEPTOKURTIC


@pytest.mark.asyncio
async def test_a_lopsided_shape_reads_skewed():
    atom, ctx = await _ready(symmetry_band=0.5, normal_kurtosis_band=1.0)
    await _shape(ctx, 3.0, 0.2)
    assert out(ctx)[-1]["distribution_type"] == MODULE.TYPE_SKEWED_POSITIVE


@pytest.mark.asyncio
async def test_it_waits_for_both_moments():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_SKEW]({"symbol": "NQ", "skewness": 0.1})
    assert out(ctx) == []


@pytest.mark.asyncio
async def test_confidence_stays_inside_the_unit_range():
    atom, ctx = await _ready()
    await _shape(ctx, 50.0, 50.0)
    assert 0.0 <= out(ctx)[-1]["confidence"] <= 1.0
