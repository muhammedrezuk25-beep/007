from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_BUILT = "execution.order.built"
EVENT_CONFIRMED = "execution.confirmed"
EVENT_OUT = "execution.latency_measured"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ROUNDTRIP = "NO_ROUNDTRIP_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._memory_limit = 0
        self._slow_threshold_s = 0.0
        self._sent: dict[str, dict[str, Any]] = {}
        self._order: list[str] = []
        self.measured_count = 0
        self.slow_count = 0
        self._total_s = 0.0
        self._worst_s = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._memory_limit = int(cfg["pending_orders_memory"])
        self._slow_threshold_s = float(cfg["slow_roundtrip_s"])
        context.subscribe(EVENT_BUILT, self._on_built)
        context.subscribe(EVENT_CONFIRMED, self._on_confirmed)
        self._initialized = True
        context.logger.info("566 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("566 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("566 stopped (measured=%d, slow=%d)",
                                      self.measured_count, self.slow_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_built(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        request_id = inner.get("request_id")
        sent_at = _to_float(inner.get("built_at", inner.get("timestamp")))
        if not request_id or sent_at is None:
            return
        key = str(request_id)
        if key not in self._sent:
            self._order.append(key)
        self._sent[key] = {"sent_at": sent_at, "symbol": inner.get("symbol")}
        while len(self._order) > self._memory_limit:
            self._sent.pop(self._order.pop(0), None)

    async def _on_confirmed(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        request_id = payload.get("request_id")
        arrived = _to_float(payload.get("timestamp"))
        if not request_id or arrived is None:
            return
        entry = self._sent.pop(str(request_id), None)
        if entry is None:
            return
        if str(request_id) in self._order:
            self._order.remove(str(request_id))

        elapsed = round(arrived - entry["sent_at"], 6)
        if elapsed < 0:
            return

        self.measured_count += 1
        self._total_s += elapsed
        if elapsed > self._worst_s:
            self._worst_s = elapsed
        slow = elapsed >= self._slow_threshold_s
        if slow:
            self.slow_count += 1
            self._context.logger.warning("566 slow roundtrip %.3fs on %s",
                                         elapsed, entry.get("symbol"))

        await self._context.publish(EVENT_OUT, {
            "request_id": request_id, "symbol": entry.get("symbol"),
            "latency_s": elapsed, "slow": slow, "timestamp": arrived})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        average = round(self._total_s / self.measured_count, 6) if self.measured_count else 0.0
        details = {"measured": self.measured_count, "slow": self.slow_count,
                   "pending": len(self._sent), "average_s": average,
                   "worst_s": self._worst_s}
        if self.measured_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ROUNDTRIP, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="measured=%d avg=%.3fs" % (self.measured_count, average),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "measured": self.measured_count,
                "slow": self.slow_count, "total_s": self._total_s,
                "worst_s": self._worst_s}

    async def restore(self, state: dict[str, Any]) -> None:
        self.measured_count = int(state.get("measured", 0))
        self.slow_count = int(state.get("slow", 0))
        self._total_s = float(state.get("total_s", 0.0))
        self._worst_s = float(state.get("worst_s", 0.0))
