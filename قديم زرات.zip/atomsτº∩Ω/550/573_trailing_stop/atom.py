"""
573 — الوقف المتحرّك (Trailing Stop) — قسم 570

يلاحق السعرَ بمسافة، ولا يتراجع أبدًا: الوقف الجديد يصدر فقط إن كان
أفضل من الحالي بخطوة كاملة على الأقل. المسافة إمّا ثابتة بالسعر أو
مشتقّة من التقلّب (std_dev من 153 × مضاعِف) — فسوقٌ هائجة تُبعد الوقف
وساكنةٌ تُقرّبه.

القرار من داخل الذراع نفسها كان مرفوضًا بتصميم صريح
(TRAIL: NOT_SUPPORTED_BY_DESIGN) — «الفعل في العقد والقرار عند النظام».
هذه الذرة هي ذلك النظام: تقرّر هنا، وتُرسل MODIFY_SL متتاليًا عبر 575.
"""

from __future__ import annotations

import uuid
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "trade.progress"
EVENT_IN_ENDED = "trade.progress.ended"
EVENT_IN_VOLATILITY = "analysis.volatility_calculated"
EVENT_OUT = "execution.order.modify_requested"

MODE_PRICE = "price"
MODE_STDDEV = "stddev"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_TRAILING = "TRAILING"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._activate_r = 1.0
        self._mode = MODE_STDDEV
        self._stddev_mult = 2.0
        self._trail_price = 20.0
        self._step_price = 1.0
        self._retry_interval_s = 15.0
        self._stddev: dict[str, float] = {}
        self._last_request_ts: dict[int, float] = {}
        self._warned_no_vol: set[str] = set()
        self.requests_sent = 0
        self.progress_seen = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._activate_r = float(cfg.get("activate_r", 1.0))
        self._mode = str(cfg.get("distance_mode", MODE_STDDEV))
        self._stddev_mult = float(cfg.get("stddev_mult", 2.0))
        self._trail_price = float(cfg.get("trail_price", 20.0))
        self._step_price = float(cfg.get("step_price", 1.0))
        self._retry_interval_s = float(cfg.get("retry_interval_s", 15.0))
        context.subscribe(EVENT_IN, self._on_progress)
        context.subscribe(EVENT_IN_ENDED, self._on_ended)
        context.subscribe(EVENT_IN_VOLATILITY, self._on_volatility)
        context.logger.info(
            "573 initialised (mode=%s activate_r=%.2f)", self._mode, self._activate_r)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    async def _on_volatility(self, payload: dict[str, Any]) -> None:
        symbol, std = payload.get("symbol"), _to_float(payload.get("std_dev"))
        if symbol and std is not None and std > 0:
            self._stddev[symbol] = std
            self._warned_no_vol.discard(symbol)

    async def _on_ended(self, payload: dict[str, Any]) -> None:
        ticket = payload.get("ticket")
        if ticket is not None:
            self._last_request_ts.pop(int(ticket), None)

    def _distance_for(self, symbol: str) -> float | None:
        if self._mode == MODE_PRICE:
            return self._trail_price if self._trail_price > 0 else None
        std = self._stddev.get(symbol)
        if std is None:
            return None
        return std * self._stddev_mult

    async def _on_progress(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.progress_seen += 1

        ticket = payload.get("ticket")
        side = payload.get("side")
        current = _to_float(payload.get("current_price"))
        symbol = payload.get("symbol")
        r_multiple = _to_float(payload.get("r_multiple"))
        if ticket is None or side not in ("BUY", "SELL") \
                or current is None or not symbol:
            return
        if r_multiple is None or r_multiple < self._activate_r:
            return

        dist = self._distance_for(symbol)
        if dist is None or dist <= 0:
            if symbol not in self._warned_no_vol:
                self._warned_no_vol.add(symbol)
                self._context.logger.warning(
                    "573 لا تقلّب مخزَّنًا لـ%s بعد — التتبّع مؤجّل حتى يصل "
                    "analysis.volatility_calculated", symbol)
            return

        candidate = current - dist if side == "BUY" else current + dist
        current_sl = _to_float(payload.get("stop_loss"))

        # لا يتراجع، ولا يتحرّك لأقلّ من خطوة: رشقُ تعديلاتٍ صغيرة على
        # المنصّة ضجيجٌ يستهلك حصّة الطلبات بلا حماية تُذكر.
        if current_sl is not None:
            gain = candidate - current_sl if side == "BUY" \
                else current_sl - candidate
            if gain < self._step_price:
                return
        # وقفٌ خلف السعر دومًا — بلوغه للسعر إغلاقٌ فوريّ لا تتبّع.
        sane = candidate < current if side == "BUY" else candidate > current
        if not sane:
            return

        ts = _to_float(payload.get("timestamp"))
        last = self._last_request_ts.get(int(ticket))
        if ts is not None and last is not None \
                and (ts - last) < self._retry_interval_s:
            return

        body = {
            "request_id": "tr-%s" % uuid.uuid4().hex[:12],
            "action": "MODIFY_SL",
            "ticket": int(ticket),
            "symbol": symbol,
            "account_id": payload.get("account_id"),
            "side": side,
            "stop_loss": round(candidate, 10),
            "reason": REASON_TRAILING,
            "parent_event": EVENT_IN,
        }
        if payload.get("trace_id") is not None:
            body["trace_id"] = payload["trace_id"]
        if ts is not None:
            body["timestamp"] = ts
            self._last_request_ts[int(ticket)] = ts

        await self._context.publish(EVENT_OUT, body)
        self.requests_sent += 1

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="mode=%s sent=%d" % (self._mode, self.requests_sent),
            details={"requests_sent": self.requests_sent,
                     "progress_seen": self.progress_seen,
                     "symbols_with_volatility": sorted(self._stddev)})
