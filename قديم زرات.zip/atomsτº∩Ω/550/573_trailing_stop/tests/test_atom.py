"""Tests for atom 573 - Trailing Stop."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom573"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 573

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        pass

    def of(self, name):
        return [p for n, p in self.published if n == name]


def prog(ticket=1, side="BUY", cur=110.0, sl=100.0, r=1.5, ts=TS, sym="NQ"):
    return {"ticket": ticket, "symbol": sym, "account_id": "111",
            "side": side, "current_price": cur, "stop_loss": sl,
            "r_multiple": r, "timestamp": ts, "trace_id": "T"}


async def build(**over):
    atom = MODULE.Atom()
    cfg = dict(MANIFEST["config"]); cfg.update(over)
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


@pytest.mark.asyncio
async def test_price_mode_trails_and_never_retreats():
    atom, ctx = await build(distance_mode="price", trail_price=5.0,
                            step_price=1.0, retry_interval_s=0)
    await atom._on_progress(prog(cur=110.0, sl=100.0))
    out = ctx.of("execution.order.modify_requested")
    assert out[-1]["stop_loss"] == 105.0 and out[-1]["reason"] == "TRAILING"
    # السعر تراجع — الوقف لا يتراجع معه
    await atom._on_progress(prog(cur=107.0, sl=105.0, ts=TS + 20))
    assert len(ctx.of("execution.order.modify_requested")) == 1
    # تقدّم بخطوة كاملة — يتبع
    await atom._on_progress(prog(cur=111.5, sl=105.0, ts=TS + 40))
    assert ctx.of("execution.order.modify_requested")[-1]["stop_loss"] == 106.5


@pytest.mark.asyncio
async def test_step_gate_blocks_noise():
    atom, ctx = await build(distance_mode="price", trail_price=5.0,
                            step_price=2.0, retry_interval_s=0)
    await atom._on_progress(prog(cur=110.0, sl=104.5))  # تحسّن 0.5 < خطوة 2
    assert ctx.of("execution.order.modify_requested") == []


@pytest.mark.asyncio
async def test_sell_side_mirrors():
    atom, ctx = await build(distance_mode="price", trail_price=5.0,
                            retry_interval_s=0)
    await atom._on_progress(prog(side="SELL", cur=90.0, sl=100.0))
    assert ctx.of("execution.order.modify_requested")[-1]["stop_loss"] == 95.0


@pytest.mark.asyncio
async def test_stddev_mode_waits_for_volatility_then_uses_it():
    atom, ctx = await build(distance_mode="stddev", stddev_mult=2.0,
                            retry_interval_s=0)
    await atom._on_progress(prog(cur=110.0, sl=100.0))
    assert ctx.of("execution.order.modify_requested") == []  # لا تقلّب بعد
    await atom._on_volatility({"symbol": "NQ", "std_dev": 3.0})
    await atom._on_progress(prog(cur=110.0, sl=100.0, ts=TS + 1))
    assert ctx.of("execution.order.modify_requested")[-1]["stop_loss"] == 104.0


@pytest.mark.asyncio
async def test_activation_r_and_sanity_behind_price():
    atom, ctx = await build(distance_mode="price", trail_price=5.0,
                            retry_interval_s=0, activate_r=1.0)
    await atom._on_progress(prog(r=0.5))
    assert ctx.of("execution.order.modify_requested") == []
    # مسافة أكبر من الربح كله — المرشَّح أمام السعر؟ لا: خلفه دائمًا
    atom2, ctx2 = await build(distance_mode="price", trail_price=50.0,
                              retry_interval_s=0)
    await atom2._on_progress(prog(cur=110.0, sl=None))
    reqs = ctx2.of("execution.order.modify_requested")
    assert reqs and reqs[-1]["stop_loss"] == 60.0  # خلف السعر — سليم


@pytest.mark.asyncio
async def test_retry_throttle_and_ended_purge():
    atom, ctx = await build(distance_mode="price", trail_price=5.0,
                            step_price=0.0, retry_interval_s=30)
    await atom._on_progress(prog(cur=110.0, sl=None, ts=TS))
    await atom._on_progress(prog(cur=120.0, sl=105.0, ts=TS + 5))
    assert len(ctx.of("execution.order.modify_requested")) == 1
    await atom._on_ended({"ticket": 1})
    assert atom._last_request_ts == {}
