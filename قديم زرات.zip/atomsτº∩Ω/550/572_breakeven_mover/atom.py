"""
572 — ناقل الوقف إلى التعادل (Break-even Mover) — قسم 570

القاعدة الواحدة: بلوغ الربح حدًّا معلنًا (بوحدة R) ينقل الوقف إلى سعر
الدخول (± إزاحة). «خاسرة تتحوّل متعادلة» — أرخص إدارة صفقة وأعلاها
مردودًا على إطار الدقيقة بمخاطرة 1%.

العصمة من التكرار حالةٌ لا ذاكرة: الطلب يصدر فقط إن كان الوقف الحالي
أسوأ من هدف التعادل. نُفِّذ التعديل؟ الوقف في trade.progress التالي صار
عند التعادل فيسكت الشرط من تلقائه — لا snapshot ولا عدّاد يحفظ «فعلتُها».
رُفض؟ خانقُ إعادةٍ بطابع الأحداث يمنع رشقًا على منصّة رافضة.
"""

from __future__ import annotations

import uuid
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "trade.progress"
EVENT_IN_ENDED = "trade.progress.ended"
EVENT_OUT = "execution.order.modify_requested"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_BREAKEVEN = "BREAKEVEN"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._trigger_r = 1.0
        self._offset_price = 0.0
        self._retry_interval_s = 30.0
        # آخر طلب لكل تذكرة (بطابع الحدث) — يمنع الرشق عند الرفض فقط؛
        # النجاح يُسكت الشرطَ نفسه فلا يحتاج ذاكرة.
        self._last_request_ts: dict[int, float] = {}
        self.progress_seen = 0
        self.requests_sent = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._trigger_r = float(cfg.get("trigger_r", 1.0))
        self._offset_price = float(cfg.get("offset_price", 0.0))
        self._retry_interval_s = float(cfg.get("retry_interval_s", 30.0))
        context.subscribe(EVENT_IN, self._on_progress)
        context.subscribe(EVENT_IN_ENDED, self._on_ended)
        context.logger.info(
            "572 initialised (trigger_r=%.2f offset=%.4f)",
            self._trigger_r, self._offset_price)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    async def _on_ended(self, payload: dict[str, Any]) -> None:
        ticket = payload.get("ticket")
        if ticket is not None:
            self._last_request_ts.pop(int(ticket), None)

    async def _on_progress(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.progress_seen += 1

        ticket = payload.get("ticket")
        side = payload.get("side")
        entry = _to_float(payload.get("entry_price"))
        r_multiple = _to_float(payload.get("r_multiple"))
        if ticket is None or side not in ("BUY", "SELL") or entry is None:
            return
        # بلا r لا قرار: مركز بلا وقف أصلي لا يُدار من هنا — 573 يظلّله.
        if r_multiple is None or r_multiple < self._trigger_r:
            return

        target = entry + self._offset_price if side == "BUY" \
            else entry - self._offset_price
        current_sl = _to_float(payload.get("stop_loss"))

        # «أسوأ من التعادل» بحسب الاتجاه — وإلا فالمهمّة منجزة أو متجاوَزة
        # (وقفٌ متحرّكٌ سبقنا فوق التعادل لا يُنزَل أبدًا).
        if current_sl is not None:
            done = current_sl >= target if side == "BUY" else current_sl <= target
            if done:
                return

        ts = _to_float(payload.get("timestamp"))
        last = self._last_request_ts.get(int(ticket))
        if ts is not None and last is not None \
                and (ts - last) < self._retry_interval_s:
            return

        body = {
            "request_id": "be-%s" % uuid.uuid4().hex[:12],
            "action": "MODIFY_SL",
            "ticket": int(ticket),
            "symbol": payload.get("symbol"),
            "account_id": payload.get("account_id"),
            "side": side,
            "stop_loss": round(target, 10),
            "reason": REASON_BREAKEVEN,
            "parent_event": EVENT_IN,
        }
        if payload.get("trace_id") is not None:
            body["trace_id"] = payload["trace_id"]
        if ts is not None:
            body["timestamp"] = ts
            self._last_request_ts[int(ticket)] = ts

        await self._context.publish(EVENT_OUT, body)
        self.requests_sent += 1
        self._context.logger.info(
            "572 breakeven requested ticket=%s sl→%.5f (r=%.2f)",
            ticket, target, r_multiple)

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d sent=%d" % (self.progress_seen, self.requests_sent),
            details={"progress_seen": self.progress_seen,
                     "requests_sent": self.requests_sent,
                     "trigger_r": self._trigger_r})
