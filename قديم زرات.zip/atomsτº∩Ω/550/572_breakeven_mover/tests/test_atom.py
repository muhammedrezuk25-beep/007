"""Tests for atom 572 - Break-even Mover."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom572"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 572

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        pass

    def of(self, name):
        return [p for n, p in self.published if n == name]


def progress(ticket=1, side="BUY", entry=100.0, sl=90.0, r=1.2,
             ts=TS, **extra):
    return {"ticket": ticket, "symbol": "NQ", "account_id": "111",
            "side": side, "entry_price": entry, "stop_loss": sl,
            "r_multiple": r, "timestamp": ts, "trace_id": "T", **extra}


async def build(**over):
    atom = MODULE.Atom()
    cfg = dict(MANIFEST["config"]); cfg.update(over)
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


@pytest.mark.asyncio
async def test_triggers_at_one_r_and_carries_trace():
    atom, ctx = await build()
    await atom._on_progress(progress(r=0.9))
    assert ctx.of("execution.order.modify_requested") == []
    await atom._on_progress(progress(r=1.0, ts=TS + 40))
    out = ctx.of("execution.order.modify_requested")
    assert len(out) == 1
    req = out[0]
    assert req["action"] == "MODIFY_SL" and req["stop_loss"] == 100.0
    assert req["reason"] == "BREAKEVEN" and req["trace_id"] == "T"
    assert req["parent_event"] == "trade.progress"


@pytest.mark.asyncio
async def test_state_driven_idempotency_after_platform_applied():
    atom, ctx = await build()
    await atom._on_progress(progress(r=1.5))
    assert len(ctx.of("execution.order.modify_requested")) == 1
    # المنصّة نفّذت: الوقف صار عند الدخول — الشرط يسكت من تلقائه
    await atom._on_progress(progress(r=1.6, sl=100.0, ts=TS + 100))
    assert len(ctx.of("execution.order.modify_requested")) == 1


@pytest.mark.asyncio
async def test_never_lowers_a_better_trailing_stop():
    atom, ctx = await build()
    # وقفٌ متحرّك سبقنا فوق التعادل — لا يُنزَل
    await atom._on_progress(progress(r=2.0, sl=104.0))
    assert ctx.of("execution.order.modify_requested") == []
    # والبيع مرآته
    await atom._on_progress(progress(ticket=2, side="SELL", entry=100.0,
                                     sl=96.0, r=2.0))
    assert ctx.of("execution.order.modify_requested") == []


@pytest.mark.asyncio
async def test_retry_throttle_when_rejected():
    atom, ctx = await build(retry_interval_s=30.0)
    await atom._on_progress(progress(r=1.2, ts=TS))
    await atom._on_progress(progress(r=1.2, ts=TS + 5))   # داخل الخانق
    assert len(ctx.of("execution.order.modify_requested")) == 1
    await atom._on_progress(progress(r=1.2, ts=TS + 31))  # بعده
    assert len(ctx.of("execution.order.modify_requested")) == 2


@pytest.mark.asyncio
async def test_offset_and_ended_purge():
    atom, ctx = await build(offset_price=0.5)
    await atom._on_progress(progress(r=1.2))
    assert ctx.of("execution.order.modify_requested")[0]["stop_loss"] == 100.5
    await atom._on_ended({"ticket": 1})
    assert atom._last_request_ts == {}


@pytest.mark.asyncio
async def test_no_original_stop_means_no_action():
    atom, ctx = await build()
    await atom._on_progress(progress(r=None, sl=None))
    assert ctx.of("execution.order.modify_requested") == []
