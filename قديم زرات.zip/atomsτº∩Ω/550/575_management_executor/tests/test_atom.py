"""Tests for atom 575 - Management Executor (real temp sqlite bridge)."""

from __future__ import annotations

import importlib.util
import json
import sqlite3
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom575"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 575

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []
        self.handlers: dict[str, object] = {}

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        self.handlers[name] = handler

    def of(self, name):
        return [p for n, p in self.published if n == name]


def modify(rid="m1", ticket=42, sl=105.0, **extra):
    return {"request_id": rid, "action": "MODIFY_SL", "ticket": ticket,
            "symbol": "NQ", "account_id": "111", "side": "BUY",
            "stop_loss": sl, "reason": "BREAKEVEN", "trace_id": "T",
            "timestamp": TS, **extra}


async def build(tmp_path, db_name="bridge.db"):
    atom = MODULE.Atom()
    ctx = Ctx({"db_path": str(tmp_path / db_name)})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def rows(db):
    conn = sqlite3.connect(db)
    try:
        cur = conn.execute(
            "SELECT request_id, action, symbol, side, volume, stop_loss,"
            " take_profit, ticket, params_json, status, created_at"
            " FROM commands ORDER BY id")
        return cur.fetchall()
    finally:
        conn.close()


def test_validate_request_names_every_refusal():
    v = MODULE.validate_request
    assert v({"action": "MODIFY_SL", "ticket": 1, "symbol": "NQ"})[1] == "NO_STOP_VALUE"
    assert v({"action": "MODIFY_TP", "ticket": 1, "symbol": "NQ"})[1] == "NO_TP_VALUE"
    assert v({"action": "CLOSE_PARTIAL", "ticket": 1, "symbol": "NQ"})[1] == "NO_VOLUME"
    assert v({"action": "CLOSE", "symbol": "NQ"})[1] == "NO_TICKET"
    assert v({"action": "CLOSE", "ticket": 1})[1] == "NO_SYMBOL"
    assert v({"action": "DANCE", "ticket": 1, "symbol": "NQ"})[1].startswith("UNKNOWN_ACTION")
    row, err = v({"ticket": 1, "symbol": "NQ", "request_id": "x",
                  "volume": 0.5}, default_action="CLOSE_PARTIAL")
    assert err is None and row["action"] == "CLOSE_PARTIAL"


@pytest.mark.asyncio
async def test_modify_sl_lands_in_bridge_with_exact_columns(tmp_path):
    atom, ctx = await build(tmp_path)
    await atom._on_request(modify(), None)
    db = ctx.config["db_path"]
    got = rows(db)
    assert len(got) == 1
    rid, action, sym, side, vol, sl, tp, ticket, pj, status, created = got[0]
    assert (rid, action, sym, side, ticket, status) == \
        ("m1", "MODIFY_SL", "NQ", "BUY", 42, "PENDING")
    assert sl == 105.0 and vol is None and tp is None
    assert created > 0
    params = json.loads(pj)
    assert params["reason"] == "BREAKEVEN" and params["account_id"] == "111"
    written = ctx.of("execution.management.command_written")
    assert written and written[0]["request_id"] == "m1"


@pytest.mark.asyncio
async def test_duplicate_request_id_writes_once(tmp_path):
    atom, ctx = await build(tmp_path)
    await atom._on_request(modify(), None)
    await atom._on_request(modify(), None)
    assert len(rows(ctx.config["db_path"])) == 1
    assert atom.duplicate_count == 1


@pytest.mark.asyncio
async def test_invalid_request_publishes_failed_and_writes_nothing(tmp_path):
    atom, ctx = await build(tmp_path)
    await atom._on_request({"request_id": "bad", "action": "MODIFY_SL",
                            "ticket": 9, "symbol": "NQ"}, None)
    assert rows(ctx.config["db_path"]) == []
    failed = ctx.of("execution.management.command_failed")
    assert failed and failed[0]["reason"] == "NO_STOP_VALUE"


@pytest.mark.asyncio
async def test_close_partial_default_action_from_event(tmp_path):
    atom, ctx = await build(tmp_path)
    await atom._on_request({"request_id": "p1", "ticket": 7, "symbol": "NQ",
                            "volume": 0.5, "timestamp": TS}, "CLOSE_PARTIAL")
    got = rows(ctx.config["db_path"])
    assert got[0][1] == "CLOSE_PARTIAL" and got[0][4] == 0.5


@pytest.mark.asyncio
async def test_db_failure_reports_and_allows_retry(tmp_path):
    atom, ctx = await build(tmp_path)
    atom._db_path = str(tmp_path / "no_such_dir" / "x.db")  # كتابة ستفشل
    await atom._on_request(modify(rid="r1"), None)
    failed = ctx.of("execution.management.command_failed")
    assert failed and failed[0]["reason"].startswith("DB_WRITE_FAILED")
    assert "r1" not in atom._seen  # الباب مفتوح لإعادةٍ لاحقة
    hs = await atom.health_check()
    assert hs.state.value == "degraded"
