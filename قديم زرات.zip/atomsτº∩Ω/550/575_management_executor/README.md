# 575 — منفّذ التعديل (الذراع الثانية للجسر)
يترجم `execution.order.{modify,close_partial,close}_requested` إلى صفوف
`commands` بالحالة PENDING — والإكسبرت v1.1 ينفّذ `MODIFY_SL/TP` و
`CLOSE_PARTIAL` و`CLOSE` بالاسم. انضباط 601 نفسه (WAL + busy_timeout +
إعادة محاولة على القفل + to_thread)، وإزالة تكرار بمعرّف الطلب، والغائب
يُرفض مسمًّى (`NO_STOP_VALUE`...) عبر `command_failed`. `created_at`
بساعة الجدار عمدًا — حارس البائت في الذراع يقيس عليها.
