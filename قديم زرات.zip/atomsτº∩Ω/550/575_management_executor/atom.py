"""
575 — منفّذ التعديل (Management Executor) — قسم 570

الذراع الثانية للجسر: 601 يكتب أوامر الفتح، وهذه تكتب أوامر الإدارة
(MODIFY_SL · MODIFY_TP · CLOSE_PARTIAL · CLOSE) في جدول `commands`
نفسه — والإكسبرت NQ_Arm v1.1 ينفّذها بالاسم حرفًا بحرف.

انضباط القفل منسوخ من 601 قصدًا لا سهوًا (WAL + busy_timeout +
synchronous=NORMAL + إعادة محاولة على القفل وحده + الكتابة في خيط عبر
to_thread) — الذرّتان تكتبان الملف نفسه فتلتزمان الانضباط نفسه، والمادة
تمنع الاستيراد بينهما فيُكرَّر النصّ لا يُشارَك.

`created_at` بساعة الجدار عمدًا: الإكسبرت يقيس عمر الأمر بساعته هو،
وحارس البائت فيه (InpMaxCmdAgeSec) يحكم على هذا الحقل — طابعٌ رسميّ
مزامَن هنا يظهر انحرافًا هناك (نفس منطق نبضة 601 المشروح في _now).
"""

from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import time
from collections import OrderedDict
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN_MODIFY = "execution.order.modify_requested"
EVENT_IN_PARTIAL = "execution.order.close_partial_requested"
EVENT_IN_CLOSE = "execution.order.close_requested"
EVENT_OUT_WRITTEN = "execution.management.command_written"
EVENT_OUT_FAILED = "execution.management.command_failed"

VALID_ACTIONS = ("MODIFY_SL", "MODIFY_TP", "CLOSE_PARTIAL", "CLOSE")

REASON_NOT_STARTED = "NOT_STARTED"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05
_DEDUPE_CAPACITY = 512

_SCHEMA = """
CREATE TABLE IF NOT EXISTS commands (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id   TEXT    NOT NULL,
    action       TEXT    NOT NULL,
    symbol       TEXT    NOT NULL,
    side         TEXT,
    volume       REAL,
    price        REAL,
    stop_loss    REAL,
    take_profit  REAL,
    ticket       INTEGER,
    trail_dist   REAL,
    trail_step   REAL,
    params_json  TEXT,
    status       TEXT    NOT NULL DEFAULT 'PENDING',
    result       TEXT,
    created_at   REAL    NOT NULL,
    taken_at     REAL,
    done_at      REAL
)
"""
_INDEX = "CREATE INDEX IF NOT EXISTS idx_cmd_status ON commands(status, id)"

_INSERT = """
INSERT INTO commands (request_id, action, symbol, side, volume, price,
                      stop_loss, take_profit, ticket, params_json,
                      status, created_at)
VALUES (?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, 'PENDING', ?)
"""


def _resolve_db(configured: str) -> str:
    """المسار من البيئة أولًا ثم الإعداد — NQ_BRIDGE_DB يوحّد الطرفين
    على ملفٍ واحد بلا تحرير مانيفست لكل جهاز (نفس عقد 601 و618)."""
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str) -> sqlite3.Connection:
    connection = sqlite3.connect(db_path, timeout=_DB_TIMEOUT_S)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """قفلٌ يُعاد، وخطأٌ يُرفع فورًا — القفل حالة عابرة والخطأ حقيقة."""
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            if "locked" not in str(exc) and "busy" not in str(exc):
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("lock")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def validate_request(payload: dict[str, Any],
                     default_action: str | None = None) -> tuple[dict | None, str | None]:
    """يترجم حدث طلبٍ إلى صفّ أوامر — أو يسمّي سبب الرفض. دالة نقية.

    الغائب لا يُخترع: MODIFY_SL بلا قيمة وقفٍ ليس أمرًا ناقصًا يُرمَّم،
    هو خللٌ في المسار يُعلَن (نفس عقيدة 553/601 مع الحجم).
    """
    action = str(payload.get("action") or default_action or "").upper()
    if action not in VALID_ACTIONS:
        return None, "UNKNOWN_ACTION:%s" % action
    ticket = payload.get("ticket")
    try:
        ticket = int(ticket)
    except (TypeError, ValueError):
        return None, "NO_TICKET"
    if ticket <= 0:
        return None, "NO_TICKET"
    symbol = payload.get("symbol")
    if not symbol:
        return None, "NO_SYMBOL"

    sl = _to_float(payload.get("stop_loss"))
    tp = _to_float(payload.get("take_profit"))
    volume = _to_float(payload.get("volume"))

    if action == "MODIFY_SL" and (sl is None or sl <= 0):
        return None, "NO_STOP_VALUE"
    if action == "MODIFY_TP" and (tp is None or tp <= 0):
        return None, "NO_TP_VALUE"
    if action == "CLOSE_PARTIAL" and (volume is None or volume <= 0):
        return None, "NO_VOLUME"

    row = {
        "request_id": str(payload.get("request_id") or ""),
        "action": action,
        "symbol": str(symbol),
        "side": payload.get("side"),
        "volume": volume,
        "stop_loss": sl,
        "take_profit": tp,
        "ticket": ticket,
        "params_json": json.dumps(
            {k: payload[k] for k in ("reason", "account_id", "trace_id")
             if payload.get(k) is not None},
            ensure_ascii=False) or None,
    }
    if not row["request_id"]:
        return None, "NO_REQUEST_ID"
    return row, None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._db_path = "nq_brain.db"
        self._schema_ready = False
        # آخر المعرّفات المكتوبة — إعادةُ بثٍّ لنفس الطلب لا تكتب صفّين.
        self._seen: OrderedDict[str, None] = OrderedDict()
        self.written_count = 0
        self.failed_count = 0
        self.duplicate_count = 0
        self.last_error: str | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._db_path = _resolve_db(str(context.config.get("db_path", "nq_brain.db")))
        context.subscribe(EVENT_IN_MODIFY, self._make_handler(None))
        context.subscribe(EVENT_IN_PARTIAL, self._make_handler("CLOSE_PARTIAL"))
        context.subscribe(EVENT_IN_CLOSE, self._make_handler("CLOSE"))
        context.logger.info("575 initialised (db=%s)", self._db_path)

    async def start(self) -> None:
        self._running = True
        # المخطط بأفضل جهد لا شرط إقلاع: مسارٌ خاطئ يُعلن في الصحة
        # ويُلتقط عند أول كتابة — لا يُسقط الذرة (عقيدة 601 نفسها).
        self._schema_ready = await asyncio.to_thread(self._ensure_schema)

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    def _ensure_schema(self) -> bool:
        try:
            conn = _bridge_connect(self._db_path)
            try:
                conn.execute(_SCHEMA)
                conn.execute(_INDEX)
                conn.commit()
            finally:
                conn.close()
            return True
        except Exception as exc:  # noqa: BLE001
            self.last_error = str(exc)
            return False

    def _insert(self, row: dict[str, Any]) -> None:
        def op() -> None:
            conn = _bridge_connect(self._db_path)
            try:
                conn.execute(_INSERT, (
                    row["request_id"], row["action"], row["symbol"],
                    row["side"], row["volume"], row["stop_loss"],
                    row["take_profit"], row["ticket"], row["params_json"],
                    time.time()))
                conn.commit()
            finally:
                conn.close()
        _with_retry(op)

    def _make_handler(self, default_action: str | None):
        async def handler(payload: dict[str, Any]) -> None:
            await self._on_request(payload, default_action)
        return handler

    async def _on_request(self, payload: dict[str, Any],
                          default_action: str | None) -> None:
        if not self._running or self._context is None:
            return

        row, error = validate_request(payload, default_action)
        if row is None:
            self.failed_count += 1
            self.last_error = error
            await self._context.publish(EVENT_OUT_FAILED, {
                "request_id": payload.get("request_id"),
                "reason": error,
                **_passthrough(payload),
            })
            self._context.logger.error("575 رفض طلب إدارة: %s", error)
            return

        rid = row["request_id"]
        if rid in self._seen:
            self.duplicate_count += 1
            return
        self._seen[rid] = None
        while len(self._seen) > _DEDUPE_CAPACITY:
            self._seen.popitem(last=False)

        try:
            await asyncio.to_thread(self._insert, row)
        except Exception as exc:  # noqa: BLE001 — قفلٌ استُنفدت محاولاته أو قرص
            self.failed_count += 1
            self.last_error = str(exc)
            self._seen.pop(rid, None)  # فشلُ الكتابة يفتح الباب لإعادةٍ لاحقة
            await self._context.publish(EVENT_OUT_FAILED, {
                "request_id": rid,
                "reason": "DB_WRITE_FAILED:%s" % exc,
                **_passthrough(payload),
            })
            self._context.logger.error("575 فشل كتابة أمر %s: %s", rid, exc)
            return

        self.written_count += 1
        self.last_error = None
        await self._context.publish(EVENT_OUT_WRITTEN, {
            "request_id": rid,
            "action": row["action"],
            "ticket": row["ticket"],
            "symbol": row["symbol"],
            **_passthrough(payload),
        })

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {
            "db_path": self._db_path,
            "written": self.written_count,
            "failed": self.failed_count,
            "duplicates": self.duplicate_count,
            "last_error": self.last_error,
        }
        if not self._schema_ready and self.written_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="BRIDGE_SCHEMA_UNREADY:%s" % self.last_error,
                                details=details)
        if self.last_error is not None:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=str(self.last_error), details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="written=%d" % self.written_count,
                            details=details)


def _passthrough(payload: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {"parent_event": payload.get("parent_event")}
    for key in ("trace_id", "timestamp", "account_id"):
        if payload.get(key) is not None:
            out[key] = payload[key]
    return {k: v for k, v in out.items() if v is not None}
