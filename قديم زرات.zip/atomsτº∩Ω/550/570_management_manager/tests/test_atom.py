"""Tests for atom 570 - Management Manager."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom570"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 570

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []
        self.handlers: dict[str, object] = {}

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        self.handlers[name] = handler

    def of(self, name):
        return [p for n, p in self.published if n == name]


async def build(**over):
    atom = MODULE.Atom()
    cfg = dict(MANIFEST["config"]); cfg.update(over)
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


@pytest.mark.asyncio
async def test_aggregates_counts_and_active_tickets():
    atom, ctx = await build(publish_min_interval_s=0)
    h = ctx.handlers
    await h["trade.progress"]({"ticket": 1, "symbol": "NQ", "r_multiple": 0.4,
                               "timestamp": TS})
    await h["execution.order.modify_requested"](
        {"reason": "BREAKEVEN", "timestamp": TS + 1})
    await h["execution.order.modify_requested"](
        {"reason": "TRAILING", "timestamp": TS + 2})
    await h["execution.order.close_partial_requested"]({"timestamp": TS + 3})
    await h["execution.management.command_written"]({"timestamp": TS + 4})
    await h["execution.order.blocked"](
        {"reason": "ACCOUNT_HALTED", "timestamp": TS + 5})
    last = ctx.of("execution.management.unified")[-1]
    assert last["active_tickets"] == [1]
    assert last["breakeven_requests"] == 1
    assert last["trailing_requests"] == 1
    assert last["partial_requests"] == 1
    assert last["commands_written"] == 1
    assert last["orders_blocked"] == 1
    assert last["last_reason"] == "ACCOUNT_HALTED"


@pytest.mark.asyncio
async def test_event_time_throttle():
    atom, ctx = await build(publish_min_interval_s=2.0)
    h = ctx.handlers["trade.progress"]
    await h({"ticket": 1, "timestamp": TS})
    await h({"ticket": 2, "timestamp": TS + 0.5})   # داخل الخانق — يُجمع بصمت
    assert len(ctx.of("execution.management.unified")) == 1
    await h({"ticket": 3, "timestamp": TS + 2.5})
    out = ctx.of("execution.management.unified")
    assert len(out) == 2 and out[-1]["active_tickets"] == [1, 2, 3]


@pytest.mark.asyncio
async def test_ended_forces_immediate_publish_and_removal():
    atom, ctx = await build(publish_min_interval_s=60.0)
    await ctx.handlers["trade.progress"]({"ticket": 9, "timestamp": TS})
    await ctx.handlers["trade.progress.ended"]({"ticket": 9,
                                                "timestamp": TS + 0.1})
    last = ctx.of("execution.management.unified")[-1]
    assert last["active_tickets"] == [] and last["active_count"] == 0
