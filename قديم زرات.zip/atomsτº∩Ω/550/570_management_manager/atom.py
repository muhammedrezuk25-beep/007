"""
570 — جامع قسم إدارة الصفقة (Management Manager)

نافذة القسم الواحدة: يجمع نشاط 571-575 وحاجزَ 553 الجديد في حدثٍ موحّد
`execution.management.unified` تقرؤه اللوحات (850) والمخازن — بدل أن
يشترك كلٌّ منها بخمسة أحداث ويعيد الجمع بنفسه.

يبثّ عند التغيّر فقط وبخانقٍ بطابع الأحداث — قسمٌ ساكن لا يملأ الناقل.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN_PROGRESS = "trade.progress"
EVENT_IN_ENDED = "trade.progress.ended"
EVENT_IN_MODIFY = "execution.order.modify_requested"
EVENT_IN_PARTIAL = "execution.order.close_partial_requested"
EVENT_IN_WRITTEN = "execution.management.command_written"
EVENT_IN_FAILED = "execution.management.command_failed"
EVENT_IN_BLOCKED = "execution.order.blocked"
EVENT_OUT = "execution.management.unified"

REASON_NOT_STARTED = "NOT_STARTED"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._publish_min_interval_s = 2.0
        self._active: dict[int, dict[str, Any]] = {}
        self._counts = {
            "breakeven_requests": 0,
            "trailing_requests": 0,
            "partial_requests": 0,
            "commands_written": 0,
            "commands_failed": 0,
            "orders_blocked": 0,
        }
        self._last_reason: str | None = None
        self._last_publish_ts: float | None = None
        self._dirty = False
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._publish_min_interval_s = float(
            context.config.get("publish_min_interval_s", 2.0))
        context.subscribe(EVENT_IN_PROGRESS, self._on_progress)
        context.subscribe(EVENT_IN_ENDED, self._on_ended)
        context.subscribe(EVENT_IN_MODIFY, self._count("modify"))
        context.subscribe(EVENT_IN_PARTIAL, self._count("partial"))
        context.subscribe(EVENT_IN_WRITTEN, self._count("written"))
        context.subscribe(EVENT_IN_FAILED, self._count("failed"))
        context.subscribe(EVENT_IN_BLOCKED, self._count("blocked"))
        context.logger.info("570 initialised")

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    def _count(self, kind: str):
        async def handler(payload: dict[str, Any]) -> None:
            if not self._running:
                return
            if kind == "modify":
                reason = str(payload.get("reason", ""))
                key = "trailing_requests" if reason == "TRAILING" \
                    else "breakeven_requests"
                self._counts[key] += 1
            elif kind == "partial":
                self._counts["partial_requests"] += 1
            elif kind == "written":
                self._counts["commands_written"] += 1
            elif kind == "failed":
                self._counts["commands_failed"] += 1
                self._last_reason = str(payload.get("reason"))
            elif kind == "blocked":
                self._counts["orders_blocked"] += 1
                self._last_reason = str(payload.get("reason"))
            self._dirty = True
            await self._maybe_publish(payload)
        return handler

    async def _on_progress(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        ticket = payload.get("ticket")
        if ticket is None:
            return
        self._active[int(ticket)] = {
            "symbol": payload.get("symbol"),
            "account_id": payload.get("account_id"),
            "r_multiple": payload.get("r_multiple"),
            "progress": payload.get("progress"),
        }
        self._dirty = True
        await self._maybe_publish(payload)

    async def _on_ended(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        ticket = payload.get("ticket")
        if ticket is not None and int(ticket) in self._active:
            del self._active[int(ticket)]
            self._dirty = True
        await self._maybe_publish(payload, force=True)

    async def _maybe_publish(self, trigger: dict[str, Any],
                             force: bool = False) -> None:
        if self._context is None or not self._dirty:
            return
        ts = _to_float(trigger.get("timestamp"))
        if not force and ts is not None and self._last_publish_ts is not None \
                and (ts - self._last_publish_ts) < self._publish_min_interval_s:
            return

        body: dict[str, Any] = {
            "active_count": len(self._active),
            "active_tickets": sorted(self._active),
            "tickets": {str(t): dict(v) for t, v in self._active.items()},
            **self._counts,
            "last_reason": self._last_reason,
        }
        if ts is not None:
            body["timestamp"] = ts
            self._last_publish_ts = ts
        if trigger.get("trace_id") is not None:
            body["trace_id"] = trigger["trace_id"]

        await self._context.publish(EVENT_OUT, body)
        self.published_count += 1
        self._dirty = False

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="active=%d published=%d" % (
                len(self._active), self.published_count),
            details={"active_tickets": sorted(self._active),
                     **self._counts,
                     "published": self.published_count})
