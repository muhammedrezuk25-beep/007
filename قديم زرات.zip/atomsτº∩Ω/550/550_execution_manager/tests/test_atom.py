from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom550"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 550

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic_beyond_name():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 550


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_stop_then_start_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    assert atom._running is True


@pytest.mark.asyncio
async def test_it_keeps_the_latest_state_of_each_event():
    atom, ctx = await _ready()
    await ctx.handlers["execution.order.built"]({"request_id": "r1", "symbol": "NQ"})
    await ctx.handlers["execution.confirmed"]({"request_id": "r1", "entry_price": 100.0})
    unified = out(ctx, MODULE.EVENT_OUT)[-1]
    assert set(unified["sections"]) == {"execution.order.built", "execution.confirmed"}


@pytest.mark.asyncio
async def test_it_publishes_nothing_of_its_own():
    """A collector republishes; it does not decide. Every field it emits comes
    from an event it received."""
    atom, ctx = await _ready()
    await ctx.handlers["execution.order.built"]({"request_id": "r1", "symbol": "NQ"})
    assert {n for n, _ in ctx.published} == {MODULE.EVENT_OUT}


@pytest.mark.asyncio
async def test_health_names_the_silent_sections():
    atom, ctx = await _ready()
    await ctx.handlers["execution.order.built"]({"request_id": "r1"})
    details = (await atom.health_check()).details
    assert "execution.confirmed" in details["silent"]
