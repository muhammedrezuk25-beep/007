from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_BUILT = "execution.order.built"
EVENT_CONFIRMED = "execution.confirmed"
EVENT_OUT = "execution.slippage_measured"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_FILLS = "NO_FILLS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._memory_limit = 0
        self._alert_pct = 0.0
        self._expected: dict[str, dict[str, Any]] = {}
        self._order: list[str] = []
        self.measured_count = 0
        self.unmatched_count = 0
        self._total_pct = 0.0
        self._worst_pct = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._memory_limit = int(cfg["pending_orders_memory"])
        self._alert_pct = float(cfg["alert_slippage_pct"])
        context.subscribe(EVENT_BUILT, self._on_built)
        context.subscribe(EVENT_CONFIRMED, self._on_confirmed)
        self._initialized = True
        context.logger.info("560 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("560 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("560 stopped (measured=%d)", self.measured_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_built(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        request_id = inner.get("request_id")
        reference = _to_float(inner.get("reference_price"))
        if not request_id or reference is None:
            return
        key = str(request_id)
        if key not in self._expected:
            self._order.append(key)
        self._expected[key] = {"reference": reference,
                               "account_id": inner.get("account_id"),
                               "symbol": inner.get("symbol"),
                               "side": inner.get("side")}
        while len(self._order) > self._memory_limit:
            self._expected.pop(self._order.pop(0), None)

    async def _on_confirmed(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        request_id = payload.get("request_id")
        filled = _to_float(payload.get("entry_price"))
        if filled is None or filled <= 0:
            return
        entry = self._expected.pop(str(request_id), None) if request_id else None
        if entry is None:
            self.unmatched_count += 1
            return
        if str(request_id) in self._order:
            self._order.remove(str(request_id))

        reference = entry["reference"]
        raw = filled - reference
        if str(entry.get("side", "")).upper() == "SELL":
            raw = -raw
        pct = round(raw / reference * 100.0, 6)

        self.measured_count += 1
        self._total_pct += pct
        if abs(pct) > abs(self._worst_pct):
            self._worst_pct = pct

        body: dict[str, Any] = {
            "request_id": request_id, "symbol": entry.get("symbol"),
            "side": entry.get("side"), "reference_price": reference,
            "fill_price": filled, "slippage": round(raw, 6),
            "slippage_pct": pct, "adverse": pct > 0,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        if abs(pct) >= self._alert_pct:
            self._context.logger.warning("560 slippage %.4f%% on %s",
                                         pct, entry.get("symbol"))
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        average = round(self._total_pct / self.measured_count, 6) if self.measured_count else 0.0
        details = {"measured": self.measured_count, "unmatched": self.unmatched_count,
                   "pending": len(self._expected), "average_pct": average,
                   "worst_pct": self._worst_pct}
        if self.measured_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_FILLS, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="measured=%d avg=%.4f%%" % (self.measured_count, average),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "measured": self.measured_count,
                "unmatched": self.unmatched_count, "total_pct": self._total_pct,
                "worst_pct": self._worst_pct}

    async def restore(self, state: dict[str, Any]) -> None:
        self.measured_count = int(state.get("measured", 0))
        self.unmatched_count = int(state.get("unmatched", 0))
        self._total_pct = float(state.get("total_pct", 0.0))
        self._worst_pct = float(state.get("worst_pct", 0.0))
