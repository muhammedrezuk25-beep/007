from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom560"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 560

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic_beyond_name():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 560


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_stop_then_start_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    assert atom._running is True


async def _cycle(ctx, reference, fill, side="BUY", rid="r1"):
    await ctx.handlers[MODULE.EVENT_BUILT]({
        "request_id": rid, "symbol": "NQ", "side": side,
        "reference_price": reference, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_CONFIRMED]({
        "request_id": rid, "entry_price": fill, "timestamp": TS + 1})


@pytest.mark.asyncio
async def test_a_worse_fill_on_a_buy_is_adverse():
    atom, ctx = await _ready()
    await _cycle(ctx, 100.0, 100.5)
    event = out(ctx, MODULE.EVENT_OUT)[0]
    assert event["slippage"] == 0.5
    assert event["adverse"] is True


@pytest.mark.asyncio
async def test_the_sign_flips_for_a_sell():
    """A higher fill helps a seller and hurts a buyer. Without the flip the
    same number would mean opposite things depending on side."""
    atom, ctx = await _ready()
    await _cycle(ctx, 100.0, 100.5, side="SELL")
    event = out(ctx, MODULE.EVENT_OUT)[0]
    assert event["slippage"] == -0.5
    assert event["adverse"] is False


@pytest.mark.asyncio
async def test_percentage_is_relative_to_the_reference():
    atom, ctx = await _ready()
    await _cycle(ctx, 200.0, 202.0)
    assert out(ctx, MODULE.EVENT_OUT)[0]["slippage_pct"] == 1.0


@pytest.mark.asyncio
async def test_a_fill_without_a_matching_order_is_counted_not_guessed():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_CONFIRMED]({"request_id": "never",
                                                 "entry_price": 100.0})
    assert out(ctx, MODULE.EVENT_OUT) == []
    assert atom.unmatched_count == 1


@pytest.mark.asyncio
async def test_pending_orders_are_capped():
    atom, ctx = await _ready(pending_orders_memory=3)
    for i in range(6):
        await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": f"r{i}", "symbol": "NQ",
                                                 "side": "BUY", "reference_price": 100.0})
    assert len(atom._expected) == 3


@pytest.mark.asyncio
async def test_healthy_after_a_measurement():
    atom, ctx = await _ready()
    await _cycle(ctx, 100.0, 100.1)
    assert (await atom.health_check()).state.name == "HEALTHY"
