from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom554"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 554

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic_beyond_name():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 554


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_stop_then_start_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    assert atom._running is True


@pytest.mark.asyncio
async def test_one_request_id_carries_its_whole_history():
    atom, ctx = await _ready()
    for event in (MODULE.EVENT_BUILT, MODULE.EVENT_VALIDATED,
                  MODULE.EVENT_SENT, MODULE.EVENT_CONFIRMED):
        await ctx.handlers[event]({"request_id": "r1", "symbol": "NQ", "side": "BUY"})
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["status"] == MODULE.STATUS_FILLED
    assert last["history"] == ["BUILT", "VALIDATED", "SENT", "FILLED"]


@pytest.mark.asyncio
async def test_a_rejection_carries_its_reason():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": "r1", "symbol": "NQ"})
    await ctx.handlers[MODULE.EVENT_REJECTED]({"request_id": "r1", "reason": "BAD_VOLUME"})
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["status"] == MODULE.STATUS_REJECTED
    assert last["reason"] == "BAD_VOLUME"


@pytest.mark.asyncio
async def test_an_unfinished_order_is_visible_in_health():
    """An order stuck between built and filled is the symptom of a broken
    bridge. Counting it makes the break visible."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": "r1", "symbol": "NQ"})
    assert (await atom.health_check()).details["unfinished"] == 1
    await ctx.handlers[MODULE.EVENT_CONFIRMED]({"request_id": "r1"})
    assert (await atom.health_check()).details["unfinished"] == 0


@pytest.mark.asyncio
async def test_tracked_orders_are_capped():
    atom, ctx = await _ready(tracked_orders_memory=3)
    for i in range(6):
        await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": f"r{i}", "symbol": "NQ"})
    assert len(atom._orders) == 3


@pytest.mark.asyncio
async def test_an_event_without_request_id_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"symbol": "NQ"})
    assert out(ctx, MODULE.EVENT_OUT) == []


# ── دورة حياة الأمر تُغلق عند الجسر ─────────────────────────────────

def test_the_bridge_result_is_part_of_the_lifecycle():
    """553 يرسل، و601 يكتب أو يفشل، وهذه الذرّة لم تكن تعلم أيًّا منهما.

    فالأمر يبقى في SENT إلى الأبد: لا يُغلق ولا يُعاد. وهذه ليست حالة
    نادرة — قفل القاعدة يقع، والمفتاح ينقلب."""
    for event in ("platform.brain_signal.written",
                  "platform.brain_signal.write_failed",
                  "platform.brain_signal.halted"):
        assert event in MANIFEST["subscribes"]


@pytest.mark.asyncio
async def test_a_written_order_reaches_the_platform():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": "r1", "symbol": "USTEC",
                                            "timestamp": TS})
    await ctx.handlers["platform.brain_signal.written"]({
        "request_id": "r1", "symbol": "USTEC", "timestamp": TS})
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["status"] == MODULE.STATUS_QUEUED


@pytest.mark.asyncio
async def test_a_failed_write_is_announced_as_a_rejection():
    """الفشل يُعلَن رفضًا فيدخل مسار التصنيف القائم: 561 يميّز المؤقّت من
    الدائم، و562 يعيد المؤقّت وحده.

    والتصنيف لا يقع هنا: 561 يملكه، وتكراره يعطي جوابين لسؤال واحد."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": "r2", "symbol": "USTEC",
                                            "timestamp": TS})
    await ctx.handlers["platform.brain_signal.write_failed"]({
        "request_id": "r2", "symbol": "USTEC", "reason": "database is locked",
        "timestamp": TS})
    rejected = [p for n, p in ctx.published if n == MODULE.EVENT_REJECTED]
    assert rejected
    assert rejected[-1]["request_id"] == "r2"
    assert rejected[-1]["reason"] == "database is locked"
    assert out(ctx, MODULE.EVENT_OUT)[-1]["status"] == MODULE.STATUS_REJECTED


@pytest.mark.asyncio
async def test_a_halted_write_closes_without_a_retry():
    """المفتاح قرار مالك لا عطل عابر، فلا تُطلب إعادة."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": "r3", "symbol": "USTEC",
                                            "timestamp": TS})
    await ctx.handlers["platform.brain_signal.halted"]({
        "request_id": "r3", "reason": "EMERGENCY_HALT", "timestamp": TS})
    assert out(ctx, MODULE.EVENT_OUT)[-1]["status"] == MODULE.STATUS_HALTED


@pytest.mark.asyncio
async def test_a_bridge_result_without_an_order_is_ignored():
    """نتيجة لأمر لا تعرفه هذه الذرّة ليست حالة تُتتبَّع."""
    atom, ctx = await _ready()
    await ctx.handlers["platform.brain_signal.written"]({
        "request_id": "unknown", "timestamp": TS})
    assert not out(ctx, MODULE.EVENT_OUT)
