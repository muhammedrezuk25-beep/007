from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_BUILT = "execution.order.built"
EVENT_VALIDATED = "execution.order.validated"
EVENT_REJECTED = "execution.order.rejected"
EVENT_SENT = "trading.final_decision"
EVENT_CONFIRMED = "execution.confirmed"
EVENT_OUT = "execution.order_status_tracked"

EVENT_WRITTEN = "platform.brain_signal.written"
EVENT_WRITE_FAILED = "platform.brain_signal.write_failed"
EVENT_WRITE_HALTED = "platform.brain_signal.halted"

STATUS_BUILT = "BUILT"
STATUS_VALIDATED = "VALIDATED"
STATUS_SENT = "SENT"
STATUS_FILLED = "FILLED"
STATUS_REJECTED = "REJECTED"
STATUS_QUEUED = "QUEUED"
STATUS_HALTED = "HALTED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ORDERS = "NO_ORDERS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._memory_limit = 0
        self._orders: dict[str, dict[str, Any]] = {}
        self._order_keys: list[str] = []
        self._counts: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._memory_limit = int(context.config["tracked_orders_memory"])
        for event, status in ((EVENT_BUILT, STATUS_BUILT),
                              (EVENT_VALIDATED, STATUS_VALIDATED),
                              (EVENT_SENT, STATUS_SENT),
                              (EVENT_CONFIRMED, STATUS_FILLED),
                              (EVENT_REJECTED, STATUS_REJECTED),
                              (EVENT_WRITTEN, STATUS_QUEUED),
                              (EVENT_WRITE_HALTED, STATUS_HALTED)):
            context.subscribe(event, self._make_tracker(status))
        context.subscribe(EVENT_WRITE_FAILED, self._on_write_failed)
        self._initialized = True
        context.logger.info("554 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("554 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("554 stopped (tracked=%d)", len(self._orders))

    async def shutdown(self) -> None:
        await self.stop()

    def _make_tracker(self, status: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._track(status, payload)
        return handler

    async def _on_write_failed(self, payload: dict[str, Any]) -> None:
        """A write that failed is announced as a rejection.

        It enters the classification path that already exists: 561 tells a
        passing fault from a permanent one, and 562 retries only the passing
        kind. A locked database is worth another attempt; a kill switch is
        not.

        The classification does not happen here. 561 owns it, and repeating
        the judgement in two places gives two answers to one question — and
        they drift the first time one of them changes.
        """
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        request_id = inner.get("request_id") or payload.get("request_id")
        if not request_id or str(request_id) not in self._orders:
            return
        await self._track(STATUS_REJECTED, payload)
        body = {"request_id": request_id,
                "symbol": inner.get("symbol") or self._orders[str(request_id)].get("symbol"),
                "side": inner.get("side") or self._orders[str(request_id)].get("side"),
                "reason": inner.get("reason", "BRIDGE_WRITE_FAILED")}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_REJECTED, body)

    async def _track(self, status: str, payload: dict[str, Any]) -> None:
        """Records a state change, and ignores a bridge result for an order
        that never passed through here: it is not a state this atom tracks.
        """
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        request_id = inner.get("request_id") or payload.get("request_id")
        if not request_id:
            return
        key = str(request_id)

        if key not in self._orders and status in (STATUS_QUEUED, STATUS_HALTED):
            return
        if key not in self._orders:
            self._order_keys.append(key)
            self._orders[key] = {"request_id": request_id,
                                 "account_id": inner.get("account_id"),
                                 "symbol": inner.get("symbol"),
                                 "side": inner.get("side"), "history": []}
        entry = self._orders[key]
        entry["status"] = status
        entry["history"].append(status)
        if inner.get("reason"):
            entry["reason"] = inner.get("reason")
        self._counts[status] = self._counts.get(status, 0) + 1

        while len(self._order_keys) > self._memory_limit:
            self._orders.pop(self._order_keys.pop(0), None)

        body = {"request_id": request_id, "symbol": entry.get("symbol"),
                "side": entry.get("side"), "status": status,
                "history": list(entry["history"])}
        if entry.get("reason"):
            body["reason"] = entry["reason"]
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        stuck = [k for k, v in self._orders.items()
                 if v.get("status") in (STATUS_BUILT, STATUS_VALIDATED, STATUS_SENT)]
        details = {"tracked": len(self._orders), "per_status": dict(self._counts),
                   "unfinished": len(stuck)}
        if not self._orders:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ORDERS, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="tracked=%d unfinished=%d" % (len(self._orders), len(stuck)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "orders": dict(self._orders),
                "keys": list(self._order_keys), "counts": dict(self._counts)}

    async def restore(self, state: dict[str, Any]) -> None:
        self._orders = dict(state.get("orders") or {})
        self._order_keys = list(state.get("keys") or [])
        self._counts = {str(k): int(v) for k, v in (state.get("counts") or {}).items()}
