from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom564"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 564

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 564


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def _pos(ticket, volume=0.1, symbol="NQ"):
    return {"ticket": ticket, "symbol": symbol, "side": "BUY", "volume": volume}


def _sys(ticket, size=0.1, symbol="NQ"):
    return {"ticket": ticket, "symbol": symbol, "side": "BUY", "size": size}


async def _feed(ctx, platform, system, at=TS):
    await ctx.handlers[MODULE.EVENT_PLATFORM]({"positions": platform, "timestamp": at})
    await ctx.handlers[MODULE.EVENT_TRACKED]({"positions": system, "timestamp": at})


def _mismatches(ctx):
    return out(ctx, MODULE.EVENT_MISMATCH)


@pytest.mark.asyncio
async def test_matching_sides_are_in_sync():
    atom, ctx = await _ready()
    await _feed(ctx, [_pos(1), _pos(2)], [_sys(1), _sys(2)])
    assert atom.compare()["state"] == MODULE.STATE_IN_SYNC
    assert _mismatches(ctx) == []


@pytest.mark.asyncio
async def test_a_position_open_on_the_platform_and_unknown_here_is_named():
    """The account table carries open_count only. Knowing a position is
    missing is not the same as knowing which one, and an unknown open
    position is risk nobody is measuring."""
    atom, ctx = await _ready(confirmations_required=1)
    await _feed(ctx, [_pos(1), _pos(2, symbol="XAU")], [_sys(1)])
    report = atom.compare()
    assert report["state"] == MODULE.STATE_DRIFTED
    assert report["untracked"] == ["2"]
    alerts = [m for m in _mismatches(ctx) if m["kind"] == MODULE.KIND_UNTRACKED]
    assert alerts and alerts[0]["ticket"] == "2"
    assert alerts[0]["symbol"] == "XAU"


@pytest.mark.asyncio
async def test_a_position_the_system_holds_and_the_platform_does_not():
    atom, ctx = await _ready(confirmations_required=1)
    await _feed(ctx, [_pos(1)], [_sys(1), _sys(9)])
    assert atom.compare()["phantom"] == ["9"]
    assert [m["kind"] for m in _mismatches(ctx)] == [MODULE.KIND_PHANTOM]


@pytest.mark.asyncio
async def test_a_volume_gap_is_named():
    atom, ctx = await _ready(confirmations_required=1, volume_tolerance=0.001)
    await _feed(ctx, [_pos(1, volume=0.5)], [_sys(1, size=0.1)])
    gaps = [m for m in _mismatches(ctx) if m["kind"] == MODULE.KIND_VOLUME]
    assert gaps
    assert gaps[0]["platform_volume"] == 0.5
    assert gaps[0]["system_volume"] == 0.1


@pytest.mark.asyncio
async def test_a_volume_difference_inside_the_tolerance_is_not_a_gap():
    atom, ctx = await _ready(confirmations_required=1, volume_tolerance=0.01)
    await _feed(ctx, [_pos(1, volume=0.105)], [_sys(1, size=0.1)])
    assert atom.compare()["volume_gaps"] == []


@pytest.mark.asyncio
async def test_a_transient_gap_between_two_publishes_is_not_reported():
    """609 and 659 publish at different moments, so any single comparison
    sees a gap that exists only between two writes. A real gap survives the
    next read; a transient one does not."""
    atom, ctx = await _ready(confirmations_required=2)
    await ctx.handlers[MODULE.EVENT_PLATFORM]({"positions": [_pos(1), _pos(2)],
                                               "timestamp": TS})
    assert _mismatches(ctx) == []
    await ctx.handlers[MODULE.EVENT_TRACKED]({"positions": [_sys(1), _sys(2)],
                                              "timestamp": TS})
    assert _mismatches(ctx) == []


@pytest.mark.asyncio
async def test_a_persistent_gap_is_reported_after_confirmation():
    atom, ctx = await _ready(confirmations_required=2)
    for _ in range(3):
        await _feed(ctx, [_pos(1), _pos(2)], [_sys(1)])
    assert [m["ticket"] for m in _mismatches(ctx)] == ["2"]


@pytest.mark.asyncio
async def test_the_same_gap_is_reported_once_not_on_every_read():
    atom, ctx = await _ready(confirmations_required=1)
    for _ in range(5):
        await _feed(ctx, [_pos(1), _pos(2)], [_sys(1)])
    assert len(_mismatches(ctx)) == 1


@pytest.mark.asyncio
async def test_a_resolved_gap_can_be_reported_again_if_it_returns():
    atom, ctx = await _ready(confirmations_required=1)
    await _feed(ctx, [_pos(1), _pos(2)], [_sys(1)])
    await _feed(ctx, [_pos(1), _pos(2)], [_sys(1), _sys(2)])
    await _feed(ctx, [_pos(1), _pos(2)], [_sys(1)])
    assert len(_mismatches(ctx)) == 2


@pytest.mark.asyncio
async def test_it_waits_until_both_sides_have_spoken():
    """Comparing against a side that never reported would call every
    position untracked."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_PLATFORM]({"positions": [_pos(1)], "timestamp": TS})
    assert atom.compare()["state"] == MODULE.STATE_WAITING
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_it_never_changes_a_position():
    """609 reads, this reports, a human or 516 decides. Nothing here writes
    to the platform or issues an order."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for forbidden in ("execution.order", "commands", "sqlite3", "INSERT", "UPDATE"):
        assert forbidden not in src or forbidden == "execution.order"
    assert set(MANIFEST["publishes"]) == {"execution.order_status_tracked",
                                          "execution.sync_mismatch"}


@pytest.mark.asyncio
async def test_health_names_every_kind_of_gap():
    atom, ctx = await _ready(confirmations_required=1)
    await _feed(ctx, [_pos(1, volume=0.5), _pos(2)], [_sys(1, size=0.1), _sys(9)])
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert "untracked=1" in status.message
    assert "phantom=1" in status.message
    assert "volume=1" in status.message


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready(confirmations_required=1)
    await _feed(ctx, [_pos(1), _pos(2)], [_sys(1)])
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.mismatch_count == atom.mismatch_count
