from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PLATFORM = "platform.positions.state"
EVENT_TRACKED = "portfolio.open_trades_tracked"
EVENT_APPEARED = "platform.position.appeared"
EVENT_VANISHED = "platform.position.vanished"
EVENT_OUT = "execution.order_status_tracked"
EVENT_MISMATCH = "execution.sync_mismatch"

STATE_IN_SYNC = "IN_SYNC"
STATE_DRIFTED = "DRIFTED"
STATE_WAITING = "AWAITING_BOTH_SIDES"

KIND_UNTRACKED = "UNTRACKED_ON_PLATFORM"
KIND_PHANTOM = "PHANTOM_IN_SYSTEM"
KIND_VOLUME = "VOLUME_MISMATCH"

REASON_NOT_STARTED = "NOT_STARTED"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._volume_tolerance = 0.0
        self._confirmations = 0
        self._platform: dict[str, dict[str, Any]] = {}
        self._tracked: dict[str, dict[str, Any]] = {}
        self._platform_seen = False
        self._tracked_seen = False
        self._reported: set[str] = set()
        self._pending: dict[str, int] = {}
        self.comparisons = 0
        self.mismatch_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._volume_tolerance = float(context.config["volume_tolerance"])
        self._confirmations = int(context.config["confirmations_required"])
        context.subscribe(EVENT_PLATFORM, self._on_platform)
        context.subscribe(EVENT_TRACKED, self._on_tracked)
        context.subscribe(EVENT_APPEARED, self._on_change)
        context.subscribe(EVENT_VANISHED, self._on_change)
        self._initialized = True
        context.logger.info("564 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("564 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "564 stopped (comparisons=%d, mismatches=%d)",
                self.comparisons, self.mismatch_count)

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _index(rows: Any) -> dict[str, dict[str, Any]]:
        indexed: dict[str, dict[str, Any]] = {}
        if not isinstance(rows, list):
            return indexed
        for row in rows:
            if not isinstance(row, dict):
                continue
            ticket = row.get("ticket")
            if ticket is None:
                continue
            indexed[str(ticket)] = row
        return indexed

    async def _on_platform(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._platform = self._index(payload.get("positions"))
        self._platform_seen = True
        await self._compare(payload)

    async def _on_tracked(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._tracked = self._index(payload.get("positions"))
        self._tracked_seen = True
        await self._compare(payload)

    async def _on_change(self, payload: dict[str, Any]) -> None:
        """A position appeared or vanished on the platform. 609 already
        named it; this atom only notes that the picture moved so the next
        comparison is not treated as a repeat of the last one."""
        if not self._running:
            return
        ticket = payload.get("ticket")
        if ticket is not None:
            self._reported.discard(str(ticket))

    def compare(self) -> dict[str, Any]:
        untracked = sorted(set(self._platform) - set(self._tracked))
        phantom = sorted(set(self._tracked) - set(self._platform))

        volume_gaps = []
        for ticket in sorted(set(self._platform) & set(self._tracked)):
            on_platform = _to_float(self._platform[ticket].get("volume"))
            in_system = _to_float(self._tracked[ticket].get("size"))
            if in_system is None:
                in_system = _to_float(self._tracked[ticket].get("volume"))
            if on_platform is None or in_system is None:
                continue
            if abs(on_platform - in_system) > self._volume_tolerance:
                volume_gaps.append({
                    "ticket": ticket,
                    "platform_volume": on_platform,
                    "system_volume": in_system,
                })

        if not (self._platform_seen and self._tracked_seen):
            state = STATE_WAITING
        elif untracked or phantom or volume_gaps:
            state = STATE_DRIFTED
        else:
            state = STATE_IN_SYNC

        return {
            "state": state,
            "platform_count": len(self._platform),
            "system_count": len(self._tracked),
            "untracked": untracked,
            "phantom": phantom,
            "volume_gaps": volume_gaps,
            "drift": len(self._platform) - len(self._tracked),
        }

    async def _compare(self, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        report = self.compare()
        self.comparisons += 1

        stamp = payload.get("timestamp")
        body = dict(report)
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

        if report["state"] != STATE_DRIFTED:
            self._pending.clear()
            self._reported.clear()
            return

        seen_now: set[str] = set()
        for kind, tickets in ((KIND_UNTRACKED, report["untracked"]),
                              (KIND_PHANTOM, report["phantom"])):
            for ticket in tickets:
                key = "%s:%s" % (kind, ticket)
                seen_now.add(key)
                if key in self._reported:
                    continue
                self._pending[key] = self._pending.get(key, 0) + 1
                if self._pending[key] < self._confirmations:
                    continue
                self._reported.add(key)
                self.mismatch_count += 1
                source = (self._platform if kind == KIND_UNTRACKED
                          else self._tracked).get(ticket, {})
                detail: dict[str, Any] = {
                    "kind": kind, "ticket": ticket,
                    "symbol": source.get("symbol"), "side": source.get("side"),
                }
                if isinstance(stamp, (int, float)):
                    detail["timestamp"] = stamp
                self._context.logger.error(
                    "564 %s: ticket %s (%s)", kind, ticket, source.get("symbol"))
                await self._context.publish(EVENT_MISMATCH, detail)

        for gap in report["volume_gaps"]:
            key = "%s:%s" % (KIND_VOLUME, gap["ticket"])
            seen_now.add(key)
            if key in self._reported:
                continue
            self._pending[key] = self._pending.get(key, 0) + 1
            if self._pending[key] < self._confirmations:
                continue
            self._reported.add(key)
            self.mismatch_count += 1
            detail = {"kind": KIND_VOLUME, **gap}
            if isinstance(stamp, (int, float)):
                detail["timestamp"] = stamp
            self._context.logger.error(
                "564 %s: ticket %s platform=%s system=%s",
                KIND_VOLUME, gap["ticket"], gap["platform_volume"],
                gap["system_volume"])
            await self._context.publish(EVENT_MISMATCH, detail)

        for key in [k for k in self._pending if k not in seen_now]:
            self._pending.pop(key, None)
            self._reported.discard(key)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        report = self.compare()
        details = dict(report)
        details["comparisons"] = self.comparisons
        details["mismatches"] = self.mismatch_count

        if report["state"] == STATE_WAITING:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=STATE_WAITING, details=details)
        if report["state"] == STATE_DRIFTED:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="platform=%d system=%d untracked=%d phantom=%d volume=%d" % (
                    report["platform_count"], report["system_count"],
                    len(report["untracked"]), len(report["phantom"]),
                    len(report["volume_gaps"])),
                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="in sync on %d positions" % report["platform_count"],
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "comparisons": self.comparisons,
                "mismatches": self.mismatch_count,
                "reported": sorted(self._reported)}

    async def restore(self, state: dict[str, Any]) -> None:
        self.comparisons = int(state.get("comparisons", 0))
        self.mismatch_count = int(state.get("mismatches", 0))
        self._reported = set(state.get("reported") or [])
