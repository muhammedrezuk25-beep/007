from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom561"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 561

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic_beyond_name():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 561


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_stop_then_start_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    assert atom._running is True


@pytest.mark.asyncio
async def test_a_market_rejection_is_retryable():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1", "reason": "RETCODE_10004"})
    event = out(ctx, MODULE.EVENT_OUT)[0]
    assert event["family"] == MODULE.CLASS_MARKET
    assert event["disposition"] == MODULE.RETRYABLE


@pytest.mark.asyncio
async def test_a_contract_rejection_is_terminal():
    """Retrying a malformed order produces the same rejection forever."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1", "reason": "MISSING_SYMBOL"})
    event = out(ctx, MODULE.EVENT_OUT)[0]
    assert event["family"] == MODULE.CLASS_CONTRACT
    assert event["disposition"] == MODULE.TERMINAL


@pytest.mark.asyncio
async def test_a_risk_rejection_is_terminal():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1", "reason": "KILL_SWITCH"})
    assert out(ctx, MODULE.EVENT_OUT)[0]["family"] == MODULE.CLASS_RISK


@pytest.mark.asyncio
async def test_consecutive_rejections_raise_an_alert():
    atom, ctx = await _ready(consecutive_alert_threshold=3)
    for i in range(3):
        await ctx.handlers[MODULE.EVENT_IN]({"request_id": f"r{i}", "reason": "RETCODE_1"})
    assert out(ctx, MODULE.EVENT_OUT)[-1]["streak_alert"] is True


@pytest.mark.asyncio
async def test_day_roll_clears_the_streak():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"reason": "RETCODE_1"})
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom._streak == 0


@pytest.mark.asyncio
async def test_a_rejection_without_a_reason_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1"})
    assert out(ctx, MODULE.EVENT_OUT) == []


# ── فشل الجسر: مؤقّت لا دائم ────────────────────────────────────────

def test_a_locked_database_is_worth_another_attempt():
    """قفل القاعدة حالة عابرة: الطرف الآخر يكتب كل عُشر ثانية وينتهي.

    وكان يُصنَّف مجهولًا فيُغلَق نهائيًّا — فيضيع أمر صحيح لأن القاعدة
    كانت مشغولة لحظةً."""
    for reason in ("database is locked", "DATABASE IS LOCKED",
                   "sqlite3.OperationalError: database is locked"):
        _, disposition = MODULE.Atom().classify(reason)
        assert disposition == MODULE.RETRYABLE, reason


def test_a_busy_database_is_worth_another_attempt():
    _, disposition = MODULE.Atom().classify("database is busy")
    assert disposition == MODULE.RETRYABLE


def test_a_kill_switch_is_never_retried():
    """المفتاح قرار مالك لا عطل عابر. وإعادة المحاولة عليه تلتفّ على
    الإيقاف الذي طلبه."""
    _, disposition = MODULE.Atom().classify("EMERGENCY_HALT")
    assert disposition == MODULE.TERMINAL


def test_a_bad_order_is_never_retried():
    """أمر بلا حجم أو برمز مجهول لن يصير صالحًا بالمحاولة الثانية."""
    for reason in ("NO_VOLUME", "MISSING_SYMBOL", "BAD_PRICE"):
        _, disposition = MODULE.Atom().classify(reason)
        assert disposition == MODULE.TERMINAL, reason
