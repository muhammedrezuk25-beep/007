from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "execution.order.rejected"
EVENT_TRADE_REJECTED = "trade.rejected"
EVENT_OUT = "execution.rejection_analyzed"
EVENT_DAY = "SYS_DAY"

CLASS_CONTRACT = "CONTRACT"
CLASS_RISK = "RISK"
CLASS_MARKET = "MARKET"
CLASS_UNKNOWN = "UNKNOWN"

RETRYABLE = "RETRYABLE"
TERMINAL = "TERMINAL"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_REJECTIONS = "NO_REJECTIONS_YET"

_CONTRACT_MARKERS = ("MISSING", "BAD_", "NO_VOLUME", "NO_SYMBOL",
                     "UNKNOWN_ACTION", "WRONG_SIDE", "NOT_SUPPORTED")
_RISK_MARKERS = ("KILL_SWITCH", "LIMIT", "EXPOSURE", "DRAWDOWN",
                 "MAX_", "INVALID_SYMBOL_SPEC", "RISK_")
_MARKET_MARKERS = ("RETCODE", "NO_MONEY", "MARKET_CLOSED", "REQUOTE",
                   "PRICE_CHANGED", "NO_POSITION", "TIMEOUT",
                   "LOCKED", "IS BUSY", "DATABASE IS", "DISK I/O")


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._streak_limit = 0
        self._by_reason: dict[str, int] = {}
        self._by_class: dict[str, int] = {}
        self._streak = 0
        self.analyzed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._streak_limit = int(context.config["consecutive_alert_threshold"])
        context.subscribe(EVENT_IN, self._on_rejected)
        context.subscribe(EVENT_TRADE_REJECTED, self._on_rejected)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("561 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("561 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("561 stopped (analyzed=%d)", self.analyzed_count)

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def classify(reason: str) -> tuple[str, str]:
        """Sorts a rejection into a class and a disposition.

        A bridge lock counts as a market fault, not an unknown one: the far
        side writes every hundred milliseconds and finishes, so the row will
        go in on the next attempt. Classified as unknown it closed for good,
        and a sound order was lost because the database happened to be busy
        for an instant.
        """
        upper = str(reason or "").upper()
        for marker in _RISK_MARKERS:
            if marker in upper:
                return CLASS_RISK, TERMINAL
        for marker in _CONTRACT_MARKERS:
            if marker in upper:
                return CLASS_CONTRACT, TERMINAL
        for marker in _MARKET_MARKERS:
            if marker in upper:
                return CLASS_MARKET, RETRYABLE
        return CLASS_UNKNOWN, TERMINAL

    async def _on_rejected(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        reason = inner.get("reason") or payload.get("reason")
        if not reason:
            return

        family, disposition = self.classify(reason)
        self.analyzed_count += 1
        self._streak += 1
        self._by_reason[str(reason)] = self._by_reason.get(str(reason), 0) + 1
        self._by_class[family] = self._by_class.get(family, 0) + 1

        body: dict[str, Any] = {
            "request_id": inner.get("request_id"),
            "account_id": inner.get("account_id"),
            "symbol": inner.get("symbol"), "reason": reason,
            "family": family, "disposition": disposition,
            "consecutive": self._streak,
            "streak_alert": self._streak >= self._streak_limit,
        }
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        if body["streak_alert"]:
            self._context.logger.warning(
                "561 %d consecutive rejections, latest %s", self._streak, reason)
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._streak = 0
        self._by_reason.clear()
        self._by_class.clear()

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"analyzed": self.analyzed_count, "consecutive": self._streak,
                   "by_reason": dict(self._by_reason), "by_family": dict(self._by_class)}
        if self.analyzed_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_REJECTIONS, details=details)
        if self._streak >= self._streak_limit:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="%d consecutive rejections" % self._streak,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="analyzed=%d" % self.analyzed_count, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "analyzed": self.analyzed_count,
                "streak": self._streak, "by_reason": dict(self._by_reason),
                "by_family": dict(self._by_class)}

    async def restore(self, state: dict[str, Any]) -> None:
        self.analyzed_count = int(state.get("analyzed", 0))
        self._streak = int(state.get("streak", 0))
        self._by_reason = {str(k): int(v) for k, v in (state.get("by_reason") or {}).items()}
        self._by_class = {str(k): int(v) for k, v in (state.get("by_family") or {}).items()}
