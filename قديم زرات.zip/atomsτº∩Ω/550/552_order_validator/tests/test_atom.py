from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom552"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 552

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic_beyond_name():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 552


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_stop_then_start_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    assert atom._running is True


@pytest.mark.asyncio
async def test_valid_order_passes():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "request_id": "r1", "symbol": "NQ", "side": "BUY", "volume": 0.1,
        "reference_price": 100.0, "stop_loss": 95.0, "timestamp": TS})
    assert len(out(ctx, MODULE.EVENT_VALID)) == 1
    assert out(ctx, MODULE.EVENT_REJECTED) == []


@pytest.mark.asyncio
async def test_stop_above_entry_on_a_buy_is_refused():
    """A stop above the entry on a buy closes the trade the moment it opens.
    The platform would accept it and the loss would look like a strategy
    failure rather than a malformed order."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "request_id": "r1", "symbol": "NQ", "side": "BUY", "volume": 0.1,
        "reference_price": 100.0, "stop_loss": 110.0})
    rejected = out(ctx, MODULE.EVENT_REJECTED)
    assert rejected and rejected[0]["reason"] == MODULE.BAD_STOP


@pytest.mark.asyncio
async def test_stop_below_entry_on_a_sell_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "request_id": "r1", "symbol": "NQ", "side": "SELL", "volume": 0.1,
        "reference_price": 100.0, "stop_loss": 90.0})
    assert out(ctx, MODULE.EVENT_REJECTED)[0]["reason"] == MODULE.BAD_STOP


@pytest.mark.asyncio
async def test_target_on_the_wrong_side_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "request_id": "r1", "symbol": "NQ", "side": "BUY", "volume": 0.1,
        "reference_price": 100.0, "stop_loss": 95.0, "take_profit": 90.0})
    assert out(ctx, MODULE.EVENT_REJECTED)[0]["reason"] == MODULE.BAD_TARGET


@pytest.mark.asyncio
async def test_zero_volume_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({
        "request_id": "r1", "symbol": "NQ", "side": "BUY", "volume": 0,
        "reference_price": 100.0, "stop_loss": 95.0})
    assert out(ctx, MODULE.EVENT_REJECTED)[0]["reason"] == MODULE.BAD_VOLUME


@pytest.mark.asyncio
async def test_missing_request_id_is_refused():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"symbol": "NQ", "side": "BUY", "volume": 0.1,
                                          "reference_price": 100.0, "stop_loss": 95.0})
    assert out(ctx, MODULE.EVENT_REJECTED)[0]["reason"] == MODULE.BAD_REQUEST_ID


@pytest.mark.asyncio
async def test_missing_stop_refused_only_when_required():
    atom, ctx = await _ready(require_stop_loss=True)
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1", "symbol": "NQ",
                                          "side": "BUY", "volume": 0.1,
                                          "reference_price": 100.0})
    assert out(ctx, MODULE.EVENT_REJECTED)[0]["reason"] == MODULE.BAD_STOP

    atom2, ctx2 = await _ready(require_stop_loss=False)
    await ctx2.handlers[MODULE.EVENT_IN]({"request_id": "r1", "symbol": "NQ",
                                           "side": "BUY", "volume": 0.1,
                                           "reference_price": 100.0})
    assert len(out(ctx2, MODULE.EVENT_VALID)) == 1


@pytest.mark.asyncio
async def test_timestamp_is_inherited():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN]({"request_id": "r1", "symbol": "NQ",
                                          "side": "BUY", "volume": 0.1,
                                          "reference_price": 100.0,
                                          "stop_loss": 95.0, "timestamp": 55.0})
    assert out(ctx, MODULE.EVENT_VALID)[0]["timestamp"] == 55.0
