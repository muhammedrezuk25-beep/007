from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "execution.order.built"
EVENT_VALID = "execution.order.validated"
EVENT_REJECTED = "execution.order.rejected"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRAFFIC = "NO_ORDERS_YET"

BAD_REQUEST_ID = "MISSING_REQUEST_ID"
BAD_SYMBOL = "MISSING_SYMBOL"
BAD_SIDE = "BAD_SIDE"
BAD_VOLUME = "BAD_VOLUME"
BAD_PRICE = "BAD_REFERENCE_PRICE"
BAD_STOP = "STOP_ON_WRONG_SIDE"
BAD_TARGET = "TARGET_ON_WRONG_SIDE"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._require_stop = False
        self._require_target = False
        self.validated_count = 0
        self.rejected_count = 0
        self._reasons: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._require_stop = bool(cfg["require_stop_loss"])
        self._require_target = bool(cfg["require_take_profit"])
        context.subscribe(EVENT_IN, self._on_order_built)
        self._initialized = True
        context.logger.info("552 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("552 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("552 stopped (validated=%d, rejected=%d)",
                                      self.validated_count, self.rejected_count)

    async def shutdown(self) -> None:
        await self.stop()

    def validate(self, order: dict[str, Any]) -> str | None:
        if not order.get("request_id"):
            return BAD_REQUEST_ID
        symbol = order.get("symbol")
        if not isinstance(symbol, str) or not symbol.strip():
            return BAD_SYMBOL
        side = str(order.get("side", "")).strip().upper()
        if side not in (SIDE_BUY, SIDE_SELL):
            return BAD_SIDE
        volume = _to_float(order.get("volume"))
        if volume is None or volume <= 0:
            return BAD_VOLUME
        reference = _to_float(order.get("reference_price"))
        if reference is None or reference <= 0:
            return BAD_PRICE

        stop = _to_float(order.get("stop_loss"))
        if stop is None:
            if self._require_stop:
                return BAD_STOP
        elif (side == SIDE_BUY and stop >= reference) or (
                side == SIDE_SELL and stop <= reference):
            return BAD_STOP

        target = _to_float(order.get("take_profit"))
        if target is None:
            if self._require_target:
                return BAD_TARGET
        elif (side == SIDE_BUY and target <= reference) or (
                side == SIDE_SELL and target >= reference):
            return BAD_TARGET
        return None

    async def _on_order_built(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        reason = self.validate(inner)
        body: dict[str, Any] = {"request_id": inner.get("request_id"),
                                "account_id": inner.get("account_id"),
                                "symbol": inner.get("symbol"),
                                "side": inner.get("side")}
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp

        if reason is None:
            self.validated_count += 1
            await self._context.publish(EVENT_VALID, {**inner, **body})
            return

        self.rejected_count += 1
        self._reasons[reason] = self._reasons.get(reason, 0) + 1
        self._context.logger.warning("552 rejected %s: %s",
                                     inner.get("symbol"), reason)
        await self._context.publish(EVENT_REJECTED, {**body, "reason": reason})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"validated": self.validated_count,
                   "rejected": self.rejected_count, "reasons": dict(self._reasons)}
        if self.validated_count == 0 and self.rejected_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_TRAFFIC, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="validated=%d rejected=%d" % (
                                self.validated_count, self.rejected_count),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "validated": self.validated_count,
                "rejected": self.rejected_count, "reasons": dict(self._reasons)}

    async def restore(self, state: dict[str, Any]) -> None:
        self.validated_count = int(state.get("validated", 0))
        self.rejected_count = int(state.get("rejected", 0))
        self._reasons = {str(k): int(v)
                         for k, v in (state.get("reasons") or {}).items()}
