"""Tests for atom 571 - Position Tracker."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom571"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 571

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []
        self.handlers: dict[str, object] = {}

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        self.handlers[name] = handler

    def of(self, name):
        return [p for n, p in self.published if n == name]


def pos(ticket=1, symbol="NQ", side="BUY", entry=100.0, cur=100.0,
        sl=90.0, tp=120.0, volume=1.0, **extra):
    return {"ticket": ticket, "symbol": symbol, "side": side,
            "entry_price": entry, "current_price": cur, "stop_loss": sl,
            "take_profit": tp, "volume": volume, "profit": 0.0, **extra}


async def build(config=None):
    atom = MODULE.Atom()
    ctx = Ctx(config if config is not None else dict(MANIFEST["config"]))
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def test_progress_math_buy():
    out = MODULE.compute_progress("BUY", 100.0, 110.0, 90.0, 120.0)
    assert out["gain_price"] == 10.0
    assert out["risk_price"] == 10.0
    assert out["r_multiple"] == 1.0
    assert out["progress"] == 0.5


def test_progress_math_sell_and_missing_targets():
    out = MODULE.compute_progress("SELL", 100.0, 95.0, 105.0, 80.0)
    assert out["gain_price"] == 5.0 and out["r_multiple"] == 1.0
    naked = MODULE.compute_progress("BUY", 100.0, 105.0, None, None)
    assert naked["risk_price"] is None
    assert naked["r_multiple"] is None
    assert naked["progress"] is None  # الغياب غياب، لا صفر


@pytest.mark.asyncio
async def test_state_emits_progress_with_trace_inheritance():
    atom, ctx = await build()
    await atom._on_positions({"positions": [pos()], "account_id": "111",
                              "trace_id": "T1", "timestamp": TS})
    out = ctx.of("trade.progress")
    assert len(out) == 1
    p = out[0]
    assert p["ticket"] == 1 and p["account_id"] == "111"
    assert p["trace_id"] == "T1" and p["parent_event"] == "platform.positions.state"
    assert p["timestamp"] == TS


@pytest.mark.asyncio
async def test_tick_uses_bid_for_buy_and_throttles():
    atom, ctx = await build()
    await atom._on_positions({"positions": [pos(sl=95.0)], "timestamp": TS})
    ctx.published.clear()
    await atom._on_tick({"symbol": "NQ", "bid": 110.0, "ask": 110.5,
                         "timestamp": TS + 2})
    p = ctx.of("trade.progress")[0]
    assert p["current_price"] == 110.0  # BUY يخرج على bid
    assert p["r_multiple"] == 2.0
    ctx.published.clear()
    # داخل نافذة الخنق — لا بثّ ثانٍ
    await atom._on_tick({"symbol": "NQ", "bid": 111.0, "ask": 111.5,
                         "timestamp": TS + 2.3})
    assert ctx.of("trade.progress") == []
    # بعد النافذة — يمرّ
    await atom._on_tick({"symbol": "NQ", "bid": 112.0, "ask": 112.5,
                         "timestamp": TS + 3.5})
    assert len(ctx.of("trade.progress")) == 1


@pytest.mark.asyncio
async def test_vanished_ticket_publishes_ended_and_purges():
    atom, ctx = await build()
    await atom._on_positions({"positions": [pos(ticket=7)], "timestamp": TS})
    await atom._on_positions({"positions": [], "timestamp": TS + 1})
    ended = ctx.of("trade.progress.ended")
    assert len(ended) == 1 and ended[0]["ticket"] == 7
    assert atom._positions == {}


@pytest.mark.asyncio
async def test_bad_rows_are_skipped_silently():
    atom, ctx = await build()
    await atom._on_positions({"positions": [
        {"ticket": "x"}, "junk", pos(ticket=2, side="HOLD"),
        pos(ticket=3, entry=None), pos(ticket=4)],
        "timestamp": TS})
    out = ctx.of("trade.progress")
    assert [p["ticket"] for p in out] == [4]


@pytest.mark.asyncio
async def test_health_degraded_before_first_state():
    atom, _ = await build()
    hs = await atom.health_check()
    assert hs.state.value == "degraded"
    await atom._on_positions({"positions": [], "timestamp": TS})
    hs = await atom.health_check()
    assert hs.state.value == "healthy"
