"""
571 — متتبّع المركز الحي (Position Tracker) — قسم إدارة الصفقة 570

المشكلة التي يحلّها: النظام كان يفتح الصفقة بوقف وهدف ثابتين ثم يتركها.
كل صفقة إمّا تضرب الوقف أو الهدف — لا حالة ثالثة. هذه الذرة تصنع الحالة
الثالثة: تدمج جدول المراكز (609) مع التكّات الحيّة (613) وتنشر تقدّم كل
مركز رقمًا قابلًا للقرار، فتبني عليه 572/573/574 قراراتها.

المدخل:  platform.positions.state (609) — الحقيقة عن المراكز
         market.tick (613) — السعر الحي بين قراءتين
المخرج:  trade.progress        لكل مركز مفتوح
         trade.progress.ended  لحظة اختفاء المركز — به تُطهَّر ذواكر القسم

الطوابع تُورَّث من الحدث المحفِّز ولا تُقرأ ساعة الجهاز (قاعدة التوقيت).
trace_id يُمرَّر يدويًا مع parent_event — الحل الثاني من ورقة الأثر،
مطبَّق هنا على سلسلة الإدارة كاملة دون فتح النواة.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN_POSITIONS = "platform.positions.state"
EVENT_IN_TICK = "market.tick"
EVENT_OUT_PROGRESS = "trade.progress"
EVENT_OUT_ENDED = "trade.progress.ended"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_POSITIONS_FEED = "NO_POSITIONS_STATE_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _trace(payload: dict, parent: str) -> dict:
    """يورّث trace_id والطابع من الحدث المحفِّز ويسمّي أباه.

    بلا هذا يحقن الناقل معرّفًا عشوائيًا جديدًا فتنقطع السلسلة —
    وسؤال «لماذا تحرّك الوقف؟» يفقد جوابه (ورقة الأثر، الحل الثاني).
    """
    out: dict[str, Any] = {"parent_event": parent}
    if payload.get("trace_id") is not None:
        out["trace_id"] = payload["trace_id"]
    ts = _to_float(payload.get("timestamp"))
    if ts is not None:
        out["timestamp"] = ts
    return out


def compute_progress(side: str, entry: float, current: float,
                     stop_loss: float | None, take_profit: float | None,
                     ) -> dict[str, Any]:
    """أرقام القرار من أرقام المركز — دالة نقية قابلة للاختبار وحدها.

    gain: الربح بوحدة السعر باتجاه الصفقة.
    risk: مسافة الدخول للوقف (موجبة إن كان الوقف في جهته الصحيحة).
    r_multiple: gain/risk — «كم R ربحنا» وهو لغة 572/574.
    progress: نسبة قطع الطريق نحو الهدف، مقصوصة في [0, 1].
    الغائب يبقى None — صفرٌ مسافةٌ وصفرٌ ربحٌ، والغياب غياب.
    """
    is_buy = side == "BUY"
    gain = (current - entry) if is_buy else (entry - current)

    risk = None
    if stop_loss is not None and stop_loss > 0:
        d = (entry - stop_loss) if is_buy else (stop_loss - entry)
        if d > 0:
            risk = d

    reward = None
    if take_profit is not None and take_profit > 0:
        d = (take_profit - entry) if is_buy else (entry - take_profit)
        if d > 0:
            reward = d

    r_multiple = (gain / risk) if risk else None
    progress = None
    if reward:
        progress = max(0.0, min(1.0, gain / reward))

    return {
        "gain_price": round(gain, 10),
        "risk_price": round(risk, 10) if risk is not None else None,
        "reward_price": round(reward, 10) if reward is not None else None,
        "r_multiple": round(r_multiple, 6) if r_multiple is not None else None,
        "progress": round(progress, 6) if progress is not None else None,
    }


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        # الحقيقة عن المراكز كما وردت آخر مرة، مفهرسة بالتذكرة.
        self._positions: dict[int, dict[str, Any]] = {}
        # آخر bid/ask لكل رمز — سعر الخروج الصادق: شراءٌ يخرج على bid.
        self._last_bid: dict[str, float] = {}
        self._last_ask: dict[str, float] = {}
        # آخر بثّ لكل تذكرة (بطابع الحدث لا بساعة الجهاز) — خانق التكّات.
        self._last_emit_ts: dict[int, float] = {}

        self._emit_min_interval_s = 1.0
        self.states_seen = 0
        self.ticks_seen = 0
        self.progress_published = 0
        self.ended_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._emit_min_interval_s = float(
            context.config.get("emit_min_interval_s", 1.0))
        context.subscribe(EVENT_IN_POSITIONS, self._on_positions)
        context.subscribe(EVENT_IN_TICK, self._on_tick)
        context.logger.info(
            "571 initialised (emit_min_interval=%.1fs)", self._emit_min_interval_s)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        rows = payload.get("positions")
        if not isinstance(rows, list):
            return
        self.states_seen += 1

        fresh: dict[int, dict[str, Any]] = {}
        for row in rows:
            if not isinstance(row, dict):
                continue
            ticket = row.get("ticket")
            if ticket is None:
                continue
            try:
                ticket = int(ticket)
            except (TypeError, ValueError):
                continue
            entry = dict(row)
            if payload.get("account_id") is not None and "account_id" not in entry:
                entry["account_id"] = payload["account_id"]
            fresh[ticket] = entry

        # من اختفى انتهى — الحدث الذي تُطهِّر به 572/573/574 ذواكرها،
        # فلا يبقى قرارٌ معلّقًا على تذكرة ماتت.
        for gone in set(self._positions) - set(fresh):
            old = self._positions[gone]
            await self._context.publish(EVENT_OUT_ENDED, {
                "ticket": gone,
                "symbol": old.get("symbol"),
                "account_id": old.get("account_id"),
                "side": old.get("side"),
                **_trace(payload, EVENT_IN_POSITIONS),
            })
            self.ended_published += 1
            self._last_emit_ts.pop(gone, None)

        self._positions = fresh

        # الحالة الجديدة مرجع كافٍ للبث — بلا خانق: 609 يقرأ كل ثانية.
        for ticket, entry in fresh.items():
            await self._emit(ticket, entry, payload, EVENT_IN_POSITIONS,
                             throttled=False)

    async def _on_tick(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        bid, ask = _to_float(payload.get("bid")), _to_float(payload.get("ask"))
        if bid is not None:
            self._last_bid[symbol] = bid
        if ask is not None:
            self._last_ask[symbol] = ask
        self.ticks_seen += 1

        for ticket, entry in self._positions.items():
            if entry.get("symbol") != symbol:
                continue
            await self._emit(ticket, entry, payload, EVENT_IN_TICK,
                             throttled=True)

    async def _emit(self, ticket: int, entry: dict[str, Any],
                    trigger: dict[str, Any], parent: str, *,
                    throttled: bool) -> None:
        assert self._context is not None
        ts = _to_float(trigger.get("timestamp"))
        if throttled and ts is not None:
            last = self._last_emit_ts.get(ticket)
            if last is not None and (ts - last) < self._emit_min_interval_s:
                return

        side = str(entry.get("side", "")).upper()
        entry_price = _to_float(entry.get("entry_price"))
        if side not in ("BUY", "SELL") or entry_price is None:
            return

        symbol = entry.get("symbol")
        # سعر الخروج الصادق: الشراء يُغلق على bid والبيع على ask.
        # وإن غابت التكّة بعد، سعرُ الجسر أصدقُ من لا شيء.
        live = (self._last_bid if side == "BUY" else self._last_ask).get(symbol)
        current = live if live is not None else _to_float(entry.get("current_price"))
        if current is None:
            return

        sl = _to_float(entry.get("stop_loss"))
        tp = _to_float(entry.get("take_profit"))
        body: dict[str, Any] = {
            "ticket": ticket,
            "symbol": symbol,
            "account_id": entry.get("account_id"),
            "side": side,
            "volume": _to_float(entry.get("volume")),
            "entry_price": entry_price,
            "current_price": current,
            "stop_loss": sl if sl and sl > 0 else None,
            "take_profit": tp if tp and tp > 0 else None,
            "profit": _to_float(entry.get("profit")),
            **compute_progress(side, entry_price, current, sl, tp),
            **_trace(trigger, parent),
        }
        await self._context.publish(EVENT_OUT_PROGRESS, body)
        self.progress_published += 1
        if ts is not None:
            self._last_emit_ts[ticket] = ts

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {
            "open_tickets": sorted(self._positions),
            "states_seen": self.states_seen,
            "ticks_seen": self.ticks_seen,
            "progress_published": self.progress_published,
            "ended_published": self.ended_published,
        }
        if self.states_seen == 0:
            # جوعُ مدخلٍ لا عطل: 609 لم ينشر بعد، وإعادة تشغيلنا لا تنشره.
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_POSITIONS_FEED,
                                details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="tracking=%d published=%d" % (
                len(self._positions), self.progress_published),
            details=details)
