"""
551 — منشئ أمر التداول (Order Builder)
========================================
يحوّل طلب القرار إلى **أمر تداول مكتمل** جاهز للإرسال.

**الفرق عن 467**: 467 يقول «قرّرنا الشراء». هذا يقول «اشترِ 0.5 لوت من
US100 بوقف عند 21400 وهدف عند 21600».

**لا يرسل شيئاً.** يبني الحمولة وينشرها، و601 يرسلها. الفصل مقصود: من
يبني الأمر لا يملك قناة التنفيذ، ومن ينفّذ لا يقرّر المحتوى.

**لا يخترع حجماً ولا وقفاً.** كل قيمة تأتي من `config` أو من الحمولة
الواردة. حجم صفقة مخترع خسارة حقيقية بمال حقيقي.

**الحجم من الإعداد لا من حساب مخاطرة هنا**: حساب حجم المركز من رصيد
الحساب ونسبة المخاطرة مسؤولية قسم 500 — وهو المالك الوحيد للمال. حين
يُبنى، يُمرَّر الحجم في الحمولة ويُستعمل بدل الافتراضي.
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _built_at(inner: dict, payload: dict) -> dict:
    """Inherit the decision's instant for built_at, never a fresh reading.

    Preference order used across the project: the inner decision payload's own
    timestamp, then the envelope's, then nothing - core.event_bus stamps the
    event itself via setdefault and built_at is simply absent rather than
    invented.
    """
    for candidate in (inner.get("timestamp"), payload.get("timestamp")):
        if isinstance(candidate, (int, float)):
            return {"built_at": candidate}
    return {}

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin. When the inbound event carries none, the key is omitted and
    core.event_bus stamps it via setdefault - stamped once, never invented.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


ATOM_VERSION = "1.0.0"

EVENT_IN = "execution.order.requested"
EVENT_OUT = "execution.order.built"
EVENT_REJECTED = "execution.order.rejected"

# فرق لوت أصغر من هذا ليس قصًّا بل تقريب خطوة الوسيط. والتمييز يهمّ: السقف
# يقصّ الحجم وكان يترك النسبة معلنة كما هي — USTEC خامه 27.62 لوت والسقف
# 5.0، فالمخاطرة الفعلية 0.181% والأمر يقول 1%، ومن يقيّم الاستراتيجية
# يقسم عائدها على مخاطرة لم تُؤخَذ.
_LOT_EPSILON = 1e-9
NO_SIZE = "NO_MEASURED_SIZE"
EVENT_ACCOUNT = "portfolio.account_tracked"
EVENT_RISK_REQUEST = "risk.validation.requested"
EVENT_RISK_RESPONSE = "risk.validation.completed"
RISK_DECLINED = "RISK_DECLINED"
RISK_TIMEOUT = "RISK_TIMEOUT"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

REASON_NO_INPUT = "NO_ORDERS_YET"
REASON_NOT_STARTED = "NOT_STARTED"

BAD_SIDE = "unknown_side"
BAD_PRICE = "no_reference_price"
BAD_SYMBOL = "no_symbol"


def _to_float(value: Any) -> float | None:
    """يرفض NaN كما يرفض غير الرقمي — NaN يجتاز كل مقارنة صامتاً."""
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False

        self._default_volume = 0.0
        self._stop_distance_pct = 0.0
        self._risk_pct = 0.0
        self._min_volume = 0.0
        self._max_volume = 0.0
        self._volume_step = 0.0
        self._equity: dict[str, float] = {}
        self._specs: dict[str, float] = {}
        self.sized_from_risk = 0
        self.sized_from_default = 0
        self._target_distance_pct = 0.0
        self._require_price = True

        self._last_price: dict[str, float] = {}
        self._venue: dict[str, str] = {}
        self._contract_size: dict[str, float] = {}
        self._last_sizing: dict[str, Any] = {}
        self._built = 0
        self._rejected: dict[str, int] = {}
        self._received = 0
        self._pending: dict[str, dict[str, Any]] = {}
        self._risk_timeout_s = 0.0
        self._risk_declined = 0
        self._risk_timed_out = 0

    # ----------------------------------------------------- التهيئة --

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._risk_timeout_s = float(cfg["risk_timeout_s"])

        self._default_volume = float(cfg["default_volume"])
        self._stop_distance_pct = float(cfg["stop_distance_pct"])
        self._risk_pct = float(cfg["risk_per_trade_pct"])
        self._risk_pct_by_account = {
            str(k): float(v)
            for k, v in (cfg.get("risk_per_trade_pct_by_account") or {}).items()}
        self._min_volume = float(cfg["min_volume"])
        self._max_volume = float(cfg["max_volume"])
        self._volume_step = float(cfg["volume_step"])
        self._target_distance_pct = float(cfg["target_distance_pct"])
        self._require_price = bool(cfg["require_reference_price"])

        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_IN, self._on_order_requested)
        context.subscribe("market.tick", self._on_price)
        context.subscribe("market.symbol_specs", self._on_specs)
        context.subscribe(EVENT_RISK_RESPONSE, self._on_risk_response)

        self._initialized = True
        context.logger.info(
            "تهيّأت الذرة %d (حجم=%.2f · وقف=%.2f%% · هدف=%.2f%%)",
            context.atom_id, self._default_volume,
            self._stop_distance_pct, self._target_distance_pct,
        )

    # -------------------------------------------------- دورة الحياة --

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (بُني=%d، مرفوض=%s)",
                self._context.atom_id, self._built,
                {k: v for k, v in self._rejected.items() if v} or "لا شيء",
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------- الاستقبال --

    async def _on_account(self, payload: dict[str, Any]) -> None:
        """Equity per account, never one figure for all of them.

        A single equity overwritten by whichever account reported last sizes
        a position from one account and sends it to another — real money, and
        no fault visible anywhere.
        """
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            return
        equity = _to_float(payload.get("equity"))
        if equity is not None and equity > 0:
            self._equity[str(account_id)] = equity

    def size_for(self, account_id: str | None, reference: float | None,
                 stop_distance: float | None,
                 contract_size: float | None,
                 symbol: str | None = None) -> float | None:
        """Position size from the account, not a constant.

        A fixed lot risks a different fraction of the account on every
        instrument and every stop distance. On M1 the system opens often, so
        the same fixed lot compounds that mismatch trade after trade.

        size = (equity x risk_pct / 100) / (stop_distance x contract_size)

        so the loss at the stop is that account's configured percentage
        regardless of the instrument — a gold account at one percent and an
        index account at half of it get different sizes from the same equity,
        which is exactly the point. The equity is that of the account the order is bound
        for: an account with ten thousand and one with a hundred thousand
        risking the same percentage must get sizes ten times apart.

        Without an equity figure for that account the answer is None, never a
        guess: inventing a size is inventing the risk.
        """
        equity = self._equity.get(str(account_id)) if account_id else None
        if equity is None or equity <= 0:
            return None
        if stop_distance is None or stop_distance <= 0:
            return None
        if contract_size is None and symbol:
            contract_size = self._contract_size.get(str(symbol))
        if contract_size is None or contract_size <= 0:
            return None
        # نسبة الحساب إن ذُكرت، وإلا الافتراضي المعلَن: حساب جديد يتداول
        # بالنسبة المحافظة لا بلا نسبة.
        risk_pct = self._risk_pct_by_account.get(str(account_id), self._risk_pct)
        budget = equity * risk_pct / 100.0
        raw = budget / (stop_distance * contract_size)
        if self._volume_step > 0:
            raw = int(raw / self._volume_step) * self._volume_step
        final = max(self._min_volume, min(raw, self._max_volume))
        self._last_sizing = {"capped": abs(final - raw) > _LOT_EPSILON,
                             "actual_pct": final * stop_distance
                             * contract_size / equity * 100.0}
        return round(final, 8)

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        """Contract sizes from 618, per symbol.

        There is no safe default: gold is 100 and an index is 1, so falling
        back to one made a gold order a hundred times too large — capped only
        by max_volume, which is not a computed size.
        """
        for row in (payload.get("symbols") or []):
            if not isinstance(row, dict):
                continue
            size = _to_float(row.get("contract_size"))
            if row.get("symbol") and size and size > 0:
                self._contract_size[str(row["symbol"])] = size

    async def _on_price(self, payload: dict[str, Any]) -> None:
        """السعر المرجعي للوقف والهدف. لا يبني أمراً — يخزّن فقط."""
        if not self._running:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        account_id = inner.get("account_id")
        price = _to_float(inner.get("price", inner.get("mid")))
        if isinstance(symbol, str) and price is not None and price > 0:
            self._last_price[symbol] = price
        # المصدر يُمرَّر في market.tick حتى هنا ثم كان يضيع، فيُبنى الأمر
        # ويُكتب في جسر MT5 مهما جاءت التكّة من بايننس أو ريثمك: سعرُ
        # بتكوين من بايننس كان يفتح صفقة على منصّة أخرى.
        provider = inner.get("provider", payload.get("provider"))
        if isinstance(symbol, str) and isinstance(provider, str) and provider:
            self._venue[symbol] = provider
        now = _to_float(inner.get("timestamp", payload.get("timestamp")))
        if now is not None:
            self._expire_pending(now)


    def _reject(self, reason: str, symbol: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1
        if self._context is not None:
            self._context.logger.warning("رُفض بناء أمر %s — %s", symbol or "?", reason)

    async def _on_order_requested(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        self._received += 1

        symbol = inner.get("symbol")

        account_id = inner.get("account_id")
        side = str(inner.get("side", "")).strip().upper()

        if not isinstance(symbol, str) or not symbol.strip():
            self._reject(BAD_SYMBOL, "")
            return
        symbol = symbol.strip()

        if side not in (SIDE_BUY, SIDE_SELL):
            self._reject(BAD_SIDE, symbol)
            return

        # السعر من الحمولة أولاً، ثم آخر سعر معروف
        reference = _to_float(inner.get("price")) or self._last_price.get(symbol)
        if reference is None or reference <= 0:
            if self._require_price:
                self._reject(BAD_PRICE, symbol)
                await self._context.publish(EVENT_REJECTED, {
                    "request_id": inner.get("request_id"),
                    "account_id": account_id,
                    "symbol": symbol, "side": side, "reason": BAD_PRICE,
                    **_ts_from(payload),
                })
                return
            reference = None

        # الحجم من الحمولة إن حسبته إدارة المخاطر، وإلا الافتراضي
        volume = _to_float(inner.get("volume", inner.get("size")))
        if volume is None or volume <= 0:
            stop_gap = (reference * self._stop_distance_pct / 100.0
                        if reference is not None else None)
            contract_size = (_to_float(inner.get("contract_size"))
                             or self._contract_size.get(str(symbol)))
            volume = self.size_for(account_id, reference, stop_gap,
                                   contract_size, symbol)
            if volume is None:
                self.sized_from_default += 1
                self._rejected[NO_SIZE] = self._rejected.get(NO_SIZE, 0) + 1
                await self._context.publish(EVENT_REJECTED, {
                    "request_id": inner.get("request_id"), "reason": NO_SIZE,
                    "account_id": account_id, "symbol": symbol, "side": side,
                    **_ts_from(payload)})
                return
            self.sized_from_risk += 1

        intended_pct = self._risk_pct_by_account.get(str(account_id), self._risk_pct)
        taken = self._last_sizing.get("actual_pct")
        actual_pct = round(taken, 6) if taken is not None else intended_pct
        stop_loss = take_profit = None
        if reference is not None:
            stop_gap = reference * self._stop_distance_pct / 100.0
            target_gap = reference * self._target_distance_pct / 100.0
            if side == SIDE_BUY:
                stop_loss = round(reference - stop_gap, 6)
                take_profit = round(reference + target_gap, 6)
            else:
                stop_loss = round(reference + stop_gap, 6)
                take_profit = round(reference - target_gap, 6)

        request_id = inner.get("request_id")
        if not isinstance(request_id, str) or not request_id:
            request_id = "%s:%s:%r" % (
                symbol, side, _built_at(inner, payload).get("built_at"))

        order = {
            "request_id": inner.get("request_id"),
            "risk_pct_intended": intended_pct,
            "risk_pct": actual_pct,
            "size_capped": bool(self._last_sizing.get("capped")),
            "account_id": account_id,
            "symbol": symbol,
            "side": side,
            "volume": volume,
            "reference_price": reference,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            # Decision fields pass through untouched: 563 echoes them back in
            # trade.closed, which is how 414 learns which strategy produced
            # which outcome.
            **{k: inner[k] for k in ("strategy", "confidence", "stability")
               if inner.get(k) is not None},
            # built_at carries the decision's own instant, not ours. Re-reading
            # the clock here would place the order at a different moment than
            # the decision that ordered it, and 566 measures 551 -> 563 latency
            # off exactly this field.
            **_built_at(inner, payload),
        }
        order["request_id"] = request_id

        self._pending[request_id] = order
        await self._context.publish(EVENT_RISK_REQUEST, {
            "request_id": request_id,
            "account_id": account_id,
            "symbol": symbol,
            "side": side,
            "volume": volume,
            **_built_at(inner, payload),
        })

    async def _on_risk_response(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        request_id = payload.get("request_id")
        order = self._pending.pop(request_id, None)
        if order is None:
            return

        if not payload.get("approved"):
            self._risk_declined += 1
            reason = payload.get("reason") or RISK_DECLINED
            self._rejected[RISK_DECLINED] = self._rejected.get(RISK_DECLINED, 0) + 1
            await self._context.publish(EVENT_REJECTED, {
                "request_id": request_id,
                "symbol": order.get("symbol"),
                "side": order.get("side"),
                "reason": reason,
                **({"timestamp": order["built_at"]} if "built_at" in order else {}),
            })
            return

        self._built += 1
        await self._context.publish(EVENT_OUT, order)

    def _expire_pending(self, now: float) -> int:
        if self._risk_timeout_s <= 0 or not self._pending:
            return 0
        stale = [rid for rid, order in self._pending.items()
                 if now - float(order.get("built_at") or now) > self._risk_timeout_s]
        for rid in stale:
            self._pending.pop(rid, None)
        if stale:
            self._risk_timed_out += len(stale)
            self._rejected[RISK_TIMEOUT] = self._rejected.get(RISK_TIMEOUT, 0) + len(stale)
        return len(stale)

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {"built": self._built, "received": self._received,
                   "rejected": {k: v for k, v in self._rejected.items() if v},
                   "symbols_priced": len(self._last_price),
                   "awaiting_risk": len(self._pending),
                   "risk_declined": self._risk_declined,
                   "risk_timed_out": self._risk_timed_out}

        # لا أمر ليس عطلاً — قد لا يكون قرار مرّ بعد
        if self._received == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"بُني={self._built} من {self._received}", details=details,
        )

    # --------------------------------------------------- اللقطة --

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "built": self._built,
                "received": self._received, "rejected": dict(self._rejected)}

    async def restore(self, state: dict[str, Any]) -> None:
        """الأسعار لا تُستعاد: سعر مرجعي من تشغيل سابق يبني وقفاً وهدفاً
        على سوق لم يعد موجوداً."""
        self._built = int(state.get("built", 0))
        self._received = int(state.get("received", 0))
        self._rejected = {str(k): int(v)
                          for k, v in (state.get("rejected") or {}).items()}
