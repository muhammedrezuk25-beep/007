"""اختبارات الذرة 551 — منشئ أمر التداول."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]
import yaml as _yaml
from pathlib import Path as _MP
_MANIFEST_CONFIG = _yaml.safe_load(
    (_MP(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]

CONFIG = {**_MANIFEST_CONFIG, "default_volume": 0.01, "stop_distance_pct": 0.25,
          "target_distance_pct": 0.50, "require_reference_price": True}


def _load():
    spec = importlib.util.spec_from_file_location("_atom551", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom551"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 551
    def __init__(self, config=None):
        self.config = config or CONFIG
        self.published = []; self.handlers = {}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready(config=None, ctx_class=None, equity=100_000.0):
    """حساب مسجَّل ومعاملات عقود واصلة — وهما شرطا قياس أي حجم.

    وبدونهما لا يُبنى أمر: لا حجم افتراضي، لأن 0.01 رقمٌ لم يقسه أحد
    ويصل المنصّة ويفتح صفقة."""
    m = _load(); a = m.Atom(); c = (ctx_class or _AutoApproveCtx)(config)
    await a.initialize(c); await a.start()
    if equity is not None and "portfolio.account_tracked" in c.handlers:
        await c.handlers["portfolio.account_tracked"]({
            "account_id": "A", "equity": equity, "timestamp": 100.0})
    if "market.symbol_specs" in c.handlers:
        await c.handlers["market.symbol_specs"]({
            "provider": "MT5",
            "symbols": [{"symbol": s, "contract_size": 1.0, "tick_value": 1.0,
                         "tick_size": 0.01}
                        for s in ("US100", "USTEC", "NQ", "BTCUSD", "XAUUSD",
                                   "EURUSD")],
            "timestamp": 100.0})
    return m, a, c


def _built(c):
    return [p for n, p in c.published if n == "execution.order.built"]


async def _approve(c, approved=True, reason=None):
    handler = c.handlers.get("risk.validation.completed")
    if handler is None:
        return
    pending = [p for n, p in c.published if n == "risk.validation.requested"]
    for request in pending:
        await handler({"request_id": request.get("request_id"),
                       "approved": approved, "reason": reason})


class _AutoApproveCtx(Ctx):
    """551 no longer publishes the order directly: it asks 516 first and
    builds only on approval. Tests that assert on the built payload approve
    automatically so they keep testing what they were written to test."""

    async def publish(self, n, p):
        self.published.append((n, p))
        if n == "risk.validation.requested":
            handler = self.handlers.get("risk.validation.completed")
            if handler is not None:
                await handler({"request_id": p.get("request_id"), "approved": True})


async def _spec(c, symbol, contract_size=1.0):
    """معامل العقد يصل من 618 — وبدونه لا يُقاس حجم."""
    handler = c.handlers.get("market.symbol_specs")
    if handler is None:
        return
    await handler({"provider": "MT5", "symbols": [
        {"symbol": symbol, "contract_size": contract_size,
         "tick_value": 1.0, "tick_size": 0.01}], "timestamp": 100.0})


async def _price(c, value=1000.0, symbol="US100"):
    await c.handlers["market.tick"]({"symbol": symbol, "price": value})


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print_no_network():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for banned in ("print(", "import socket", "import sqlite3", "import urllib"):
        assert banned not in src


@pytest.mark.asyncio
async def test_buy_stop_below_target_above():
    m, a, c = await _ready()
    await _price(c, 1000.0)
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "BUY"})
    o = _built(c)[0]
    assert o["stop_loss"] == pytest.approx(997.5)     # −0.25%
    assert o["take_profit"] == pytest.approx(1005.0)  # +0.50%
    assert o["stop_loss"] < o["reference_price"] < o["take_profit"]


@pytest.mark.asyncio
async def test_sell_stop_above_target_below():
    """عكس الاتجاه في البيع يجعل الوقف هدفاً والهدف وقفاً."""
    m, a, c = await _ready()
    await _price(c, 1000.0)
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "SELL"})
    o = _built(c)[0]
    assert o["stop_loss"] == pytest.approx(1002.5)
    assert o["take_profit"] == pytest.approx(995.0)
    assert o["take_profit"] < o["reference_price"] < o["stop_loss"]


@pytest.mark.asyncio
async def test_distances_are_percentage_not_points():
    """النقاط تختلف معناها بين أداة وأخرى — النسبة واحدة."""
    m, a, c = await _ready()
    await _price(c, 100.0, "SMALL"); await _spec(c, "SMALL")
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "SMALL", "side": "BUY"})
    small = _built(c)[-1]
    await _price(c, 60000.0, "BIG"); await _spec(c, "BIG")
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "BIG", "side": "BUY"})
    big = _built(c)[-1]
    small_gap = small["reference_price"] - small["stop_loss"]
    big_gap = big["reference_price"] - big["stop_loss"]
    assert big_gap > small_gap * 100          # المسافة تتناسب مع السعر


@pytest.mark.asyncio
async def test_volume_from_payload_overrides_default():
    """حين تحسبه إدارة المخاطر يُستعمل بدل الافتراضي."""
    m, a, c = await _ready()
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "symbol": "US100", "side": "BUY", "volume": 0.5})
    assert _built(c)[0]["volume"] == 0.5


@pytest.mark.asyncio
async def test_an_unmeasurable_size_is_refused_not_defaulted():
    """كان يرجع إلى default_volume حين يعجز عن القياس.

    و0.01 رقمٌ لم يقسه أحد: يصل المنصّة ويفتح صفقة بحجم لا سند له. و508
    يرفض في الحالة نفسها، والاتّساق هنا هو الحماية."""
    m, a, c = await _ready(equity=None)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "symbol": "US100", "side": "BUY"})
    assert not _built(c)
    rejected = [p for n, p in c.published if n == "execution.order.rejected"]
    assert rejected and rejected[-1]["reason"] == "NO_MEASURED_SIZE"


@pytest.mark.asyncio
async def test_no_price_rejects_not_guesses():
    """أمر بلا وقف مخاطرة مفتوحة — يُرفض بدل أن يُرسل عارياً."""
    m, a, c = await _ready()
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "BUY"})
    assert _built(c) == []
    rejected = [p for n, p in c.published if n == "execution.order.rejected"]
    assert rejected and rejected[0]["reason"] == "no_reference_price"


@pytest.mark.asyncio
async def test_payload_price_used_before_last_tick():
    m, a, c = await _ready()
    await _price(c, 1000.0)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "symbol": "US100", "side": "BUY", "price": 2000.0})
    assert _built(c)[0]["reference_price"] == 2000.0


@pytest.mark.asyncio
async def test_unknown_side_rejected():
    m, a, c = await _ready()
    await _price(c)
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "HOLD"})
    assert _built(c) == []
    assert a._rejected["unknown_side"] == 1


@pytest.mark.asyncio
async def test_missing_symbol_rejected():
    m, a, c = await _ready()
    await c.handlers["execution.order.requested"]({"account_id": "A", "side": "BUY"})
    assert _built(c) == []
    assert a._rejected["no_symbol"] == 1


@pytest.mark.asyncio
async def test_decision_fields_passed_through():
    """414 يتعلّم أي استراتيجية أنتجت أي نتيجة."""
    m, a, c = await _ready()
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "symbol": "US100", "side": "BUY", "strategy": "trend", "confidence": 0.82})
    o = _built(c)[0]
    assert o["strategy"] == "trend" and o["confidence"] == 0.82


@pytest.mark.asyncio
async def test_symbols_priced_independently():
    m, a, c = await _ready()
    await _price(c, 1000.0, "A"); await _spec(c, "A")
    await _price(c, 50.0, "B"); await _spec(c, "B")
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "B", "side": "BUY"})
    assert _built(c)[0]["reference_price"] == 50.0


@pytest.mark.asyncio
async def test_nan_price_ignored():
    m, a, c = await _ready()
    await _price(c, float("nan"))
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "BUY"})
    assert _built(c) == []


@pytest.mark.asyncio
async def test_health_no_orders_is_degraded_not_broken():
    m, a, c = await _ready()
    s = await a.health_check()
    assert s.state.name == "DEGRADED" and "NO_ORDERS" in s.message


@pytest.mark.asyncio
async def test_prices_not_restored():
    """سعر من تشغيل سابق يبني وقفاً على سوق لم يعد موجوداً."""
    m, a, c = await _ready()
    await _price(c, 1000.0)
    await c.handlers["execution.order.requested"]({"account_id": "A", "symbol": "US100", "side": "BUY"})
    snap = await a.snapshot()
    fresh = m.Atom(); await fresh.initialize(Ctx()); await fresh.restore(snap)
    assert fresh._last_price == {}
    assert fresh._built == snap["built"]


# ═══ risk validation gate ═══

@pytest.mark.asyncio
async def test_asks_risk_before_building():
    """551 no longer publishes the order straight out. The build paper says it
    consumes risk.validation.completed from 500, and 516 has been publishing
    that event with no reader since it was built."""
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    asked = [p for n, p in c.published if n == "risk.validation.requested"]
    assert len(asked) == 1
    assert asked[0]["request_id"] == "r1"
    assert _built(c) == []


@pytest.mark.asyncio
async def test_builds_only_after_approval():
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    assert _built(c) == []
    await _approve(c, True)
    assert len(_built(c)) == 1
    assert _built(c)[0]["request_id"] == "r1"


@pytest.mark.asyncio
async def test_declined_order_is_rejected_not_built():
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    await _approve(c, False, "KILL_SWITCH")
    assert _built(c) == []
    rejected = [p for n, p in c.published if n == "execution.order.rejected"]
    assert rejected and rejected[0]["reason"] == "KILL_SWITCH"


@pytest.mark.asyncio
async def test_response_for_an_unknown_request_is_ignored():
    m, a, c = await _ready(ctx_class=Ctx)
    await c.handlers["risk.validation.completed"](
        {"request_id": "never-asked", "approved": True})
    assert _built(c) == []


@pytest.mark.asyncio
async def test_a_response_is_consumed_once():
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    await _approve(c, True)
    await c.handlers["risk.validation.completed"](
        {"request_id": "r1", "approved": True})
    assert len(_built(c)) == 1


@pytest.mark.asyncio
async def test_two_orders_are_tracked_independently():
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    for rid in ("r1", "r2"):
        await c.handlers["execution.order.requested"](
            {"account_id": "A", "request_id": rid, "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    await c.handlers["risk.validation.completed"]({"request_id": "r2", "approved": True})
    built = _built(c)
    assert len(built) == 1 and built[0]["request_id"] == "r2"

    await c.handlers["risk.validation.completed"](
        {"request_id": "r1", "approved": False, "reason": "MAX_OPEN_TRADES"})
    assert len(_built(c)) == 1


@pytest.mark.asyncio
async def test_health_reports_pending_and_declined():
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    details = (await a.health_check()).details
    assert details["awaiting_risk"] == 1

    await _approve(c, False, "KILL_SWITCH")
    details = (await a.health_check()).details
    assert details["awaiting_risk"] == 0
    assert details["risk_declined"] == 1


@pytest.mark.asyncio
async def test_stale_pending_orders_expire():
    """An order left waiting forever holds memory and hides a broken 516."""
    m, a, c = await _ready(ctx_class=Ctx)
    await _price(c)
    await c.handlers["execution.order.requested"](
        {"account_id": "A", "request_id": "r1", "symbol": "US100", "side": "BUY", "timestamp": 100.0})
    assert a._expire_pending(100.0 + CONFIG["risk_timeout_s"] + 1) == 1
    assert (await a.health_check()).details["awaiting_risk"] == 0


@pytest.mark.asyncio
async def test_timeout_actually_runs_on_market_ticks():
    """The expiry existed but nothing called it: 500 orders stayed in memory
    forever and hid the fact that 516 had stopped answering."""
    m, a, c = await _ready(ctx_class=Ctx)
    await c.handlers["market.tick"]({"symbol": "US100", "price": 1000.0,
                                     "timestamp": 100.0})
    for i in range(50):
        await c.handlers["execution.order.requested"](
            {"account_id": "A", "request_id": f"r{i}", "symbol": "US100", "side": "BUY",
             "timestamp": 100.0})
    assert (await a.health_check()).details["awaiting_risk"] == 50

    await c.handlers["market.tick"]({"symbol": "US100", "price": 1000.0,
                                     "timestamp": 102.0})
    assert (await a.health_check()).details["awaiting_risk"] == 50

    await c.handlers["market.tick"](
        {"symbol": "US100", "price": 1000.0,
         "timestamp": 100.0 + CONFIG["risk_timeout_s"] + 1})
    details = await a.health_check()
    assert details.details["awaiting_risk"] == 0
    assert details.details["risk_timed_out"] == 50


@pytest.mark.asyncio
async def test_expiry_uses_the_tick_stamp_not_a_local_clock():
    m, a, c = await _ready(ctx_class=Ctx)
    # Code only, not docstrings: the file explains the rule in prose.
    import ast as _ast
    tree = _ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))
    calls = [n for n in _ast.walk(tree) if isinstance(n, _ast.Call)]
    for call in calls:
        func = call.func
        if isinstance(func, _ast.Attribute) and func.attr == "time":
            assert not (isinstance(func.value, _ast.Name) and func.value.id == "time")


# ── حجم المركز من المخاطرة، لا حجم ثابت ─────────────────────────────

import importlib.util as _iu551
import sys as _sys551
import yaml as _y551
from pathlib import Path as _P551

_D551 = _P551(__file__).resolve().parents[1]
_S551 = _iu551.spec_from_file_location("_rsk551", _D551 / "atom.py")
_M551 = _iu551.module_from_spec(_S551)
_sys551.modules["_rsk551"] = _M551
_sys551.path.insert(0, str(_D551))
try:
    _S551.loader.exec_module(_M551)
finally:
    _sys551.path.remove(str(_D551))

_CFG551 = _y551.safe_load((_D551 / "manifest.yaml").read_text(encoding="utf-8"))["config"]


class _Risk551:
    atom_id = 551

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, **over):
        self.config = {**_CFG551, **over}
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _risk_atom(equity=10_000.0, **over):
    """الحساب "A" مسجَّل بحقوقه: الحجم يُحسب من حقوق حسابه لا من رقم عامّ."""
    atom = _M551.Atom()
    ctx = _Risk551(**over)
    await atom.initialize(ctx)
    await atom.start()
    if equity is not None:
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": "A", "equity": equity, "timestamp": 1785600000.0})
    # معاملات العقود تصل من 618. وبدونها لا يُقاس حجم، ولا حجم افتراضي:
    # 0.01 رقمٌ لم يقسه أحد ويصل المنصّة ويفتح صفقة.
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": s, "contract_size": 1.0, "tick_value": 1.0,
                     "tick_size": 0.01}
                    for s in ("USTEC", "NQ", "US100", "BTCUSD", "EURUSD")],
        "timestamp": 1785600000.0})
    return atom, ctx


@pytest.mark.asyncio
async def test_the_manifest_declares_a_risk_percentage():
    """A fixed 0.01 lot risks a different fraction of the account on every
    instrument and every stop distance. Scalping on M1 fires often, so the
    same fixed lot compounds the mismatch."""
    assert "risk_per_trade_pct" in _CFG551
    assert _CFG551["risk_per_trade_pct"] == 1.0


@pytest.mark.asyncio
async def test_volume_scales_with_equity():
    """One percent of a bigger account is a bigger position for the same
    stop distance."""
    # السقف مرفوع هنا عمدًا: هذا اختبار للتناسب لا للسقف، والسقف له
    # اختباره الخاص أدناه.
    atom, ctx = await _risk_atom(max_volume=1000.0)
    for acc, eq in (("small", 10_000.0), ("large", 100_000.0)):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": eq, "timestamp": 1785600000.0})
    small = atom.size_for("small", reference=28_400.0,
                          stop_distance=28_400.0 * 0.0012, contract_size=1.0)
    large = atom.size_for("large", reference=28_400.0,
                          stop_distance=28_400.0 * 0.0012, contract_size=1.0)
    assert large > small
    assert round(large / small, 1) == 10.0


@pytest.mark.asyncio
async def test_a_wider_stop_gives_a_smaller_position():
    """The loss at the stop is what is held at one percent, so a stop twice
    as far must halve the size."""
    atom, ctx = await _risk_atom(max_volume=1000.0)
    tight = atom.size_for("A", reference=28_400.0,
                          stop_distance=10.0, contract_size=1.0)
    wide = atom.size_for("A", reference=28_400.0,
                         stop_distance=20.0, contract_size=1.0)
    assert round(tight / wide, 1) == 2.0


@pytest.mark.asyncio
async def test_the_loss_at_the_stop_is_one_percent():
    atom, ctx = await _risk_atom(risk_per_trade_pct=1.0)
    equity = 10_000.0
    stop_distance = 12.0
    size = atom.size_for("A", reference=28_400.0,
                         stop_distance=stop_distance, contract_size=1.0)
    loss = size * stop_distance * 1.0
    assert abs(loss - equity * 0.01) <= equity * 0.01 * 0.51


@pytest.mark.asyncio
async def test_the_contract_size_is_honoured():
    """A forex lot is 100000 units and an index CFD is 1. Ignoring that
    makes the same number mean two different risks."""
    atom, ctx = await _risk_atom()
    index = atom.size_for("A", reference=28_400.0,
                          stop_distance=12.0, contract_size=1.0)
    forex = atom.size_for("A", reference=1.085,
                          stop_distance=0.0012, contract_size=100_000.0)
    assert index > 0 and forex > 0
    assert index != forex


@pytest.mark.asyncio
async def test_a_missing_equity_falls_back_and_says_so():
    """Without an account figure there is nothing to take one percent of.
    Guessing a size would be inventing the risk."""
    atom, ctx = await _risk_atom(equity=None)
    assert atom.size_for("A", reference=28_400.0,
                         stop_distance=12.0, contract_size=1.0) is None


@pytest.mark.asyncio
async def test_a_zero_stop_distance_is_refused():
    atom, ctx = await _risk_atom()
    assert atom.size_for("A", reference=28_400.0,
                         stop_distance=0.0, contract_size=1.0) is None


@pytest.mark.asyncio
async def test_the_size_respects_the_broker_floor_and_ceiling():
    atom, ctx = await _risk_atom(equity=100_000.0, min_volume=0.01, max_volume=2.0)
    huge = atom.size_for("A", reference=28_400.0,
                         stop_distance=1.0, contract_size=1.0)
    # وقف واسع جدًّا على عقد كبير: النتيجة تحت الأرضية فتُرفع إليها.
    tiny = atom.size_for("A", reference=28_400.0,
                         stop_distance=500.0, contract_size=1_000.0)
    assert huge == 2.0
    assert tiny == 0.01


@pytest.mark.asyncio
async def test_the_size_lands_on_the_broker_step():
    atom, ctx = await _risk_atom(volume_step=0.01)
    size = atom.size_for("A", reference=28_400.0,
                         stop_distance=7.3, contract_size=1.0)
    assert abs(round(size / 0.01) * 0.01 - size) < 1e-9


# ── الحجم من حقوق حسابه ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_the_size_comes_from_the_target_account_equity():
    """حقوق واحدة لكل الحسابات تعني حجمًا محسوبًا من حساب ومرسَلًا إلى
    آخر — بمال حقيقي وبلا أن يظهر عطل.

    حساب بعشرة آلاف وآخر بمئة ألف يخاطران بنسبة واحدة: الحجمان يجب أن
    يختلفا عشر مرّات."""
    # السقف مرفوع: هذا اختبار للتناسب لا للسقف.
    atom, ctx = await _risk_atom(equity=None, max_volume=1000.0)
    for acc, eq in (("A", 10000.0), ("B", 100000.0)):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": eq, "timestamp": 1785600000.0})
    small = atom.size_for("A", reference=28_400.0,
                          stop_distance=34.08, contract_size=1.0)
    large = atom.size_for("B", reference=28_400.0,
                          stop_distance=34.08, contract_size=1.0)
    # التقريب إلى خطوة الوسيط يزيح النتيجة قليلًا، والنسبة هي المقصودة.
    assert round(large / small, 1) == 10.0


@pytest.mark.asyncio
async def test_an_unknown_account_gets_no_size():
    """Fail Closed. حجمٌ من حقوق لا يعرفها أحد ليس حجمًا."""
    atom, ctx = await _risk_atom()
    assert atom.size_for("UNKNOWN", reference=28_400.0,
                         stop_distance=34.08, contract_size=1.0) is None


# ── نسبة مخاطرة لكل حساب ────────────────────────────────────────────

def test_the_manifest_allows_a_percentage_per_account():
    """نسبة واحدة لكل الحسابات تخالف قرار المالك: حساب الذهب يخاطر
    بواحد بالمئة وحساب المؤشّرات بنصفه.

    والافتراضي يبقى لحساب لم يُذكَر — فحساب جديد لا يتداول بلا نسبة
    بل بالنسبة المحافظة المعلَنة."""
    assert "risk_per_trade_pct_by_account" in _CFG551
    assert "risk_per_trade_pct" in _CFG551


@pytest.mark.asyncio
async def test_each_account_risks_its_own_percentage():
    atom, ctx = await _risk_atom(
        equity=None, max_volume=1000.0,
        risk_per_trade_pct_by_account={"GOLD": 1.0, "INDEX": 0.5})
    for acc in ("GOLD", "INDEX"):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": 100_000.0, "timestamp": 1785600000.0})
    gold = atom.size_for("GOLD", reference=2650.0,
                         stop_distance=26.5, contract_size=1.0)
    index = atom.size_for("INDEX", reference=2650.0,
                          stop_distance=26.5, contract_size=1.0)
    assert round(gold / index, 1) == 2.0


@pytest.mark.asyncio
async def test_an_account_with_no_entry_uses_the_default():
    atom, ctx = await _risk_atom(
        equity=None, max_volume=1000.0,
        risk_per_trade_pct_by_account={"GOLD": 1.0})
    for acc in ("GOLD", "OTHER"):
        await ctx.handlers["portfolio.account_tracked"]({
            "account_id": acc, "equity": 100_000.0, "timestamp": 1785600000.0})
    known = atom.size_for("GOLD", reference=2650.0,
                          stop_distance=26.5, contract_size=1.0)
    unknown = atom.size_for("OTHER", reference=2650.0,
                            stop_distance=26.5, contract_size=1.0)
    assert known == unknown == pytest.approx(known)


@pytest.mark.asyncio
async def test_the_percentage_is_reported_with_the_order():
    """من يقرأ الأمر يرى بأي نسبة حُسب حجمه — وإلا صار الرقم بلا سند."""
    atom, ctx = await _risk_atom(
        equity=None, risk_per_trade_pct_by_account={"GOLD": 1.0})
    await ctx.handlers["portfolio.account_tracked"]({
        "account_id": "GOLD", "equity": 100_000.0, "timestamp": 1785600000.0})
    # معامل عقد الذهب 100 — لا يُفترض، يصل من 618.
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "XAUUSD", "contract_size": 100.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": 1785600000.0})
    await ctx.handlers["market.tick"]({
        "provider": "MT5", "symbol": "XAUUSD", "price": 2650.0,
        "timestamp": 1785600000.0})
    await ctx.handlers["execution.order.requested"]({
        "account_id": "GOLD", "symbol": "XAUUSD", "side": "BUY",
        "request_id": "g1", "timestamp": 1785600000.0})
    # الأمر ينتظر موافقة المخاطر قبل أن يُبنى — وهذا مقصود.
    await ctx.handlers["risk.validation.completed"]({
        "request_id": "g1", "approved": True, "timestamp": 1785600000.0})
    built = [p for n, p in ctx.published if n == "execution.order.built"]
    rejected = [p for n, p in ctx.published if n == "execution.order.rejected"]
    assert built, "رُفض بـ%s" % (rejected[-1].get("reason") if rejected else "?")
    # المعلَنة هي النيّة، والفعلية ما أُخذ. وهما متقاربتان هنا: لا سقف
    # يقصّ، وخطوة الوسيط وحدها تقرّب الحجم لأسفل.
    assert built[-1]["risk_pct_intended"] == 1.0
    assert 0.99 <= built[-1]["risk_pct"] <= 1.0
    assert built[-1]["size_capped"] is False


@pytest.mark.asyncio
async def test_a_missing_contract_size_is_refused_not_assumed():
    """كان يفترض 1.0 حين يغيب المعامل. والذهب معامله 100، فالحجم يخرج
    مئة ضعف ولا يمنعه إلا السقف — وقيس على تشغيل حيّ: 113 أمرًا على
    XAUUSD بحجم 50 لوت، وهو سقف max_volume لا نتيجة حساب.

    و508 يرفض بلا معامل. وأن يفترضه هذا هو الفرق بين رقم مقيس ورقم
    مخترَع يسوق صفقة."""
    atom, ctx = await _risk_atom(equity=100_000.0, max_volume=1000.0)
    assert atom.size_for("A", reference=2650.0, stop_distance=3.18,
                         contract_size=None) is None


@pytest.mark.asyncio
async def test_an_order_without_a_contract_size_is_not_built():
    atom, ctx = await _risk_atom(equity=100_000.0)
    await ctx.handlers["market.tick"]({
        "provider": "MT5", "symbol": "XAUUSD", "price": 2650.0,
        "timestamp": 1785600000.0})
    await ctx.handlers["execution.order.requested"]({"account_id": "A", 
        "account_id": "A", "symbol": "XAUUSD", "side": "BUY",
        "request_id": "x1", "timestamp": 1785600000.0})
    await ctx.handlers["risk.validation.completed"]({
        "request_id": "x1", "approved": True, "timestamp": 1785600000.0})
    built = [p for n, p in ctx.published if n == "execution.order.built"]
    assert not built
    rejected = [p for n, p in ctx.published if n == "execution.order.rejected"]
    assert rejected


@pytest.mark.asyncio
async def test_the_spec_from_618_sizes_the_order():
    """المعامل يصل حدثًا من 618، فيُحسب الحجم عليه لا على افتراض."""
    atom, ctx = await _risk_atom(equity=100_000.0, max_volume=1000.0)
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "XAUUSD", "contract_size": 100.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": 1785600000.0})
    size = atom.size_for("A", reference=2650.0, stop_distance=3.18,
                         contract_size=None, symbol="XAUUSD")
    assert size is not None
    assert round(size, 2) == 3.14


@pytest.mark.asyncio
async def test_a_capped_size_reports_the_risk_it_actually_takes():
    """السقف يقصّ الحجم ويترك `risk_pct` معلنة كما هي.

    وقيس على تشغيل بالقيم الحقيقية: USTEC حجمه الخام 27.62 لوت، والسقف
    5.0 — فالمخاطرة الفعلية 0.181% والأمر يقول 1%.

    ومن يقرأ الأمر يظنّ الحساب يخاطر بخمسة أضعاف ما يخاطر به، ومن يقيّم
    الاستراتيجية يقسم عائدها على مخاطرة لم تُؤخَذ."""
    atom, ctx = await _risk_atom(equity=100_000.0, max_volume=5.0)
    await ctx.handlers["market.symbol_specs"]({
        "provider": "MT5",
        "symbols": [{"symbol": "USTEC", "contract_size": 1.0,
                     "tick_value": 1.0, "tick_size": 0.01}],
        "timestamp": 1785600000.0})
    await ctx.handlers["market.tick"]({
        "provider": "MT5", "symbol": "USTEC", "price": 30_173.42,
        "timestamp": 1785600000.0})
    await ctx.handlers["execution.order.requested"]({
        "account_id": "A", "symbol": "USTEC", "side": "BUY",
        "request_id": "u1", "timestamp": 1785600000.0})
    await ctx.handlers["risk.validation.completed"]({
        "request_id": "u1", "approved": True, "timestamp": 1785600000.0})
    built = [p for n, p in ctx.published if n == "execution.order.built"]
    assert built
    order = built[-1]
    assert order["volume"] == 5.0
    assert order["risk_pct_intended"] == 1.0
    assert round(order["risk_pct"], 3) == 0.181
    assert order["size_capped"] is True
