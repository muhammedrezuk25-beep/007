"""اختبارات الذرّة 563 — مترجم أحداث التنفيذ"""

from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_SPEC = importlib.util.spec_from_file_location("_atom563", ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_SPEC)
sys.modules["_atom563"] = MODULE
sys.path.insert(0, str(ATOM_DIR))
try:
    _SPEC.loader.exec_module(MODULE)
finally:
    sys.path.remove(str(ATOM_DIR))

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785600000.0


class Ctx:
    atom_id = 563

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self):
        self.config = {}
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def events(ctx, name):
    return [p for n, p in ctx.published if n == name]


def _row(kind, **over):
    body = {"event_type": kind, "ticket": 1, "symbol": "USTEC", "side": "BUY",
            "volume": 0.5, "entry_price": 28400.0, "exit_price": None,
            "open_time": TS, "close_time": None, "reason": None,
            "source_row_id": 1, "timestamp": TS}
    body.update(over)
    return body


# ── البنية ──────────────────────────────────────────────────────────

def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_it_no_longer_opens_the_bridge():
    """ورقة بناء 550 تقول: «يشترك: تأكيد كتابة ناجحة من 601».

    والمبنيّ جعله قارئ جسر ثانيًا — فحمل ذرّة تنفيذ مسارًا إلى ملف
    يملكه قسم 600، وربط نتيجة الصفقة بـMT5: حساب على بايننس يكتب
    نتائجه في مكان آخر ولا تصل هذه الذرّة أبدًا."""
    assert MANIFEST["config"] == {}
    assert "platform.trade_event" in MANIFEST["subscribes"]
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for marker in ("sqlite3", "nq_brain", "SELECT", "_bridge_connect", "asyncio"):
        assert marker not in src


def test_manifest_matches_code():
    assert MANIFEST["id"] == 563
    assert set(MANIFEST["subscribes"]) == {MODULE.EVENT_IN, MODULE.EVENT_WRITTEN}
    assert set(MANIFEST["publishes"]) == {
        MODULE.EVENT_OPENED, MODULE.EVENT_CLOSED,
        MODULE.EVENT_REJECTED, MODULE.EVENT_CONFIRMED}


def test_no_clock_reading():
    """3 و806 و608 يملكون الساعة. والطابع مورَّث من الصفّ."""
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


# ── الترجمة ─────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_an_opened_row_becomes_a_trade_opened():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    opened = events(ctx, MODULE.EVENT_OPENED)
    assert opened and opened[-1]["ticket"] == 1
    assert opened[-1]["entry_price"] == 28400.0


@pytest.mark.asyncio
async def test_a_closed_row_becomes_a_trade_closed():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](
        _row("CLOSED", exit_price=28450.0, close_time=TS + 60))
    closed = events(ctx, MODULE.EVENT_CLOSED)
    assert closed and closed[-1]["exit_price"] == 28450.0
    assert closed[-1]["partial"] is False


@pytest.mark.asyncio
async def test_a_partial_close_is_marked_as_such():
    """الإغلاق الجزئي صفقة مغلقة بحجمها، والباقي المفتوح يصله حدث
    مستقلّ حين يُغلق."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](
        _row("PARTIAL", exit_price=28450.0, close_time=TS + 60))
    closed = events(ctx, MODULE.EVENT_CLOSED)
    assert closed and closed[-1]["partial"] is True


@pytest.mark.asyncio
async def test_a_rejected_row_becomes_a_trade_rejected():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("REJECTED", reason="NO_MONEY"))
    rejected = events(ctx, MODULE.EVENT_REJECTED)
    assert rejected and rejected[-1]["reason"] == "NO_MONEY"


@pytest.mark.asyncio
async def test_an_unknown_kind_publishes_nothing():
    """نوع لا يعرفه لا يُترجَم إلى أقرب معروف: الترجمة الخاطئة أسوأ من
    غيابها — 517 سيحسب ربحًا لصفقة لم تقع."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("SOMETHING_ELSE"))
    assert not ctx.published


@pytest.mark.asyncio
async def test_the_same_row_is_translated_once():
    """611 يحفظ موضعه، لكنّ إعادة تشغيل أو إطارًا معادًا يقيّد الصفقة
    مرّتين — و517 يحسب ربحها مرّتين معها."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    first = len(ctx.published)
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    assert len(ctx.published) == first


# ── تأكيد الكتابة ───────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_a_write_confirmation_is_announced_as_accepted():
    """هذه وظيفته في الورقة: يسمع تأكيد الكتابة من 601 ويعلن أن الأمر
    وصل الطابور — لا أنه نُفّذ."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_WRITTEN]({
        "request_id": "r1", "symbol": "USTEC", "action": "OPEN",
        "timestamp": TS})
    confirmed = events(ctx, MODULE.EVENT_CONFIRMED)
    assert confirmed
    assert confirmed[-1]["request_id"] == "r1"
    assert confirmed[-1]["accepted"] is True


@pytest.mark.asyncio
async def test_an_empty_confirmation_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_WRITTEN]({"timestamp": TS})
    assert not events(ctx, MODULE.EVENT_CONFIRMED)


@pytest.mark.asyncio
async def test_it_stays_silent_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    assert not ctx.published


@pytest.mark.asyncio
async def test_the_lifecycle_is_clean():
    atom, ctx = await _ready()
    await atom.stop()
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    assert not ctx.published
    await atom.shutdown()


# ── الصحّة تُفحص فعلًا ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_health_check_runs_without_raising():
    """فحص الصحّة بقي من نسخة كانت تقرأ الجسر، فظلّ يشير إلى حقول
    حُذفت: يرمي AttributeError كل ثلاثين ثانية، فتُعلَن الذرّة معطوبة
    بعد ثلاث محاولات وتُعاد تشغيلها — كل تسعين ثانية بلا انقطاع.

    ولم يظهر في الاختبارات لأن الصحّة نفسها لم تكن مفحوصة."""
    atom, ctx = await _ready()
    status = await atom.health_check()
    assert status.state.name in ("HEALTHY", "DEGRADED")


@pytest.mark.asyncio
async def test_health_is_degraded_before_the_first_row():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_is_healthy_after_a_translation():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_health_says_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_the_translated_rows_survive_a_restart():
    """مفاتيح الصفوف المترجَمة تُحفظ: بدونها تُعاد ترجمة صفٍّ بعد إعادة
    التشغيل، فتُنشر صفقة قديمة كأنها جديدة و517 يحسب ربحها مرّتين."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    fresh_ctx = Ctx()
    await fresh.initialize(fresh_ctx)
    await fresh.restore(state)
    await fresh.start()
    await fresh_ctx.handlers[MODULE.EVENT_IN](_row("OPENED"))
    assert not fresh_ctx.published
    assert fresh.translated_count == atom.translated_count
