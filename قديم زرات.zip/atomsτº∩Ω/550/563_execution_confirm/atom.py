from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "platform.trade_event"
EVENT_WRITTEN = "platform.brain_signal.written"

EVENT_OPENED = "trade.opened"
EVENT_CLOSED = "trade.closed"
EVENT_REJECTED = "trade.rejected"
EVENT_CONFIRMED = "execution.confirmed"

KIND_OPENED = "OPENED"
KIND_CLOSED = "CLOSED"
KIND_PARTIAL = "PARTIAL"
KIND_REJECTED = "REJECTED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_EVENTS = "NO_EVENTS_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    """Turns a platform's raw trade row into the events the system speaks.

    It used to open the bridge database itself and poll trade_events. The
    build paper says otherwise — "subscribes: a successful write confirmation
    from 601" — and the drift cost something concrete: an execution atom held
    a path into a file section 600 owns, and the outcome of a trade was bound
    to MT5. A Binance account records its results elsewhere, and this atom
    would never have seen them.

    611 reads the table now, whatever the venue. This atom translates, and a
    second venue is one more reader beside 611 rather than a change here.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._published: dict[str, int] = {}
        self._seen: set[Any] = set()
        self.translated_count = 0
        self.unknown_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_trade_event)
        context.subscribe(EVENT_WRITTEN, self._on_written)
        self._initialized = True
        context.logger.info("563 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("563 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("563 stopped (translated=%d)",
                                      self.translated_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_trade_event(self, payload: dict[str, Any]) -> None:
        """One row, translated once.

        The row id guards against a repeat: 611 remembers its position, but a
        restart or a replayed frame would otherwise book the same trade
        twice, and 517 would compute its result twice with it.
        """
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        row_id = inner.get("source_row_id")
        if row_id is not None:
            key = str(row_id)
            if key in self._seen:
                return
            self._seen.add(key)
        await self._emit(inner)

    async def _on_written(self, payload: dict[str, Any]) -> None:
        """A successful write into the bridge, announced as accepted.

        This is what the build paper asks of this atom. The order has reached
        the queue the platform reads; it has not filled yet, and the fill
        arrives later as its own row.
        """
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        body = {key: inner.get(key)
                for key in ("request_id", "symbol", "side", "action", "volume")
                if inner.get(key) is not None}
        if not body:
            return
        body["accepted"] = True
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._publish(EVENT_CONFIRMED, body)

    async def _emit(self, row: dict[str, Any]) -> None:
        if self._context is None:
            return

        kind = str(row.get("event_type") or "").strip().upper()
        account_id = row.get("account_id")
        ticket = row.get("ticket")
        symbol = row.get("symbol")
        side = str(row.get("side") or "").strip().upper()

        base = {
            "trade_id": str(ticket) if ticket is not None else None,
            "ticket": ticket,
            "account_id": account_id,
            "symbol": symbol,
            "side": side,
            "size": _to_float(row.get("volume")),
            "entry_price": _to_float(row.get("entry_price")),
            "exit_price": _to_float(row.get("exit_price")),
            "opened_at": _to_float(row.get("open_time")),
            "closed_at": _to_float(row.get("close_time")),
            "reason": row.get("reason"),
            "source_event_id": row.get("id"),
        }

        self.translated_count += 1
        if kind == KIND_OPENED:
            await self._publish(EVENT_OPENED, base)
            await self._publish(EVENT_CONFIRMED, base)
        elif kind in (KIND_CLOSED, KIND_PARTIAL):
            # الإغلاق الجزئي صفقة مغلقة بحجمها: 517 يحسب ربحها كما هي،
            # والباقي المفتوح يصله حدث إغلاق مستقل حين يُغلق.
            await self._publish(EVENT_CLOSED, {**base, "partial": kind == KIND_PARTIAL})
        elif kind == KIND_REJECTED:
            await self._publish(EVENT_REJECTED, base)
        else:
            self.unknown_count += 1
            self.translated_count -= 1
            self._context.logger.warning("نوع حدث تنفيذ غير معروف: %r", kind)
            return

        self._context.logger.info(
            "تنفيذ %s: %s %s حجم=%s", kind, symbol, side, base["size"],
        )

    async def _publish(self, name: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        self._published[name] = self._published.get(name, 0) + 1
        await self._context.publish(name, payload)

    # ---------------------------------------------------- الصحة --

    async def health_check(self) -> HealthStatus:
        """Health of a translator, not of a reader.

        This check was left over from the version that polled the bridge and
        still named fields that no longer exist. It raised every thirty
        seconds, so the atom was declared unhealthy after three attempts and
        restarted — every ninety seconds, without pause, while translating
        perfectly well. It went unseen because health itself was not tested.
        """
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {"translated": self.translated_count,
                   "unknown": self.unknown_count,
                   "published": dict(self._published),
                   "seen_rows": len(self._seen)}
        if not self._published:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_EVENTS, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="translated=%d" % self.translated_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        """The rows already translated are kept.

        Without them a row is translated again after a restart: an old trade
        is published as new, and 517 books its result a second time. 611
        remembers its own position, but the two are not the same guard — a
        replayed frame reaches this atom without 611 moving at all.
        """
        return {"version": ATOM_VERSION,
                "seen": sorted(str(x) for x in self._seen),
                "translated": self.translated_count,
                "unknown": self.unknown_count,
                "published": dict(self._published)}

    async def restore(self, state: dict[str, Any]) -> None:
        self._seen = set(state.get("seen") or [])
        self.translated_count = int(state.get("translated", 0))
        self.unknown_count = int(state.get("unknown", 0))
        self._published = {str(k): int(v)
                           for k, v in (state.get("published") or {}).items()}

