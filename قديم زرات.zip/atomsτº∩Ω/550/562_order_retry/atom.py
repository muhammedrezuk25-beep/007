from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_ANALYZED = "execution.rejection_analyzed"
EVENT_BUILT = "execution.order.built"
EVENT_TICK = "market.tick"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "execution.order.built"
EVENT_ABANDONED = "execution.retry_abandoned"

RETRYABLE = "RETRYABLE"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_RETRIES = "NO_RETRIES_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._max_attempts = 0
        self._backoff_s = 0.0
        self._memory_limit = 0
        self._orders: dict[str, dict[str, Any]] = {}
        self._order_keys: list[str] = []
        self._attempts: dict[str, int] = {}
        self._waiting: dict[str, float] = {}
        self.retried_count = 0
        self.abandoned_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._max_attempts = int(cfg["max_attempts"])
        self._backoff_s = float(cfg["backoff_s"])
        self._memory_limit = int(cfg["pending_orders_memory"])
        context.subscribe(EVENT_BUILT, self._on_built)
        context.subscribe(EVENT_ANALYZED, self._on_analyzed)
        context.subscribe(EVENT_TICK, self._on_tick)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("562 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("562 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("562 stopped (retried=%d, abandoned=%d)",
                                      self.retried_count, self.abandoned_count)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_built(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        request_id = inner.get("request_id")
        if not request_id or inner.get("retry_of"):
            return
        key = str(request_id)
        if key not in self._orders:
            self._order_keys.append(key)
        self._orders[key] = dict(inner)
        while len(self._order_keys) > self._memory_limit:
            stale = self._order_keys.pop(0)
            self._orders.pop(stale, None)
            self._attempts.pop(stale, None)
            self._waiting.pop(stale, None)

    async def _on_analyzed(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if str(payload.get("disposition", "")).upper() != RETRYABLE:
            return
        request_id = payload.get("request_id")
        if not request_id:
            return
        key = str(request_id)
        if key not in self._orders:
            return

        attempts = self._attempts.get(key, 0)
        if attempts >= self._max_attempts:
            if key not in self._waiting:
                self.abandoned_count += 1
                body = {"request_id": request_id,
                        "symbol": self._orders[key].get("symbol"),
                        "attempts": attempts, "reason": payload.get("reason")}
                stamp = payload.get("timestamp")
                if isinstance(stamp, (int, float)):
                    body["timestamp"] = stamp
                self._context.logger.warning(
                    "562 gives up on %s after %d attempts", request_id, attempts)
                await self._context.publish(EVENT_ABANDONED, body)
            self._waiting.pop(key, None)
            return

        due = _to_float(payload.get("timestamp"))
        if due is None:
            await self._republish(key, payload)
            return
        self._waiting[key] = due + self._backoff_s

    async def _on_tick(self, payload: dict[str, Any]) -> None:
        if not self._running or not self._waiting:
            return
        now = _to_float(payload.get("timestamp"))
        if now is None:
            return
        for key in [k for k, due in self._waiting.items() if now >= due]:
            self._waiting.pop(key, None)
            await self._republish(key, payload)

    async def _republish(self, key: str, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        order = self._orders.get(key)
        if order is None:
            return
        self._attempts[key] = self._attempts.get(key, 0) + 1
        self.retried_count += 1
        body = dict(order)
        body["retry_of"] = order.get("request_id")
        body["attempt"] = self._attempts[key]
        stamp = _to_float(payload.get("timestamp"))
        if stamp is not None:
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._attempts.clear()
        self._waiting.clear()

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"retried": self.retried_count, "abandoned": self.abandoned_count,
                   "tracked_orders": len(self._orders), "waiting": len(self._waiting),
                   "attempts": dict(self._attempts)}
        if self.retried_count == 0 and self.abandoned_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_RETRIES, details=details)
        if self.abandoned_count:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="abandoned=%d" % self.abandoned_count,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="retried=%d" % self.retried_count, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "attempts": dict(self._attempts),
                "retried": self.retried_count, "abandoned": self.abandoned_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._attempts = {str(k): int(v)
                          for k, v in (state.get("attempts") or {}).items()}
        self.retried_count = int(state.get("retried", 0))
        self.abandoned_count = int(state.get("abandoned", 0))
