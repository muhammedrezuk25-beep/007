from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom562"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1000.0


class Ctx:
    atom_id = 562

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 562


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _build(ctx, rid="r1", symbol="NQ", at=TS):
    await ctx.handlers[MODULE.EVENT_BUILT]({"request_id": rid, "symbol": symbol,
                                             "side": "BUY", "volume": 0.1,
                                             "timestamp": at})


async def _reject(ctx, rid="r1", disposition="RETRYABLE", at=TS):
    await ctx.handlers[MODULE.EVENT_ANALYZED]({"request_id": rid, "reason": "RETCODE_1",
                                                "disposition": disposition,
                                                "timestamp": at})


def _retries(ctx):
    return [p for n, p in ctx.published
            if n == MODULE.EVENT_OUT and p.get("retry_of")]


@pytest.mark.asyncio
async def test_a_retryable_rejection_is_republished_after_the_backoff():
    atom, ctx = await _ready(backoff_s=1.0)
    await _build(ctx)
    await _reject(ctx)
    assert _retries(ctx) == []
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 2})
    assert len(_retries(ctx)) == 1


@pytest.mark.asyncio
async def test_the_backoff_is_respected():
    atom, ctx = await _ready(backoff_s=5.0)
    await _build(ctx)
    await _reject(ctx)
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 2})
    assert _retries(ctx) == []
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 6})
    assert len(_retries(ctx)) == 1


@pytest.mark.asyncio
async def test_a_terminal_rejection_is_never_retried():
    """Retrying a contract or risk rejection produces the same rejection
    forever. 561 makes that call; this atom obeys it."""
    atom, ctx = await _ready()
    await _build(ctx)
    await _reject(ctx, disposition="TERMINAL")
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 99})
    assert _retries(ctx) == []


@pytest.mark.asyncio
async def test_attempts_stop_at_the_ceiling_and_the_order_is_abandoned():
    atom, ctx = await _ready(max_attempts=2, backoff_s=0.0)
    await _build(ctx)
    for i in range(4):
        await _reject(ctx, at=TS + i)
        await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + i + 1})
    assert len(_retries(ctx)) == 2
    assert out(ctx, MODULE.EVENT_ABANDONED)


@pytest.mark.asyncio
async def test_a_retry_is_marked_and_never_retried_again():
    """Without the marker the republished order would re-enter this atom's own
    memory and the attempt counter would restart from zero."""
    atom, ctx = await _ready(backoff_s=0.0)
    await _build(ctx)
    await _reject(ctx)
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 1})
    retry = _retries(ctx)[0]
    assert retry["retry_of"] == "r1"
    await ctx.handlers[MODULE.EVENT_BUILT](retry)
    assert atom._orders["r1"].get("retry_of") is None


@pytest.mark.asyncio
async def test_an_unknown_request_is_not_invented():
    atom, ctx = await _ready()
    await _reject(ctx, rid="never")
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 9})
    assert _retries(ctx) == []


@pytest.mark.asyncio
async def test_day_roll_clears_the_attempt_counters():
    atom, ctx = await _ready(max_attempts=1, backoff_s=0.0)
    await _build(ctx)
    await _reject(ctx)
    await ctx.handlers[MODULE.EVENT_TICK]({"symbol": "NQ", "timestamp": TS + 1})
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom._attempts == {}


@pytest.mark.asyncio
async def test_pending_orders_are_capped():
    atom, ctx = await _ready(pending_orders_memory=3)
    for i in range(6):
        await _build(ctx, rid=f"r{i}")
    assert len(atom._orders) == 3
