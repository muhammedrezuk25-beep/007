"""Tests for atom 574 - Partial Closer."""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom574"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
TS = 1785000000.0


class Ctx:
    atom_id = 574

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = config
        self.published: list[tuple[str, dict]] = []

    async def publish(self, name, payload=None):
        self.published.append((name, dict(payload or {})))

    def subscribe(self, name, handler):
        pass

    def of(self, name):
        return [p for n, p in self.published if n == name]


def prog(ticket=1, r=1.2, volume=1.0, ts=TS):
    return {"ticket": ticket, "symbol": "NQ", "account_id": "111",
            "side": "BUY", "volume": volume, "r_multiple": r,
            "timestamp": ts, "trace_id": "T"}


async def build(**over):
    atom = MODULE.Atom()
    cfg = dict(MANIFEST["config"]); cfg.update(over)
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def test_close_volume_math():
    cv = MODULE.close_volume
    assert cv(1.0, 0.5, 0.01, 0.01) == 0.5
    assert cv(0.30, 0.5, 0.10, 0.10) == 0.10   # تدوير نزولًا على الخطوة
    assert cv(0.01, 0.5, 0.01, 0.01) is None    # جزء أصغر من خطوة
    assert cv(0.02, 0.5, 0.01, 0.05) is None    # البقيّة دون الحدّ
    assert cv(1.0, 1.5, 0.01, 0.01) is None     # كسر غير صالح


@pytest.mark.asyncio
async def test_one_shot_per_ticket():
    atom, ctx = await build()
    await atom._on_progress(prog(r=1.2))
    await atom._on_progress(prog(r=2.0, volume=0.5, ts=TS + 120))
    out = ctx.of("execution.order.close_partial_requested")
    assert len(out) == 1
    assert out[0]["volume"] == 0.5 and out[0]["action"] == "CLOSE_PARTIAL"


@pytest.mark.asyncio
async def test_below_trigger_does_nothing():
    atom, ctx = await build()
    await atom._on_progress(prog(r=0.8))
    assert ctx.of("execution.order.close_partial_requested") == []
    assert atom._done == set()


@pytest.mark.asyncio
async def test_indivisible_volume_is_final_not_retried():
    atom, ctx = await build(volume_step=0.1)
    await atom._on_progress(prog(r=1.5, volume=0.1))
    assert ctx.of("execution.order.close_partial_requested") == []
    assert 1 in atom._done  # قرارٌ نهائي — لا إعادة فحص كل ثانية


@pytest.mark.asyncio
async def test_snapshot_restore_survives_restart():
    atom, ctx = await build()
    await atom._on_progress(prog(r=1.5))
    snap = await atom.snapshot()
    atom2, ctx2 = await build()
    await atom2.restore(snap)
    await atom2._on_progress(prog(r=2.0, volume=0.5, ts=TS + 300))
    assert ctx2.of("execution.order.close_partial_requested") == []


@pytest.mark.asyncio
async def test_ended_reopens_ticket_number_for_reuse():
    atom, ctx = await build()
    await atom._on_progress(prog(r=1.5))
    await atom._on_ended({"ticket": 1})
    assert atom._done == set()
    await atom._on_progress(prog(r=1.5, ts=TS + 200))
    assert len(ctx.of("execution.order.close_partial_requested")) == 2
