"""
574 — المُغلِق الجزئي (Partial Closer) — قسم 570

عند بلوغ الهدف الأول (بوحدة R) يُغلَق جزءٌ معلن من الحجم ويُترك الباقي
يركض — «تأمين ربحٍ نقديّ مع بقاء التذكرة في السوق».

قرارٌ لمرّة واحدة لكل تذكرة، وذاكرته تُحفظ بلقطة (snapshot) وتُستعاد:
إعادة تشغيلٍ وسط صفقة نصفُها مغلقٌ يجب ألّا تُغلق النصف الثاني — الحالة
وحدها لا تكفي هنا (الحجم المتبقّي لا يقول «أُغلق نصفه» أم «فُتح هكذا»)،
فهذه الذرة الوحيدة في القسم التي تحمل ذاكرةً تستحق البقاء.
"""

from __future__ import annotations

import math
import uuid
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "trade.progress"
EVENT_IN_ENDED = "trade.progress.ended"
EVENT_OUT = "execution.order.close_partial_requested"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_PARTIAL = "PARTIAL_TP"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def close_volume(volume: float, fraction: float, step: float,
                 min_remaining: float) -> float | None:
    """حجم الإغلاق مُدوَّرًا نزولًا على خطوة الحجم — دالة نقية.

    يُرجَع None حين لا يصحّ الإغلاق: جزءٌ أصغر من خطوة، أو بقيّةٌ أصغر
    من الحدّ — «إغلاقٌ يقتل التذكرة» ليس إغلاقًا جزئيًا.
    """
    if volume <= 0 or not (0 < fraction < 1) or step <= 0:
        return None
    part = math.floor((volume * fraction) / step + 1e-9) * step
    part = round(part, 8)
    if part < step:
        return None
    remaining = round(volume - part, 8)
    if remaining < min_remaining:
        return None
    return part


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._trigger_r = 1.0
        self._fraction = 0.5
        self._volume_step = 0.01
        self._min_remaining = 0.01
        self._retry_interval_s = 60.0
        self._done: set[int] = set()
        self._last_request_ts: dict[int, float] = {}
        self.requests_sent = 0
        self.progress_seen = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._trigger_r = float(cfg.get("trigger_r", 1.0))
        self._fraction = float(cfg.get("close_fraction", 0.5))
        self._volume_step = float(cfg.get("volume_step", 0.01))
        self._min_remaining = float(cfg.get("min_remaining", 0.01))
        self._retry_interval_s = float(cfg.get("retry_interval_s", 60.0))
        context.subscribe(EVENT_IN, self._on_progress)
        context.subscribe(EVENT_IN_ENDED, self._on_ended)
        context.logger.info(
            "574 initialised (trigger_r=%.2f fraction=%.2f)",
            self._trigger_r, self._fraction)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        pass

    # ------------------------------------------------------------------

    async def _on_ended(self, payload: dict[str, Any]) -> None:
        ticket = payload.get("ticket")
        if ticket is None:
            return
        ticket = int(ticket)
        self._done.discard(ticket)
        self._last_request_ts.pop(ticket, None)

    async def _on_progress(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.progress_seen += 1

        ticket = payload.get("ticket")
        r_multiple = _to_float(payload.get("r_multiple"))
        volume = _to_float(payload.get("volume"))
        if ticket is None or r_multiple is None or volume is None:
            return
        ticket = int(ticket)
        if ticket in self._done or r_multiple < self._trigger_r:
            return

        part = close_volume(volume, self._fraction,
                            self._volume_step, self._min_remaining)
        if part is None:
            # حجمٌ لا يقبل القسمة — قرارٌ نهائي لهذه التذكرة لا تأجيل:
            # الحجم لا يكبر لاحقًا، وإعادة الفحص كل ثانية ضجيج.
            self._done.add(ticket)
            self._context.logger.info(
                "574 ticket=%s حجمه %.4f لا يقبل إغلاقًا جزئيًا — تُترك كاملة",
                ticket, volume)
            return

        ts = _to_float(payload.get("timestamp"))
        last = self._last_request_ts.get(ticket)
        if ts is not None and last is not None \
                and (ts - last) < self._retry_interval_s:
            return

        body = {
            "request_id": "pc-%s" % uuid.uuid4().hex[:12],
            "action": "CLOSE_PARTIAL",
            "ticket": ticket,
            "symbol": payload.get("symbol"),
            "account_id": payload.get("account_id"),
            "side": payload.get("side"),
            "volume": part,
            "reason": REASON_PARTIAL,
            "parent_event": EVENT_IN,
        }
        if payload.get("trace_id") is not None:
            body["trace_id"] = payload["trace_id"]
        if ts is not None:
            body["timestamp"] = ts
            self._last_request_ts[ticket] = ts

        await self._context.publish(EVENT_OUT, body)
        self.requests_sent += 1
        # لمرّة واحدة: الطلب صدر، والمنصّة إمّا نفّذت أو ردّت السبب —
        # وتكرار «أغلق النصف» على تذكرةٍ نصفُها ذهب يُغلقها كلّها مرّتين.
        self._done.add(ticket)
        self._context.logger.info(
            "574 partial close requested ticket=%s volume=%.4f (r=%.2f)",
            ticket, part, r_multiple)

    # ------------------------------------------------------------------

    async def snapshot(self) -> dict[str, Any]:
        return {"done": sorted(self._done)}

    async def restore(self, state: dict[str, Any]) -> None:
        done = state.get("done")
        if isinstance(done, list):
            self._done = {int(t) for t in done}

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="sent=%d done=%d" % (self.requests_sent, len(self._done)),
            details={"requests_sent": self.requests_sent,
                     "done_tickets": sorted(self._done),
                     "progress_seen": self.progress_seen})
