from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "execution.order.built"
EVENT_OUT = "execution.priority_ordered"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ORDERS = "NO_ORDERS_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._symbol_priority: dict[str, int] = {}
        self._default_priority = 0
        self._counts: dict[str, int] = {}
        self.ordered_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._symbol_priority = {str(k).upper(): int(v)
                                 for k, v in dict(cfg["symbol_priority"]).items()}
        self._default_priority = int(cfg["default_priority"])
        context.subscribe(EVENT_IN, self._on_order_built)
        self._initialized = True
        context.logger.info("567 initialised with %d ranked symbols",
                            len(self._symbol_priority))

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("567 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("567 stopped (ordered=%d)", self.ordered_count)

    async def shutdown(self) -> None:
        await self.stop()

    def priority_of(self, symbol: Any, confidence: Any) -> int:
        base = self._symbol_priority.get(str(symbol).upper(), self._default_priority)
        score = _to_float(confidence)
        if score is None:
            return base
        return base + int(round(score * 10))

    async def _on_order_built(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        inner = payload.get("payload", payload) if isinstance(payload, dict) else {}
        symbol = inner.get("symbol")
        account_id = inner.get("account_id")
        if not symbol:
            return

        priority = self.priority_of(symbol, inner.get("confidence"))
        self.ordered_count += 1
        self._counts[str(symbol)] = self._counts.get(str(symbol), 0) + 1

        body: dict[str, Any] = {
            "request_id": inner.get("request_id"), "symbol": symbol,
            "side": inner.get("side"), "priority": priority,
            "ranked": str(symbol).upper() in self._symbol_priority,
        }
        stamp = inner.get("timestamp", payload.get("timestamp"))
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"ordered": self.ordered_count, "ranked_symbols": len(self._symbol_priority),
                   "per_symbol": dict(self._counts)}
        if self.ordered_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_ORDERS, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="ordered=%d" % self.ordered_count, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "ordered": self.ordered_count,
                "counts": dict(self._counts)}

    async def restore(self, state: dict[str, Any]) -> None:
        self.ordered_count = int(state.get("ordered", 0))
        self._counts = {str(k): int(v) for k, v in (state.get("counts") or {}).items()}
