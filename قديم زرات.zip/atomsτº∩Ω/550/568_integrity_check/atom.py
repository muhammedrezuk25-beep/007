from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_STATUS = "execution.order_status_tracked"
EVENT_SLIPPAGE = "execution.slippage_measured"
EVENT_LATENCY = "execution.latency_measured"
EVENT_REJECTION = "execution.rejection_analyzed"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "execution.integrity_checked"

STATUS_FILLED = "FILLED"
STATUS_REJECTED = "REJECTED"

VERDICT_SOUND = "SOUND"
VERDICT_SUSPECT = "SUSPECT"

FLAG_FILL_RATE = "LOW_FILL_RATE"
FLAG_SLIPPAGE = "HIGH_SLIPPAGE"
FLAG_LATENCY = "HIGH_LATENCY"
FLAG_UNFINISHED = "ORDERS_UNFINISHED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_SAMPLE = "SAMPLE_TOO_SMALL"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._min_sample = 0
        self._min_fill_rate = 0.0
        self._max_slippage_pct = 0.0
        self._max_latency_s = 0.0
        self._max_unfinished = 0
        self._filled = 0
        self._rejected = 0
        self._unfinished = 0
        self._slippage_total = 0.0
        self._slippage_count = 0
        self._latency_total = 0.0
        self._latency_count = 0
        self._retryable = 0
        self.checks_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._min_sample = int(cfg["min_sample"])
        self._min_fill_rate = float(cfg["min_fill_rate"])
        self._max_slippage_pct = float(cfg["max_average_slippage_pct"])
        self._max_latency_s = float(cfg["max_average_latency_s"])
        self._max_unfinished = int(cfg["max_unfinished_orders"])
        context.subscribe(EVENT_STATUS, self._on_status)
        context.subscribe(EVENT_SLIPPAGE, self._on_slippage)
        context.subscribe(EVENT_LATENCY, self._on_latency)
        context.subscribe(EVENT_REJECTION, self._on_rejection)
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True
        context.logger.info("568 initialised")

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("568 started")

    async def stop(self) -> None:
        self._running = False
        if self._context is not None:
            self._context.logger.info("568 stopped (checks=%d)", self.checks_published)

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_status(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        status = str(payload.get("status", "")).upper()
        if status == STATUS_FILLED:
            self._filled += 1
        elif status == STATUS_REJECTED:
            self._rejected += 1
        self._unfinished = int(payload.get("unfinished") or self._unfinished)
        await self._emit(payload)

    async def _on_slippage(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        value = _to_float(payload.get("slippage_pct"))
        if value is None:
            return
        self._slippage_total += abs(value)
        self._slippage_count += 1
        await self._emit(payload)

    async def _on_latency(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        value = _to_float(payload.get("latency_s"))
        if value is None:
            return
        self._latency_total += value
        self._latency_count += 1
        await self._emit(payload)

    async def _on_rejection(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        if str(payload.get("disposition", "")).upper() == "RETRYABLE":
            self._retryable += 1

    def assess(self) -> dict[str, Any]:
        total = self._filled + self._rejected
        fill_rate = round(self._filled / total, 6) if total else None
        average_slippage = (round(self._slippage_total / self._slippage_count, 6)
                            if self._slippage_count else None)
        average_latency = (round(self._latency_total / self._latency_count, 6)
                           if self._latency_count else None)

        flags = []
        if total >= self._min_sample:
            if fill_rate is not None and fill_rate < self._min_fill_rate:
                flags.append(FLAG_FILL_RATE)
            if average_slippage is not None and average_slippage > self._max_slippage_pct:
                flags.append(FLAG_SLIPPAGE)
            if average_latency is not None and average_latency > self._max_latency_s:
                flags.append(FLAG_LATENCY)
        if self._unfinished > self._max_unfinished:
            flags.append(FLAG_UNFINISHED)

        return {
            "orders": total, "filled": self._filled, "rejected": self._rejected,
            "fill_rate": fill_rate, "average_slippage_pct": average_slippage,
            "average_latency_s": average_latency, "retryable_rejections": self._retryable,
            "unfinished": self._unfinished,
            "sample_ready": total >= self._min_sample,
            "flags": flags,
            "verdict": VERDICT_SUSPECT if flags else VERDICT_SOUND,
        }

    async def _emit(self, payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = self.assess()
        self.checks_published += 1
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._filled = 0
        self._rejected = 0
        self._slippage_total = 0.0
        self._slippage_count = 0
        self._latency_total = 0.0
        self._latency_count = 0
        self._retryable = 0

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = self.assess()
        details["checks"] = self.checks_published
        if not details["sample_ready"]:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_SAMPLE, details=details)
        if details["flags"]:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=",".join(details["flags"]), details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="fill_rate=%.2f" % (details["fill_rate"] or 0.0),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "filled": self._filled,
                "rejected": self._rejected, "slippage_total": self._slippage_total,
                "slippage_count": self._slippage_count,
                "latency_total": self._latency_total,
                "latency_count": self._latency_count, "retryable": self._retryable}

    async def restore(self, state: dict[str, Any]) -> None:
        self._filled = int(state.get("filled", 0))
        self._rejected = int(state.get("rejected", 0))
        self._slippage_total = float(state.get("slippage_total", 0.0))
        self._slippage_count = int(state.get("slippage_count", 0))
        self._latency_total = float(state.get("latency_total", 0.0))
        self._latency_count = int(state.get("latency_count", 0))
        self._retryable = int(state.get("retryable", 0))
