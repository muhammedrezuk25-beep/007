from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom568"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1000.0


class Ctx:
    atom_id = 568

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    atom = MODULE.Atom()
    ctx = Ctx({**CONFIG, **over})
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 568


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_traffic_is_degraded():
    atom, ctx = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_lifecycle_is_reversible():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await atom.shutdown()
    assert atom._running is False


async def _status(ctx, status, n=1):
    for i in range(n):
        await ctx.handlers[MODULE.EVENT_STATUS]({"request_id": f"o{status}{i}",
                                                  "status": status, "timestamp": TS})


@pytest.mark.asyncio
async def test_the_verdict_waits_for_a_sample():
    """Judging the execution path on two orders is noise. Below the sample
    size no flag is raised at all."""
    atom, ctx = await _ready(min_sample=10, min_fill_rate=0.9)
    await _status(ctx, "REJECTED", 2)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert last["sample_ready"] is False
    assert last["verdict"] == MODULE.VERDICT_SOUND


@pytest.mark.asyncio
async def test_a_low_fill_rate_is_flagged_once_judgeable():
    atom, ctx = await _ready(min_sample=5, min_fill_rate=0.8)
    await _status(ctx, "FILLED", 2)
    await _status(ctx, "REJECTED", 3)
    last = out(ctx, MODULE.EVENT_OUT)[-1]
    assert MODULE.FLAG_FILL_RATE in last["flags"]
    assert last["verdict"] == MODULE.VERDICT_SUSPECT


@pytest.mark.asyncio
async def test_a_healthy_path_is_sound():
    atom, ctx = await _ready(min_sample=5, min_fill_rate=0.8)
    await _status(ctx, "FILLED", 9)
    await _status(ctx, "REJECTED", 1)
    assert out(ctx, MODULE.EVENT_OUT)[-1]["verdict"] == MODULE.VERDICT_SOUND


@pytest.mark.asyncio
async def test_average_slippage_is_measured_on_the_absolute_value():
    """A run of fills half favourable and half adverse must not cancel out to
    zero: what matters is how far the fills land from the decision price."""
    atom, ctx = await _ready(min_sample=1, max_average_slippage_pct=0.05)
    await ctx.handlers[MODULE.EVENT_SLIPPAGE]({"slippage_pct": 0.2, "timestamp": TS})
    await ctx.handlers[MODULE.EVENT_SLIPPAGE]({"slippage_pct": -0.2, "timestamp": TS})
    assert out(ctx, MODULE.EVENT_OUT)[-1]["average_slippage_pct"] == 0.2


@pytest.mark.asyncio
async def test_high_slippage_is_flagged():
    atom, ctx = await _ready(min_sample=1, max_average_slippage_pct=0.05)
    await _status(ctx, "FILLED", 1)
    await ctx.handlers[MODULE.EVENT_SLIPPAGE]({"slippage_pct": 0.5, "timestamp": TS})
    assert MODULE.FLAG_SLIPPAGE in out(ctx, MODULE.EVENT_OUT)[-1]["flags"]


@pytest.mark.asyncio
async def test_high_latency_is_flagged():
    atom, ctx = await _ready(min_sample=1, max_average_latency_s=1.0)
    await _status(ctx, "FILLED", 1)
    await ctx.handlers[MODULE.EVENT_LATENCY]({"latency_s": 5.0, "timestamp": TS})
    assert MODULE.FLAG_LATENCY in out(ctx, MODULE.EVENT_OUT)[-1]["flags"]


@pytest.mark.asyncio
async def test_unfinished_orders_are_flagged_regardless_of_sample():
    """An order stuck between stages means the bridge broke. That is not a
    statistic to wait on."""
    atom, ctx = await _ready(min_sample=100, max_unfinished_orders=2)
    await ctx.handlers[MODULE.EVENT_STATUS]({"request_id": "o1", "status": "BUILT",
                                              "unfinished": 9, "timestamp": TS})
    assert MODULE.FLAG_UNFINISHED in out(ctx, MODULE.EVENT_OUT)[-1]["flags"]


@pytest.mark.asyncio
async def test_day_roll_clears_the_window():
    atom, ctx = await _ready(min_sample=1)
    await _status(ctx, "FILLED", 3)
    await ctx.handlers[MODULE.EVENT_DAY]({"official_time": TS + 86400})
    assert atom.assess()["orders"] == 0


@pytest.mark.asyncio
async def test_retryable_rejections_are_counted_apart():
    """A retryable rejection is not the same failure as a malformed order.
    Counting them apart keeps a broker hiccup from reading as a broken path."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_REJECTION]({"disposition": "RETRYABLE",
                                                 "reason": "RETCODE_1"})
    await ctx.handlers[MODULE.EVENT_REJECTION]({"disposition": "TERMINAL",
                                                 "reason": "MISSING_SYMBOL"})
    assert atom.assess()["retryable_rejections"] == 1


@pytest.mark.asyncio
async def test_a_slippage_event_without_a_figure_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_SLIPPAGE]({"symbol": "NQ"})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_a_latency_event_without_a_figure_is_ignored():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_LATENCY]({"symbol": "NQ"})
    assert out(ctx, MODULE.EVENT_OUT) == []


@pytest.mark.asyncio
async def test_health_is_healthy_on_a_sound_sample():
    atom, ctx = await _ready(min_sample=2, min_fill_rate=0.5)
    await _status(ctx, "FILLED", 3)
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_health_names_the_flags():
    atom, ctx = await _ready(min_sample=2, min_fill_rate=0.9)
    await _status(ctx, "REJECTED", 3)
    status = await atom.health_check()
    assert status.state.name == "DEGRADED"
    assert MODULE.FLAG_FILL_RATE in status.message


@pytest.mark.asyncio
async def test_nothing_is_measured_before_start():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await ctx.handlers[MODULE.EVENT_STATUS]({"status": "FILLED"})
    assert atom.assess()["orders"] == 0


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await _status(ctx, "FILLED", 2)
    await ctx.handlers[MODULE.EVENT_SLIPPAGE]({"slippage_pct": 0.02, "timestamp": TS})
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx())
    await fresh.restore(state)
    assert fresh.assess()["filled"] == 2
