# ATOM_SPEC - 553 Order Sender

## 1. Identity

| | |
|---|---|
| id | **553** (fixed for life) |
| folder | `atoms/550/553_order_sender` (free - the core identifies by id only) |
| version | 1.0.0 |
| critical | **false** - the platform must keep running and observing even when it cannot trade |
| startup_mode | auto |
| entrypoint | `atom:Atom` |

## 2. Single responsibility

Turn a built order into the final decision payload that 601 writes to the brain
bridge, and hold the gate that stops sending while trading is halted.

**Not its job:** building orders (551), validating them (552), pricing, sizing,
risk limits (500), writing to the bridge (601), or executing anything.

## 3. Why it exists

601 is the only door to the EA and it opens on an event. Before this atom, the
only thing knocking was 467 through `execution.order.requested` - which reaches
601 **without passing through the 550 pipeline at all**. The order never gets
built, priced, or stop-lossed before the bridge sees it.

601 carries a second handler, for `decision.signal.ready`. Its own docstring
says of that event name:

> "the event name, its existence and the payload shape are an assumption of
> mine - no spec gave the name explicitly"

The 550 build paper names the real one: 553 publishes `trading.final_decision`.
This atom is that sender, and it also closes a safety hole nobody had covered
(section 5.1).

## 4. Mechanism

1. Subscribes to `execution.order.built`, `emergency.halt`,
   `risk.kill_switch.reset_completed`.
2. On a built order: if the gate is closed, count it as blocked and stop.
3. Validate `side` is BUY or SELL, and that `confidence` and `stability` are
   present. Missing either means the order is counted incomplete and dropped.
4. Emit `trading.final_decision` with `bias` = the order's side, the two
   decision numbers passed through, `symbol`, `request_id`, and the inherited
   timestamp.
5. `emergency.halt` closes the gate. `risk.kill_switch.reset_completed` is the
   only thing that reopens it.

## 5. Settled decisions

### 5.1 The halt gate - the reason this atom is not just a mapper
601 writes `NEUTRAL` the moment `emergency.halt` arrives. If a sender keeps
publishing after that, 601 writes the new decision **over** the NEUTRAL and the
emergency stop undoes itself. The gate closes on halt and reopens only on an
explicit reset that 516 emits by human act.
*Guarded by:* `test_halt_closes_the_gate`,
`test_only_an_explicit_reset_reopens_the_gate`.

### 5.2 The gate survives a restart
`stop()` deliberately does not clear `_halted`. Restart is `stop()` then
`start()`, and an atom that forgets an active emergency stop while restarting
reopens the door to the EA on its own.
*Guarded by:* `test_restart_does_not_reopen_the_gate`.

### 5.3 The gate survives a snapshot
`snapshot()` carries `halted` and `halt_reason`; `restore()` puts them back.
Coming back from a restore with the gate silently open would resume sending
into a market the operator stopped trading in.
*Guarded by:* `test_snapshot_carries_the_halt_across_a_restore`.

### 5.4 It never invents confidence
601 reads `bias`, `confidence`, `stability` strictly and fails the write when
one is missing. An incomplete order is counted and dropped. A padded confidence
is a number nobody measured driving a real trade.
*Guarded by:* `test_missing_confidence_is_dropped_not_padded`,
`test_missing_stability_is_dropped_too`.

### 5.5 Source is `execution.order.built`, not `execution.order.validated`
552 is not built. Subscribing to both would send every order twice the day it
arrives. This is the one line to change when 552 exists.
*Guarded by:* `test_subscribes_to_built_not_validated`.

### 5.6 The side passes through untranslated
BUY stays BUY, SELL stays SELL. 601 already treats the order vocabulary and the
bias vocabulary as one, and `NEUTRAL` is reserved for 601's halt path.
*Guarded by:* `test_sell_side_passes_through_untranslated`.

### 5.7 It never re-reads the clock
The decision, the order and the send describe one moment. The timestamp is
inherited; when the inbound event carries none, the key is omitted and
`core.event_bus` stamps it once.
*Guarded by:* `test_timestamp_is_inherited_not_reread`,
`test_no_inbound_timestamp_means_no_invented_one`.

## 6. Full contract

See `api_spec.yaml` for every field and type.

**Publishes:** `trading.final_decision` -
`{bias, confidence, stability, symbol, request_id, timestamp?}`

**Subscribes:** `execution.order.built` (551), `emergency.halt` (516),
`risk.kill_switch.reset_completed` (516)

**Dependencies:** 551.

## 7. Settings

| Key | Value | Reasoning |
|---|---|---|
| `require_decision_fields` | `true` | 601 rejects an incomplete write anyway. This makes the drop visible here, with a counter and a log line naming the missing field, instead of surfacing as a bridge failure. Setting it false does not pad anything - it only moves the rejection downstream. |

## 8. Health states

| State | Condition | Effect |
|---|---|---|
| `UNHEALTHY` | not started | restart policy applies |
| `DEGRADED` | gate closed / no orders received yet / orders received but all incomplete | logged, **no restart** |
| `HEALTHY` | at least one decision sent | - |

A closed gate is a correct deliberate state, not a fault. UNHEALTHY there would
invite a restart, and restarting a halted sender is the last thing anyone wants.

`details` carries `received`, `sent`, `blocked`, `incomplete`, `halted`.

## 9. Snapshot

Saves the four counters plus `halted` and `halt_reason`. The halt is saved on
purpose - see 5.3. Nothing else is stored: this atom holds no order state, it
maps and forwards.

## 10. Safe modification

**Safe without fear**
- adding an *optional* field to `trading.final_decision`
- adding a counter or a health detail
- log wording

**Breaks consumers - needs coordination**
- renaming or removing `bias`, `confidence` or `stability`: 601 reads all three
  strictly and fails the write
- switching the source to `execution.order.validated`: correct once 552 exists,
  but adding it *alongside* the current one double-sends every order
- changing `require_decision_fields` to false: does not pad anything, but moves
  the rejection from here to the bridge

**Violates a settled decision - do not do**
- clearing the halt on `stop()` or on `restore()` (5.2, 5.3)
- defaulting a missing confidence or stability (5.4)
- sending `NEUTRAL` from here (5.6)
- re-reading the clock for the outgoing timestamp (5.7)

## 11. Who depends on it

**Consumes from:** 551 (orders), 516 (halt and reset).

**Consumed by:** 601, which writes `bias`, `confidence`, `stability` into
`nq_brain.db` for the EA to read.

**If 553 stops:** no new decisions reach the bridge through the 550 pipeline.
601 still has its `execution.order.requested` handler wired to 467, so orders
would keep reaching the bridge by the path that bypasses order building - the
platform would keep trading on unbuilt orders rather than stopping. That
redundancy is noted in `api_spec.yaml` and has not been removed, because
removing it is a change to 601.

## 12. Tests

25 tests.

| Area | Count | What it guards |
|---|---|---|
| structure | 5 | syntax, no `print()`, manifest matches code, source is `built` not `validated`, subscribe without await |
| sending | 5 | mapping, SELL passthrough, timestamp inheritance, no invented timestamp, nested payload shape |
| halt gate | 4 | closes on halt, only reset reopens, survives restart, survives snapshot |
| refuses to invent | 4 | missing confidence, missing stability, unknown side, malformed payload |
| health | 5 | the three states plus halted-is-DEGRADED and incomplete-is-DEGRADED |
| lifecycle | 2 | stop/start still sends, snapshot round trip |

## 13. Behaviour proven by running

Unit tests: **25 passed in 0.80s**.

Live chain through a miniature bus, 551 -> 553 -> a stand-in for 601's write:

```
normal:          551:built -> 553:final_decision   ->  601 wrote ('BUY', 0.82, 0.71)
after halt:      551:built                          ->  601 wrote nothing
after reset:     551:built -> 553:final_decision   ->  601 wrote ('BUY', 0.82, 0.71)
```

**Not yet proven:** behaviour against the real 601 writing to a real
`nq_brain.db`, and against a real EA reading it. The chain test used a stand-in
that applies 601's strict field reads, not 601 itself with its SQLite path.

## 14. Deliberately not built

- **No retry.** 562 owns retry. A sender that retries on its own would send the
  same decision twice.
- **No validation beyond the fields it must read.** 552 owns order validation.
  This atom checks only what it needs to build a legal payload.
- **No sizing, pricing or risk check.** 551 and section 500 own those.
- **No removal of 601's older handlers.** `execution.order.requested` and
  `decision.signal.ready` still reach 601 and now duplicate this path. Removing
  them is a change to 601 and belongs to whoever owns that atom.
