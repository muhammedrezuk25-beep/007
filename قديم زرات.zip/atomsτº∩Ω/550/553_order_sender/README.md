# 553 - Order Sender

Turns a built order into the final decision payload that **601** writes to the
brain bridge, and refuses to send while trading is halted.

```
467 -> execution.order.requested -> 551 -> execution.order.built
                                             |
                                            553  <- emergency.halt closes
                                             |    <- reset reopens
                                    trading.final_decision
                                             |
                                            601 -> nq_brain.db -> EA
```

## What it publishes

| Event | When |
|---|---|
| `trading.final_decision` | one per built order that passes the gate and carries `confidence` and `stability` |

Payload: `{bias, confidence, stability, symbol, request_id, timestamp?}`

## The halt gate

601 writes `NEUTRAL` the instant `emergency.halt` arrives. A sender that keeps
publishing writes the next decision **straight over that NEUTRAL**, and the
emergency stop undoes itself.

So this atom closes on `emergency.halt` and reopens only on
`risk.kill_switch.reset_completed`, which 516 emits by explicit human act.

The gate survives `stop()`/`start()` and survives `snapshot`/`restore`. Nothing
reopens it automatically.

## What it refuses to do

- **Never invents confidence.** 601 reads `bias`, `confidence` and `stability`
  strictly. An order missing them is counted and dropped, not padded - a padded
  confidence is a number nobody measured driving a real trade.
- **Never translates the side.** BUY stays BUY, SELL stays SELL. `NEUTRAL`
  belongs to 601's halt path only.
- **Never re-reads the clock.** The timestamp is inherited from the order.

## Health

| State | When |
|---|---|
| `UNHEALTHY` | not started |
| `DEGRADED` | halted / no orders received yet / orders received but all incomplete |
| `HEALTHY` | at least one decision sent |

A closed gate is `DEGRADED`, never `UNHEALTHY` - restarting a halted sender is
the last thing anyone wants.

## Settings

| Key | Default | Why |
|---|---|---|
| `require_decision_fields` | `true` | 601 rejects an incomplete write anyway; this makes the drop visible here instead of at the bridge |

## Testing

```bash
pytest atoms/550/553_order_sender/tests/ -q
```

25 tests. Four of them guard the halt gate specifically, including restart and
snapshot survival.
