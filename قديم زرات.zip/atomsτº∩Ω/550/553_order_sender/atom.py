"""
553 - Order Sender
==================
Single responsibility: turn a built order into the final decision payload that
601 writes to the brain bridge, and refuse to send while trading is halted.

Why it exists: 601 is the only door to the EA, and it opens on an event. Until
now the only atom knocking on that door was 467 through
`execution.order.requested`, which bypasses the whole 550 pipeline - the order
never gets built, priced or validated before it reaches the bridge. 601 also
carries a second handler for `decision.signal.ready`, and its own docstring
admits that event name was invented rather than specified. This atom is the
specified sender, and `trading.final_decision` is the specified event.

Settled decisions:

  * The halt gate. 601 writes NEUTRAL the moment `emergency.halt` arrives. If
    a sender keeps publishing after that, 601 writes the new decision straight
    over the NEUTRAL and the emergency stop undoes itself. This atom therefore
    closes on halt and reopens only on `risk.kill_switch.reset_completed`,
    which 516 emits by explicit human act. Nothing reopens it automatically.

  * It never invents confidence. 601 reads bias, confidence and stability
    strictly and fails the write when one is missing. An order that arrives
    without them is counted and dropped, not padded with a default - a padded
    confidence is a number nobody measured driving a real trade.

  * It subscribes to `execution.order.built` (551), not
    `execution.order.validated` (552), because 552 is not built. This is the
    one line to change when it is. Subscribing to both would send every order
    twice the day 552 arrives.

  * It sends bias as the order's own side. BUY stays BUY, SELL stays SELL.
    No translation table, because 601 already treats the two vocabularies as
    one and NEUTRAL is reserved for the halt path.
"""

from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN_ORDER = "execution.order.built"
EVENT_IN_HALT = "emergency.halt"
EVENT_IN_RESET = "risk.kill_switch.reset_completed"
EVENT_IN_TERMINAL = "platform.terminal_state"
EVENT_IN_HALT_PAIR = "risk.halt.pair"
EVENT_IN_HALT_ACCOUNT = "risk.halt.account"
EVENT_OUT = "trading.final_decision"
EVENT_OUT_BLOCKED = "execution.order.blocked"

REQUIRED_FIELDS = ("confidence", "stability")
VALID_SIDES = ("BUY", "SELL")

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_ORDERS_RECEIVED"
REASON_HALTED = "HALTED"
REASON_INCOMPLETE = "ORDERS_MISSING_DECISION_FIELDS"



def _to_number(value: Any) -> float | None:
    """يمرّر الرقم كما هو، ولا يستبدل الغائب بصفر: صفرٌ حجمٌ وصفرٌ سعرٌ،
    والغياب غيابٌ — والطرف المنفِّذ يرفض الغائب بدل أن ينفّذه بصفر."""
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh reading.

    The decision, the order and the send all describe one moment. Re-reading
    the clock at each hop puts them at three, and a downstream freshness check
    then rejects one of them. When nothing is inherited the key is omitted and
    core.event_bus stamps the event once via setdefault.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._halted = False
        self._halt_reason = ""
        # حالة المنصّة كما نشرها 619: None = لم تصل بعد (لا نحجب على جهل)،
        # وإلا صحيح/خطأ محسوبة من الأذون الثلاثة معًا.
        self._terminal_ok: bool | None = None
        self._terminal_detail = ""
        # الإيقاف المتدرّج من 516: كان يُنشَر ولا يُطاع — من هنا يُطاع.
        self._halted_pairs: set[tuple[str, str]] = set()
        self._halted_accounts: set[str] = set()

        self._gate_on_platform = True
        self._require_decision_fields = True
        self.received_count = 0
        self.sent_count = 0
        self.blocked_count = 0
        self.incomplete_count = 0

    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._require_decision_fields = bool(context.config["require_decision_fields"])
        self._gate_on_platform = bool(context.config.get("gate_on_platform", True))

        context.subscribe(EVENT_IN_ORDER, self._on_order_built)
        context.subscribe(EVENT_IN_HALT, self._on_halt)
        context.subscribe(EVENT_IN_RESET, self._on_reset)
        context.subscribe(EVENT_IN_TERMINAL, self._on_terminal_state)
        context.subscribe(EVENT_IN_HALT_PAIR, self._on_halt_pair)
        context.subscribe(EVENT_IN_HALT_ACCOUNT, self._on_halt_account)

        self._initialized = True
        context.logger.info("553 initialised, listening on %s", EVENT_IN_ORDER)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._context.logger.info("553 started")

    async def stop(self) -> None:
        """Reversible. The halt gate is deliberately NOT cleared here.

        Restart is stop() then start(), and an atom that forgets an active
        emergency stop while restarting would reopen the door to the EA on its
        own. Only an explicit reset reopens it.
        """
        self._running = False
        if self._context is not None:
            self._context.logger.info(
                "553 stopped (received=%d, sent=%d, blocked=%d, incomplete=%d)",
                self.received_count, self.sent_count,
                self.blocked_count, self.incomplete_count,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------------------------

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        self._halted = True
        self._halt_reason = str(payload.get("reason", ""))
        if self._context is not None:
            self._context.logger.critical(
                "553 gate closed by emergency.halt (reason=%s) - no further sends",
                self._halt_reason,
            )

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        self._halted = False
        self._halt_reason = ""
        # 516 يمسح مفصّلاته عند التصفير — والمرآة هنا تُمسح معه، وإلا بقيت
        # بوابةٌ مقفلةً على إيقافٍ لم يعد قائمًا عند مصدره.
        self._halted_pairs.clear()
        self._halted_accounts.clear()
        if self._context is not None:
            self._context.logger.warning(
                "553 gate reopened by %s (operator=%s)",
                EVENT_IN_RESET, payload.get("operator"),
            )

    async def _on_terminal_state(self, payload: dict[str, Any]) -> None:
        """حالة المنصّة من 619 — كانت تُنشَر ولا يسمعها المُرسِل.

        النتيجة المقيسة قبل هذا: التداول موقوف بزرّ المالك والنظام يكدّس
        أوامر PENDING في الجسر حتى تبوت. من هنا: منصّةٌ غير جاهزة =
        لا كتابة أصلًا، والذراع تحرس البائت احتياطًا لا اعتمادًا.
        """
        connected = payload.get("connected")
        trade = payload.get("trade_allowed")
        expert = payload.get("expert_allowed")
        if connected is None and trade is None and expert is None:
            return
        self._terminal_ok = bool(connected) and bool(trade) and bool(expert)
        if not self._terminal_ok:
            self._terminal_detail = (
                "DISCONNECTED" if not connected
                else "OWNER_HALT" if not trade
                else "EXPERT_NOT_ALLOWED")
        else:
            self._terminal_detail = ""

    async def _on_halt_pair(self, payload: dict[str, Any]) -> None:
        account_id, symbol = payload.get("account_id"), payload.get("symbol")
        if account_id in (None, "") or not symbol:
            return
        self._halted_pairs.add((str(account_id), str(symbol)))
        if self._context is not None:
            self._context.logger.warning(
                "553 pair gate closed: account=%s symbol=%s (%s)",
                account_id, symbol, payload.get("reason"))

    async def _on_halt_account(self, payload: dict[str, Any]) -> None:
        account_id = payload.get("account_id")
        if account_id in (None, ""):
            return
        self._halted_accounts.add(str(account_id))
        if self._context is not None:
            self._context.logger.warning(
                "553 account gate closed: account=%s (%s)",
                account_id, payload.get("reason"))

    async def _block(self, inner: dict[str, Any], reason: str) -> None:
        """رفضٌ مسمّى لا إسقاطٌ صامت: الحدث يقرؤه 570 واللوحات، فيُرى
        «لماذا لم يخرج الأمر» بدل عدّادٍ يكبر بلا تفسير."""
        self.blocked_count += 1
        if self._context is None:
            return
        body = {
            "request_id": inner.get("request_id"),
            "symbol": inner.get("symbol"),
            "account_id": inner.get("account_id"),
            "reason": reason,
            **_ts_from(inner),
        }
        if inner.get("trace_id") is not None:
            body["trace_id"] = inner["trace_id"]
        await self._context.publish(EVENT_OUT_BLOCKED, body)
        self._context.logger.warning(
            "553 blocked order %s: %s", inner.get("request_id"), reason)

    async def _on_order_built(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return

        inner = payload.get("payload", payload)
        if not isinstance(inner, dict):
            return

        self.received_count += 1

        if self._halted:
            self.blocked_count += 1
            self._context.logger.warning(
                "553 dropped an order while halted (request_id=%s)",
                inner.get("request_id"),
            )
            return

        # ── بوابة المنصّة: 619 قال «غير جاهزة» — لا يُكتب أمرٌ سيموت ──
        # None تمرّ: غيابُ الخبر ليس خبرًا سيّئًا، والحجب على جهلٍ يوقف
        # بيئات بلا جسر أصلًا (الاختبارات، المحاكاة).
        if self._gate_on_platform and self._terminal_ok is False:
            await self._block(inner, "PLATFORM_%s" % self._terminal_detail)
            return

        # ── الإيقاف المتدرّج من 516: حسابٌ موقوف أو زوجُه ──
        account_id = inner.get("account_id")
        acct = str(account_id) if account_id not in (None, "") else None
        if acct is not None:
            if acct in self._halted_accounts:
                await self._block(inner, "ACCOUNT_HALTED")
                return
            symbol = inner.get("symbol")
            if symbol and (acct, str(symbol)) in self._halted_pairs:
                await self._block(inner, "PAIR_HALTED")
                return

        side = str(inner.get("side", "")).upper()
        if side not in VALID_SIDES:
            self.incomplete_count += 1
            self._context.logger.error("553 rejected an order with side=%r", side)
            return

        missing = [f for f in REQUIRED_FIELDS if inner.get(f) is None]
        if missing and self._require_decision_fields:
            self.incomplete_count += 1
            self._context.logger.error(
                "553 dropped order %s: missing %s. 601 reads these strictly and "
                "a padded value would be an unmeasured number driving a trade.",
                inner.get("request_id"), ", ".join(missing),
            )
            return

        # الأمر يمرّ كاملًا. كانت هذه النقطة تُسقط volume و stop_loss و
        # take_profit التي بناها 551، فيصل الجسر رأيًا لا أمرًا — ويضطر
        # الطرف المنفِّذ أن يحسبها بنفسه، وهو ما لا يجوز أن يفعله.
        body: dict[str, Any] = {
            "action": "OPEN",
            "bias": side,
            "side": side,
            "confidence": float(inner["confidence"]) if inner.get("confidence") is not None else None,
            "stability": float(inner["stability"]) if inner.get("stability") is not None else None,
            "account_id": inner.get("account_id"),
            "symbol": inner.get("symbol"),
            "request_id": inner.get("request_id"),
            "volume": _to_number(inner.get("volume")),
            "reference_price": _to_number(inner.get("reference_price")),
            "stop_loss": _to_number(inner.get("stop_loss")),
            "take_profit": _to_number(inner.get("take_profit")),
            "strategy": inner.get("strategy"),
            **_ts_from(inner if "timestamp" in inner else payload),
        }
        await self._context.publish(EVENT_OUT, body)
        self.sent_count += 1

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "received": self.received_count,
            "sent": self.sent_count,
            "blocked": self.blocked_count,
            "incomplete": self.incomplete_count,
            "halted": self._halted,
        }

        # A closed gate is a correct, deliberate state, not a fault. Reporting
        # UNHEALTHY here would invite a restart, and a restart of a halted
        # sender is the last thing anyone wants.
        if self._halted:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="%s: %s" % (REASON_HALTED, self._halt_reason),
                                details=details)

        # Input starvation: 551 has published nothing yet. The atom is not
        # broken, and restarting it does not produce an order.
        if self.received_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_INPUT, details=details)

        if self.sent_count == 0 and self.incomplete_count > 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_INCOMPLETE, details=details)

        return HealthStatus(state=HealthState.HEALTHY,
                            message="sent=%d" % self.sent_count, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "received": self.received_count,
            "sent": self.sent_count,
            "blocked": self.blocked_count,
            "incomplete": self.incomplete_count,
            "halted": self._halted,
            "halt_reason": self._halt_reason,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.received_count = int(state.get("received", 0))
        self.sent_count = int(state.get("sent", 0))
        self.blocked_count = int(state.get("blocked", 0))
        self.incomplete_count = int(state.get("incomplete", 0))
        # An active halt survives a snapshot on purpose. Coming back from a
        # restore with the gate silently open would resume sending into a
        # market the operator stopped trading in.
        self._halted = bool(state.get("halted", False))
        self._halt_reason = str(state.get("halt_reason", ""))
