"""Tests for atom 553 - Order Sender."""

from __future__ import annotations

import ast
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]

# Unique module name. Loading every atom under the shared name "atom" makes the
# second atom in a process import the first one's cached module.
_MODULE_NAME = "_atom553"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]

TS = 1700000000.5


class Ctx:
    atom_id = 553

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config if config is not None else CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _order(side="BUY", confidence=0.82, stability=0.71, **extra):
    """A payload shaped like what 551 actually publishes."""
    body = {
        "request_id": "req-1",
        "symbol": "NQ",
        "side": side,
        "volume": 1.0,
        "reference_price": 20000.0,
        "stop_loss": 19950.0,
        "take_profit": 20100.0,
        "strategy": 410,
        "timestamp": TS,
    }
    if confidence is not None:
        body["confidence"] = confidence
    if stability is not None:
        body["stability"] = stability
    body.update(extra)
    return body


async def _ready(config=None):
    atom = MODULE.Atom()
    ctx = Ctx(config)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


def _sent(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


# ---------------------------------------------------------------- structure


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 553
    assert set(MANIFEST["publishes"]) == {MODULE.EVENT_OUT, MODULE.EVENT_OUT_BLOCKED}
    assert set(MANIFEST["subscribes"]) == {
        MODULE.EVENT_IN_ORDER, MODULE.EVENT_IN_HALT, MODULE.EVENT_IN_RESET,
        MODULE.EVENT_IN_TERMINAL, MODULE.EVENT_IN_HALT_PAIR,
        MODULE.EVENT_IN_HALT_ACCOUNT,
    }


def test_subscribes_to_built_not_validated():
    """Settled decision: 552 is not built, so the source is 551's output.

    Subscribing to both execution.order.built and execution.order.validated
    would send every order twice the day 552 arrives.
    """
    assert MODULE.EVENT_IN_ORDER == "execution.order.built"
    assert "execution.order.validated" not in MANIFEST["subscribes"]


@pytest.mark.asyncio
async def test_subscribes_all_three_without_await():
    atom, ctx = await _ready()
    assert set(ctx.handlers) == {
        MODULE.EVENT_IN_ORDER, MODULE.EVENT_IN_HALT, MODULE.EVENT_IN_RESET,
        MODULE.EVENT_IN_TERMINAL, MODULE.EVENT_IN_HALT_PAIR,
        MODULE.EVENT_IN_HALT_ACCOUNT,
    }


# ---------------------------------------------------------------- sending


@pytest.mark.asyncio
async def test_built_order_becomes_final_decision():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    out = _sent(ctx)
    assert len(out) == 1
    assert out[0]["bias"] == "BUY"
    assert out[0]["confidence"] == 0.82
    assert out[0]["stability"] == 0.71
    assert out[0]["symbol"] == "NQ"
    assert out[0]["request_id"] == "req-1"


@pytest.mark.asyncio
async def test_sell_side_passes_through_untranslated():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order(side="SELL"))
    assert _sent(ctx)[0]["bias"] == "SELL"


@pytest.mark.asyncio
async def test_timestamp_is_inherited_not_reread():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert _sent(ctx)[0]["timestamp"] == TS


@pytest.mark.asyncio
async def test_no_inbound_timestamp_means_no_invented_one():
    atom, ctx = await _ready()
    order = _order()
    del order["timestamp"]
    await ctx.handlers[MODULE.EVENT_IN_ORDER](order)
    assert "timestamp" not in _sent(ctx)[0]


@pytest.mark.asyncio
async def test_accepts_the_nested_payload_shape_too():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER]({"payload": _order()})
    assert len(_sent(ctx)) == 1


# ---------------------------------------------------------------- halt gate


@pytest.mark.asyncio
async def test_halt_closes_the_gate():
    """Settled decision, and the reason this atom exists.

    601 writes NEUTRAL the moment emergency.halt arrives. A sender that keeps
    publishing writes the next decision straight over that NEUTRAL, and the
    emergency stop undoes itself.
    """
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_HALT]({"reason": "RISK_DAILY_LIMIT"})
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert _sent(ctx) == []
    assert atom.blocked_count == 1


@pytest.mark.asyncio
async def test_only_an_explicit_reset_reopens_the_gate():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_HALT]({"reason": "RISK_DAILY_LIMIT"})
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    await ctx.handlers[MODULE.EVENT_IN_RESET]({"operator": "mohammed"})
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert len(_sent(ctx)) == 1
    assert atom.blocked_count == 1


@pytest.mark.asyncio
async def test_restart_does_not_reopen_the_gate():
    """stop() must not clear an active halt. An atom that forgets an emergency
    stop while restarting reopens the door to the EA on its own."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_HALT]({"reason": "RISK_SYSTEM_LIMIT"})
    await atom.stop()
    await atom.start()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert _sent(ctx) == []


@pytest.mark.asyncio
async def test_snapshot_carries_the_halt_across_a_restore():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_HALT]({"reason": "MAX_CONSECUTIVE_LOSSES"})
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    fresh_ctx = Ctx()
    await fresh.initialize(fresh_ctx)
    await fresh.restore(state)
    await fresh.start()
    await fresh_ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert [p for n, p in fresh_ctx.published if n == MODULE.EVENT_OUT] == []


# ---------------------------------------------------- refuses to invent


@pytest.mark.asyncio
async def test_missing_confidence_is_dropped_not_padded():
    """Settled decision: no invented confidence.

    601 reads the field strictly, and a padded value would be a number nobody
    measured driving a real trade.
    """
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order(confidence=None))
    assert _sent(ctx) == []
    assert atom.incomplete_count == 1


@pytest.mark.asyncio
async def test_missing_stability_is_dropped_too():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order(stability=None))
    assert _sent(ctx) == []
    assert atom.incomplete_count == 1


@pytest.mark.asyncio
async def test_unknown_side_is_rejected():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order(side="MAYBE"))
    assert _sent(ctx) == []
    assert atom.incomplete_count == 1


@pytest.mark.asyncio
async def test_malformed_payload_does_not_kill_the_atom():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER]({"payload": "not a dict"})
    await ctx.handlers[MODULE.EVENT_IN_ORDER]({})
    assert _sent(ctx) == []


# ---------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_no_orders_yet_is_degraded():
    atom, _ = await _ready()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_halted_is_degraded_never_unhealthy():
    """A closed gate is a correct deliberate state. UNHEALTHY would invite a
    restart, and restarting a halted sender is the last thing anyone wants."""
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_HALT]({"reason": "RISK_DAILY_LIMIT"})
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_healthy_after_a_send():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_only_incomplete_orders_is_degraded():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order(confidence=None))
    assert (await atom.health_check()).state.name == "DEGRADED"


# ---------------------------------------------------------------- lifecycle


@pytest.mark.asyncio
async def test_stop_then_start_still_sends():
    atom, ctx = await _ready()
    await atom.stop()
    await atom.start()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    assert len(_sent(ctx)) == 1


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx = await _ready()
    await ctx.handlers[MODULE.EVENT_IN_ORDER](_order())
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh.sent_count == 1
    assert fresh.received_count == 1


# ─── v1.1.0: بوابة المنصّة والإيقاف المتدرّج ────────────────────────────

def _gate_order(request_id="r1", account_id="111", symbol="NQ"):
    return {"payload": {"request_id": request_id, "side": "BUY",
                        "confidence": 0.8, "stability": 0.7,
                        "account_id": account_id, "symbol": symbol,
                        "volume": 1.0, "stop_loss": 90.0,
                        "take_profit": 120.0, "timestamp": TS}}


async def _armed():
    atom = MODULE.Atom()
    ctx = Ctx()
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx


@pytest.mark.asyncio
async def test_platform_gate_blocks_when_owner_halted_and_reopens():
    atom, ctx = await _armed()
    await atom._on_terminal_state({"connected": True, "trade_allowed": False,
                                   "expert_allowed": True})
    await atom._on_order_built(_gate_order())
    assert [n for n, _ in ctx.published] == ["execution.order.blocked"]
    assert ctx.published[0][1]["reason"] == "PLATFORM_OWNER_HALT"
    ctx.published.clear()
    await atom._on_terminal_state({"connected": True, "trade_allowed": True,
                                   "expert_allowed": True})
    await atom._on_order_built(_gate_order(request_id="r2"))
    assert [n for n, _ in ctx.published] == ["trading.final_decision"]


@pytest.mark.asyncio
async def test_unknown_platform_state_passes():
    atom, ctx = await _armed()
    await atom._on_order_built(_gate_order())
    assert [n for n, _ in ctx.published] == ["trading.final_decision"]


@pytest.mark.asyncio
async def test_scoped_halts_block_only_their_scope_and_reset_clears():
    atom, ctx = await _armed()
    await atom._on_halt_pair({"account_id": "111", "symbol": "NQ",
                              "reason": "STRATEGY_LIMIT"})
    await atom._on_halt_account({"account_id": "222", "reason": "DAILY_LOSS"})

    await atom._on_order_built(_gate_order(account_id="111", symbol="NQ"))
    await atom._on_order_built(_gate_order(request_id="r2", account_id="111",
                                      symbol="ES"))
    await atom._on_order_built(_gate_order(request_id="r3", account_id="222",
                                      symbol="ES"))
    names = [n for n, _ in ctx.published]
    assert names == ["execution.order.blocked", "trading.final_decision",
                     "execution.order.blocked"]
    assert ctx.published[0][1]["reason"] == "PAIR_HALTED"
    assert ctx.published[2][1]["reason"] == "ACCOUNT_HALTED"

    ctx.published.clear()
    await atom._on_reset({"operator": "test"})
    await atom._on_order_built(_gate_order(request_id="r4", account_id="111",
                                      symbol="NQ"))
    assert [n for n, _ in ctx.published] == ["trading.final_decision"]
