"""
203 — Internal Structure (الهيكل الداخلي)

يشترك: مخرجات 201 (structure.swing_detected). ينشر:
structure.internal_updated.

منطق مُستنتَج — مكمِّل حرفي لـ202: نقطة تأرجح **لا تكسر** الحد
الخارجي الحالي (لا تُسجِّل قمة أعلى من كل القمم السابقة، ولا قاعًا
أدنى من كل القيعان) = هيكل داخلي — تصحيح/ارتداد ضمن الحركة الخارجية
القائمة، لا اتجاه خارجي جديد.

تكرار حسابي متعمَّد مع 202 (لا استدعاء بينهما — قاعدة 0): كل ذرة
تحسب حدودها الخارجية بذاكرتها الخاصة لتحديد "هل هذا داخلي؟" بدل
الاعتماد على مخرجات 202 مباشرة، لأن التواصل بين الذرات عبر الأحداث
فقط، لا قراءة حالة داخلية لذرة أخرى.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._external_high: dict[str, float] = {}
        self._external_low: dict[str, float] = {}
        self.internal_updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.swing_detected", self._on_swing)
        context.logger.info("InternalStructure(203) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("InternalStructure(203) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات_داخلية={self.internal_updates_count}")

    async def snapshot(self) -> dict:
        return {"external_high": self._external_high, "external_low": self._external_low, "internal_updates_count": self.internal_updates_count}

    async def restore(self, state: dict) -> None:
        self._external_high = state.get("external_high", {})
        self._external_low = state.get("external_low", {})
        self.internal_updates_count = state.get("internal_updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_swing(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        is_new_external_extreme = False

        if payload["type"] == "high":
            current = self._external_high.get(symbol)
            if current is None or payload["price"] > current:
                self._external_high[symbol] = payload["price"]
                is_new_external_extreme = True
        else:
            current = self._external_low.get(symbol)
            if current is None or payload["price"] < current:
                self._external_low[symbol] = payload["price"]
                is_new_external_extreme = True

        if not is_new_external_extreme:
            self.internal_updates_count += 1
            await self._context.publish(
                "structure.internal_updated",
                {"symbol": symbol, "type": payload["type"], "price": payload["price"], "index": payload["index"]},
            )
