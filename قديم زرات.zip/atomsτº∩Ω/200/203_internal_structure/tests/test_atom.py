import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom203"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=203, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_swing_never_internal():
    print("\n--- test_first_swing_never_internal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    events = [p for n, p in published if n == "structure.internal_updated"]
    assert len(events) == 0, "أول قمة = خارجية دائمًا، لا يمكن أن تكون داخلية"
    print("OK — أول قمة اعتُبِرت خارجية، صفر حدث داخلي")


async def test_lower_high_is_internal():
    print("\n--- test_lower_high_is_internal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 95, "index": 6})  # أدنى — داخلي
    events = [p for n, p in published if n == "structure.internal_updated"]
    assert len(events) == 1
    assert events[0]["price"] == 95
    print(f"OK — قمة أدنى من الخارجية اعتُبِرت داخلية: {events[0]}")


async def test_new_external_extreme_is_not_internal():
    print("\n--- test_new_external_extreme_is_not_internal ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 110, "index": 6})  # أعلى — خارجي جديد
    events = [p for n, p in published if n == "structure.internal_updated"]
    assert len(events) == 0, "قمة أعلى = حد خارجي جديد، ليست داخلية"
    print("OK — قمة أعلى (حد خارجي جديد) لم تُعتبَر داخلية")


async def test_mutually_exclusive_with_202_logic():
    """يثبت أن 202 و203 متكاملان تمامًا (تجزئة كاملة) — كل نقطة إما
    خارجية أو داخلية، لا الاثنين، لا لا شيء."""
    print("\n--- test_mutually_exclusive_with_202_logic ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    swings = [
        {"symbol": "NQ", "type": "high", "price": 100, "index": 1},
        {"symbol": "NQ", "type": "high", "price": 90, "index": 2},   # داخلي
        {"symbol": "NQ", "type": "high", "price": 120, "index": 3},  # خارجي جديد
        {"symbol": "NQ", "type": "low", "price": 50, "index": 4},
        {"symbol": "NQ", "type": "low", "price": 60, "index": 5},    # داخلي
    ]
    for s in swings:
        await atom._on_swing(s)
    internal = [p for n, p in published if n == "structure.internal_updated"]
    assert len(internal) == 2, f"من أصل 5 نقاط، 2 لازم تكون داخلية (index=2 وindex=5)، لقيت {len(internal)}"
    print(f"OK — من 5 نقاط، 2 داخلية بدقّة (الباقي خارجية): {[e['index'] for e in internal]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 1})
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 90, "index": 2})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.internal_updates_count == 1
    assert atom2._external_high["NQ"] == 100
    print("OK — restore() نقل الحدود الخارجية المرجعية والعدّاد بدقّة")


async def main():
    tests = [
        test_first_swing_never_internal,
        test_lower_high_is_internal,
        test_new_external_extreme_is_not_internal,
        test_mutually_exclusive_with_202_logic,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
