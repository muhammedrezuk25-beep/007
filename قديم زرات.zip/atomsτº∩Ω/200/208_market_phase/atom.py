"""
208 — Market Phase (طور السوق)

يشترك: مخرجات 207 (market.trend.changed). ينشر: market.phase.changed.

منطق مُستنتَج بالكامل (لا سبك دقيق أُعطي غير "يشترك بـ207، ينشر
market.phase.changed"): طور السوق هنا = **نضج الاتجاه** بعدد مرات
تأكيده عبر الزمن — EARLY (أول تأكيد)، ESTABLISHED (2-4)، EXTENDED
(5+ — قد يكون قريبًا من الاستنفاد). RANGE/TRANSITION = NEUTRAL مباشرة.

بق تصميم حقيقي وجدته أثناء البناء: بما أن 207 (Edge-triggered)
لا تكرر نفس الحالة أبدًا مرتين متتاليتين، مقارنة "نفس الحالة السابقة
حرفيًا" كانت ستفشل دائمًا (التأكيد لن يُكتشَف أبدًا). الحل: تتبّع
**آخر اتجاه فعلي** (UPTREND/DOWNTREND) بذاكرة منفصلة تنجو عبر توقفات
RANGE/TRANSITION — عودة لنفس الاتجاه بعد توقف = تأكيد إضافي (النضج
يستمر)، اتجاه معاكس = بداية جديدة (يتصفّر العدّاد).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_TRENDING_STATES = {"UPTREND", "DOWNTREND"}
_ESTABLISHED_THRESHOLD = 2
_EXTENDED_THRESHOLD = 5


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_trending_direction: dict[str, str] = {}
        self._confirmation_count: dict[str, int] = {}
        self._current_phase: dict[str, str] = {}
        self.phase_changes_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.trend.changed", self._on_trend_changed)
        context.logger.info("MarketPhase(208) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("MarketPhase(208) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"أطوار_مُتابَعة={self._current_phase}")

    async def snapshot(self) -> dict:
        return {
            "last_trending_direction": self._last_trending_direction, "confirmation_count": self._confirmation_count,
            "current_phase": self._current_phase, "phase_changes_count": self.phase_changes_count,
        }

    async def restore(self, state: dict) -> None:
        self._last_trending_direction = state.get("last_trending_direction", {})
        self._confirmation_count = state.get("confirmation_count", {})
        self._current_phase = state.get("current_phase", {})
        self.phase_changes_count = state.get("phase_changes_count", 0)

    # ------------------------------------------------------------------

    async def _on_trend_changed(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        new_state = payload["state"]
        is_trending = new_state in _TRENDING_STATES

        if is_trending:
            if self._last_trending_direction.get(symbol) == new_state:
                self._confirmation_count[symbol] = self._confirmation_count.get(symbol, 0) + 1
            else:
                self._confirmation_count[symbol] = 1
            self._last_trending_direction[symbol] = new_state

        if not is_trending:
            new_phase = "NEUTRAL"
        elif self._confirmation_count[symbol] >= _EXTENDED_THRESHOLD:
            new_phase = "EXTENDED"
        elif self._confirmation_count[symbol] >= _ESTABLISHED_THRESHOLD:
            new_phase = "ESTABLISHED"
        else:
            new_phase = "EARLY"

        if self._current_phase.get(symbol) == new_phase:
            return  # Edge-triggered
        self._current_phase[symbol] = new_phase
        self.phase_changes_count += 1
        await self._context.publish("market.phase.changed", {"symbol": symbol, "phase": new_phase, "trend_state": new_state})
