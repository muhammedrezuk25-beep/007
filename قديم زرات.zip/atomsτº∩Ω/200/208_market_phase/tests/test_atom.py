import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom208"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=208, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_trend_is_early():
    print("\n--- test_first_trend_is_early ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
    events = [p for n, p in published if n == "market.phase.changed"]
    assert events == [{"symbol": "NQ", "phase": "EARLY", "trend_state": "UPTREND"}]
    print(f"OK — أول اتجاه = EARLY: {events[0]}")


async def test_range_is_neutral():
    print("\n--- test_range_is_neutral ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "RANGE"})
    events = [p for n, p in published if n == "market.phase.changed"]
    assert events == [{"symbol": "NQ", "phase": "NEUTRAL", "trend_state": "RANGE"}]
    print(f"OK — RANGE = NEUTRAL مباشرة: {events[0]}")


async def test_same_direction_resumed_after_pause_increments_confirmation():
    """يختبر بالضبط الحل للبق المُكتشَف — تأكيد عبر توقف RANGE/TRANSITION."""
    print("\n--- test_same_direction_resumed_after_pause_increments_confirmation ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})       # تأكيد 1 → EARLY
    await atom._on_trend_changed({"symbol": "NQ", "state": "TRANSITION"})    # توقف → NEUTRAL
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})       # عودة لنفس الاتجاه → تأكيد 2 → ESTABLISHED

    phases = [p["phase"] for n, p in published if n == "market.phase.changed"]
    assert phases == ["EARLY", "NEUTRAL", "ESTABLISHED"], phases
    assert atom._confirmation_count["NQ"] == 2
    print(f"OK — عودة لنفس الاتجاه بعد توقف زادت التأكيد لـ2 (ESTABLISHED): {phases}")


async def test_opposite_direction_resets_confirmation():
    print("\n--- test_opposite_direction_resets_confirmation ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
    await atom._on_trend_changed({"symbol": "NQ", "state": "TRANSITION"})
    await atom._on_trend_changed({"symbol": "NQ", "state": "DOWNTREND"})  # اتجاه معاكس — بداية جديدة

    assert atom._confirmation_count["NQ"] == 1, "اتجاه معاكس = بداية جديدة، لا استمرار للعدّاد"
    phases = [p["phase"] for n, p in published if n == "market.phase.changed"]
    assert phases[-1] == "EARLY"
    print(f"OK — اتجاه معاكس صفّر العدّاد، رجع EARLY: {phases}")


async def test_five_confirmations_reaches_extended():
    print("\n--- test_five_confirmations_reaches_extended ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for _ in range(5):
        await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
        await atom._on_trend_changed({"symbol": "NQ", "state": "TRANSITION"})
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})  # التأكيد السادس
    assert atom._confirmation_count["NQ"] == 6
    phases = [p["phase"] for n, p in published if n == "market.phase.changed"]
    assert phases[-1] == "EXTENDED", phases
    print(f"OK — 6 تأكيدات → EXTENDED: {phases[-1]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_trend_changed({"symbol": "NQ", "state": "UPTREND"})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._confirmation_count["NQ"] == 1
    assert atom2._current_phase["NQ"] == "EARLY"
    print("OK — restore() نقل حالة النضج كاملة بدقّة")


async def main():
    tests = [
        test_first_trend_is_early,
        test_range_is_neutral,
        test_same_direction_resumed_after_pause_increments_confirmation,
        test_opposite_direction_resets_confirmation,
        test_five_confirmations_reaches_extended,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
