"""
201 — Swing Detection (كشف نقاط التأرجح)

يشترك: market_data.candle_closed. ينشر: structure.swing_detected —
{symbol, type: "high"|"low", price, index}.

منطق مُستنتَج (لا سبك حسابي دقيق أُعطي): نقطة تأرجح = قمة/قاع محلي
مؤكَّد بمقارنة شمعة "مركزية" بجيرانها على الجانبين (نافذة متمركزة،
lookback=lookahead=2 افتراضيًا، حجم نافذة=5). **بالضرورة تأكيد
متأخِّر** — لا يمكن معرفة إن شمعة كانت قمة/قاع إلا بعد وصول شمعات
لاحقة كافية؛ هذا ليس قيدًا تصميميًا هنا، هو طبيعة المفهوم نفسه
(Swing Detection لا يمكن أن تكون فورية بالتعريف).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_LOOKBACK = 2


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._lookback = _DEFAULT_LOOKBACK
        self._windows: dict[str, list[dict]] = {}
        self.swings_detected_count = 0
        self._index_counters: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._lookback = int(context.config.get("lookback", _DEFAULT_LOOKBACK))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("SwingDetection(201) تمت تهيئته (lookback=%d)", self._lookback)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SwingDetection(201) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"نقاط_تأرجح_مكتشَفة={self.swings_detected_count}")

    async def snapshot(self) -> dict:
        return {
            "windows": self._windows, "swings_detected_count": self.swings_detected_count,
            "index_counters": self._index_counters,
        }

    async def restore(self, state: dict) -> None:
        self._windows = state.get("windows", {})
        self.swings_detected_count = state.get("swings_detected_count", 0)
        self._index_counters = state.get("index_counters", {})

    # ------------------------------------------------------------------

    async def _on_candle(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        window = self._windows.setdefault(symbol, [])
        idx = self._index_counters.get(symbol, 0)
        window.append({"index": idx, "high": payload["high"], "low": payload["low"]})
        self._index_counters[symbol] = idx + 1

        window_size = 2 * self._lookback + 1
        if len(window) > window_size:
            window.pop(0)
        if len(window) < window_size:
            return  # لسا ما وصلت شمعات كافية لتأكيد نقطة مركزية

        center = window[self._lookback]
        others = window[: self._lookback] + window[self._lookback + 1:]

        if all(center["high"] >= o["high"] for o in others) and any(center["high"] > o["high"] for o in others):
            await self._publish_swing(symbol, "high", center)
        elif all(center["low"] <= o["low"] for o in others) and any(center["low"] < o["low"] for o in others):
            await self._publish_swing(symbol, "low", center)

    async def _publish_swing(self, symbol: str, swing_type: str, center: dict) -> None:
        self.swings_detected_count += 1
        price = center["high"] if swing_type == "high" else center["low"]
        await self._context.publish(
            "structure.swing_detected", {"symbol": symbol, "type": swing_type, "price": price, "index": center["index"]}
        )
