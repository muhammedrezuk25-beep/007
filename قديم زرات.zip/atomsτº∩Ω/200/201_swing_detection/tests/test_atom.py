import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom201"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=201, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed_candles(atom, symbol, highs, lows):
    for h, l in zip(highs, lows):
        await atom._on_candle({"symbol": symbol, "high": h, "low": l, "open": h, "close": l, "volume": 1, "timeframe": "60s"})


async def test_swing_high_confirmed_at_center():
    print("\n--- test_swing_high_confirmed_at_center ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # قمة واضحة عند index=2: 10,15,20,15,10
    await _feed_candles(atom, "NQ", highs=[10, 15, 20, 15, 10], lows=[5, 5, 5, 5, 5])
    swings = [p for n, p in published if n == "structure.swing_detected"]
    assert len(swings) == 1
    assert swings[0] == {"symbol": "NQ", "type": "high", "price": 20, "index": 2}
    print(f"OK — قمة مؤكَّدة عند index=2: {swings[0]}")


async def test_swing_low_confirmed_at_center():
    print("\n--- test_swing_low_confirmed_at_center ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # قاع واضح عند index=2: 20,15,10,15,20
    await _feed_candles(atom, "NQ", highs=[25, 25, 25, 25, 25], lows=[20, 15, 10, 15, 20])
    swings = [p for n, p in published if n == "structure.swing_detected"]
    assert len(swings) == 1
    assert swings[0] == {"symbol": "NQ", "type": "low", "price": 10, "index": 2}
    print(f"OK — قاع مؤكَّد عند index=2: {swings[0]}")


async def test_monotonic_sequence_no_swing():
    print("\n--- test_monotonic_sequence_no_swing ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 12, 14, 16, 18], lows=[5, 7, 9, 11, 13])
    swings = [p for n, p in published if n == "structure.swing_detected"]
    assert len(swings) == 0, "اتجاه صاعد بحت — بلا أي قمة أو قاع محلي"
    print("OK — تسلسل أحادي الاتجاه (صاعد بحت) → صفر نقاط تأرجح")


async def test_insufficient_candles_no_detection_yet():
    print("\n--- test_insufficient_candles_no_detection_yet ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 20, 10], lows=[5, 5, 5])  # 3 شموع بس، النافذة تحتاج 5
    swings = [p for n, p in published if n == "structure.swing_detected"]
    assert len(swings) == 0, "لسا ما وصلت شمعات كافية لتأكيد نقطة مركزية"
    print("OK — 3 شموع فقط (تحت حجم النافذة 5) → بلا كشف بعد")


async def test_symbols_tracked_independently():
    print("\n--- test_symbols_tracked_independently ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 15, 20, 15, 10], lows=[5, 5, 5, 5, 5])
    await _feed_candles(atom, "ES", highs=[10, 12, 14, 16, 18], lows=[5, 7, 9, 11, 13])
    swings = [p for n, p in published if n == "structure.swing_detected"]
    assert len(swings) == 1 and swings[0]["symbol"] == "NQ"
    print(f"OK — NQ عندها قمة، ES بلا أي قمة (اتجاه صاعد بحت) — نوافذ مستقلة تمامًا")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 15, 20], lows=[5, 5, 5])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert len(atom2._windows["NQ"]) == 3
    assert atom2._index_counters["NQ"] == 3
    print("OK — restore() نقل النافذة الجارية وعدّاد الفهرس بدقّة")


async def main():
    tests = [
        test_swing_high_confirmed_at_center,
        test_swing_low_confirmed_at_center,
        test_monotonic_sequence_no_swing,
        test_insufficient_candles_no_detection_yet,
        test_symbols_tracked_independently,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
