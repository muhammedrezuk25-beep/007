"""
202 — External Structure (الهيكل الخارجي)

يشترك: مخرجات 201 (structure.swing_detected). ينشر:
structure.external_updated.

منطق مُستنتَج (لا سبك حسابي دقيق أُعطي): "هيكل خارجي" = نقاط
تأرجح تُسجِّل **قمة جديدة أعلى من كل القمم السابقة** أو **قاع جديد
أدنى من كل القيعان السابقة** لنفس الرمز — الحد الخارجي لحركة السعر.
نقاط لا تكسر هذا الحد = هيكل داخلي (203، منطق منفصل).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._external_high: dict[str, float] = {}
        self._external_low: dict[str, float] = {}
        self.updates_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.swing_detected", self._on_swing)
        context.logger.info("ExternalStructure(202) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ExternalStructure(202) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"تحديثات={self.updates_count}")

    async def snapshot(self) -> dict:
        return {"external_high": self._external_high, "external_low": self._external_low, "updates_count": self.updates_count}

    async def restore(self, state: dict) -> None:
        self._external_high = state.get("external_high", {})
        self._external_low = state.get("external_low", {})
        self.updates_count = state.get("updates_count", 0)

    # ------------------------------------------------------------------

    async def _on_swing(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        is_new_extreme = False

        if payload["type"] == "high":
            current = self._external_high.get(symbol)
            if current is None or payload["price"] > current:
                self._external_high[symbol] = payload["price"]
                is_new_extreme = True
        else:  # "low"
            current = self._external_low.get(symbol)
            if current is None or payload["price"] < current:
                self._external_low[symbol] = payload["price"]
                is_new_extreme = True

        if is_new_extreme:
            self.updates_count += 1
            await self._context.publish(
                "structure.external_updated",
                {
                    "symbol": symbol, "type": payload["type"], "price": payload["price"],
                    "external_high": self._external_high.get(symbol), "external_low": self._external_low.get(symbol),
                },
            )
