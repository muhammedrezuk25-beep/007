import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom202"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=202, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_swing_high_always_sets_external():
    print("\n--- test_first_swing_high_always_sets_external ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    events = [p for n, p in published if n == "structure.external_updated"]
    assert len(events) == 1
    assert atom._external_high["NQ"] == 100
    print(f"OK — أول قمة تُسجَّل خارجية تلقائيًا: {events[0]}")


async def test_lower_high_does_not_update_external():
    print("\n--- test_lower_high_does_not_update_external ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 95, "index": 6})  # أدنى من القمة السابقة
    events = [p for n, p in published if n == "structure.external_updated"]
    assert len(events) == 1, "قمة أدنى من الخارجية الحالية لا تُحدِّث شيئًا — تصير هيكل داخلي (203)"
    assert atom._external_high["NQ"] == 100, "الخارجية تبقى 100، لا تنخفض لـ95"
    print("OK — قمة أدنى من الخارجية الحالية لم تُحدِّثها")


async def test_higher_high_updates_external():
    print("\n--- test_higher_high_updates_external ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 110, "index": 6})  # أعلى من السابقة
    events = [p for n, p in published if n == "structure.external_updated"]
    assert len(events) == 2
    assert atom._external_high["NQ"] == 110
    print(f"OK — قمة أعلى حدَّثت الخارجية لـ110: {events[1]}")


async def test_high_and_low_tracked_independently():
    print("\n--- test_high_and_low_tracked_independently ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    await atom._on_swing({"symbol": "NQ", "type": "low", "price": 50, "index": 4})
    assert atom._external_high["NQ"] == 100
    assert atom._external_low["NQ"] == 50
    print(f"OK — قمة وقاع خارجيان مستقلان تمامًا: high={atom._external_high['NQ']} low={atom._external_low['NQ']}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_swing({"symbol": "NQ", "type": "high", "price": 100, "index": 2})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._external_high["NQ"] == 100
    print("OK — restore() نقل الحدود الخارجية بدقّة")


async def main():
    tests = [
        test_first_swing_high_always_sets_external,
        test_lower_high_does_not_update_external,
        test_higher_high_updates_external,
        test_high_and_low_tracked_independently,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
