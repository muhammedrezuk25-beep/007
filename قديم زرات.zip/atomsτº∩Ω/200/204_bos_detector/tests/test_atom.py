import asyncio
import pytest
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom204"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=204, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_external_break_not_bos():
    print("\n--- test_first_external_break_not_bos ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    events = [p for n, p in published if n == "market.bos.detected"]
    assert len(events) == 0, "كسر خارجي أول من نوعه — بلا اتجاه سابق للمقارنة، ليس BOS"
    print("OK — كسر خارجي أول → صفر BOS")


async def test_consecutive_same_direction_is_bos():
    print("\n--- test_consecutive_same_direction_is_bos ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 110})  # نفس الاتجاه (قمة بعد قمة)
    events = [p for n, p in published if n == "market.bos.detected"]
    assert len(events) == 1
    _required = {"symbol": "NQ", "direction": "high", "price": 110}
    for _k, _v in _required.items():
        assert events[0][_k] == _v
    print(f"OK — قمة بعد قمة (استمرارية صعودية) = BOS: {events[0]}")


async def test_direction_change_not_bos():
    print("\n--- test_direction_change_not_bos ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    await atom._on_external({"symbol": "NQ", "type": "low", "price": 50})  # تغيّر اتجاه — ذاك دور 205
    events = [p for n, p in published if n == "market.bos.detected"]
    assert len(events) == 0, "تغيّر اتجاه (قمة ثم قاع) ليس استمرارية — ليس BOS (ذاك CHOCH، 205)"
    print("OK — تغيّر اتجاه (قمة ثم قاع) لم يُعتبَر BOS")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._last_external_type["NQ"] == "high"
    print("OK — restore() نقل آخر اتجاه معروف بدقّة")


async def main():
    tests = [
        test_first_external_break_not_bos,
        test_consecutive_same_direction_is_bos,
        test_direction_change_not_bos,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


@pytest.mark.asyncio
async def test_bos_carries_the_level_it_broke():
    """406 measures break depth against the level, and the level is the
    previous external structure price. Without it 406 publishes no strength
    and its vote carries no weight in 458."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for price in (28400.0, 28420.0, 28520.0):
        await atom._on_external({"symbol": "NQ", "type": "high",
                                 "price": price, "timestamp": 1.0})
    events = [p for n, p in published if n == "market.bos.detected"]
    assert [e["level"] for e in events] == [28400.0, 28420.0]
    assert [e["price"] for e in events] == [28420.0, 28520.0]


@pytest.mark.asyncio
async def test_first_structure_has_no_level_and_does_not_invent_one():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100.0})
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 110.0})
    events = [p for n, p in published if n == "market.bos.detected"]
    assert events[0]["level"] == 100.0


@pytest.mark.asyncio
async def test_level_survives_a_snapshot():
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100.0})
    state = await atom.snapshot()

    fresh = Atom()
    fresh_context, fresh_published = make_context()
    await fresh.initialize(fresh_context)
    await fresh.restore(state)
    await fresh._on_external({"symbol": "NQ", "type": "high", "price": 110.0})
    events = [p for n, p in fresh_published if n == "market.bos.detected"]
    assert events and events[0]["level"] == 100.0
