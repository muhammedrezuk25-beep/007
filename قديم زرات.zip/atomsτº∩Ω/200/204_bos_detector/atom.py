"""
204 — BOS Detector (كشف كسر الهيكل)

يشترك: مخرجات 202 (structure.external_updated). ينشر:
market.bos.detected.

منطق مُستنتَج (مصطلح SMC قياسي، لا سبك حسابي دقيق أُعطي): BOS
(Break of Structure) = كسر حد خارجي **بنفس اتجاه** آخر كسر خارجي
سابق — استمرارية الاتجاه (قمة أعلى بعد قمة أعلى سابقة، أو قاع أدنى
بعد قاع أدنى سابق). الكسر الأول من نوعه، أو كسر **بعكس** الاتجاه
السابق، ليس BOS — ذاك دور 205 (CHOCH، تغيّر الطابع).

تكرار حسابي متعمَّد مع 205 (يتتبّعان نفس "آخر اتجاه خارجي" كل
واحدة بذاكرتها المستقلة — لا استدعاء بينهما، قاعدة 0).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_external_type: dict[str, str] = {}
        self._last_external_price: dict[str, float] = {}
        self.bos_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.external_updated", self._on_external)
        context.logger.info("BOSDetector(204) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("BOSDetector(204) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"BOS_مكتشَف={self.bos_count}")

    async def snapshot(self) -> dict:
        return {"last_external_type": self._last_external_type,
                "last_external_price": self._last_external_price,
                "bos_count": self.bos_count}

    async def restore(self, state: dict) -> None:
        self._last_external_type = state.get("last_external_type", {})
        self._last_external_price = state.get("last_external_price", {})
        self.bos_count = state.get("bos_count", 0)

    # ------------------------------------------------------------------

    async def _on_external(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        current_type = payload["type"]
        last_type = self._last_external_type.get(symbol)

        last_price = self._last_external_price.get(symbol)

        if last_type == current_type:  # نفس الاتجاه مرتين متتاليتين = استمرارية = BOS
            self.bos_count += 1
            body = {"symbol": symbol, "direction": current_type,
                    "price": payload["price"]}
            if last_price is not None:
                body["level"] = last_price
            stamp = payload.get("timestamp")
            if isinstance(stamp, (int, float)):
                body["timestamp"] = stamp
            await self._context.publish("market.bos.detected", body)

        self._last_external_type[symbol] = current_type
        price = payload.get("price")
        if isinstance(price, (int, float)):
            self._last_external_price[symbol] = float(price)
