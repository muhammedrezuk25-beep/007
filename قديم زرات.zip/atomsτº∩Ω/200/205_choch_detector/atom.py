"""
205 — CHOCH Detector (كشف تغيّر الطابع)

يشترك: مخرجات 202 (structure.external_updated). ينشر:
market.choch.detected.

منطق مُستنتَج (SMC قياسي) — عكس 204 حرفيًا: CHOCH = كسر خارجي
**بعكس** اتجاه آخر كسر خارجي سابق (إشارة انعكاس اتجاه محتمل). أول
كسر من نوعه ليس CHOCH (لا اتجاه سابق للمقارنة أصلًا).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_external_type: dict[str, str] = {}
        self.choch_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.external_updated", self._on_external)
        context.logger.info("CHOCHDetector(205) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("CHOCHDetector(205) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"CHOCH_مكتشَف={self.choch_count}")

    async def snapshot(self) -> dict:
        return {"last_external_type": self._last_external_type, "choch_count": self.choch_count}

    async def restore(self, state: dict) -> None:
        self._last_external_type = state.get("last_external_type", {})
        self.choch_count = state.get("choch_count", 0)

    # ------------------------------------------------------------------

    async def _on_external(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        current_type = payload["type"]
        last_type = self._last_external_type.get(symbol)

        if last_type is not None and last_type != current_type:  # اتجاه معاكس = تغيّر طابع
            self.choch_count += 1
            await self._context.publish(
                "market.choch.detected", {"symbol": symbol, "new_direction": current_type, "price": payload["price"]}
            )

        self._last_external_type[symbol] = current_type
