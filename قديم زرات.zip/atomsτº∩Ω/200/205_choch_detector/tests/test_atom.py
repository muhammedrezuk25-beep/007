import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom205"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=205, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_first_external_break_not_choch():
    print("\n--- test_first_external_break_not_choch ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    events = [p for n, p in published if n == "market.choch.detected"]
    assert len(events) == 0
    print("OK — كسر خارجي أول → صفر CHOCH")


async def test_direction_reversal_is_choch():
    print("\n--- test_direction_reversal_is_choch ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    await atom._on_external({"symbol": "NQ", "type": "low", "price": 50})  # انعكاس
    events = [p for n, p in published if n == "market.choch.detected"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "new_direction": "low", "price": 50}
    print(f"OK — انعكاس اتجاه (قمة ثم قاع) = CHOCH: {events[0]}")


async def test_consecutive_same_direction_not_choch():
    print("\n--- test_consecutive_same_direction_not_choch ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 110})  # استمرارية — ذاك BOS (204)
    events = [p for n, p in published if n == "market.choch.detected"]
    assert len(events) == 0, "استمرارية اتجاه ليست تغيّر طابع (ذاك BOS، 204)"
    print("OK — استمرارية اتجاه لم تُعتبَر CHOCH")


async def test_mutually_exclusive_with_bos_across_sequence():
    """يثبت أن 204 و205 يغطيان كل الحالات بلا تداخل — كل كسر خارجي
    بعد الأول إما BOS أو CHOCH، لا الاثنين معًا."""
    print("\n--- test_mutually_exclusive_with_bos_across_sequence ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    sequence = [
        {"symbol": "NQ", "type": "high", "price": 100},
        {"symbol": "NQ", "type": "high", "price": 110},  # BOS بمنطق 204
        {"symbol": "NQ", "type": "low", "price": 50},     # CHOCH هون
        {"symbol": "NQ", "type": "low", "price": 40},     # BOS بمنطق 204
    ]
    for s in sequence:
        await atom._on_external(s)
    choch_events = [p for n, p in published if n == "market.choch.detected"]
    assert len(choch_events) == 1, f"CHOCH وحدة بس بهالتسلسل (نقطة الانعكاس)، لقيت {len(choch_events)}"
    print(f"OK — CHOCH وحدة بس بالنقطة الصحيحة من التسلسل: {choch_events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_external({"symbol": "NQ", "type": "high", "price": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._last_external_type["NQ"] == "high"
    print("OK — restore() نقل آخر اتجاه معروف بدقّة")


async def main():
    tests = [
        test_first_external_break_not_choch,
        test_direction_reversal_is_choch,
        test_consecutive_same_direction_not_choch,
        test_mutually_exclusive_with_bos_across_sequence,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
