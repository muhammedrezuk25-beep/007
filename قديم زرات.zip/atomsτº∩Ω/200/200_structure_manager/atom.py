"""
200 — مدير هيكل السوق (Market Structure Manager)

محسوم سابقًا بالكامل — دور مختلف عن نمط "الجامع" المعتاد (101
مثلًا): "subscribe + normalize + validate فقط (بلا نشر نهائي — هاي
مهمة 210)". فُهِمَت هنا كـ: **جامع نشاط العائلة الكاملة** (201-210،
10 أحداث) لأغراض المراقبة/الصحة فقط — ينشر حدث حالة عائلة خفيف
(structure.family_status)، **لا** ينافس market.structure.updated
(210، الحدث النهائي الحقيقي للقسم). قاعدة 1 حرفيًا: جامع، يشترك،
يوحّد، ينشر — بس بلا ادّعاء دور 210.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_FAMILY_EVENTS = [
    "structure.swing_detected", "structure.external_updated", "structure.internal_updated",
    "market.bos.detected", "market.choch.detected", "structure.mss_detected",
    "market.trend.changed", "market.phase.changed", "structure.validated", "structure.validation_failed",
]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.event_counts: dict[str, int] = {name: 0 for name in _FAMILY_EVENTS}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _FAMILY_EVENTS:
            context.subscribe(event_name, self._make_tracker(event_name))
        context.logger.info("MarketStructureManager(200) تمت تهيئته (يراقب %d نوع حدث عائلي)", len(_FAMILY_EVENTS))

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("MarketStructureManager(200) بدأ المراقبة")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total = sum(self.event_counts.values())
        return HealthStatus(state=HealthState.HEALTHY, message=f"إجمالي نشاط العائلة={total} {self.event_counts}")

    async def snapshot(self) -> dict:
        return {"event_counts": self.event_counts}

    async def restore(self, state: dict) -> None:
        self.event_counts = dict(state.get("event_counts", {name: 0 for name in _FAMILY_EVENTS}))

    # ------------------------------------------------------------------

    def _make_tracker(self, event_name: str):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            self.event_counts[event_name] += 1
            await self._context.publish(
                "structure.family_status",
                {"last_event": event_name, "total_activity": sum(self.event_counts.values())},
            )

        return handler
