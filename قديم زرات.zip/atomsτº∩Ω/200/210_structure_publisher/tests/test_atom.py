import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom210"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=210, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_validated_swing_produces_unified_state():
    print("\n--- test_validated_swing_produces_unified_state ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "type": "high", "price": 100}})
    events = [p for n, p in published if n == "market.structure.updated"]
    assert len(events) == 1
    assert events[0]["symbol"] == "NQ"
    assert events[0]["state"] == {"type": "high", "price": 100}
    print(f"OK — أول تحديث مُتحقَّق منه أنتج حالة موحَّدة: {events[0]}")


async def test_state_accumulates_across_multiple_validated_updates():
    print("\n--- test_state_accumulates_across_multiple_validated_updates ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "state": "UPTREND"}})       # من 207
    await atom._on_validated({"payload": {"symbol": "NQ", "phase": "EARLY"}})          # من 208
    last_state = published[-1][1]["state"]
    assert last_state == {"state": "UPTREND", "phase": "EARLY"}, "اللقطة الأخيرة تراكمت من مصدرين، لا آخر واحد بس"
    print(f"OK — الحالة تراكمت من مصدرين مختلفين (207+208): {last_state}")


async def test_symbols_tracked_independently():
    print("\n--- test_symbols_tracked_independently ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "state": "UPTREND"}})
    await atom._on_validated({"payload": {"symbol": "ES", "state": "DOWNTREND"}})
    assert atom._state["NQ"]["state"] == "UPTREND"
    assert atom._state["ES"]["state"] == "DOWNTREND"
    print(f"OK — NQ وES بحالتين مستقلتين: {atom._state}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "state": "UPTREND"}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._state["NQ"]["state"] == "UPTREND"
    assert atom2.published_count == 1
    print("OK — restore() نقل الحالة الموحَّدة كاملة بدقّة")


async def main():
    tests = [
        test_validated_swing_produces_unified_state,
        test_state_accumulates_across_multiple_validated_updates,
        test_symbols_tracked_independently,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
