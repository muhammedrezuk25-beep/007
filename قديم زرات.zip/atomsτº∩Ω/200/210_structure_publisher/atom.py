"""
210 — Structure Publisher (ناشر الهيكل)

يشترك: مخرجات 209 (structure.validated **بس**، لا validation_failed
— فقط المُتحقَّق منه يصل هون). ينشر: market.structure.updated —
الحدث الموحَّد النهائي لقسم هيكل السوق كامل (201-209).

آلية: نفس نمط تجميع 101 (جامع، قاعدة 1) — يحتفظ بآخر حالة معروفة من
كل نوع حدث مصدر لكل رمز، ينشر لقطة موحَّدة عند كل تحديث مُتحقَّق منه.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._state: dict[str, dict] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.validated", self._on_validated)
        context.logger.info("StructurePublisher(210) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("StructurePublisher(210) بدأ الاستماع لـstructure.validated")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"رموز_مُتابَعة={len(self._state)} منشور={self.published_count}")

    async def snapshot(self) -> dict:
        return {"state": self._state, "published_count": self.published_count}

    async def restore(self, state: dict) -> None:
        self._state = state.get("state", {})
        self.published_count = state.get("published_count", 0)

    # ------------------------------------------------------------------

    async def _on_validated(self, payload: dict) -> None:
        if self._context is None:
            return
        inner = payload.get("payload", {})
        symbol = str(inner.get("symbol", "_global"))
        symbol_state = self._state.setdefault(symbol, {})
        symbol_state.update({k: v for k, v in inner.items() if k != "symbol"})

        self.published_count += 1
        await self._context.publish(
            "market.structure.updated", {"symbol": symbol, "state": dict(symbol_state), **_ts_from(payload)}
        )
