import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom207"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=207, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_bos_high_sets_uptrend():
    print("\n--- test_bos_high_sets_uptrend ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 100})
    events = [p for n, p in published if n == "market.trend.changed"]
    assert events == [{"symbol": "NQ", "state": "UPTREND"}]
    print(f"OK — BOS اتجاه high → UPTREND: {events[0]}")


async def test_bos_low_sets_downtrend():
    print("\n--- test_bos_low_sets_downtrend ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "low", "price": 50})
    events = [p for n, p in published if n == "market.trend.changed"]
    assert events == [{"symbol": "NQ", "state": "DOWNTREND"}]
    print(f"OK — BOS اتجاه low → DOWNTREND: {events[0]}")


async def test_choch_sets_transition():
    print("\n--- test_choch_sets_transition ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 100})
    await atom._on_mss({"symbol": "NQ", "shift_type": "choch", "direction": "low", "price": 50})
    events = [p for n, p in published if n == "market.trend.changed"]
    assert [e["state"] for e in events] == ["UPTREND", "TRANSITION"]
    print(f"OK — CHOCH بعد UPTREND → TRANSITION: {events[-1]}")


async def test_edge_triggered_no_republish_on_same_state():
    print("\n--- test_edge_triggered_no_republish_on_same_state ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 100})
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 110})  # نفس UPTREND
    events = [p for n, p in published if n == "market.trend.changed"]
    assert len(events) == 1, "نفس الحالة مرتين — Edge-triggered، بلا نشر تكراري"
    print("OK — BOS متتالٍ بنفس الاتجاه لم يُعِد النشر (Edge-triggered)")


async def test_raw_trend_sets_default_before_any_mss():
    print("\n--- test_raw_trend_sets_default_before_any_mss ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_raw_trend({"symbol": "NQ", "direction": "up"})
    events = [p for n, p in published if n == "market.trend.changed"]
    assert events == [{"symbol": "NQ", "state": "UPTREND"}]
    print(f"OK — 151 (خام) حدَّد حالة افتراضية قبل أي MSS: {events[0]}")


async def test_raw_trend_none_direction_means_range():
    print("\n--- test_raw_trend_none_direction_means_range ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_raw_trend({"symbol": "NQ", "direction": "none"})
    events = [p for n, p in published if n == "market.trend.changed"]
    assert events == [{"symbol": "NQ", "state": "RANGE"}]
    print(f"OK — 151 بلا اتجاه واضح → RANGE: {events[0]}")


async def test_raw_trend_does_not_override_real_mss():
    print("\n--- test_raw_trend_does_not_override_real_mss ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 100})  # MSS حقيقي أولًا
    await atom._on_raw_trend({"symbol": "NQ", "direction": "down"})  # 151 يحاول يخالف بعدين
    events = [p for n, p in published if n == "market.trend.changed"]
    assert len(events) == 1 and events[0]["state"] == "UPTREND", "MSS حقيقي وصل — 151 ما عاد يتجاوزه"
    print("OK — 151 لم يتجاوز حالة أُقِرَّت فعليًا من MSS حقيقي")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_mss({"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._trend["NQ"] == "UPTREND"
    print("OK — restore() نقل حالة الاتجاه الرسمية بدقّة")


async def main():
    tests = [
        test_bos_high_sets_uptrend,
        test_bos_low_sets_downtrend,
        test_choch_sets_transition,
        test_edge_triggered_no_republish_on_same_state,
        test_raw_trend_sets_default_before_any_mss,
        test_raw_trend_none_direction_means_range,
        test_raw_trend_does_not_override_real_mss,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
