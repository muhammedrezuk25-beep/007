"""
207 — Trend State (حالة الاتجاه)

الذرة الوحيدة يلي "تعلن" الاتجاه الرسمي بكل النظام. يشترك: مخرجات
206 (structure.mss_detected) + مؤشر 151 الخام (trend.detected، من
قسم 150 غير مبنية بعد بهذه الدفعة — الاشتراك مسجَّل مسبقًا، مُختبَر
بأحداث مُصطنَعة). القيم الثابتة: UPTREND | DOWNTREND | RANGE |
TRANSITION. ينشر: market.trend.changed — **Edge-triggered فقط عند
تغيّر الحالة الفعلي**، لا كل حدث مصدر.

منطق مُستنتَج للتحويل: BOS (استمرارية مؤكَّدة) → UPTREND/DOWNTREND
حسب الاتجاه. CHOCH (إشارة انعكاس، غير مؤكَّدة كاتجاه ثابت بعد) →
TRANSITION. 151 (المؤشر الخام) يحدِّد الحالة الافتراضية **قبل** وصول
أي MSS حقيقي فقط — بمجرد وصول MSS، هو المصدر الحاكم.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_VALID_STATES = {"UPTREND", "DOWNTREND", "RANGE", "TRANSITION"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._trend: dict[str, str] = {}
        # مَن يحكم الحالة لكل رمز: "mss" أو "raw". القفل يجب أن يكون
        # على حكم MSS الحقيقي، لا على مجرّد وجود قيمة سابقة.
        self._governed_by: dict[str, str] = {}
        self.changes_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.mss_detected", self._on_mss)
        context.subscribe("trend.detected", self._on_raw_trend)
        context.logger.info("TrendState(207) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TrendState(207) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حالات_مُتابَعة={self._trend}")

    async def snapshot(self) -> dict:
        return {"trend": self._trend, "governed_by": self._governed_by,
                "changes_count": self.changes_count}

    async def restore(self, state: dict) -> None:
        self._trend = state.get("trend", {})
        self._governed_by = state.get("governed_by", {})
        self.changes_count = state.get("changes_count", 0)

    # ------------------------------------------------------------------

    async def _set_trend(self, symbol: str, new_state: str) -> None:
        assert new_state in _VALID_STATES
        if self._trend.get(symbol) == new_state:
            return  # Edge-triggered — بلا تغيير فعلي، بلا نشر
        self._trend[symbol] = new_state
        self.changes_count += 1
        if self._context is not None:
            await self._context.publish("market.trend.changed", {"symbol": symbol, "state": new_state})

    async def _on_mss(self, payload: dict) -> None:
        symbol = payload["symbol"]
        self._governed_by[symbol] = "mss"
        if payload["shift_type"] == "choch":
            await self._set_trend(symbol, "TRANSITION")
        elif payload["shift_type"] == "bos":
            new_state = "UPTREND" if payload["direction"] == "high" else "DOWNTREND"
            await self._set_trend(symbol, new_state)

    async def _on_raw_trend(self, payload: dict) -> None:
        """151 يحدِّد الحالة الافتراضية بس قبل وصول أي MSS حقيقي."""
        symbol = payload["symbol"]
        if self._governed_by.get(symbol) == "mss":
            return  # MSS حقيقي حكم — هو الحاكم الآن، 151 لا يتجاوزه
        # قبل الإصلاح كان الشرط `if symbol in self._trend` — وهو صحيح
        # لو أن المُدخِل الوحيد هو MSS، لكن 151 نفسه يملأ القاموس عند
        # أول إشارة، فيقفل على نفسه ويُهمل كل تحديثاته اللاحقة. في
        # تشغيل حقيقي: 66 إشارة من 151، تغيير واحد فقط، والحالة عالقة
        # على RANGE ⇒ probability_up=0.5 ⇒ confidence=0.0 ⇒ 454 يرفض كل قرار.
        self._governed_by[symbol] = "raw"
        direction = payload.get("direction", "none")
        default_state = {"up": "UPTREND", "down": "DOWNTREND"}.get(direction, "RANGE")
        await self._set_trend(symbol, default_state)
