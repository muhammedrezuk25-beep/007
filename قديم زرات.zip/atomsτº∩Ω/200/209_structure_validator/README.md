# 209 — Structure Validator (مدقق الهيكل)

يشترك بكل الثمانية مخرجات (201-208). ⚠️ بعكس 112 (Edge-triggered،
صمت لو سليم): هنا **قرار صريح بكل مرة** — `structure.validated` أو
`structure.validation_failed`. فحوصات مُستنتَجة: أسعار موجبة، تناسق
منطقي (`external_high >= external_low`)، قيم من مجموعات ثابتة صحيحة.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
7 اختبارات: نقطة سليمة، سعر سالب، تناقض `external_high<low`، حالة
اتجاه غير صالحة، `shift_type` غير معروف، **الثمانية أنواع معًا بلا
عيب إغلاق متأخر**، `snapshot`/`restore`. **نتيجة: 7/7.**
