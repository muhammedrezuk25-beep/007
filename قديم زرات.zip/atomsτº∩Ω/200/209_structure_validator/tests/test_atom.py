import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom209"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=209, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_valid_swing_validated():
    print("\n--- test_valid_swing_validated ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.swing_detected", {"symbol": "NQ", "type": "high", "price": 100, "index": 1})
    valid = [p for n, p in bus.published if n == "structure.validated"]
    assert len(valid) == 1
    print(f"OK — نقطة تأرجح سليمة → validated: {valid[0]}")


async def test_negative_price_swing_fails():
    print("\n--- test_negative_price_swing_fails ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.swing_detected", {"symbol": "NQ", "type": "high", "price": -5, "index": 1})
    failed = [p for n, p in bus.published if n == "structure.validation_failed"]
    assert len(failed) == 1
    assert "سعر غير موجب" in failed[0]["problem"]
    print(f"OK — سعر سالب اكتُشِف: {failed[0]}")


async def test_external_contradiction_fails():
    print("\n--- test_external_contradiction_fails ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.external_updated", {"symbol": "NQ", "type": "high", "price": 100, "external_high": 50, "external_low": 80})
    failed = [p for n, p in bus.published if n == "structure.validation_failed"]
    assert len(failed) == 1
    assert "تناقض" in failed[0]["problem"]
    print(f"OK — تناقض external_high<external_low اكتُشِف: {failed[0]}")


async def test_invalid_trend_state_fails():
    print("\n--- test_invalid_trend_state_fails ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market.trend.changed", {"symbol": "NQ", "state": "SIDEWAYS_ZIGZAG"})  # قيمة خارج المجموعة الثابتة
    failed = [p for n, p in bus.published if n == "structure.validation_failed"]
    assert len(failed) == 1
    assert "حالة اتجاه غير صالحة" in failed[0]["problem"]
    print(f"OK — حالة اتجاه خارج المجموعة الثابتة اكتُشِفت: {failed[0]}")


async def test_invalid_mss_shift_type_fails():
    print("\n--- test_invalid_mss_shift_type_fails ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.mss_detected", {"symbol": "NQ", "shift_type": "unknown_type", "direction": "high", "price": 100})
    failed = [p for n, p in bus.published if n == "structure.validation_failed"]
    assert len(failed) == 1
    assert "shift_type غير صالح" in failed[0]["problem"]
    print(f"OK — shift_type غير معروف اكتُشِف: {failed[0]}")


async def test_all_eight_event_types_wired_no_late_binding():
    print("\n--- test_all_eight_event_types_wired_no_late_binding ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.swing_detected", {"type": "high", "price": 1})
    await bus.publish("structure.external_updated", {"external_high": 10, "external_low": 5})
    await bus.publish("structure.internal_updated", {"price": 1})
    await bus.publish("market.bos.detected", {"price": 1})
    await bus.publish("market.choch.detected", {"price": 1})
    await bus.publish("structure.mss_detected", {"shift_type": "bos"})
    await bus.publish("market.trend.changed", {"state": "UPTREND"})
    await bus.publish("market.phase.changed", {"phase": "EARLY"})
    assert atom.validated_count == 8, f"كل الثمانية أنواع لازم تُفحَص بمنطقها الصحيح، لقيت validated_count={atom.validated_count}"
    print(f"OK — الثمانية أنواع كلهم اتفحصوا بمنطقهم الصحيح: validated_count={atom.validated_count}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("structure.swing_detected", {"symbol": "NQ", "type": "high", "price": 100, "index": 1})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.validated_count == 1
    print("OK — restore() نقل العدّادين بدقّة")


async def main():
    tests = [
        test_valid_swing_validated,
        test_negative_price_swing_fails,
        test_external_contradiction_fails,
        test_invalid_trend_state_fails,
        test_invalid_mss_shift_type_fails,
        test_all_eight_event_types_wired_no_late_binding,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
