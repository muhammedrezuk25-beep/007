"""
209 — Structure Validator (مدقق الهيكل)

يشترك: كل مخرجات 201-208 (8 أحداث). يتحقق من عدم وجود إشارات كاذبة
(Sanity Check). ينشر structure.validated أو structure.validation_failed
— **كلاهما، بعكس 112 (لا صمت هنا، القرار صريح بكل مرة)**.

فحوصات مُستنتَجة (لا سبك دقيق أُعطي لكل نوع): أسعار موجبة، تناسق
منطقي (external_high >= external_low لو الاثنين موجودان)، قيم من
مجموعات ثابتة صحيحة (shift_type، trend state، phase).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_VALID_TREND_STATES = {"UPTREND", "DOWNTREND", "RANGE", "TRANSITION"}
_VALID_PHASES = {"EARLY", "ESTABLISHED", "EXTENDED", "NEUTRAL"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.validated_count = 0
        self.failed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("structure.swing_detected", self._make_checker(self._check_swing))
        context.subscribe("structure.external_updated", self._make_checker(self._check_external))
        context.subscribe("structure.internal_updated", self._make_checker(self._check_price_positive))
        context.subscribe("market.bos.detected", self._make_checker(self._check_price_positive))
        context.subscribe("market.choch.detected", self._make_checker(self._check_price_positive))
        context.subscribe("structure.mss_detected", self._make_checker(self._check_mss))
        context.subscribe("market.trend.changed", self._make_checker(self._check_trend))
        context.subscribe("market.phase.changed", self._make_checker(self._check_phase))
        context.logger.info("StructureValidator(209) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("StructureValidator(209) بدأ التحقق")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"مُتحقَّق={self.validated_count} فشل={self.failed_count}")

    async def snapshot(self) -> dict:
        return {"validated_count": self.validated_count, "failed_count": self.failed_count}

    async def restore(self, state: dict) -> None:
        self.validated_count = state.get("validated_count", 0)
        self.failed_count = state.get("failed_count", 0)

    # ------------------------------------------------------------------

    def _make_checker(self, check_fn):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            problem = check_fn(payload)
            if problem is None:
                self.validated_count += 1
                await self._context.publish("structure.validated", {"payload": payload})
            else:
                self.failed_count += 1
                await self._context.publish("structure.validation_failed", {"problem": problem, "payload": payload})

        return handler

    @staticmethod
    def _check_swing(payload: dict) -> str | None:
        if payload.get("price", 0) <= 0:
            return f"سعر غير موجب: {payload.get('price')}"
        if payload.get("type") not in {"high", "low"}:
            return f"نوع نقطة تأرجح غير صالح: {payload.get('type')}"
        return None

    @staticmethod
    def _check_external(payload: dict) -> str | None:
        eh, el = payload.get("external_high"), payload.get("external_low")
        if eh is not None and el is not None and eh < el:
            return f"تناقض: external_high({eh}) < external_low({el})"
        return None

    @staticmethod
    def _check_price_positive(payload: dict) -> str | None:
        if payload.get("price", 0) <= 0:
            return f"سعر غير موجب: {payload.get('price')}"
        return None

    @staticmethod
    def _check_mss(payload: dict) -> str | None:
        if payload.get("shift_type") not in {"bos", "choch"}:
            return f"shift_type غير صالح: {payload.get('shift_type')}"
        return None

    @staticmethod
    def _check_trend(payload: dict) -> str | None:
        if payload.get("state") not in _VALID_TREND_STATES:
            return f"حالة اتجاه غير صالحة: {payload.get('state')}"
        return None

    @staticmethod
    def _check_phase(payload: dict) -> str | None:
        if payload.get("phase") not in _VALID_PHASES:
            return f"طور غير صالح: {payload.get('phase')}"
        return None
