import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom206"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=206, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_bos_unified_with_correct_shift_type():
    print("\n--- test_bos_unified_with_correct_shift_type ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market.bos.detected", {"symbol": "NQ", "direction": "high", "price": 110})
    events = [p for n, p in bus.published if n == "structure.mss_detected"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "shift_type": "bos", "direction": "high", "price": 110}
    print(f"OK — BOS مُوحَّد بـshift_type صحيح: {events[0]}")


async def test_choch_unified_with_correct_shift_type_no_late_binding():
    """يثبت عدم وجود عيب إغلاق متأخر بين handler الـBOS وhandler الـCHOCH"""
    print("\n--- test_choch_unified_with_correct_shift_type_no_late_binding ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market.bos.detected", {"symbol": "NQ", "direction": "high", "price": 110})
    await bus.publish("market.choch.detected", {"symbol": "NQ", "new_direction": "low", "price": 50})
    events = [p for n, p in bus.published if n == "structure.mss_detected"]
    assert len(events) == 2
    assert events[0]["shift_type"] == "bos"
    assert events[1]["shift_type"] == "choch" and events[1]["direction"] == "low"
    print(f"OK — BOS وCHOCH كل واحد بـshift_type الصحيح بالضبط: {[e['shift_type'] for e in events]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("market.bos.detected", {"symbol": "NQ", "direction": "high", "price": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2.mss_count == 1
    print("OK — restore() نقل العدّاد بدقّة")


async def main():
    tests = [test_bos_unified_with_correct_shift_type, test_choch_unified_with_correct_shift_type_no_late_binding, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
