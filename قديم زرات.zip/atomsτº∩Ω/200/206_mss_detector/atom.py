"""
206 — Market Structure Shift / MSS (تحوّل هيكل السوق)

يشترك: مخرجات 204 (market.bos.detected) و205 (market.choch.detected).
ينشر: structure.mss_detected.

منطق مُستنتَج: MSS هنا = **جامع موحِّد** فوق BOS/CHOCH (قاعدة 1) —
حدث واحد يجمع كلا النوعين بحقل shift_type مميِّز، بدل ما يضطر أي
مستهلك لاحق (207 مثلًا) يشترك بحدثين منفصلين. بلا تصنيف/قرار إضافي
غير موجود بمصدريه أصلًا.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.mss_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.bos.detected", self._on_bos)
        context.subscribe("market.choch.detected", self._on_choch)
        context.logger.info("MSSDetector(206) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("MSSDetector(206) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"MSS_مُوحَّد={self.mss_count}")

    async def snapshot(self) -> dict:
        return {"mss_count": self.mss_count}

    async def restore(self, state: dict) -> None:
        self.mss_count = state.get("mss_count", 0)

    # ------------------------------------------------------------------

    async def _on_bos(self, payload: dict) -> None:
        await self._publish_mss(payload["symbol"], "bos", payload["direction"], payload["price"])

    async def _on_choch(self, payload: dict) -> None:
        await self._publish_mss(payload["symbol"], "choch", payload["new_direction"], payload["price"])

    async def _publish_mss(self, symbol: str, shift_type: str, direction: str, price: float) -> None:
        if self._context is None:
            return
        self.mss_count += 1
        await self._context.publish(
            "structure.mss_detected", {"symbol": symbol, "shift_type": shift_type, "direction": direction, "price": price}
        )
