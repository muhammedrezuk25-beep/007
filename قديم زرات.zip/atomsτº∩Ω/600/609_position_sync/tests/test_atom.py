from __future__ import annotations

import ast
import asyncio
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom609"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 609

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 609


import shutil
import sqlite3
import tempfile

_ROWS = [(1, "USTEC", "BUY", 0.1, 28400.0, 28420.0, 28330.0, 0.0, 20.0, 0.0, 0, "", TS, TS),
         (2, "XAUUSD", "SELL", 0.05, 2650.0, 2645.0, 2670.0, 0.0, -8.0, 0.0, 0, "", TS, TS)]


def _make_db(tmp, rows=None):
    path = str(Path(tmp) / "nq_brain.db")
    connection = sqlite3.connect(path)
    connection.execute(
        "CREATE TABLE positions (ticket INTEGER PRIMARY KEY, symbol TEXT,"
        " side TEXT, volume REAL, entry_price REAL, current_price REAL,"
        " stop_loss REAL, take_profit REAL, profit REAL, swap REAL,"
        " magic INTEGER, comment TEXT, opened_at REAL, updated_at REAL)")
    connection.executemany(
        "INSERT INTO positions VALUES (" + ",".join("?" * 14) + ")",
        _ROWS if rows is None else rows)
    connection.commit()
    connection.close()
    return path


async def _ready(rows=None, **over):
    tmp = tempfile.mkdtemp()
    path = _make_db(tmp, rows)
    cfg = {**CONFIG, "db_path": path, "poll_interval_s": 60.0}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    atom._running = True
    await atom._read_once()
    return atom, ctx, tmp, path


@pytest.mark.asyncio
async def test_it_reads_the_positions_the_platform_holds():
    atom, ctx, tmp, path = await _ready()
    try:
        state = out(ctx, MODULE.EVENT_OUT)[-1]
        assert state["open_count"] == 2
        assert state["tickets"] == ["1", "2"]
        assert state["floating_pnl"] == 12.0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_every_position_carries_its_own_fields():
    atom, ctx, tmp, path = await _ready()
    try:
        rows = {str(p["ticket"]): p for p in out(ctx, MODULE.EVENT_OUT)[-1]["positions"]}
        assert rows["1"]["symbol"] == "USTEC"
        assert rows["1"]["volume"] == 0.1
        assert rows["2"]["side"] == "SELL"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_new_position_is_named_when_it_appears():
    atom, ctx, tmp, path = await _ready()
    try:
        connection = sqlite3.connect(path)
        connection.execute(
            "INSERT INTO positions VALUES (" + ",".join("?" * 14) + ")",
            (3, "EURUSD", "BUY", 0.2, 1.08, 1.09, 1.07, 0.0, 5.0, 0.0, 0, "", TS, TS))
        connection.commit()
        connection.close()
        await atom._read_once()
        appeared = out(ctx, MODULE.EVENT_OPENED)
        assert appeared and appeared[-1]["ticket"] == 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_position_closed_on_the_platform_is_named_when_it_vanishes():
    """A position closed by hand on the terminal leaves no trade event for
    the system. Naming it is the only way the system learns."""
    atom, ctx, tmp, path = await _ready()
    try:
        connection = sqlite3.connect(path)
        connection.execute("DELETE FROM positions WHERE ticket=2")
        connection.commit()
        connection.close()
        await atom._read_once()
        vanished = out(ctx, MODULE.EVENT_CLOSED)
        assert vanished and vanished[-1]["ticket"] == 2
        assert vanished[-1]["symbol"] == "XAUUSD"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_unchanged_read_names_nothing():
    atom, ctx, tmp, path = await _ready()
    try:
        before = len(out(ctx, MODULE.EVENT_OPENED)) + len(out(ctx, MODULE.EVENT_CLOSED))
        await atom._read_once()
        after = len(out(ctx, MODULE.EVENT_OPENED)) + len(out(ctx, MODULE.EVENT_CLOSED))
        assert before == after
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_empty_table_is_a_valid_state_not_an_error():
    atom, ctx, tmp, path = await _ready(rows=[])
    try:
        assert out(ctx, MODULE.EVENT_OUT)[-1]["open_count"] == 0
        assert (await atom.health_check()).state.name == "HEALTHY"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_unreadable_bridge_is_degraded_not_fatal():
    atom, ctx, tmp, path = await _ready(db_path="/proc/nowhere/nq.db")
    try:
        atom._db_path = "/proc/nowhere/nq.db"
        atom.read_count = 0
        await atom._read_once()
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_it_reads_only_and_never_writes():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "mode=ro" in src
    for verb in ("INSERT", "UPDATE", "DELETE"):
        assert verb not in src


@pytest.mark.asyncio
async def test_positions_are_grouped_by_symbol():
    atom, ctx, tmp, path = await _ready()
    try:
        assert out(ctx, MODULE.EVENT_OUT)[-1]["by_symbol"] == {"USTEC": 1, "XAUUSD": 1}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, tmp, path = await _ready()
    try:
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh.read_count == atom.read_count
        assert len(fresh._positions) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_start_reads_once_then_schedules_the_loop():
    atom, ctx, tmp, path = await _ready()
    try:
        atom._running = False
        atom._task = None
        await atom.start()
        assert atom._running is True
        assert atom._task is not None
        await atom.stop()
        assert atom._task is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_loop_reads_again_on_its_interval():
    atom, ctx, tmp, path = await _ready(poll_interval_s=0.05)
    try:
        atom._running = False
        atom._task = None
        await atom.start()
        before = atom.read_count
        await asyncio.sleep(0.2)
        assert atom.read_count > before
        await atom.stop()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_is_idempotent():
    atom, ctx, tmp, path = await _ready()
    try:
        await atom.stop()
        await atom.stop()
        await atom.shutdown()
        assert atom._running is False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_nothing_runs_before_initialize_completes():
    atom = MODULE.Atom()
    await atom.start()
    assert atom._running is False


# ── هوية الحساب ─────────────────────────────────────────────────────

def test_the_account_id_is_read_from_the_bridge():
    """الإكسبرت يكتب رقم الحساب مع كل صفّ. وبلا قراءته لا يُعرَف أي
    حساب يملك هذا المركز أو هذه النتيجة — فيُجمَع ما لا يُجمَع."""
    assert "account_id" in MODULE._IDENTITY_FIELDS
