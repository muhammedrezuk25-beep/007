from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

_DB_TIMEOUT_S = 5.0

EVENT_OUT = "platform.positions.state"
EVENT_OPENED = "platform.position.appeared"
EVENT_CLOSED = "platform.position.vanished"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_READ = "BRIDGE_UNREADABLE"
REASON_NO_DATA = "NO_READ_YET"

_COLUMNS = ("ticket", "symbol", "side", "volume", "entry_price",
            "current_price", "stop_loss", "take_profit", "profit",
            "swap", "magic", "opened_at", "updated_at")

_IDENTITY_FIELDS = ("account_id",)



def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            text = str(exc)
            if "locked" not in text and "busy" not in text:
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("locked")


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = ""
        self._poll_interval_s = 0.0
        self._stale_after_s = 0.0
        self._positions: dict[str, dict[str, Any]] = {}
        self._last_read_at: float | None = None
        self._last_error = ""
        self.read_count = 0
        self.appeared_count = 0
        self.vanished_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._stale_after_s = float(cfg["stale_after_s"])
        self._initialized = True
        context.logger.info("609 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        await self._read_once()
        self._task = asyncio.create_task(self._loop())
        self._context.logger.info("609 started")

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        if self._context is not None:
            self._context.logger.info(
                "609 stopped (reads=%d, appeared=%d, vanished=%d)",
                self.read_count, self.appeared_count, self.vanished_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _read_rows(self) -> list[dict[str, Any]]:
        """Positions, with the account they belong to read separately.

        A database written by an older arm has no account_id column, and
        asking for it inside the main select drops every row for one missing
        field. Read on its own it is simply absent, and the rows still
        arrive.
        """
        columns = ", ".join(_COLUMNS)
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(
                "SELECT %s FROM %s" % (columns, self._table))
            rows = [dict(row) for row in cursor.fetchall()]
            for row in rows:
                row.setdefault("account_id", None)
            try:
                ident = connection.execute(
                    "SELECT ticket, account_id FROM %s" % self._table).fetchall()
                by_ticket = {r[0]: r[1] for r in ident}
                for row in rows:
                    row["account_id"] = by_ticket.get(row.get("ticket"))
            except sqlite3.Error:
                pass
            return rows
        finally:
            connection.close()

    async def _read_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._read_rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return

        self._last_error = ""
        self.read_count += 1

        fresh: dict[str, dict[str, Any]] = {}
        newest_stamp: float | None = None
        for row in rows:
            ticket = row.get("ticket")
            if ticket is None:
                continue
            updated = _to_float(row.get("updated_at"))
            if updated is not None:
                if newest_stamp is None or updated > newest_stamp:
                    newest_stamp = updated
            fresh[str(ticket)] = {
                "ticket": ticket,
                "symbol": row.get("symbol"),
                "side": row.get("side"),
                "volume": _to_float(row.get("volume")),
                "entry_price": _to_float(row.get("entry_price")),
                "current_price": _to_float(row.get("current_price")),
                "stop_loss": _to_float(row.get("stop_loss")),
                "take_profit": _to_float(row.get("take_profit")),
                "profit": _to_float(row.get("profit")),
                "swap": _to_float(row.get("swap")),
                "magic": row.get("magic"),
                "opened_at": _to_float(row.get("opened_at")),
                "account_id": row.get("account_id"),
            }

        appeared = [k for k in fresh if k not in self._positions]
        vanished = [k for k in self._positions if k not in fresh]
        previous = dict(self._positions)
        self._positions = fresh
        self._last_read_at = newest_stamp

        stamp: dict[str, Any] = {}
        if newest_stamp is not None:
            stamp["timestamp"] = newest_stamp

        for key in appeared:
            self.appeared_count += 1
            await self._context.publish(EVENT_OPENED, {**fresh[key], **stamp})
        for key in vanished:
            self.vanished_count += 1
            await self._context.publish(EVENT_CLOSED, {**previous[key], **stamp})

        await self._context.publish(EVENT_OUT, {**self.state(), **stamp})

    async def _loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._poll_interval_s)
                if self._running:
                    await self._read_once()
        except asyncio.CancelledError:
            pass

    def state(self) -> dict[str, Any]:
        by_symbol: dict[str, int] = {}
        total_volume = 0.0
        floating = 0.0
        for entry in self._positions.values():
            symbol = str(entry.get("symbol"))
            by_symbol[symbol] = by_symbol.get(symbol, 0) + 1
            if entry.get("volume"):
                total_volume += abs(entry["volume"])
            if entry.get("profit") is not None:
                floating += entry["profit"]
        return {
            "open_count": len(self._positions),
            "tickets": sorted(self._positions),
            "by_symbol": by_symbol,
            "total_volume": round(total_volume, 8),
            "floating_pnl": round(floating, 6),
            "positions": [dict(v) for v in self._positions.values()],
            "read_at": self._last_read_at,
        }

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = self.state()
        details["reads"] = self.read_count
        details["appeared"] = self.appeared_count
        details["vanished"] = self.vanished_count
        details["last_error"] = self._last_error

        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_NO_READ,
                                details=details)
        if self.read_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_DATA, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="open=%d floating=%.2f" % (
                len(self._positions), details["floating_pnl"]),
            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "positions": dict(self._positions),
                "reads": self.read_count, "appeared": self.appeared_count,
                "vanished": self.vanished_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._positions = dict(state.get("positions") or {})
        self.read_count = int(state.get("reads", 0))
        self.appeared_count = int(state.get("appeared", 0))
        self.vanished_count = int(state.get("vanished", 0))
