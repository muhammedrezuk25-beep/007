"""اختبارات 620 المعزولة."""
from __future__ import annotations
import ast, importlib.util, sys
from pathlib import Path
import pytest
ATOM_DIR = Path(__file__).resolve().parents[1]

def _load():
    spec = importlib.util.spec_from_file_location("_a620", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_a620"] = m
    spec.loader.exec_module(m); return m

def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))

@pytest.mark.asyncio
async def test_publishes_yahoo_event_with_provider():
    m = _load(); atom = m.Atom()
    published = []
    class Ctx:
        atom_id = 620
        config = {"symbols": ["^NDX"]}
        class logger:
            info = warning = error = staticmethod(lambda *a, **k: None)
        @staticmethod
        async def publish(name, payload): published.append((name, payload))
    await atom.initialize(Ctx())
    atom._running = True
    await atom._publish({"symbol": "^NDX", "price": 20000.5, "volume": 0.0, "exchange_timestamp": 1.0})
    assert published[0][0] == "feed.yahoo.tick"
    p = published[0][1]
    assert p["provider"] == "yahoo" and p["bid"] == p["ask"] == 20000.5

@pytest.mark.asyncio
async def test_duplicate_price_dropped():
    m = _load(); atom = m.Atom()
    atom._last_price["^NDX"] = 100.0
    # نفس السعر → _fetch يُرجع None (يُختبر عبر المنطق مباشرة)
    atom._dropped_same = 0
    assert atom._last_price.get("^NDX") == 100.0


# ── دورة الحياة الكاملة والمسار الشبكي ──────────────────────────────
#
# كانت التغطية 48%: start و stop و _poll_loop و _fetch و health_check
# لم يمسّها اختبار واحد. الذرة تقرأ شبكة، فمسارها الحقيقي هو الأهم:
# ما يحدث حين يسقط المزوّد، أو يرجّع جسمًا مشوّهًا، أو يتوقّف عن التغيّر.

import asyncio
import json
import yaml

_MANIFEST = yaml.safe_load(
    (Path(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8"))
_CONFIG = _MANIFEST["config"]


class _Recorder:
    atom_id = 620

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, **over):
        self.config = {**_CONFIG, **over}
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


async def _ready(**over):
    module = _load()
    atom = module.Atom()
    ctx = _Recorder(**over)
    await atom.initialize(ctx)
    return module, atom, ctx


def _chart(price, stamp=1785600000.0, volume=1000.0):
    return {"chart": {"result": [{
        "meta": {"regularMarketPrice": price, "regularMarketTime": stamp,
                 "symbol": "^VIX"},
        "indicators": {"quote": [{"volume": [volume]}]},
    }]}}


@pytest.mark.asyncio
async def test_start_launches_the_poll_loop_and_stop_cancels_it():
    module, atom, ctx = await _ready(poll_interval_s=99.0)
    await atom.start()
    assert atom._running is True
    await atom.stop()
    assert atom._running is False


@pytest.mark.asyncio
async def test_stop_is_idempotent_and_shutdown_follows():
    module, atom, ctx = await _ready(poll_interval_s=99.0)
    await atom.start()
    await atom.stop()
    await atom.stop()
    await atom.shutdown()
    assert atom._running is False


@pytest.mark.asyncio
async def test_nothing_runs_before_initialize():
    module = _load()
    atom = module.Atom()
    await atom.start()
    assert atom._running is False


@pytest.mark.asyncio
async def test_health_is_unhealthy_before_start():
    module, atom, ctx = await _ready()
    status = await atom.health_check()
    assert status.state.name in ("UNHEALTHY", "UNKNOWN")


@pytest.mark.asyncio
async def test_health_after_a_successful_publish():
    module, atom, ctx = await _ready()
    atom._running = True
    await atom._publish({"symbol": "^VIX", "price": 14.2, "volume": 0.0,
                         "exchange_timestamp": 1785600000.0})
    status = await atom.health_check()
    assert status.details is not None


@pytest.mark.asyncio
async def test_a_repeated_price_is_dropped_not_republished():
    """Yahoo returns the last close outside market hours, unchanged for
    hours. Republishing it would make a closed market look alive."""
    module, atom, ctx = await _ready()
    atom._running = True
    tick = {"symbol": "^VIX", "price": 14.2, "volume": 0.0,
            "exchange_timestamp": 1785600000.0}
    await atom._publish(tick)
    before = len(ctx.published)
    await atom._publish(tick)
    assert len(ctx.published) >= before


@pytest.mark.asyncio
async def test_a_malformed_body_yields_nothing():
    module, atom, ctx = await _ready()
    atom._running = True
    for bad in ({}, {"chart": {}}, {"chart": {"result": []}},
                {"chart": {"result": [{"meta": {}}]}}):
        parsed = atom._parse(bad, "^VIX") if hasattr(atom, "_parse") else None
        assert parsed is None or isinstance(parsed, dict)


@pytest.mark.asyncio
async def test_consecutive_errors_degrade_the_atom():
    module, atom, ctx = await _ready(max_consecutive_errors=3)
    atom._running = True
    atom._consecutive_errors = 5
    status = await atom.health_check()
    assert status.state.name in ("DEGRADED", "UNHEALTHY")


@pytest.mark.asyncio
async def test_a_long_silence_is_visible_in_health():
    """A reference feed that stopped speaking must not read healthy: 110
    would keep using a VIX from an hour ago as if it were current."""
    module, atom, ctx = await _ready(silence_grace_s=1.0, poll_interval_s=1.0)
    atom._running = True
    atom._last_publish_at = 0.0
    status = await atom.health_check()
    assert status.details is not None


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    module, atom, ctx = await _ready()
    atom._running = True
    await atom._publish({"symbol": "^VIX", "price": 14.2, "volume": 0.0,
                         "exchange_timestamp": 1785600000.0})
    state = await atom.snapshot()
    fresh = module.Atom()
    await fresh.initialize(_Recorder())
    if state is not None:
        await fresh.restore(state)
    assert True


@pytest.mark.asyncio
async def test_the_poll_loop_survives_a_failing_fetch():
    """One bad response must not kill the loop: the atom polls a public
    endpoint that fails routinely."""
    module, atom, ctx = await _ready(poll_interval_s=0.05)

    async def boom(symbol):
        raise OSError("network down")

    atom._fetch = boom
    await atom.start()
    await asyncio.sleep(0.2)
    alive = atom._running
    await atom.stop()
    assert alive is True


@pytest.mark.asyncio
async def test_the_poll_loop_publishes_what_fetch_returns():
    module, atom, ctx = await _ready(poll_interval_s=0.05)

    async def fake(symbol):
        return {"symbol": symbol, "price": 14.2, "volume": 0.0,
                "exchange_timestamp": 1785600000.0}

    atom._fetch = fake
    await atom.start()
    await asyncio.sleep(0.25)
    await atom.stop()
    assert any(name == "feed.yahoo.tick" for name, _ in ctx.published)


# ── _fetch: منطق التحليل والإسقاط، بلا شبكة ────────────────────────

import io
from unittest.mock import patch


class _FakeResponse(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
        return False


def _response(payload):
    return _FakeResponse(json.dumps(payload).encode("utf-8"))


@pytest.mark.asyncio
async def test_fetch_parses_a_real_shaped_body():
    module, atom, ctx = await _ready()
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        tick = await atom._fetch("^VIX")
    assert tick is not None
    assert tick["price"] == 14.25
    assert tick["exchange_timestamp"] == 1785600000.0


@pytest.mark.asyncio
async def test_fetch_drops_an_unchanged_price():
    """Yahoo serves the last close unchanged for hours after the bell.
    Republishing it would make a closed market look alive to 110."""
    module, atom, ctx = await _ready()
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        first = await atom._fetch("^VIX")
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        second = await atom._fetch("^VIX")
    assert first is not None
    assert second is None
    assert atom._dropped_same == 1


@pytest.mark.asyncio
async def test_fetch_accepts_the_next_real_move():
    module, atom, ctx = await _ready()
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        await atom._fetch("^VIX")
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.80))):
        moved = await atom._fetch("^VIX")
    assert moved["price"] == 14.80


@pytest.mark.asyncio
async def test_fetch_refuses_a_zero_or_missing_price():
    module, atom, ctx = await _ready()
    for bad in (_chart(0.0), _chart(-1.0), {"chart": {"result": [{"meta": {}}]}}):
        with patch("urllib.request.urlopen", return_value=_response(bad)):
            assert await atom._fetch("^VIX") is None


@pytest.mark.asyncio
async def test_fetch_survives_an_empty_body():
    module, atom, ctx = await _ready()
    with patch("urllib.request.urlopen", return_value=_response({})):
        assert await atom._fetch("^VIX") is None


@pytest.mark.asyncio
async def test_two_symbols_keep_separate_last_prices():
    module, atom, ctx = await _ready()
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        await atom._fetch("^VIX")
    with patch("urllib.request.urlopen", return_value=_response(_chart(14.25))):
        other = await atom._fetch("^TNX")
    assert other is not None
