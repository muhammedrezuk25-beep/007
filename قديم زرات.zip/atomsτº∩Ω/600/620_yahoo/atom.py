"""
620 — مصدر Yahoo Finance (موصّل)
"""

from __future__ import annotations

import asyncio
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_SILENCE_POLL_FACTOR = 5

EVENT_TICK = "feed.yahoo.tick"
PROVIDER = "yahoo"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_ERRORS = "REPEATED_FAILURE"
REASON_NO_TICK = "NO_TICK_YET"
REASON_SILENT = "FEED_SILENT"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    """موصّل Yahoo Finance متعدد الرموز — يبثّ ما يستقبله فقط.

    **لا يختلق بيانات إطلاقاً**: فشل الشبكة يعني UNHEALTHY وصمتاً تاماً
    على الناقل، لا قيماً بديلة ولا محاكاة ولا آخر سعر معروف.

    مصدر HTTP polling (لا WebSocket عام عند ياهو) — أبطأ من بث بايننس
    لكنه متاح من كل المناطق بلا حجب، ويدعم المؤشرات (^NDX = ناسداك 100).
    Yahoo يعطي سعراً واحداً (regularMarketPrice) لا bid/ask — يُنشر
    bid=ask=السعر، افتراض صريح موثَّق لا اختلاق.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._symbols: list[str] = []
        self._base_url = ""
        self._poll_interval = 0.0
        self._request_timeout = 0.0
        self._publish_timeout = 0.0
        self._max_errors = 0
        self._silence_grace = 0.0
        self._running = False
        self._task: asyncio.Task | None = None
        self._published = 0
        self._dropped_same = 0
        self._consecutive_errors = 0
        self._last_error = ""
        self._last_tick_mono = 0.0
        self._last_price: dict[str, float] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        raw_symbols = cfg.get("symbols", ["^NDX"])
        self._symbols = [str(s) for s in raw_symbols if str(s).strip()]
        self._base_url = str(cfg.get("base_url", "https://query1.finance.yahoo.com/v8/finance/chart/"))
        self._poll_interval = float(cfg.get("poll_interval_s", 2.0))
        self._request_timeout = float(cfg.get("request_timeout_s", 6.0))
        self._publish_timeout = float(cfg.get("publish_timeout_s", 1.5))
        self._max_errors = int(cfg.get("max_consecutive_errors", 5))
        self._silence_grace = float(cfg.get("silence_grace_s", 20.0))
        context.logger.info(
            "تمت تهيئة الذرة %d (%d رمز، سحب كل %.1fs)",
            context.atom_id, len(self._symbols), self._poll_interval,
        )

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._poll_loop())
        self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        self._running = False
        if self._task and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        if self._context is not None:
            self._context.logger.info(
                "أوقفت الذرة %d (نُشر=%d، مكرر=%d)",
                self._context.atom_id, self._published, self._dropped_same,
            )

    async def shutdown(self) -> None:
        await self.stop()
        self._last_price.clear()

    async def _poll_loop(self) -> None:
        while self._running and self._context is not None:
            for symbol in self._symbols:
                if not self._running:
                    break
                try:
                    tick = await self._fetch(symbol)
                    if tick is not None:
                        await self._publish(tick)
                        self._consecutive_errors = 0
                except asyncio.CancelledError:
                    return
                except Exception as exc:  # noqa: BLE001 — شبكة خارجية
                    self._consecutive_errors += 1
                    self._last_error = str(exc)
                    self._context.logger.warning(
                        "فشل جلب %s من ياهو (خطأ متتالٍ %d): %s",
                        symbol, self._consecutive_errors, exc,
                    )
            await asyncio.sleep(self._poll_interval)

    async def _fetch(self, symbol: str) -> dict[str, Any] | None:
        url = self._base_url + urllib.parse.quote(symbol)
        req = urllib.request.Request(url, headers={
            # ياهو يحجب الوكلاء غير المتصفّحية بـ403 أحيانًا — هوية متصفح قياسية
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
            "Accept": "application/json,text/plain,*/*",
        })

        def _do() -> dict:
            with urllib.request.urlopen(req, timeout=self._request_timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))

        data = await asyncio.to_thread(_do)
        result = (data.get("chart", {}).get("result") or [{}])[0]
        meta = result.get("meta", {})
        price = _to_float(meta.get("regularMarketPrice"))
        if price is None or price <= 0.0:
            return None
        # إسقاط التكرار: نفس السعر لنفس الرمز لا يُعاد نشره
        if self._last_price.get(symbol) == price:
            self._dropped_same += 1
            return None
        self._last_price[symbol] = price
        return {
            "symbol": meta.get("symbol", symbol),
            "price": price,
            "volume": _to_float(meta.get("regularMarketVolume")) or 0.0,
            "exchange_timestamp": _to_float(meta.get("regularMarketTime")),
        }

    async def _publish(self, tick: dict[str, Any]) -> None:
        if self._context is None:
            return
        received_at = time.time()
        price = tick["price"]
        payload = {
            "provider": PROVIDER,
            "symbol": tick["symbol"],
            "bid": price,   # ياهو سعر واحد — افتراض صريح موثَّق أعلاه
            "ask": price,
            "price": price,
            "volume": tick["volume"],
            "exchange_timestamp": tick["exchange_timestamp"],
            "received_timestamp": received_at,
        }
        try:
            await asyncio.wait_for(
                self._context.publish(EVENT_TICK, payload),
                timeout=self._publish_timeout,
            )
            self._published += 1
            self._last_tick_mono = time.monotonic()
        except asyncio.TimeoutError:
            self._last_error = "publish timeout"

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._consecutive_errors >= self._max_errors:
            return HealthStatus(
                state=HealthState.UNHEALTHY,
                message=f"{REASON_ERRORS}: {self._last_error}",
            )
        if self._last_tick_mono == 0.0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_TICK)
        age = time.monotonic() - self._last_tick_mono
        if age > max(self._silence_grace, self._poll_interval * _SILENCE_POLL_FACTOR):
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"{REASON_SILENT}: {age:.1f}s",
            )
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"يبثّ {len(self._symbols)} رمز (نُشر={self._published})",
        )

    async def snapshot(self) -> dict[str, Any]:
        return {
            "published": self._published,
            "dropped_same": self._dropped_same,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self._published = int(state.get("published", 0))
        self._dropped_same = int(state.get("dropped_same", 0))
