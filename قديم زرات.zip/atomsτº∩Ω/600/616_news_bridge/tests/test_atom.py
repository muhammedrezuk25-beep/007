from __future__ import annotations

import ast
import asyncio
import importlib.util
import sys
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MOD_NAME = "_atom616"
_spec = importlib.util.spec_from_file_location(_MOD_NAME, ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_spec)
sys.modules[_MOD_NAME] = MODULE
_spec.loader.exec_module(MODULE)

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 616

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config or CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def out(ctx, name):
    return [p for n, p in ctx.published if n == name]


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_atom_file_is_bare_code():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert ast.get_docstring(ast.parse(src)) is None
    assert not [l for l in src.splitlines() if l.strip().startswith("#")]
    assert "print(" not in src
    assert not any("\u0600" <= ch <= "\u06ff" for ch in src)


def test_manifest_has_no_arabic():
    text = (ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8")
    assert not any("\u0600" <= ch <= "\u06ff" for ch in text)


def test_no_clock_reading():
    assert "time.time()" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_id():
    assert MANIFEST["id"] == 616


import shutil
import sqlite3
import tempfile


def _make_db(tmp, news=None, calendar=None):
    path = str(Path(tmp) / "nq_brain.db")
    connection = sqlite3.connect(path)
    connection.execute(
        "CREATE TABLE news (id INTEGER PRIMARY KEY AUTOINCREMENT, headline TEXT,"
        " link TEXT, source TEXT, sentiment_score REAL, impact_level TEXT,"
        " published_at REAL, written_at REAL)")
    connection.execute(
        "CREATE TABLE calendar (id TEXT PRIMARY KEY, title TEXT, country TEXT,"
        " currency TEXT, impact_level TEXT, scheduled_at REAL, actual TEXT,"
        " forecast TEXT, previous TEXT, written_at REAL)")
    for row in (news if news is not None else
                [("Headline one", "http://x/1", "tech", 0.8, "UNKNOWN", TS, TS)]):
        connection.execute(
            "INSERT INTO news (headline, link, source, sentiment_score,"
            " impact_level, published_at, written_at) VALUES (?,?,?,?,?,?,?)", row)
    for row in (calendar if calendar is not None else
                [("cpi-1", "CPI YoY", "US", "USD", "HIGH", TS + 900, None,
                  "3.1%", "3.4%", TS)]):
        connection.execute(
            "INSERT INTO calendar VALUES (?,?,?,?,?,?,?,?,?,?)", row)
    connection.commit()
    connection.close()
    return path


async def _ready(news=None, calendar=None, **over):
    tmp = tempfile.mkdtemp()
    path = _make_db(tmp, news, calendar)
    cfg = {**CONFIG, "db_path": path, "poll_interval_s": 60.0}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    atom._running = True
    await atom._read_once()
    return atom, ctx, tmp, path


@pytest.mark.asyncio
async def test_it_publishes_the_rows_the_bot_wrote():
    atom, ctx, tmp, path = await _ready()
    try:
        news = out(ctx, MODULE.EVENT_NEWS)
        assert len(news) == 1
        assert news[0]["headline"] == "Headline one"
        assert news[0]["sentiment_score"] == 0.8
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_it_publishes_what_108_and_109_subscribe_to():
    """Not through 613: that hub validates provider, symbol, bid and ask
    before forwarding, because it routes price ticks. A headline has none
    of those."""
    assert set(MANIFEST["publishes"]) == {"market.news", "market.calendar"}


@pytest.mark.asyncio
async def test_a_headline_is_never_published_twice():
    atom, ctx, tmp, path = await _ready()
    try:
        await atom._read_once()
        await atom._read_once()
        assert len(out(ctx, MODULE.EVENT_NEWS)) == 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_new_headline_is_picked_up():
    atom, ctx, tmp, path = await _ready()
    try:
        connection = sqlite3.connect(path)
        connection.execute(
            "INSERT INTO news (headline, sentiment_score, impact_level,"
            " published_at, written_at) VALUES (?,?,?,?,?)",
            ("Headline two", -0.5, "HIGH", TS + 60, TS + 60))
        connection.commit()
        connection.close()
        await atom._read_once()
        assert len(out(ctx, MODULE.EVENT_NEWS)) == 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_calendar_event_republishes_only_when_its_value_arrives():
    """The forecast is written once and republished on every read would spam
    109. It matters again when the actual value lands, and written_at moves."""
    atom, ctx, tmp, path = await _ready()
    try:
        await atom._read_once()
        assert len(out(ctx, MODULE.EVENT_CALENDAR)) == 1
        connection = sqlite3.connect(path)
        connection.execute(
            "UPDATE calendar SET actual='3.0%', written_at=? WHERE id='cpi-1'",
            (TS + 900,))
        connection.commit()
        connection.close()
        await atom._read_once()
        events = out(ctx, MODULE.EVENT_CALENDAR)
        assert len(events) == 2
        assert events[-1]["actual"] == "3.0%"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_a_missing_sentiment_survives_as_none():
    atom, ctx, tmp, path = await _ready(
        news=[("No keywords here", "", "market", None, "UNKNOWN", TS, TS)])
    try:
        assert out(ctx, MODULE.EVENT_NEWS)[0]["sentiment_score"] is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_an_unreadable_bridge_is_degraded_not_fatal():
    tmp = tempfile.mkdtemp()
    try:
        atom = MODULE.Atom()
        ctx = Ctx({**CONFIG, "db_path": "/proc/nowhere/nq.db"})
        await atom.initialize(ctx)
        atom._running = True
        await atom._read_once()
        assert (await atom.health_check()).state.name == "DEGRADED"
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_it_reads_only_and_never_writes():
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "mode=ro" in src
    for verb in ("INSERT", "UPDATE", "DELETE"):
        assert verb not in src


@pytest.mark.asyncio
async def test_the_batch_limit_bounds_one_read():
    rows = [(f"Headline {i}", "", "tech", 0.5, "UNKNOWN", TS + i, TS + i)
            for i in range(10)]
    atom, ctx, tmp, path = await _ready(news=rows, batch_limit=3)
    try:
        assert len(out(ctx, MODULE.EVENT_NEWS)) == 3
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom = MODULE.Atom()
    await atom.initialize(Ctx())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_snapshot_keeps_the_read_position():
    atom, ctx, tmp, path = await _ready()
    try:
        state = await atom.snapshot()
        fresh = MODULE.Atom()
        await fresh.restore(state)
        assert fresh._last_news_id == atom._last_news_id
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_start_reads_once_then_schedules_the_loop():
    atom, ctx, tmp, path = await _ready()
    try:
        atom._running = False
        atom._task = None
        await atom.start()
        assert atom._running is True
        assert atom._task is not None
        await atom.stop()
        assert atom._task is None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_the_loop_reads_again_on_its_interval():
    atom, ctx, tmp, path = await _ready(poll_interval_s=0.05)
    try:
        atom._running = False
        atom._task = None
        await atom.start()
        before = atom.read_count
        await asyncio.sleep(0.2)
        assert atom.read_count > before
        await atom.stop()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_stop_is_idempotent():
    atom, ctx, tmp, path = await _ready()
    try:
        await atom.stop()
        await atom.stop()
        await atom.shutdown()
        assert atom._running is False
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


@pytest.mark.asyncio
async def test_nothing_runs_before_initialize_completes():
    atom = MODULE.Atom()
    await atom.start()
    assert atom._running is False
