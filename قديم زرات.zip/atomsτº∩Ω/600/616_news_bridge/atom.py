from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

_DB_TIMEOUT_S = 5.0

EVENT_NEWS = "market.news"
EVENT_CALENDAR = "market.calendar"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_UNREADABLE = "BRIDGE_UNREADABLE"
REASON_NO_DATA = "NO_ROWS_YET"

_NEWS_COLUMNS = ("id", "headline", "link", "source", "sentiment_score",
                 "impact_level", "published_at", "written_at")
_CALENDAR_COLUMNS = ("id", "title", "country", "currency", "impact_level",
                     "scheduled_at", "actual", "forecast", "previous",
                     "written_at")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            text = str(exc)
            if "locked" not in text and "busy" not in text:
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("locked")


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._poll_interval_s = 0.0
        self._batch_limit = 0
        self._last_news_id = 0
        self._seen_events: dict[str, float] = {}
        self._last_error = ""
        self.news_published = 0
        self.calendar_published = 0
        self.read_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._batch_limit = int(cfg["batch_limit"])
        self._initialized = True
        context.logger.info("616 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        await self._read_once()
        self._task = asyncio.create_task(self._loop())
        self._context.logger.info("616 started")

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        if self._context is not None:
            self._context.logger.info(
                "616 stopped (news=%d, calendar=%d)",
                self.news_published, self.calendar_published)

    async def shutdown(self) -> None:
        await self.stop()

    def _query(self, sql: str, params: tuple) -> list[dict[str, Any]]:
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            return [dict(row) for row in connection.execute(sql, params).fetchall()]
        finally:
            connection.close()

    def _read_rows(self) -> tuple[list[dict], list[dict]]:
        news = self._query(
            "SELECT %s FROM news WHERE id > ? ORDER BY id LIMIT ?"
            % ", ".join(_NEWS_COLUMNS), (self._last_news_id, self._batch_limit))
        calendar = self._query(
            "SELECT %s FROM calendar ORDER BY scheduled_at LIMIT ?"
            % ", ".join(_CALENDAR_COLUMNS), (self._batch_limit,))
        return news, calendar

    async def _read_once(self) -> None:
        if self._context is None:
            return
        try:
            news, calendar = await asyncio.to_thread(self._read_rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return

        self._last_error = ""
        self.read_count += 1

        for row in news:
            row_id = row.get("id")
            if isinstance(row_id, int) and row_id > self._last_news_id:
                self._last_news_id = row_id
            body: dict[str, Any] = {
                "headline": row.get("headline"),
                "link": row.get("link"),
                "source": row.get("source"),
                "sentiment_score": _to_float(row.get("sentiment_score")),
                "impact_level": row.get("impact_level") or "UNKNOWN",
                "published_at": _to_float(row.get("published_at")),
            }
            stamp = _to_float(row.get("published_at")) or _to_float(row.get("written_at"))
            if stamp is not None:
                body["timestamp"] = stamp
            self.news_published += 1
            await self._context.publish(EVENT_NEWS, body)

        for row in calendar:
            key = str(row.get("id"))
            written = _to_float(row.get("written_at")) or 0.0
            if self._seen_events.get(key) == written:
                continue
            self._seen_events[key] = written
            body = {
                "id": key,
                "title": row.get("title"),
                "country": row.get("country"),
                "currency": row.get("currency"),
                "impact_level": row.get("impact_level") or "UNKNOWN",
                "scheduled_at": _to_float(row.get("scheduled_at")),
                "actual": row.get("actual"),
                "forecast": row.get("forecast"),
                "previous": row.get("previous"),
            }
            if written:
                body["timestamp"] = written
            self.calendar_published += 1
            await self._context.publish(EVENT_CALENDAR, body)

    async def _loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._poll_interval_s)
                if self._running:
                    await self._read_once()
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"reads": self.read_count, "news": self.news_published,
                   "calendar": self.calendar_published,
                   "last_news_id": self._last_news_id,
                   "tracked_events": len(self._seen_events),
                   "db_path": self._db_path, "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error or REASON_UNREADABLE,
                                details=details)
        if self.news_published == 0 and self.calendar_published == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="news=%d calendar=%d" % (
                                self.news_published, self.calendar_published),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "last_news_id": self._last_news_id,
                "seen_events": dict(self._seen_events),
                "news": self.news_published, "calendar": self.calendar_published}

    async def restore(self, state: dict[str, Any]) -> None:
        self._last_news_id = int(state.get("last_news_id", 0))
        self._seen_events = {str(k): float(v)
                             for k, v in (state.get("seen_events") or {}).items()}
        self.news_published = int(state.get("news", 0))
        self.calendar_published = int(state.get("calendar", 0))
