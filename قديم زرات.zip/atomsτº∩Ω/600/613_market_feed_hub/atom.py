"""
613 — بوابة بيانات السوق (Market Feed Hub)
"""

from __future__ import annotations

import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

# المصادر مباشرة — بلا طبقة توحيد وسيطة. الترجيح هنا يقرأ حقل
# provider من الحمولة، فلا يحتاج توحيد اسم مسبقاً.
FEED_EVENTS = ("feed.binance.tick", "feed.yahoo.tick", "feed.mt5.tick",
               "feed.rithmic.tick")
EVENT_SOURCE_TICK = FEED_EVENTS[0]
EVENT_HEARTBEAT = "kernel.clock.heartbeat"
EVENT_MARKET_TICK = "market.tick"
EVENT_MARKET_VOLUME = "market.volume"
EVENT_PROVIDER_DOWN = "market.feed.provider_down"
EVENT_PROVIDER_RECOVERED = "market.feed.provider_recovered"
EVENT_CAPABILITIES = "market.feed.capabilities"

# القدرات تُستنتج مما يصل فعلاً، لا من جدول مزوّدين مكتوب هنا.
# جدول كهذا يكذب فور تغيّر بثّ المزوّد، ولا أحد ينتبه.
CAPABILITY_FIELDS = {
    "tick":   ("bid", "ask"),
    "volume": ("volume",),
    "depth":  ("bids", "asks"),
    "trades": ("trade_price", "last_trade"),
}

WATCHED_INPUTS = FEED_EVENTS + (EVENT_HEARTBEAT,)
STARVATION_QUORUM = 1
OUTPUTS = (EVENT_MARKET_TICK, EVENT_CAPABILITIES)
LABEL_MINE = "atom.addressed_to_me"
SIDES = 2.0


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    """الواجهة الرسمية الوحيدة لبيانات السوق أمام القسم 101.

    يترجم `feed.*.tick` (من المصادر مباشرة) إلى `market.tick` الذي تنتظره
    102/103/105/116، ويوجّه الحجم إلى حدثه المسمّى الذي ينتظره 104.

    **قاعدة الاختيار معلنة لا مخفية**: عند ورود نفس الرمز من أكثر من
    مزوّد يفوز الأحدث بطابع المنصة، وعند التعادل يفوز الأقل تأخيراً.
    ما دون ذلك يُهمَل كقديم — لا يُدمج ولا يُتوسّط ولا يُخترع.

    كشف سقوط المزوّد يعتمد على نبضة CLOCK لا على حلقة داخلية: الحدث
    الغائب لا يستطيع الإبلاغ عن غيابه بنفسه.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._provider_timeout = 0.0
        self._publish_timeout = 0.0
        self._max_silence = 0.0
        self._voice_repeat = 0.0
        self._started_at = 0.0
        self._starving = False
        self._since = 0.0
        self._voiced_at = 0.0
        self._arrivals: dict[str, int] = {}
        self._seen: dict[str, int] = {}
        self._marks: dict[str, float] = {}
        self._official_time = 0.0
        self._providers: dict[str, dict[str, Any]] = {}
        self._forwarded = 0
        # قدرة صارت True لا تعود False: غياب حقل في تكّة واحدة لا يعني
        # أن المزوّد فقد القدرة — قد تكون تكّة ناقصة عابرة.
        self._capabilities: dict[str, dict[str, bool]] = {}
        self._capabilities_sent: set[str] = set()
        self._stale = 0        # لم يعد يُستعمل — يبقى للتوافق مع لقطة قديمة
        self._symbols: set[str] = set()
        self._dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._provider_timeout = float(cfg["provider_timeout_s"])
        self._publish_timeout = float(cfg["publish_timeout_s"])
        self._max_silence = float(cfg["max_input_silence_seconds"])
        self._voice_repeat = float(cfg["voice_repeat_seconds"])
        # الاشتراك من خريطة التوجيه لا من قائمة ثابتة. مصدرٌ غير مذكور
        # في الخريطة لا يُشترَك فيه أصلًا: بثّه يبقى على الناقل ولا يصل
        # هذه البوابة ولا ما بعدها. هكذا يُعزل مزوّد بسطر إعداد، ويعود
        # بسطر، بلا لمس ذرّته ولا هذه.
        self._routes = dict(cfg["routes"])
        for source_event, destination in self._routes.items():
            context.subscribe(source_event,
                              self._make_router(source_event, str(destination)))
        context.subscribe(EVENT_HEARTBEAT, self._on_heartbeat)
        context.logger.info("تمت تهيئة الذرة %d", context.atom_id)

    async def start(self) -> None:
        self._started_at = time.time()
        if self._context is not None:
            self._context.logger.info("بدأت الذرة %d", self._context.atom_id)

    async def stop(self) -> None:
        if self._context is not None:
            self._context.logger.info("أوقفت الذرة %d (مرّر=%d)",
                                      self._context.atom_id, self._forwarded)

    async def shutdown(self) -> None:
        self._providers.clear()
        if self._context is not None:
            self._context.logger.info("أغلقت الذرة %d نهائياً", self._context.atom_id)

    async def health_check(self) -> HealthStatus:
        if self._context is None:
            return HealthStatus(state=HealthState.UNKNOWN, message="لم تُهيأ بعد")
        voiced = self._declare(time.time())
        if voiced is not None:
            return voiced
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="بوابة السوق تمرّر %d رمز عبر %d مسار" % (
                len(self._symbols), len(self._routes)),
            details={"forwarded": self._forwarded, "dropped": self._dropped,
                     "routes": dict(self._routes), "providers": self._stats()})

    def _stats(self) -> dict[str, Any]:
        return {name: {"ticks": info["ticks"], "latency": info["latency"],
                       "down": info["down"]}
                for name, info in self._providers.items()}

    async def snapshot(self) -> dict[str, Any] | None:
        return {"state": {"capabilities": {k: dict(v) for k, v
                                           in self._capabilities.items()},
                          "capabilities_sent": sorted(self._capabilities_sent),
                          "forwarded": self._forwarded, "stale": self._stale,
                          "dropped": self._dropped, "providers": self._providers},
                "timestamp": time.time()}

    async def restore(self, state: dict[str, Any]) -> None:
        inner = state.get("state", {})
        self._forwarded = inner.get("forwarded", 0)
        # القدرات تُستعاد: خاصية المصدر لا حالة سوق. وإعادة اكتشافها
        # تعني أن المستهلكين يعملون بمقام خاطئ حتى تصل التكّة الأولى.
        for provider, caps in (inner.get("capabilities") or {}).items():
            if isinstance(caps, dict):
                self._capabilities[provider] = {
                    k: bool(v) for k, v in caps.items() if k in CAPABILITY_FIELDS}
        self._capabilities_sent = set(inner.get("capabilities_sent") or [])
        self._stale = inner.get("stale", 0)
        self._dropped = inner.get("dropped", 0)
        self._providers = inner.get("providers", {})

    async def _on_heartbeat(self, payload: dict[str, Any]) -> None:
        """نبضة الساعة هي ما يكشف المزوّد الصامت — لا حلقة داخلية.

        A provider whose first tick has not arrived is not down. last_seen
        starts at zero and official time is a unix number, so the subtraction
        made a freshly registered source look silent for 1785704637 seconds —
        since 1970. The figure was not merely wrong in the log: the alarm
        fired on a source never given a chance, and whoever read it could not
        tell a failed provider from one that had not started.
        """
        self._note(EVENT_HEARTBEAT)
        official = _to_float(payload.get("official_time"))
        if official is None or self._context is None:
            return
        self._official_time = official
        for name, info in self._providers.items():
            if not info["last_seen"]:
                continue
            silent = official - info["last_seen"]
            if not info["down"] and silent > self._provider_timeout:
                info["down"] = True
                self._context.logger.warning(
                    "سقط المزوّد %s — صامت منذ %d ثانية", name, int(silent))
                await self._context.publish(
                    EVENT_PROVIDER_DOWN, self._notice(name, silent, official))
            elif info["down"] and silent <= self._provider_timeout:
                info["down"] = False
                self._context.logger.info("عاد المزوّد %s", name)
                await self._context.publish(
                    EVENT_PROVIDER_RECOVERED, self._notice(name, silent, official))

    def _notice(self, provider: str, silent: float, official: float) -> dict[str, Any]:
        """إشعار حالة مزوّد — حافّي (Edge) لا متكرر، كي لا يُغرق الناقل.
        التكرار مكانه السجل والحالة الصحية، لا الحدث."""
        return {"provider": provider, "silent_seconds": silent,
                "ticks_total": self._providers[provider]["ticks"],
                "timestamp": official}

    async def _observe_capabilities(self, provider: str,
                                    payload: dict[str, Any]) -> None:
        """Capabilities inferred from the fields that actually arrive, one
        set per provider.

        A single shared set made every switch between sources look like a
        fresh discovery: with two feeds alternating, the log filled with two
        messages a second and nothing new was being learned.

        And the mixing was worse than the noise. MT5 may carry depth where
        Binance does not, so one source's capability was announced under the
        other's name.

        Published on the first tick from a provider and on any genuinely new
        discovery for it — never on every tick.
        """
        if not provider:
            return
        caps = self._capabilities.setdefault(
            provider, {name: False for name in CAPABILITY_FIELDS})
        changed = False
        for capability, fields in CAPABILITY_FIELDS.items():
            if caps[capability]:
                continue
            if any(payload.get(f) is not None for f in fields):
                caps[capability] = True
                changed = True

        if changed or provider not in self._capabilities_sent:
            self._capabilities_sent.add(provider)
            if self._context is not None:
                await self._context.publish(EVENT_CAPABILITIES, {
                    "provider": provider,
                    **caps,
                    # هذان لا يصلان عبر التغذية إطلاقاً — مصدرهما موصّل
                    # مستقل، فيُعلَنان False حتى يُبنى.
                    "news": False,
                    "calendar": False,
                })
                self._context.logger.info(
                    "قدرات المصدر %s: %s", provider,
                    {k: v for k, v in caps.items() if v} or "لا شيء",
                )

    def _touch(self, provider: str, latency: float | None) -> dict[str, Any]:
        info = self._providers.setdefault(
            provider, {"ticks": 0, "latency": None, "down": False, "last_seen": 0.0})
        info["ticks"] += 1
        info["last_seen"] = self._official_time
        if latency is not None:
            info["latency"] = latency
        return info

    def _make_router(self, source_event: str, destination: str):
        """يصنع معالجًا يحمل وجهته في إغلاق خاص به.

        دالة واحدة مشتركة تقرأ متغيّر حلقة خارجيًا تجعل كل المصادر تنشر
        إلى وجهة آخر عنصر — عيب الإغلاق المتأخر المعروف في بايثون.
        """
        async def handler(payload: dict[str, Any]) -> None:
            await self._on_source_tick(payload, destination, source_event)
        return handler

    async def _on_source_tick(self, payload: dict[str, Any],
                              destination: str = EVENT_MARKET_TICK,
                              source_event: str = EVENT_SOURCE_TICK) -> None:
        # العلامة على المصدر الذي وصل فعلًا. كانت توضع على FEED_EVENTS[0]
        # دائمًا — أي بايننس — مهما كان المصدر، فيبدو وحده حيًّا ويبدو
        # الباقون جوعى وهم يبثّون. ظهر التناقض حين عملت 618: القدرات
        # تُكشف من MT5 في السطر نفسه الذي يعلن الجوع منه.
        self._note(source_event)
        if self._context is None:
            return
        self._note(LABEL_MINE)
        provider = payload.get("provider")
        symbol = payload.get("symbol")
        bid = _to_float(payload.get("bid"))
        ask = _to_float(payload.get("ask"))
        exchange_ts = _to_float(payload.get("exchange_timestamp"))
        if not provider or not symbol or bid is None or ask is None:
            self._dropped += 1
            self._context.logger.warning("حمولة تغذية ناقصة — أُسقطت")
            return
        received_at = _to_float(payload.get("received_at"))
        latency = (None if exchange_ts is None or received_at is None
                   else received_at - exchange_ts)
        self._touch(provider, latency)
        await self._observe_capabilities(str(provider), payload)
        if exchange_ts is None:
            exchange_ts = _to_float(payload.get("timestamp"))
        if exchange_ts is None:
            self._dropped += 1
            self._context.logger.warning("تيك بلا طابع زمني من %s — أُسقط", provider)
            return
        # لا ترجيح. المزوّدون هنا يبثّون أدوات مختلفة لا الأداة نفسها،
        # فاختيار "الأسرع" كان يرمي تكّة المزوّد الآخر بلا أن يقرأها أحد.
        # والفصل الكامل يأتي من الرمز: 101 و103 و115 تحفظ حالة مستقلة
        # لكل رمز، فمساران يمشيان على القناة نفسها بلا تداخل. وحقل
        # provider يبقى في الحمولة لمن أراد التمييز.
        await self._forward(payload, provider, symbol, bid, ask,
                            exchange_ts, destination)

    async def _forward(self, payload: dict[str, Any], provider: str, symbol: str,
                       bid: float, ask: float, exchange_ts: float,
                       destination: str = EVENT_MARKET_TICK) -> None:
        if self._context is None:
            return
        volume = _to_float(payload.get("volume"))
        # البوابة تُترجم ولا تبتلع: كل حقل يصل من 650 يعبر كما هو.
        # 115 (مراقب الجودة) يبني مفتاح كشف التكرار على
        # exchange_timestamp — إسقاطه كان يجعل المفتاح ثابتاً فتُعدّ
        # التكات المتتالية في سوق هادئ تكراراً زائفاً.
        tick = {
            "symbol": symbol,
            "bid": bid,
            "ask": ask,
            "price": _to_float(payload.get("price")) or (bid + ask) / SIDES,
            "volume": volume,
            "provider": provider,
            "timestamp": exchange_ts,
            "exchange_timestamp": exchange_ts,
            "received_at": _to_float(payload.get("received_at")),
        }
        self._symbols.add(symbol)
        await self._context.publish(destination, tick)
        self._note(EVENT_MARKET_TICK)
        self._forwarded += 1
        if volume is None:
            return
        await self._context.publish(EVENT_MARKET_VOLUME, {
            "symbol": symbol, "volume": volume, "provider": provider,
            "timestamp": exchange_ts})

    def _note(self, label: str) -> None:
        self._arrivals[label] = self._arrivals.get(label, 0) + 1

    def _quiet(self, label: str, now: float) -> bool:
        seen = self._arrivals.get(label, 0)
        if seen != self._seen.get(label, 0):
            self._seen[label] = seen
            self._marks[label] = now
        return now - self._marks.get(label, self._started_at) > self._max_silence

    def _declare(self, now: float) -> HealthStatus | None:
        # تُراقَب المصادر الموجَّهة فقط: مصدر أُزيل من routes لا يُشترَك فيه
        # ولن يصل أبدًا، فإعلان الجوع منه إنذار كاذب دائم.
        watched = tuple(self._routes) + (EVENT_HEARTBEAT,)
        starved = [label for label in watched if self._quiet(label, now)]
        if len(starved) >= STARVATION_QUORUM:
            return self._voice(now, "INPUT_STARVED", "انقطع مدخلي", starved)
        if not self._quiet(LABEL_MINE, now):
            if all(self._quiet(label, now) for label in OUTPUTS):
                return self._voice(now, "OUTPUT_STALLED",
                                   "وصلتني تغذية ولم أُخرج شيئاً", OUTPUTS)
        if self._starving:
            self._starving = False
            self._log("info", "عاد الوضع طبيعياً بعد %d ثانية عطل",
                      int(now - self._since))
        return None

    def _voice(self, now: float, code: str, message: str,
               labels: tuple[str, ...] | list[str]) -> HealthStatus:
        names = ", ".join(labels) or "—"
        if not self._starving:
            self._starving = True
            self._since = now
            self._voiced_at = now
            self._log("warning", "%s — %s", code, names)
        elif now - self._voiced_at >= self._voice_repeat:
            self._voiced_at = now
            self._log("warning", "%s مستمر منذ %d ثانية — %s",
                      code, int(now - self._since), names)
        return HealthStatus(
            state=HealthState.DEGRADED, message=message,
            details={"code": code, "silent": list(labels),
                     "missing_inputs": [l for l in (tuple(self._routes) + (EVENT_HEARTBEAT,))
                                        if l in labels],
                     "down_for_seconds": int(now - self._since),
                     "providers": self._stats()})

    def _log(self, level: str, message: str, *args: Any) -> None:
        if self._context is None:
            return
        if level == "warning":
            self._context.logger.warning(message, *args)
        else:
            self._context.logger.info(message, *args)
