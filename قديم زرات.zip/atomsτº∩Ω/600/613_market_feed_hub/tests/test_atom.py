"""
اختبارات الذرة 613 — بوابة بيانات السوق
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import time
import pytest

from core.contracts.atom import AtomContext, HealthState

import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom613"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
# كان EVENT_MARKET_TICK يُقرأ من الفضاء العام: نجح الاختبار منفردًا
# لأن ذرّة أخرى تركته هناك، وسقط حين تغيّر ترتيب التنفيذ.
EVENT_MARKET_TICK = _mod.EVENT_MARKET_TICK
EVENT_MARKET_VOLUME = _mod.EVENT_MARKET_VOLUME
EVENT_PROVIDER_DOWN = _mod.EVENT_PROVIDER_DOWN
EVENT_PROVIDER_RECOVERED = _mod.EVENT_PROVIDER_RECOVERED
WATCHED_INPUTS = _mod.WATCHED_INPUTS
Atom = _mod.Atom

TS = 1785200000.0


def make_context(provider_timeout=15.0, max_silence=1e12, repeat=0.0,
                 routes=None):
    context = MagicMock(spec=AtomContext)
    context.atom_id = 613
    context.config = {
        "provider_timeout_s": provider_timeout,
        # الاختبارات السلوكية تملك مساراتها؛ الافتراضي يتبع المانيفست
        # مهما ضاق (اليوم: MT5 وحده).
        "routes": routes if routes is not None else _MANIFEST_CONFIG["routes"],
        "publish_timeout_s": 0.5,
        "max_input_silence_seconds": max_silence,
        "voice_repeat_seconds": repeat,
    }
    context.logger = MagicMock()
    context.publish = AsyncMock()
    context.subscribe = MagicMock()
    return context


import yaml as _yaml
from pathlib import Path as _P
_MANIFEST_CONFIG = _yaml.safe_load(
    (_P(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
)["config"]


FULL_ROUTES = {
    "feed.mt5.tick": "market.tick",
    "feed.rithmic.tick": "market.tick",
    "feed.binance.tick": "crypto.tick",
    "feed.yahoo.tick": "market.reference",
}


async def build_atom(**kwargs):
    atom = Atom()
    context = make_context(**kwargs)
    await atom.initialize(context)
    await atom.start()
    return atom, context


def feed(provider="mt5", symbol="US100", ts=TS, bid=15000.0, ask=15010.0,
         volume=2.0, received=None):
    return {"provider": provider, "symbol": symbol, "bid": bid, "ask": ask,
            "price": None, "volume": volume, "exchange_timestamp": ts,
            "received_at": TS + 0.02 if received is None else received}


def beat(official=TS):
    return {"heartbeat": 1, "official_time": official}


def emitted(context, name):
    return [c.args[1] for c in context.publish.await_args_list if c.args[0] == name]


@pytest.mark.asyncio
async def test_subscribes_from_the_route_map_not_a_fixed_list():
    """نقطة الفصل: مصدرٌ غير مذكور في routes لا تشترك فيه البوابة أصلًا،
    فبثّه يبقى على الناقل بلا مستمع. هكذا يُعزل مزوّد بسطر إعداد."""
    atom, context = await build_atom()
    subscribed = {c.args[0] for c in context.subscribe.call_args_list}
    for source in _MANIFEST_CONFIG["routes"]:
        assert source in subscribed
    assert "kernel.clock.heartbeat" in subscribed


@pytest.mark.asyncio
async def test_removing_a_route_removes_the_subscription():
    """إزالة السطر تعزل المزوّد بلا لمس ذرّته ولا هذه."""
    routes = {k: v for k, v in _MANIFEST_CONFIG["routes"].items()
              if k != "feed.binance.tick"}
    atom = Atom()
    context = make_context()
    context.config = {**context.config, "routes": routes}
    await atom.initialize(context)
    subscribed = {c.args[0] for c in context.subscribe.call_args_list}
    assert "feed.binance.tick" not in subscribed



@pytest.mark.asyncio
async def test_health_unknown_before_initialize():
    atom = Atom()
    assert (await atom.health_check()).state == HealthState.UNKNOWN


@pytest.mark.asyncio
async def test_translates_to_market_tick_for_102():
    atom, context = await build_atom()
    await atom._on_source_tick(feed(), "market.tick")
    tick = emitted(context, EVENT_MARKET_TICK)[0]
    assert tick["symbol"] == "US100"
    assert tick["bid"] == 15000.0
    assert tick["ask"] == 15010.0
    assert tick["price"] == 15005.0
    assert tick["timestamp"] == TS          # موروث من المنصة لا ساعة حائط
    assert atom._forwarded == 1


@pytest.mark.asyncio
async def test_routes_volume_to_its_named_event_for_104():
    atom, context = await build_atom()
    await atom._on_source_tick(feed(volume=7.5), "market.tick")
    vol = emitted(context, EVENT_MARKET_VOLUME)[0]
    assert vol["volume"] == 7.5
    assert vol["symbol"] == "US100"
    assert vol["timestamp"] == TS


@pytest.mark.asyncio
async def test_no_volume_event_when_absent():
    atom, context = await build_atom()
    await atom._on_source_tick(feed(volume=None), "market.tick")
    assert emitted(context, EVENT_MARKET_TICK)
    assert emitted(context, EVENT_MARKET_VOLUME) == []





@pytest.mark.asyncio
async def test_two_providers_on_the_same_symbol_both_pass():
    """السبب المباشر لإزالة الترجيح.

    كان المزوّد "الأبطأ" يُرمى ولا يصله أحد، فيستحيل عزل مصدر أو مقارنة
    فيوتشر بـCFD. المزوّدون هنا يبثّون أدواتٍ مختلفة لا الأداة نفسها،
    فالاختيار بينهم كان يُتلف بيانات بلا مقابل.
    """
    atom, context = await build_atom()
    await atom._on_source_tick(feed(provider="rithmic", symbol="SAME", ts=TS), "market.tick")
    await atom._on_source_tick(feed(provider="mt5", symbol="SAME", ts=TS), "market.tick")
    ticks = emitted(context, "market.tick")
    assert len(ticks) == 2
    assert {t["provider"] for t in ticks} == {"rithmic", "mt5"}


@pytest.mark.asyncio
async def test_binance_lands_on_its_own_destination():
    """بايننس يذهب إلى crypto.tick فلا يلوّث الأقسام تحت 1000."""
    atom, context = await build_atom(routes=FULL_ROUTES)
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["feed.binance.tick"](feed(provider="binance", symbol="BTCUSDT"))
    assert len(emitted(context, "crypto.tick")) == 1
    assert emitted(context, "market.tick") == []


@pytest.mark.asyncio
async def test_mt5_and_rithmic_land_on_market_tick():
    atom, context = await build_atom(routes=FULL_ROUTES)
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["feed.mt5.tick"](feed(provider="mt5", symbol="USTEC"))
    await handlers["feed.rithmic.tick"](feed(provider="rithmic", symbol="NQ"))
    assert len(emitted(context, "market.tick")) == 2
    assert emitted(context, "crypto.tick") == []


@pytest.mark.asyncio
async def test_provider_field_survives_for_downstream_separation():
    """الفصل الكامل يأتي من الرمز، والتمييز من حقل provider."""
    atom, context = await build_atom()
    await atom._on_source_tick(feed(provider="rithmic", symbol="NQ"), "market.tick")
    assert emitted(context, "market.tick")[0]["provider"] == "rithmic"


@pytest.mark.asyncio
async def test_incomplete_payload_dropped_not_completed():
    atom, context = await build_atom()
    await atom._on_source_tick({"provider": "mt5", "symbol": "US100", "bid": None}, "market.tick")
    await atom._on_source_tick(feed(ts=None) | {"timestamp": None}, "market.tick")
    assert emitted(context, EVENT_MARKET_TICK) == []
    assert atom._dropped == 2
    context.logger.warning.assert_called()


@pytest.mark.asyncio
async def test_provider_down_and_recovered_are_edge_triggered():
    atom, context = await build_atom(provider_timeout=10.0)
    await atom._on_heartbeat(beat(TS))
    await atom._on_source_tick(feed("mt5"), "market.tick")

    await atom._on_heartbeat(beat(TS + 100.0))
    downs = emitted(context, EVENT_PROVIDER_DOWN)
    assert len(downs) == 1
    assert downs[0]["provider"] == "mt5"

    await atom._on_heartbeat(beat(TS + 101.0))
    assert len(emitted(context, EVENT_PROVIDER_DOWN)) == 1   # لا تكرار على الناقل

    await atom._on_source_tick(feed("mt5", ts=TS + 200.0), "market.tick")
    await atom._on_heartbeat(beat(TS + 101.0))
    assert len(emitted(context, EVENT_PROVIDER_RECOVERED)) == 1


@pytest.mark.asyncio
async def test_heartbeat_without_official_time_is_ignored():
    atom, _ = await build_atom()
    await atom._on_heartbeat({"heartbeat": 1})
    assert atom._official_time == 0.0


@pytest.mark.asyncio
async def test_starvation_is_declared_and_repeated():
    atom, context = await build_atom(max_silence=0.0)
    first = await atom.health_check()
    assert first.state == HealthState.DEGRADED
    assert first.details["code"] == "INPUT_STARVED"
    await atom.health_check()
    assert context.logger.warning.call_count >= 2


@pytest.mark.asyncio
async def test_recovers_to_silence():
    atom, context = await build_atom(max_silence=0.0)
    await atom.health_check()
    atom._max_silence = 1e12
    await atom._on_source_tick(feed(), "market.tick")
    await atom._on_heartbeat(beat())
    assert (await atom.health_check()).state == HealthState.HEALTHY
    assert atom._starving is False


@pytest.mark.asyncio
async def test_handler_ignored_without_context():
    atom = Atom()
    await atom._on_source_tick(feed(), "market.tick")
    await atom._on_heartbeat(beat())
    assert atom._forwarded == 0


@pytest.mark.asyncio
async def test_snapshot_restore():
    atom, _ = await build_atom()
    await atom._on_source_tick(feed(), "market.tick")
    snap = await atom.snapshot()
    revived = Atom()
    await revived.restore(snap)
    assert revived._forwarded == 1
    assert "mt5" in revived._providers


@pytest.mark.asyncio
async def test_a_live_source_is_not_declared_starved():
    """العطل الذي ظهر حين عملت 618: العلامة كانت توضع على FEED_EVENTS[0]
    — بايننس — مهما كان المصدر الواصل. فيبدو وحده حيًّا، ويُعلن الجوع من
    مصدر يبثّ في السطر نفسه الذي تُكشف فيه قدراته.
    """
    atom, context = await build_atom(max_silence=1.0)
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    await handlers["feed.mt5.tick"](feed(provider="mt5", symbol="USTEC"))
    assert not atom._quiet("feed.mt5.tick", time.time())


@pytest.mark.asyncio
async def test_an_unrouted_source_is_never_watched():
    """مصدر أُزيل من routes لا يُشترَك فيه ولن يصل، فمراقبته إنذار كاذب دائم."""
    routes = {k: v for k, v in _MANIFEST_CONFIG["routes"].items()
              if k != "feed.rithmic.tick"}
    atom = Atom()
    context = make_context(max_silence=1.0)
    context.config = {**context.config, "routes": routes}
    await atom.initialize(context)
    await atom.start()
    status = atom._declare(time.time() + 5.0)
    missing = (status.details or {}).get("missing_inputs", []) if status else []
    assert "feed.rithmic.tick" not in missing


# ── قدرات المصدر: لكل مزوّد قدراته ──────────────────────────────────

@pytest.mark.asyncio
async def test_capabilities_are_kept_per_provider():
    """قاموس قدرات واحد لكل المصادر جعل التبديل بينها يبدو اكتشافًا
    جديدًا في كل مرّة: مصدران متناوبان يملآن السجلّ رسالتين كل ثانية.

    والخلط أخطر من الضجيج: MT5 قد يعطي عمقًا وبايننس لا، فيُعلَن عمق
    أحدهما باسم الآخر."""
    atom, context = await build_atom(routes=FULL_ROUTES)
    handlers = {c.args[0]: c.args[1] for c in context.subscribe.call_args_list}
    for source, provider in (("feed.mt5.tick", "mt5"),
                             ("feed.binance.tick", "binance"),
                             ("feed.mt5.tick", "mt5"),
                             ("feed.binance.tick", "binance"),
                             ("feed.mt5.tick", "mt5")):
        await handlers[source](feed(provider=provider))
    published = emitted(context, "market.feed.capabilities")
    assert len(published) == 2
    assert {p["provider"] for p in published} == {"mt5", "binance"}
