"""اختبارات المرحلة 2 — إعلان قدرات المصدر من 613."""
from __future__ import annotations
import importlib.util, sys
from pathlib import Path
import pytest

ATOM_DIR = Path(__file__).resolve().parents[1]


def _load():
    spec = importlib.util.spec_from_file_location("_atom613", ATOM_DIR / "atom.py")
    m = importlib.util.module_from_spec(spec); sys.modules["_atom613"] = m
    spec.loader.exec_module(m); return m


class Ctx:
    atom_id = 613
    # الإعداد من المانيفست لا مكتوبًا هنا: أي مفتاح جديد في العقد
    # كان يُسقط الاختبارات بـKeyError بدل أن يُلتقط تلقائيًا.
    import yaml as _yaml
    from pathlib import Path as _P
    _cfg = _yaml.safe_load(
        (_P(__file__).resolve().parents[1] / "manifest.yaml").read_text(encoding="utf-8")
    )["config"]
    config = {**_cfg, "provider_timeout_s": 15.0, "publish_timeout_s": 0.5,
              "max_input_silence_seconds": 30.0, "voice_repeat_seconds": 0.0}
    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)
    def __init__(self):
        self.published = []; self.handlers = {}
    async def publish(self, n, p): self.published.append((n, p))
    def subscribe(self, n, h): self.handlers[n] = h


async def _ready():
    m = _load(); a = m.Atom(); c = Ctx()
    await a.initialize(c)
    await a.start()
    return m, a, c


def _caps(c):
    return [p for n, p in c.published if n == "market.feed.capabilities"]


def _tick(**extra):
    return {"provider": "binance", "symbol": "BTCUSDT",
            "bid": 100.0, "ask": 100.1, "exchange_timestamp": 1785000000.0,
            "received_at": 1785000000.05, **extra}


@pytest.mark.asyncio
async def test_capabilities_published_on_first_tick():
    m, a, c = await _ready()
    await a._on_source_tick(_tick())
    caps = _caps(c)
    assert len(caps) == 1
    assert caps[0]["provider"] == "binance"
    assert caps[0]["tick"] is True


@pytest.mark.asyncio
async def test_bookticker_declares_no_depth_no_volume():
    """bookTicker يعطي bid/ask فقط — القدرات تعكس ذلك بصدق."""
    m, a, c = await _ready()
    await a._on_source_tick(_tick())
    p = _caps(c)[0]
    assert p["tick"] is True
    assert p["volume"] is False
    assert p["depth"] is False
    assert p["trades"] is False


@pytest.mark.asyncio
async def test_volume_discovered_and_republished():
    """اكتشاف قدرة جديدة يُعيد النشر — مرة واحدة."""
    m, a, c = await _ready()
    await a._on_source_tick(_tick())
    await a._on_source_tick(_tick(volume=12.5))
    caps = _caps(c)
    assert len(caps) == 2
    assert caps[-1]["volume"] is True


@pytest.mark.asyncio
async def test_not_republished_when_nothing_new():
    """لا نشر مع كل تكّة — إغراق الناقل بلا فائدة."""
    m, a, c = await _ready()
    for _ in range(20):
        await a._on_source_tick(_tick())
    assert len(_caps(c)) == 1


@pytest.mark.asyncio
async def test_capability_never_flips_back_to_false():
    """تكّة ناقصة عابرة لا تعني فقدان القدرة."""
    m, a, c = await _ready()
    await a._on_source_tick(_tick(volume=5.0))
    await a._on_source_tick(_tick())              # بلا حجم
    assert _caps(c)[-1]["volume"] is True


@pytest.mark.asyncio
async def test_depth_detected_from_book_fields():
    m, a, c = await _ready()
    await a._on_source_tick(_tick(bids=[[99.0, 1.0]], asks=[[101.0, 1.0]]))
    assert _caps(c)[-1]["depth"] is True


@pytest.mark.asyncio
async def test_news_and_calendar_always_false():
    """مصدرهما موصّل مستقل لا التغذية."""
    m, a, c = await _ready()
    await a._on_source_tick(_tick())
    p = _caps(c)[0]
    assert p["news"] is False and p["calendar"] is False


@pytest.mark.asyncio
async def test_provider_change_republishes():
    m, a, c = await _ready()
    await a._on_source_tick(_tick())
    await a._on_source_tick(_tick(provider="yahoo"))
    assert _caps(c)[-1]["provider"] == "yahoo"


@pytest.mark.asyncio
async def test_capabilities_survive_restart():
    """إعادة الاكتشاف تعني مقاماً خاطئاً حتى أول تكّة."""
    m, a, c = await _ready()
    await a._on_source_tick(_tick(volume=3.0))
    snap = await a.snapshot()

    fresh = m.Atom(); fc = Ctx()
    await fresh.initialize(fc); await fresh.restore(snap)
    # القدرات لكل مزوّد: مصدران متناوبان كانا يُبطلان اكتشاف بعضهما.
    assert fresh._capabilities["binance"]["volume"] is True
    assert "binance" in fresh._capabilities_sent


@pytest.mark.asyncio
async def test_malformed_payload_publishes_nothing():
    m, a, c = await _ready()
    await a._on_source_tick({"provider": "binance"})
    assert _caps(c) == []


# ── مزوّد لم تصل تكّته بعد ليس ساقطًا ────────────────────────────────

@pytest.mark.asyncio
async def test_a_provider_that_never_ticked_is_not_declared_down():
    """last_seen يبدأ صفرًا، والزمن الرسمي رقم يونكس — فمزوّد سُجِّل ولم
    تصل تكّته بعد يبدو صامتًا منذ 1785704637 ثانية، أي منذ 1970.

    والرقم في السجلّ ليس تشويهًا فقط: الإنذار يُطلَق على مزوّد لم يُعطَ
    فرصة، ومن يقرأه لا يميّز الساقط من الذي لم يبدأ."""
    m, a, c = await _ready()
    a._providers["yahoo"] = {"ticks": 0, "latency": None,
                             "down": False, "last_seen": 0.0}
    await a._on_heartbeat({"official_time": 1785704637.0})
    downs = [p for n, p in c.published if n == "market.feed.provider_down"]
    assert not downs


@pytest.mark.asyncio
async def test_a_provider_that_ticked_then_fell_silent_is_declared_down():
    m, a, c = await _ready()
    a._providers["yahoo"] = {"ticks": 5, "latency": 0.1,
                             "down": False, "last_seen": 1785704000.0}
    await a._on_heartbeat({"official_time": 1785704637.0})
    downs = [p for n, p in c.published if n == "market.feed.provider_down"]
    assert downs
    assert downs[-1]["silent_seconds"] == 637.0
