from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "platform.trade_event"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_READ = "BRIDGE_UNREADABLE"
REASON_NO_DATA = "NO_READ_YET"

_COLUMNS = ("id", "event_type", "ticket", "symbol", "side", "volume",
            "entry_price", "exit_price", "open_time", "close_time", "reason")

# هوية الحساب: تُقرأ عمودًا مستقلًّا لأن قاعدة كتبها إكسبرت أقدم لا
# تحمله، وقراءتها ضمن مجموعة تُسقط الموجود بسبب المفقود.
_IDENTITY_FIELDS = ("account_id",)



_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            text = str(exc)
            if "locked" not in text and "busy" not in text:
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("locked")


class Atom(AtomBase):
    """Reads the arm's trade_events and publishes each row as it stands.

    The bridge database belongs to section 600. Every other table already had
    a reader here — positions, account, ticks, news — and this one did not,
    so 563 opened the file from section 550 to fill the gap. That put a path
    into a file an execution atom does not own, and bound the outcome of a
    trade to MT5: a Binance account records its results somewhere else
    entirely, and 563 would never see them.

    Nothing is interpreted here. The row travels as written, and 563 turns
    it into the events the platform speaks — one translator whatever the
    venue, so a second venue is one more reader beside this atom rather than
    a change to the translator.
    """

    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._table = ""
        self._poll_interval_s = 0.0
        self._batch_limit = 0
        self._last_id = 0
        self._task: asyncio.Task | None = None
        self._last_error = ""
        self.read_count = 0
        self.published_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._batch_limit = int(cfg["batch_limit"])
        self._initialized = True
        context.logger.info("611 initialised on %s", self._table)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        self._context.logger.info("611 started")

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        if self._context is not None:
            self._context.logger.info("611 stopped (published=%d)",
                                      self.published_count)

    async def shutdown(self) -> None:
        await self.stop()

    def _fetch(self) -> list[dict[str, Any]]:
        columns = ", ".join(_COLUMNS)
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(
                "SELECT %s FROM %s WHERE id > ? ORDER BY id LIMIT ?"
                % (columns, self._table),
                (self._last_id, self._batch_limit))
            rows = [dict(row) for row in cursor.fetchall()]
            for row in rows:
                row.setdefault("account_id", None)
            try:
                ident = connection.execute(
                    "SELECT id, account_id FROM %s WHERE id > ? ORDER BY id"
                    " LIMIT ?" % self._table,
                    (self._last_id, self._batch_limit)).fetchall()
                by_id = {r[0]: r[1] for r in ident}
                for row in rows:
                    row["account_id"] = by_id.get(row.get("id"))
            except sqlite3.Error:
                pass
            return rows
        finally:
            connection.close()

    async def _drain_once(self) -> None:
        """Reads new rows and publishes them.

        Rows are taken by ascending id and the highest seen is remembered, so
        a row is never read twice and never skipped — the arm appends and
        this atom never deletes. Deleting would be the arm's decision, not
        this one's, and a lost outcome cannot be recovered.
        """
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._fetch)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.warning("611 read failed: %s", exc)
            return
        self._last_error = ""
        if not rows:
            return
        self.read_count += len(rows)
        for row in rows:
            row_id = row.get("id")
            if isinstance(row_id, int) and row_id > self._last_id:
                self._last_id = row_id
            body = {key: row.get(key) for key in _COLUMNS if key != "id"}
            body["account_id"] = row.get("account_id")
            body["source_row_id"] = row_id
            stamp = _to_float(row.get("close_time")) or _to_float(row.get("open_time"))
            if stamp is not None:
                body["timestamp"] = stamp
            self.published_count += 1
            await self._context.publish(EVENT_OUT, body)

    async def _loop(self) -> None:
        try:
            while self._running:
                await self._drain_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            return

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {"read": self.read_count, "published": self.published_count,
                   "failures": self.failure_count, "last_id": self._last_id}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_READ, details=details)
        if self.read_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="published=%d" % self.published_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {"version": ATOM_VERSION, "last_id": self._last_id,
                "read": self.read_count, "published": self.published_count,
                "failures": self.failure_count}

    async def restore(self, state: dict[str, Any]) -> None:
        self._last_id = int(state.get("last_id", 0))
        self.read_count = int(state.get("read", 0))
        self.published_count = int(state.get("published", 0))
        self.failure_count = int(state.get("failures", 0))


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None
