"""اختبارات الذرّة 611 — قارئ أحداث الصفقات من الجسر"""

from __future__ import annotations

import ast
import importlib.util
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_SPEC = importlib.util.spec_from_file_location("_atom611", ATOM_DIR / "atom.py")
MODULE = importlib.util.module_from_spec(_SPEC)
sys.modules["_atom611"] = MODULE
sys.path.insert(0, str(ATOM_DIR))
try:
    _SPEC.loader.exec_module(MODULE)
finally:
    sys.path.remove(str(ATOM_DIR))

MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]
TS = 1785600000.0


class Ctx:
    atom_id = 611

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _make_db(rows=None):
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute(
        "CREATE TABLE trade_events (id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " event_type TEXT, ticket INTEGER, symbol TEXT, side TEXT, volume REAL,"
        " entry_price REAL, exit_price REAL, open_time REAL, close_time REAL,"
        " reason TEXT)")
    if rows is None:
        rows = [("OPENED", 1, "USTEC", "BUY", 0.5, 28400.0, None, TS, None, ""),
                ("CLOSED", 1, "USTEC", "BUY", 0.5, 28400.0, 28450.0, TS, TS + 60, "TP")]
    for r in rows:
        conn.execute("INSERT INTO trade_events (event_type,ticket,symbol,side,volume,"
                     "entry_price,exit_price,open_time,close_time,reason)"
                     " VALUES (?,?,?,?,?,?,?,?,?,?)", r)
    conn.commit(); conn.close()
    return path


async def _ready(db_path=None, **over):
    cfg = {**CONFIG, "db_path": db_path or _make_db()}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    atom._running = True
    return atom, ctx


def out(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


# ── البنية ──────────────────────────────────────────────────────────

def test_manifest_matches_code():
    assert MANIFEST["id"] == 611
    assert MANIFEST["publishes"] == [MODULE.EVENT_OUT]
    assert MANIFEST["subscribes"] == []


def test_it_reads_only_and_never_writes():
    """الإكسبرت يكتب النتائج، وحذفها قراره لا قرار هذا القسم: نتيجة
    ضائعة لا تُسترجَع."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "mode=ro" in src
    for verb in ("INSERT", "UPDATE", "DELETE", "DROP"):
        assert verb not in src


def test_no_clock_reading():
    """3 و806 و608 يملكون الساعة. والطابع مورَّث من الصفّ."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    published = src[src.index("async def _drain_once"):src.index("async def _loop")]
    assert "time.time()" not in published


def test_it_interprets_nothing():
    """الترجمة شغل 563: OPENED إلى trade.opened وهكذا. وتكرارها هنا
    يعطي جوابين لسؤال واحد."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    for word in ("trade.opened", "trade.closed", "trade.rejected"):
        assert word not in src


# ── السلوك ──────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_rows_are_published_as_they_stand():
    atom, ctx = await _ready()
    await atom._drain_once()
    rows = out(ctx)
    assert len(rows) == 2
    assert rows[0]["event_type"] == "OPENED"
    assert rows[1]["event_type"] == "CLOSED"
    assert rows[1]["exit_price"] == 28450.0


@pytest.mark.asyncio
async def test_a_row_is_never_read_twice():
    """الصفوف تُؤخذ بترتيب المعرّف ويُحفَظ الأعلى: لا تكرار ولا تخطٍّ."""
    atom, ctx = await _ready()
    await atom._drain_once()
    first = len(out(ctx))
    await atom._drain_once()
    assert len(out(ctx)) == first


@pytest.mark.asyncio
async def test_a_new_row_is_picked_up():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    before = len(out(ctx))
    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO trade_events (event_type,ticket,symbol,side,volume,"
                 "entry_price,exit_price,open_time,close_time,reason)"
                 " VALUES ('REJECTED',2,'EURUSD','SELL',0.1,NULL,NULL,?,NULL,'NO_MONEY')",
                 (TS + 120,))
    conn.commit(); conn.close()
    await atom._drain_once()
    assert len(out(ctx)) == before + 1
    assert out(ctx)[-1]["reason"] == "NO_MONEY"


@pytest.mark.asyncio
async def test_the_stamp_is_inherited_from_the_row():
    atom, ctx = await _ready()
    await atom._drain_once()
    assert out(ctx)[0]["timestamp"] == TS
    assert out(ctx)[1]["timestamp"] == TS + 60


@pytest.mark.asyncio
async def test_a_missing_table_degrades_without_stopping():
    """قاعدة كتبها إكسبرت أقدم لا تحمل الجدول. ومدخل جائع ليس عطلًا في
    هذه الذرّة."""
    path = tempfile.mktemp(suffix=".db")
    sqlite3.connect(path).close()
    atom, ctx = await _ready(path)
    await atom._drain_once()
    assert atom.failure_count == 1
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_the_position_survives_a_restart():
    """بلا حفظ الموضع تُعاد كل النتائج عند كل إقلاع، فتُحسب الصفقة
    مرّتين."""
    atom, ctx = await _ready()
    await atom._drain_once()
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.initialize(Ctx({**CONFIG, "db_path": "x"}))
    await fresh.restore(state)
    assert fresh._last_id == atom._last_id


@pytest.mark.asyncio
async def test_the_batch_limit_is_honoured():
    rows = [("OPENED", i, "USTEC", "BUY", 0.1, 28400.0, None, TS, None, "")
            for i in range(1, 8)]
    atom, ctx = await _ready(_make_db(rows), batch_limit=3)
    await atom._drain_once()
    assert len(out(ctx)) == 3


@pytest.mark.asyncio
async def test_the_lifecycle_is_clean():
    atom, ctx = await _ready()
    await atom.start()
    await atom.stop()
    assert atom._task is None
    await atom.shutdown()


# ── هوية الحساب ─────────────────────────────────────────────────────

def test_the_account_id_is_read_from_the_bridge():
    """الإكسبرت يكتب رقم الحساب مع كل صفّ. وبلا قراءته لا يُعرَف أي
    حساب يملك هذا المركز أو هذه النتيجة — فيُجمَع ما لا يُجمَع."""
    assert "account_id" in MODULE._IDENTITY_FIELDS
