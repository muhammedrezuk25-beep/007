"""Tests for atom 608 - Time Sync."""

from __future__ import annotations

import ast
import asyncio
import importlib.util
import struct
import sys
import time
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]

# Unique module name. Loading every atom under the shared name "atom" makes the
# second atom in a process import the first one's cached module, so its tests
# silently exercise the wrong code.
_MODULE_NAME = "_atom608"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
CONFIG = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))["config"]


class Ctx:
    atom_id = 608

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config=None):
        self.config = dict(config if config is not None else CONFIG)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _ntp_reply(server_unix_time: float) -> bytes:
    """Build a minimal well-formed NTP reply carrying the given time."""
    ntp_seconds = int(server_unix_time + MODULE._NTP_EPOCH_OFFSET)
    fraction = int((server_unix_time % 1) * 2**32)
    return b"\0" * 40 + struct.pack("!II", ntp_seconds, fraction)


async def _ready(config=None, reply_offset=0.0, fail=False):
    """An atom already initialised, with the socket layer replaced."""
    atom = MODULE.Atom()
    ctx = Ctx(config)
    await atom.initialize(ctx)

    def fake_query(host):
        if fail:
            raise OSError("unreachable")
        return reply_offset, 0.01

    atom._query = fake_query
    return atom, ctx


# ---------------------------------------------------------------- structure


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    manifest = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
    assert manifest["id"] == 608
    assert set(manifest["publishes"]) == {MODULE.EVENT_SYNCED, MODULE.EVENT_DRIFT}
    assert manifest["subscribes"] == []
    # 806 and 3 are the only tick sources. A tick here would be a third clock.
    assert not any("tick" in name for name in manifest["publishes"])


def test_not_critical():
    manifest = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
    assert manifest["critical"] is False


# ---------------------------------------------------------------- behaviour


@pytest.mark.asyncio
async def test_successful_sync_publishes_synced():
    atom, ctx = await _ready(reply_offset=0.01)
    await atom._sync_once()
    events = [p for n, p in ctx.published if n == MODULE.EVENT_SYNCED]
    assert len(events) == 1
    assert events[0]["offset_s"] == 0.01
    assert events[0]["server"] == CONFIG["reference_servers"][0]
    assert events[0]["sync_count"] == 1


@pytest.mark.asyncio
async def test_small_offset_raises_no_drift():
    atom, ctx = await _ready(reply_offset=0.01)   # far below drift_alert_s
    await atom._sync_once()
    assert not [p for n, p in ctx.published if n == MODULE.EVENT_DRIFT]


@pytest.mark.asyncio
async def test_large_offset_raises_drift():
    atom, ctx = await _ready(reply_offset=2.5)    # far above drift_alert_s
    await atom._sync_once()
    drifts = [p for n, p in ctx.published if n == MODULE.EVENT_DRIFT]
    assert len(drifts) == 1
    assert drifts[0]["threshold_s"] == CONFIG["drift_alert_s"]
    assert drifts[0]["previous_offset_s"] is None    # first measurement


@pytest.mark.asyncio
async def test_negative_drift_also_fires():
    """Drift is a distance, so a clock running ahead must alert too."""
    atom, ctx = await _ready(reply_offset=-2.5)
    await atom._sync_once()
    assert [p for n, p in ctx.published if n == MODULE.EVENT_DRIFT]


@pytest.mark.asyncio
async def test_publishes_no_self_stamped_timestamp():
    """Guards a settled decision: the atom never stamps its own events.

    core.event_bus fills `timestamp` via setdefault, so every event in the
    platform is stamped exactly once. `measured_at` is measurement data, not
    the event's time.
    """
    atom, ctx = await _ready(reply_offset=2.5)
    await atom._sync_once()
    for _name, payload in ctx.published:
        assert "timestamp" not in payload
        assert "measured_at" in payload


@pytest.mark.asyncio
async def test_unreachable_reference_publishes_nothing_and_does_not_raise():
    atom, ctx = await _ready(fail=True)
    assert await atom._sync_once() is False
    assert ctx.published == []
    assert atom.failure_count == 1


@pytest.mark.asyncio
async def test_falls_through_to_next_server():
    atom, ctx = await _ready()
    attempted = []

    def flaky(host):
        attempted.append(host)
        if len(attempted) == 1:
            raise OSError("first one is down")
        return 0.02, 0.01

    atom._query = flaky
    assert await atom._sync_once() is True
    assert attempted == CONFIG["reference_servers"][:2]
    assert [p for n, p in ctx.published if n == MODULE.EVENT_SYNCED][0]["server"] == attempted[1]


# ---------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom, _ = await _ready()
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_unreachable_reference_is_degraded_not_unhealthy():
    """Settled decision: starvation of an external input is DEGRADED.

    The atom is not broken because the network is down, and restarting it does
    not bring the reference back. UNHEALTHY here would burn the restart budget
    and eventually pull a working atom.
    """
    atom, _ = await _ready(fail=True)
    atom._running = True
    await atom._sync_once()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_health_healthy_after_sync():
    atom, _ = await _ready(reply_offset=0.01)
    atom._running = True
    await atom._sync_once()
    assert (await atom.health_check()).state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_stale_sync_is_degraded():
    atom, _ = await _ready(reply_offset=0.01)
    atom._running = True
    await atom._sync_once()
    atom._last_sync_at = time.time() - (CONFIG["stale_after_s"] + 1)
    assert (await atom.health_check()).state.name == "DEGRADED"


# ---------------------------------------------------------------- lifecycle


@pytest.mark.asyncio
async def test_stop_then_start_leaves_a_startable_atom():
    """Restart is stop() then start(). A counter left dirty in stop() makes
    health_check fail the moment the atom comes back."""
    atom, _ = await _ready(fail=True)
    await atom.start()
    await asyncio.sleep(0)
    await atom.stop()
    assert atom.failure_count == 0
    assert atom._task is None
    await atom.start()
    assert atom._running is True
    await atom.stop()


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, _ = await _ready(reply_offset=2.5)
    await atom._sync_once()
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert fresh.sync_count == atom.sync_count
    assert fresh.drift_count == atom.drift_count
    assert fresh._last_offset_s == atom._last_offset_s


@pytest.mark.asyncio
async def test_malformed_reply_does_not_kill_the_atom():
    atom, ctx = await _ready()

    def short_reply(host):
        raise ValueError("NTP reply shorter than expected")

    atom._query = short_reply
    assert await atom._sync_once() is False
    assert ctx.published == []


def test_ntp_arithmetic_against_a_synthetic_reply():
    """The wire parsing itself, with no socket involved."""
    atom = MODULE.Atom()
    atom._query_timeout_s = 1.0
    now = time.time()
    payload = _ntp_reply(now + 3.0)
    seconds, fraction = struct.unpack("!II", payload[40:48])
    decoded = seconds + fraction / 2**32 - MODULE._NTP_EPOCH_OFFSET
    assert abs(decoded - (now + 3.0)) < 0.001
