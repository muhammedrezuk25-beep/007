# ATOM_SPEC - 608 Time Sync

## 1. Identity

| | |
|---|---|
| id | **608** (fixed for life) |
| folder | `atoms/600/608_time_sync` (free - the core identifies by id only) |
| version | 1.0.0 |
| critical | **false** - see decision 5.3 |
| startup_mode | auto |
| entrypoint | `atom:Atom` |

## 2. Single responsibility

Measure the offset between the machine clock and an external time reference,
and publish the measurement.

**Not its job:** ticking, correcting any timestamp, deciding what the platform
does about the drift, or serving time to anyone on request.

## 3. Why it exists

Every timestamp in the platform ultimately rests on the machine clock, including
the one `core.event_bus` injects and the one 806 puts in `official_time`. That
clock has ~15.6ms resolution on Windows and drifts by seconds between OS
synchronisations.

Nothing measured that drift, so nothing could see it. A recorded incident lost
**58% of the feed** because events sharing a coarse timestamp were rejected as
stale. Timestamp inheritance fixed the *consistency* half of that problem: a
whole chain now shares one reading. This atom addresses the other half - whether
that shared reading is anywhere near real time.

## 4. Mechanism

1. `start()` launches one background loop.
2. Each cycle, references are tried **in order** until one answers.
3. For a reference: note local clock, send a 48-byte NTP request to UDP 123,
   receive the reply, note local clock again.
4. `offset = server_time - (received_at - round_trip / 2)` - the round trip is
   halved because roughly that much of it was the reply coming back.
5. Publish `time.utc.synced`. If `abs(offset) >= drift_alert_s`, additionally
   publish `time.utc.drift`.
6. If every reference fails: publish nothing, increment `failure_count`, and
   let `health_check` report it.
7. Sleep `sync_interval_s` and repeat.

The blocking socket call runs through `asyncio.to_thread`, so a slow reference
never blocks the event loop.

## 5. Settled decisions

### 5.1 It does not tick
806 (TIME_TICK) and 3 (CLOCK) are the only tick sources. A tick here would be a
third clock and would reintroduce exactly the inconsistency this atom exists to
expose.
*Guarded by:* `test_manifest_matches_code` asserts no published event name
contains `tick`.

### 5.2 It does not correct anything
`offset_s` is a reading. Nothing is rewritten, and **806 does not consume it**.
A measuring instrument does not steer. Whether the platform applies the offset
is a separate decision that belongs to whoever owns system time.

### 5.3 `critical: false`
The reference lives on the network. A critical atom is blocked from booting when
it fails, which would let an unreachable NTP server hold up the platform.
*Guarded by:* `test_not_critical`.

### 5.4 Unreachable reference is DEGRADED, never UNHEALTHY
The atom is not broken because the network is down, and restarting it does not
bring the reference back. UNHEALTHY would burn the restart budget and eventually
pull a working atom.
*Guarded by:* `test_unreachable_reference_is_degraded_not_unhealthy`.

### 5.5 It never stamps its own events
Published payloads carry no `timestamp`; `core.event_bus` fills it via
`setdefault`, so every event is stamped exactly once. `measured_at` is
measurement data and must not be read as the event time.
*Guarded by:* `test_publishes_no_self_stamped_timestamp`.

### 5.6 Reading the local clock here is the function
Comparing local against external cannot be done without reading local. This is
not an exception to the inherit-the-timestamp rule - that rule governs *stamping
events*, and 5.5 covers it.

### 5.7 Drift is a distance
A clock running **ahead** is as wrong as one running behind, so the threshold
applies to `abs(offset)`.
*Guarded by:* `test_negative_drift_also_fires`.

## 6. Full contract

See `api_spec.yaml` for every field and type. Summary:

**Publishes**
- `time.utc.synced` - `{server, offset_s, round_trip_s, measured_at, sync_count}`
- `time.utc.drift` - the same plus `{threshold_s, previous_offset_s, drift_count}`

**Subscribes:** nothing. The atom is timer-driven.

**Dependencies:** none. It needs no other atom to function.

## 7. Settings - and why each number

| Key | Value | Reasoning |
|---|---|---|
| `reference_servers` | cloudflare, pool.ntp.org, nist | three independent operators; one dead host must not silence the measurement |
| `sync_interval_s` | 900.0 | machine clocks drift on the order of seconds per day - measuring more often costs traffic without adding information |
| `query_timeout_s` | 5.0 | a host that has not answered in 5s is unreachable for our purpose; waiting longer only delays the fallback |
| `drift_alert_s` | 0.5 | above the ~15.6ms Windows resolution so noise does not trip it, below the multi-second drift that actually reorders events |
| `stale_after_s` | 2000.0 | two missed cycles plus margin - one failure is normal on a flaky link, two means the reference is gone |

## 8. Health states

| State | Condition | Effect |
|---|---|---|
| `UNHEALTHY` | not started | restart policy applies |
| `DEGRADED` | never synced / reference unreachable / last sync older than `stale_after_s` | logged and reported; **no restart** |
| `HEALTHY` | synced within `stale_after_s` | - |

`details` always carries `sync_count`, `drift_count`, `failure_count`,
`last_offset_s`, `last_server`.

## 9. Snapshot

Saves `sync_count`, `drift_count`, `last_offset_s`, `last_sync_at`,
`last_server` - the counters a dashboard reads and the last known offset, so a
restart does not look like a fresh install. Deliberately **not** saved:
`failure_count` and `_last_error`, which describe a live condition and must be
re-measured.

## 10. Safe modification

**Safe without fear**
- adding a reference host to `reference_servers`
- tuning `sync_interval_s`, `query_timeout_s`, `stale_after_s`
- adding an *optional* field to a published payload

**Breaks consumers - needs coordination**
- renaming or removing any published field: 111 re-publishes the payload
  verbatim, so the change reaches its consumers unchanged
- changing `drift_alert_s`: alert volume changes for everyone downstream
- renaming either event: 111 subscribes to both names literally

**Violates a settled decision - do not do**
- publishing a tick (5.1)
- feeding 806 or rewriting any timestamp (5.2)
- setting `critical: true` (5.3)
- returning UNHEALTHY for an unreachable reference (5.4)
- adding a `timestamp` field to a published payload (5.5)

## 11. Who depends on it

**Consumes from:** nothing.

**Consumed by:** **111** (Time Sync Manager), which subscribes to both events
and re-publishes them verbatim as `market.time.synced` / `market.time.drift`.

**If 608 stops:** 111 goes quiet. Nothing else stops. No atom's timestamps
change, because 608 never fed any of them - the platform loses visibility into
its clock drift, not its ability to run.

## 12. Tests

19 tests. Every behavioural test replaces the socket layer, so nothing touches
the network.

| Area | Count | What it guards |
|---|---|---|
| structure | 4 | syntax, no `print()`, manifest matches code, not critical |
| behaviour | 6 | sync publishes, drift threshold in both directions, fallthrough to next host, no self-stamp |
| health | 4 | the three states plus the DEGRADED-not-UNHEALTHY rule |
| lifecycle | 4 | stop/start restartability, snapshot round trip, malformed reply survival |
| arithmetic | 1 | NTP wire decoding against a synthetic reply |

## 13. Behaviour proven by running

Test run: **19 passed in 0.24s**, no network access.

**Not yet proven:** behaviour against a live NTP server. Every test uses a
replaced `_query`, so the real socket path - DNS resolution, UDP on port 123,
firewall behaviour - has not been exercised in this environment. The arithmetic
is verified against a synthetic reply; the transport is not.

## 14. Deliberately not built

- **No tick.** Decision 5.1.
- **No correction path.** Decision 5.2. If the platform should run on corrected
  time, that is a change to whoever owns system time, not to this atom.
- **No broker time source.** The reference list holds NTP hosts. Broker time
  (MetaApi / Rithmic) is closer to actual market time but is tied to a provider
  and dies with it; adding it means a second source atom, not a branch here.
- **No history.** Only the last offset is kept. Drift over time belongs to
  section 700 (storage), which subscribes to the events.
