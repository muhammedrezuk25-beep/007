# 608 - Time Sync

Measures how far the machine clock has drifted from an external reference,
and publishes the measurement. That is all it does.

## What it publishes

| Event | When |
|---|---|
| `time.utc.synced` | every successful sync (every 900s by default) |
| `time.utc.drift` | additionally, when `abs(offset_s) >= 0.5s` |

Consumed by **111** (Time Sync Manager), which re-publishes both verbatim as
`market.time.synced` and `market.time.drift` for the 101 family.

## What it does not do

- **Does not tick.** 806 and 3 are the only tick sources in the platform.
- **Does not correct.** It reports `offset_s`; nothing is rewritten and 806
  does not consume it. A measuring instrument does not steer.
- **Does not stamp its own events.** `core.event_bus` fills `timestamp`, so
  every event is stamped once. `measured_at` is measurement data.

## Settings

| Key | Default | Why |
|---|---|---|
| `reference_servers` | 3 public NTP hosts | tried in order; one dead host must not silence the measurement |
| `sync_interval_s` | 900.0 | clocks drift on the order of seconds per day |
| `query_timeout_s` | 5.0 | longer only delays falling through to the next host |
| `drift_alert_s` | 0.5 | above Windows' ~15.6ms resolution, below the multi-second drift that reorders events |
| `stale_after_s` | 2000.0 | two missed cycles plus margin |

## Health

| State | When |
|---|---|
| `UNHEALTHY` | not started |
| `DEGRADED` | never synced, reference unreachable, or last sync older than `stale_after_s` |
| `HEALTHY` | synced within `stale_after_s` |

An unreachable reference is `DEGRADED`, never `UNHEALTHY` - the atom is not
broken because the network is down, and restarting it does not bring the
reference back.

## Testing

```bash
pytest atoms/600/608_time_sync/tests/ -q
```

19 tests. The socket layer is replaced in every behavioural test, so nothing
touches the network.
