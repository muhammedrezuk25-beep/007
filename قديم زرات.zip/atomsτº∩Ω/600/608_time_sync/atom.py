"""
608 - Time Sync
===============
Single responsibility: measure how far the machine clock has drifted from an
external reference, and announce the measurement. Nothing else.

Why it exists: every timestamp in the platform ultimately rests on the machine
clock. On Windows that clock has ~15.6ms resolution and drifts by seconds
between OS synchronisations. Nobody could see that drift, because nothing
measured it. This atom measures it and publishes the number; what the platform
does with it is another atom's decision.

Settled decisions:

  * It does NOT tick. 806 (TIME_TICK) and 3 (CLOCK) are the only tick sources
    in the platform. Publishing a tick here would create a third clock and
    reintroduce exactly the inconsistency this atom exists to expose.

  * It does NOT correct anything. It reports `offset_s`; it never rewrites a
    timestamp and never feeds 806. A measuring instrument does not steer.

  * critical is false. The reference lives on the network. A critical atom is
    blocked from booting when it fails, which would make an unreachable NTP
    server able to hold up the platform. Unreachable reference is a declared
    health state, not a failure to boot.

  * Reading the local clock here is the function, not a violation of the
    inherit-the-timestamp rule. Comparing local against external is the whole
    job and cannot be done without reading local. The published events carry
    no `timestamp` of their own: core.event_bus stamps them once via
    setdefault, so this atom still never invents an event time.
    `test_publishes_no_self_stamped_timestamp` guards this.
"""

from __future__ import annotations

import asyncio
import socket
import struct
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_SYNCED = "time.utc.synced"
EVENT_DRIFT = "time.utc.drift"

# NTP wire format (RFC 5905): 48-byte packet, first byte 0x1b requests
# client mode / version 3. Seconds since 1900 sit in bytes 40..48, so the
# offset below converts an NTP epoch to a Unix epoch.
_NTP_EPOCH_OFFSET = 2_208_988_800
_NTP_PACKET_BYTES = 48
_NTP_PORT = 123
_NTP_REQUEST = b"\x1b" + 47 * b"\0"
_HALF = 2.0

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_SYNCED = "NEVER_SYNCED"
REASON_UNREACHABLE = "REFERENCE_UNREACHABLE"
REASON_STALE = "LAST_SYNC_STALE"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._task: asyncio.Task | None = None

        self._servers: list[str] = []
        self._sync_interval_s = 0.0
        self._query_timeout_s = 0.0
        self._drift_alert_s = 0.0
        self._stale_after_s = 0.0

        self._last_offset_s: float | None = None
        self._last_sync_at: float | None = None
        self._last_server = ""
        self._last_error = ""
        self.sync_count = 0
        self.drift_count = 0
        self.failure_count = 0

    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._servers = [str(s).strip() for s in cfg["reference_servers"] if str(s).strip()]
        self._sync_interval_s = float(cfg["sync_interval_s"])
        self._query_timeout_s = float(cfg["query_timeout_s"])
        self._drift_alert_s = float(cfg["drift_alert_s"])
        self._stale_after_s = float(cfg["stale_after_s"])
        self._initialized = True
        context.logger.info(
            "608 initialised with %d reference server(s), sync every %.0fs",
            len(self._servers), self._sync_interval_s,
        )

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._sync_loop())
        self._context.logger.info("608 started")

    async def stop(self) -> None:
        """Reversible. Restart is stop() then start(), so every counter that
        health_check reads must return to a state that can pass again -
        otherwise the atom reports UNHEALTHY the instant it restarts, burns its
        restart budget and gets pulled for good."""
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "608 stopped (syncs=%d, drifts=%d)", self.sync_count, self.drift_count
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------------------------

    def _query(self, host: str) -> tuple[float, float]:
        """Ask one reference. Returns (offset, round_trip), both seconds.

        Standard NTP arithmetic: note the local clock before sending and after
        receiving, read the server's time from the reply, then discount half
        the round trip because that is roughly what the reply spent coming
        back.
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self._query_timeout_s)
        try:
            sent_at = time.time()
            sock.sendto(_NTP_REQUEST, (host, _NTP_PORT))
            data, _ = sock.recvfrom(_NTP_PACKET_BYTES)
            received_at = time.time()
        finally:
            sock.close()

        if len(data) < _NTP_PACKET_BYTES:
            raise ValueError("NTP reply shorter than expected")

        seconds, fraction = struct.unpack("!II", data[40:48])
        server_time = seconds + fraction / 2**32 - _NTP_EPOCH_OFFSET

        round_trip = received_at - sent_at
        offset = server_time - (received_at - round_trip / _HALF)
        return offset, round_trip

    async def _sync_once(self) -> bool:
        """Try each reference in order until one answers."""
        if self._context is None:
            return False

        for host in self._servers:
            try:
                offset, round_trip = await asyncio.to_thread(self._query, host)
            except Exception as exc:  # noqa: BLE001 - external network
                self._last_error = "%s: %s" % (host, exc)
                self._context.logger.warning("608 reference %s failed: %s", host, exc)
                continue

            previous = self._last_offset_s
            measured_at = time.time()
            self._last_offset_s = offset
            self._last_sync_at = measured_at
            self._last_server = host
            self._last_error = ""
            self.sync_count += 1

            # No "timestamp" key: core.event_bus stamps the event once.
            body: dict[str, Any] = {
                "server": host,
                "offset_s": round(offset, 6),
                "round_trip_s": round(round_trip, 6),
                "measured_at": measured_at,
                "sync_count": self.sync_count,
            }
            await self._context.publish(EVENT_SYNCED, dict(body))

            if abs(offset) >= self._drift_alert_s:
                self.drift_count += 1
                await self._context.publish(EVENT_DRIFT, {
                    **body,
                    "threshold_s": self._drift_alert_s,
                    "previous_offset_s": previous,
                    "drift_count": self.drift_count,
                })
            return True

        self.failure_count += 1
        return False

    async def _sync_loop(self) -> None:
        try:
            while self._running:
                await self._sync_once()
                await asyncio.sleep(self._sync_interval_s)
        except asyncio.CancelledError:
            pass

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "sync_count": self.sync_count,
            "drift_count": self.drift_count,
            "failure_count": self.failure_count,
            "last_offset_s": self._last_offset_s,
            "last_server": self._last_server,
        }

        # An unreachable reference is starvation of an external input, not a
        # broken atom. Restarting does not bring the network back, so this
        # stays DEGRADED and never triggers the restart policy.
        if self._last_sync_at is None:
            state = HealthState.DEGRADED
            message = REASON_NEVER_SYNCED if not self._last_error else REASON_UNREACHABLE
        elif time.time() - self._last_sync_at > self._stale_after_s:
            state = HealthState.DEGRADED
            message = REASON_STALE
        else:
            state = HealthState.HEALTHY
            message = "offset=%.6fs via %s" % (self._last_offset_s or 0.0, self._last_server)

        return HealthStatus(state=state, message=message, details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "sync_count": self.sync_count,
            "drift_count": self.drift_count,
            "last_offset_s": self._last_offset_s,
            "last_sync_at": self._last_sync_at,
            "last_server": self._last_server,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.sync_count = int(state.get("sync_count", 0))
        self.drift_count = int(state.get("drift_count", 0))
        self._last_offset_s = state.get("last_offset_s")
        self._last_sync_at = state.get("last_sync_at")
        self._last_server = str(state.get("last_server", ""))
