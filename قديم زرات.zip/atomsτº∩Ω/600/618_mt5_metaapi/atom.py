"""
618 - MT5 Bridge Source
=======================
Single responsibility: read the tick queue the platform arm writes into the
bridge database, and publish each tick as `feed.mt5.tick`.

Why it was rewritten. The previous version pulled prices from the MetaApi
cloud: a token, a subscription, an external server, and a round trip on every
poll. All of that was rejected as a dependency, and the atom sat at
`startup_mode: manual` so it never ran - which is why 613 logged
INPUT_STARVED for `feed.mt5.tick` continuously.

The prices are already on this machine. The arm writes every tick it sees
into `ticks` in the same file 601 and 563 use. Reading them locally removes
the token, the subscription and the network entirely, and the tick that
arrives is the same tick the order will execute against - not a second
provider's approximation of it.

The atom id is unchanged on purpose: 613 subscribes to `feed.mt5.tick`
literally, and 617 and 620 keep their own events. Nothing downstream moves.

Settled decisions:

  * It reads, then deletes what it read. The table is a transport queue, not
    a store - and storage atoms subscribe to `market.tick` on the bus, they do
    not read this table. Leaving consumed rows makes the file grow without
    limit for no reader.

  * It publishes one event per tick, not a snapshot. 103 builds candles from
    ticks, and a snapshot that keeps only the newest of a window produces a
    candle whose high and low never happened.

  * `exchange_timestamp` is the broker's own `time_msc`, not our read time.
    613 picks the fastest provider by comparing these; measuring latency
    against the moment we happened to poll would make a slow reader look like
    a slow broker.

  * A missing table is DEGRADED, not UNHEALTHY. Before the arm's first cycle
    there is nothing to read, and restarting this atom does not create it.
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

PROVIDER = "MT5"
EVENT_TICK = "feed.mt5.tick"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TABLE = "TICKS_TABLE_MISSING"
REASON_NO_FILE = "BRIDGE_FILE_MISSING"
REASON_NO_DATA = "NO_TICKS_YET"

_COLUMNS = ("id", "symbol", "bid", "ask", "last", "volume", "tick_ms")
_SPEC_COLUMNS = ("symbol", "contract_size", "tick_value", "tick_size")
EVENT_SPECS = "market.symbol_specs"

_MS_PER_SECOND = 1000.0

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            if "locked" not in str(exc) and "busy" not in str(exc):
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("lock")



def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._task: asyncio.Task | None = None

        self._db_path = ""
        self._table = "ticks"
        self._poll_interval_s = 0.0
        self._batch_limit = 0
        self._delete_consumed = True

        self._last_id = 0
        self._last_error = ""
        self._symbols: set[str] = set()
        self.published_count = 0
        self.spec_publishes = 0
        self._announced: set[str] = set()
        self.spec_failures = 0
        self.dropped_count = 0
        self.failure_count = 0
        self.last_publish_at: float | None = None

    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._spec_table = str(cfg["spec_table"])
        self._spec_refresh_s = float(cfg["spec_refresh_s"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._batch_limit = int(cfg["batch_limit"])
        self._delete_consumed = bool(cfg["delete_consumed"])
        self._initialized = True
        context.logger.info(
            "618 initialised as a local bridge reader on %s", self._db_path
        )

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        self._context.logger.info("618 started")

    async def stop(self) -> None:
        """Reversible. `_last_id` is kept: it marks how far the queue was
        consumed, and forgetting it republishes ticks every consumer already
        processed."""
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "618 stopped (published=%d, dropped=%d)",
                self.published_count, self.dropped_count,
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------------------------

    def _fetch(self) -> list[dict[str, Any]]:
        """Read-only. The arm owns the inserts."""
        columns = ", ".join(_COLUMNS)
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(
                f"SELECT {columns} FROM {self._table} "
                f"WHERE id > ? ORDER BY id LIMIT ?",
                (self._last_id, self._batch_limit),
            )
            return [dict(row) for row in cursor.fetchall()]
        finally:
            connection.close()

    def _purge(self, up_to_id: int) -> None:
        """Drop what was published.

        The one write this atom makes, and it targets only rows it has already
        consumed. Without it the queue grows for the whole session with no
        reader behind it - the arm inserts every tick of every symbol.
        Storage belongs to section 700, which subscribes to `market.tick` on
        the bus rather than reading this table.
        """
        connection = _bridge_connect(self._db_path, read_only=False)
        try:
            connection.execute(
                f"DELETE FROM {self._table} WHERE id <= ?", (up_to_id,)
            )
            connection.commit()
        finally:
            connection.close()

    def _read_specs(self) -> list[dict[str, Any]]:
        columns = ", ".join(_SPEC_COLUMNS)
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(
                "SELECT %s FROM %s" % (columns, self._spec_table))
            return [dict(row) for row in cursor.fetchall()]
        finally:
            connection.close()

    async def _refresh_specs(self) -> None:
        """Contract specifications, read here because the bridge is this
        section's file.

        508 opened the database itself to get them, which put a risk atom
        inside a file that belongs to section 600 and bound it to one
        platform: a Binance account would never reach it.

        A symbol missing its contract size is dropped rather than defaulted
        to one. Position size is computed from that figure, and a number
        nobody measured would size a real trade.
        """
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._read_specs)
        except sqlite3.Error as exc:
            self.spec_failures += 1
            self._context.logger.warning("618 spec read failed: %s", exc)
            return
        usable = []
        for row in rows:
            size = _to_float(row.get("contract_size"))
            if size is None or size <= 0:
                continue
            usable.append({
                "symbol": row.get("symbol"),
                "contract_size": size,
                "tick_value": _to_float(row.get("tick_value")),
                "tick_size": _to_float(row.get("tick_size")),
            })
        if not usable:
            return
        self._announced = {row["symbol"] for row in usable}
        self.spec_publishes += 1
        await self._context.publish(EVENT_SPECS, {"provider": PROVIDER,
                                                  "symbols": usable})

    async def _announce_if_new(self, symbols: set[str]) -> None:
        """A tick for a symbol whose spec was never announced re-announces.

        The specs went out in the loop's first instant and 508 boots after
        618, so it never heard them — and the next attempt was five minutes
        away. Between the two every order was refused for a contract size
        that sat in the table the whole time: 159 refusals and not one order
        on a measured live run.

        Keying it on the tick heals the boot race and heals a symbol added
        after startup with the same rule, instead of waiting on a clock.
        """
        if not symbols - self._announced:
            return
        await self._refresh_specs()

    async def _drain_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._fetch)
        except sqlite3.Error as exc:
            self.failure_count += 1
            message = str(exc).lower()
            self._last_error = (
                REASON_NO_TABLE if "no such table" in message
                else REASON_NO_FILE if "unable to open" in message
                else str(exc)
            )
            self._context.logger.warning("618 read failed: %s", exc)
            return

        self._last_error = ""
        if not rows:
            return

        seen = {str(r["symbol"]) for r in rows if r.get("symbol")}
        await self._announce_if_new(seen)

        highest = self._last_id
        for row in rows:
            row_id = int(row["id"])
            highest = max(highest, row_id)

            symbol = row.get("symbol")
            bid = _to_float(row.get("bid"))
            ask = _to_float(row.get("ask"))
            tick_ms = _to_float(row.get("tick_ms"))

            # 613 drops a tick without symbol, bid, ask or timestamp. Dropping
            # it here keeps that count where the cause is visible.
            if not symbol or bid is None or ask is None or tick_ms is None:
                self.dropped_count += 1
                continue

            self._symbols.add(str(symbol))
            exchange_timestamp = tick_ms / _MS_PER_SECOND

            await self._context.publish(EVENT_TICK, {
                "provider": PROVIDER,
                "symbol": symbol,
                "bid": bid,
                "ask": ask,
                "price": (bid + ask) / 2.0,
                "volume": _to_float(row.get("volume")),
                "last_trade": _to_float(row.get("last")),
                # الطابع من الوسيط لا من لحظة قراءتنا: 613 يوازن بين
                # المزوّدين بفارق exchange_timestamp، فقياسه على لحظة
                # الاستطلاع يجعل القارئ البطيء يبدو وسيطًا بطيئًا.
                "exchange_timestamp": exchange_timestamp,
                "received_at": time.time(),
                "source_row_id": row_id,
            })
            self.published_count += 1
            self.last_publish_at = time.time()

        self._last_id = highest
        if self._delete_consumed and highest > 0:
            try:
                await asyncio.to_thread(self._purge, highest)
            except sqlite3.Error as exc:
                # فشل التنظيف لا يُسقط النشر: التكّات وصلت المستهلكين،
                # والصفوف الباقية ستُحذف في الدورة التالية.
                self._context.logger.warning("618 purge failed: %s", exc)

    async def _loop(self) -> None:
        """Ticks every poll, specs on their own slower interval.

        _refresh_specs was built and never called from anywhere. The table
        held the contract sizes the whole time and this atom knew how to read
        them, and nothing asked. Measured on a live run: 508 refused 159
        times for "contract_size missing" and not one order was built.

        Specs are read once at the start, before the first tick reaches the
        chain — an order cannot be sized without them, so arriving late is
        the same as not arriving.
        """
        try:
            await self._refresh_specs()
            last_specs = 0.0
            loop = asyncio.get_running_loop()
            last_specs = loop.time()
            while self._running:
                await self._drain_once()
                if loop.time() - last_specs >= self._spec_refresh_s:
                    await self._refresh_specs()
                    last_specs = loop.time()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "published": self.published_count,
            "dropped": self.dropped_count,
            "failures": self.failure_count,
            "last_id": self._last_id,
            "symbols": len(self._symbols),
            "last_error": self._last_error,
        }

        # جسر غائب هو جوع مدخل خارجي: الذراع لم يكتب بعد، وإعادة تشغيل
        # هذه الذرة لا تجعله يكتب.
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error, details=details)

        if self.published_count == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_DATA, details=details)

        return HealthStatus(state=HealthState.HEALTHY,
                            message="published=%d symbols=%d" % (
                                self.published_count, len(self._symbols)),
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "last_id": self._last_id,
            "published": self.published_count,
            "dropped": self.dropped_count,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        # موضع القراءة يُستعاد: بدونه تُعاد التكّات التي عولجت فعلًا،
        # فتبني 103 شمعة من بيانات مكرّرة.
        self._last_id = int(state.get("last_id", 0))
        self.published_count = int(state.get("published", 0))
        self.dropped_count = int(state.get("dropped", 0))
