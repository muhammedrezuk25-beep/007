"""اختبارات الذرة 618 — قارئ جسر MT5."""

from __future__ import annotations

import ast
import asyncio
import importlib.util
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom618"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]

BASE_MS = 1785600000000


class Ctx:
    atom_id = 618

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _make_db(ticks=None):
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute(
        "CREATE TABLE ticks (id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,"
        " bid REAL, ask REAL, last REAL, volume REAL, tick_ms INTEGER NOT NULL, flags INTEGER)"
    )
    if ticks is None:
        ticks = [("USTEC", 28400.0, 28401.0, 28400.5, 1.0, BASE_MS),
                 ("USTEC", 28402.0, 28403.0, 28402.5, 2.0, BASE_MS + 100),
                 ("BTCUSD", 62800.0, 62807.0, 62803.0, 0.5, BASE_MS + 200)]
    for t in ticks:
        conn.execute("INSERT INTO ticks (symbol,bid,ask,last,volume,tick_ms,flags)"
                     " VALUES (?,?,?,?,?,?,0)", t)
    conn.commit()
    conn.close()
    return path


async def _ready(db_path, **over):
    cfg = {**CONFIG, "db_path": db_path}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    return atom, ctx


def _ticks(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_TICK]


def _remaining(db):
    conn = sqlite3.connect(db)
    try:
        return conn.execute("SELECT COUNT(*) FROM ticks").fetchone()[0]
    finally:
        conn.close()


# ---------------------------------------------------------------- البنية


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 618
    # مخرَجان: التكّة، ومعاملات العقود التي يكتبها الإكسبرت في الجسر نفسه.
    # والثاني هنا لأن الجسر ملك هذا القسم — و508 كان يفتحه من خارجه.
    assert MANIFEST["publishes"] == [MODULE.EVENT_TICK, MODULE.EVENT_SPECS]
    assert MANIFEST["subscribes"] == []


def test_no_cloud_dependency_left():
    """سبب إعادة الكتابة: النسخة السابقة كانت تحتاج توكن MetaApi واشتراكًا
    وسيرفرًا خارجيًا، فبقيت manual ولم تعمل قط — وظلّ 613 يسجّل
    INPUT_STARVED على feed.mt5.tick باستمرار."""
    # يُفحص الكود لا التعليقات: التوثيق يذكر السبب عمدًا، والاعتماد هو
    # ما يجب أن يختفي — استيرادًا كان أو نداءً أو حزمة معلنة.
    import ast as _ast
    tree = _ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))
    imported = set()
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Import):
            imported.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, _ast.ImportFrom) and node.module:
            imported.add(node.module.split(".")[0])
    assert "metaapi_cloud_sdk" not in imported
    assert not any("meta" in m.lower() for m in imported)
    assert MANIFEST["metadata"]["external_python_packages"] == []
    # ولا وصول لخزنة أسرار: النسخة السابقة كانت تقرأ توكنًا منها
    assert "_secret" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_starts_automatically_now():
    """manual كانت سبب الجوع الدائم. لا شيء خارج الجهاز يلزمها الآن."""
    assert MANIFEST["startup_mode"] == "auto"


# ---------------------------------------------------------------- القراءة


@pytest.mark.asyncio
async def test_publishes_every_tick_not_a_snapshot():
    """103 يبني الشموع من التكّات: لقطة تُبقي الأحدث فقط تُنتج شمعة لم
    يحدث أعلاها ولا أدناها قط."""
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert len(_ticks(ctx)) == 3


@pytest.mark.asyncio
async def test_payload_matches_what_613_requires():
    """613 يُسقط أي تكّة بلا provider أو symbol أو bid أو ask أو طابع."""
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    t = _ticks(ctx)[0]
    for field in ("provider", "symbol", "bid", "ask", "exchange_timestamp", "received_at"):
        assert t.get(field) is not None, field
    assert t["provider"] == MODULE.PROVIDER


@pytest.mark.asyncio
async def test_exchange_timestamp_is_the_broker_stamp_in_seconds():
    """613 يوازن بين المزوّدين بفارق exchange_timestamp. قياسه على لحظة
    قراءتنا يجعل القارئ البطيء يبدو وسيطًا بطيئًا."""
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert _ticks(ctx)[0]["exchange_timestamp"] == BASE_MS / 1000.0


@pytest.mark.asyncio
async def test_multiple_symbols_pass_through():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert {t["symbol"] for t in _ticks(ctx)} == {"USTEC", "BTCUSD"}


@pytest.mark.asyncio
async def test_already_read_ticks_are_not_republished():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    await atom._drain_once()
    assert len(_ticks(ctx)) == 3


@pytest.mark.asyncio
async def test_new_ticks_are_picked_up():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()

    conn = sqlite3.connect(db)
    conn.execute("INSERT INTO ticks (symbol,bid,ask,last,volume,tick_ms,flags)"
                 " VALUES ('USTEC',28410.0,28411.0,28410.5,1.0,?,0)", (BASE_MS + 900,))
    conn.commit()
    conn.close()

    await atom._drain_once()
    assert len(_ticks(ctx)) == 4


@pytest.mark.asyncio
async def test_incomplete_tick_is_dropped_not_published():
    db = _make_db([("USTEC", None, 28401.0, 0, 0, BASE_MS)])
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert _ticks(ctx) == []
    assert atom.dropped_count == 1


@pytest.mark.asyncio
async def test_batch_limit_is_respected():
    ticks = [("USTEC", 28400.0 + i, 28401.0 + i, 0, 1.0, BASE_MS + i) for i in range(10)]
    db = _make_db(ticks)
    atom, ctx = await _ready(db, batch_limit=4)
    await atom._drain_once()
    assert len(_ticks(ctx)) == 4


# ---------------------------------------------------------------- التنظيف


@pytest.mark.asyncio
async def test_consumed_rows_are_purged():
    """الجدول طابور نقل لا مخزن: ذرات قسم 700 تشترك في market.tick على
    الناقل ولا تقرأ هذا الجدول."""
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert _remaining(db) == 0


@pytest.mark.asyncio
async def test_purge_can_be_turned_off():
    db = _make_db()
    atom, ctx = await _ready(db, delete_consumed=False)
    await atom._drain_once()
    assert _remaining(db) == 3


# ---------------------------------------------------------------- الأعطال


@pytest.mark.asyncio
async def test_missing_file_does_not_raise():
    atom, ctx = await _ready("/nonexistent/dir/nq.db")
    await atom._drain_once()
    assert _ticks(ctx) == []
    assert atom.failure_count == 1


@pytest.mark.asyncio
async def test_missing_table_does_not_raise():
    path = tempfile.mktemp(suffix=".db")
    sqlite3.connect(path).close()
    atom, ctx = await _ready(path)
    await atom._drain_once()
    assert _ticks(ctx) == []


@pytest.mark.asyncio
async def test_empty_queue_publishes_nothing():
    db = _make_db([])
    atom, ctx = await _ready(db)
    await atom._drain_once()
    assert _ticks(ctx) == []


# ---------------------------------------------------------------- الصحة


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom, _ = await _ready(_make_db())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_missing_bridge_is_degraded_not_unhealthy():
    atom, _ = await _ready("/nonexistent/dir/nq.db")
    atom._running = True
    await atom._drain_once()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_no_ticks_yet_is_degraded():
    atom, _ = await _ready(_make_db([]))
    atom._running = True
    await atom._drain_once()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_healthy_after_publishing():
    atom, _ = await _ready(_make_db())
    atom._running = True
    await atom._drain_once()
    assert (await atom.health_check()).state.name == "HEALTHY"


# ------------------------------------------------------------- دورة الحياة


@pytest.mark.asyncio
async def test_stop_then_start_still_reads():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom.start()
    await asyncio.sleep(0)
    await atom.stop()
    assert atom.failure_count == 0
    await atom.start()
    assert atom._running is True
    await atom.stop()


@pytest.mark.asyncio
async def test_snapshot_keeps_the_read_position():
    """بدونه تُعاد التكّات التي عولجت فعلًا، فتبني 103 شمعة من بيانات
    مكرّرة عند كل إعادة تشغيل."""
    db = _make_db()
    atom, ctx = await _ready(db, delete_consumed=False)
    await atom._drain_once()
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    fresh_ctx = Ctx({**CONFIG, "db_path": db, "delete_consumed": False})
    await fresh.initialize(fresh_ctx)
    await fresh.restore(state)
    await fresh._drain_once()
    assert [p for n, p in fresh_ctx.published if n == MODULE.EVENT_TICK] == []


# ── معاملات العقود: من يقرأ الجسر يقرؤها ────────────────────────────

def _seed_specs(db_path, rows):
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE IF NOT EXISTS prices (symbol TEXT PRIMARY KEY,"
                 " contract_size REAL, tick_value REAL, tick_size REAL)")
    for symbol, size, value, tick in rows:
        conn.execute("INSERT OR REPLACE INTO prices VALUES (?,?,?,?)",
                     (symbol, size, value, tick))
    conn.commit(); conn.close()


def test_the_manifest_declares_a_spec_source():
    """معاملات العقود في جدول prices بالجسر، و508 كان يفتح القاعدة
    بنفسه ليقرأها — وهو خارج قسم 600.

    والجسر ملك هذا القسم: من يفتحه من خارجه يربط ذرّة مخاطر بمنصّة."""
    assert "spec_table" in CONFIG
    assert "spec_refresh_s" in CONFIG
    assert "market.symbol_specs" in MANIFEST["publishes"]


@pytest.mark.asyncio
async def test_specs_are_published_when_they_exist():
    db = _make_db()
    _seed_specs(db, [("USTEC", 1.0, 1.0, 0.01),
                     ("EURUSD", 100000.0, 1.0, 0.00001)])
    atom, ctx = await _ready(db)
    await atom._refresh_specs()
    specs = [p for n, p in ctx.published if n == "market.symbol_specs"]
    assert specs
    rows = {s["symbol"]: s for s in specs[-1]["symbols"]}
    assert rows["USTEC"]["contract_size"] == 1.0
    assert rows["EURUSD"]["contract_size"] == 100000.0


@pytest.mark.asyncio
async def test_a_symbol_with_no_contract_size_is_left_out():
    """معامل مفقود لا يُستبدَل بواحد: الحجم محسوب عليه، ورقمٌ لم يقسه
    أحد يسوق صفقة بحجم خاطئ."""
    db = _make_db()
    _seed_specs(db, [("USTEC", 1.0, 1.0, 0.01), ("BROKEN", None, None, None)])
    atom, ctx = await _ready(db)
    await atom._refresh_specs()
    specs = [p for n, p in ctx.published if n == "market.symbol_specs"][-1]
    assert {s["symbol"] for s in specs["symbols"]} == {"USTEC"}


@pytest.mark.asyncio
async def test_a_missing_spec_table_does_not_stop_the_ticks():
    """قاعدة كتبها إكسبرت أقدم لا تحمل الجدول. والتكّات أهمّ من أن
    تتوقّف لأجل معاملات."""
    atom, ctx = await _ready(_make_db())
    await atom._refresh_specs()
    assert atom.spec_failures >= 1


@pytest.mark.asyncio
async def test_specs_are_refreshed_on_the_polling_loop():
    """_refresh_specs بُنيت ولم تُنادَ من أي مكان: الجدول يحمل معاملات
    العقود والذرّة تعرف قراءتها، ولا شيء يستدعيها.

    والأثر مقيس على تشغيل حيّ: 508 رفض 159 مرّة بـ
    "contract_size missing" ولم يُبنَ أمر واحد، والمعاملات في الجدول
    طوال الوقت."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    calls = src.count("_refresh_specs")
    assert calls >= 2, "معرَّفة ولا تُنادى"


@pytest.mark.asyncio
async def test_the_loop_publishes_specs_without_being_asked():
    db = _make_db()
    _seed_specs(db, [("USTEC", 1.0, 1.0, 0.01)])
    atom, ctx = await _ready(db)
    await atom.start()
    try:
        await asyncio.sleep(0.35)
    finally:
        await atom.stop()
    specs = [p for n, p in ctx.published if n == "market.symbol_specs"]
    assert specs, "الحلقة يجب أن تنشر المعاملات بلا نداء يدوي"


@pytest.mark.asyncio
async def test_specs_are_announced_again_for_an_unannounced_symbol():
    """المعاملات تُنشر في أوّل لحظة من الحلقة، و508 يقلع بعد 618 — فلا
    يسمعها، والإعادة بعد خمس دقائق.

    وبينهما كل أمر يُرفض بـ"contract_size missing": قيس على تشغيل حيّ
    159 رفضًا وصفر أمر، والمعاملات في الجدول طوال الوقت.

    فرمزٌ تصل تكّته ولم يُعلَن معامله بعد يُطلق إعلانًا جديدًا: يشفي
    سباق الإقلاع ويشفي معه رمزًا أُضيف بعد التشغيل."""
    db = _make_db()
    _seed_specs(db, [("USTEC", 1.0, 1.0, 0.01), ("BTCUSD", 1.0, 1.0, 0.01)])
    atom, ctx = await _ready(db)
    await atom._refresh_specs()
    first = len([p for n, p in ctx.published if n == "market.symbol_specs"])
    assert first == 1

    atom._announced.clear()          # كأن أحدًا لم يسمع
    await atom._drain_once()
    again = len([p for n, p in ctx.published if n == "market.symbol_specs"])
    assert again > first, "تكّة لرمز غير معلَن يجب أن تعيد الإعلان"


@pytest.mark.asyncio
async def test_an_announced_symbol_does_not_re_announce():
    """وإلا صار الإعلان مع كل تكّة."""
    db = _make_db()
    _seed_specs(db, [("USTEC", 1.0, 1.0, 0.01), ("BTCUSD", 1.0, 1.0, 0.01)])
    atom, ctx = await _ready(db)
    await atom._refresh_specs()
    await atom._drain_once()
    before = len([p for n, p in ctx.published if n == "market.symbol_specs"])
    await atom._drain_once()
    after = len([p for n, p in ctx.published if n == "market.symbol_specs"])
    assert after == before


def test_the_spec_interval_is_short_enough_to_heal_a_boot_race():
    """المعاملات تُنشر مرّة عند الإقلاع، و508 يقلع بعد 618 فلا يسمعها.

    والإعلان المشروط بالرمز الجديد لا يشفيها: نداء الإقلاع يملأ
    _announced فيصمت النداء التالي.

    فالإعادة الدورية هي الشفاء الوحيد — وثلاثمئة ثانية تعني خمس دقائق
    يُرفض فيها كل أمر بـ"contract_size missing"، وقيس على تشغيل: 2177
    رفضًا وصفر أمر."""
    assert CONFIG["spec_refresh_s"] <= 10.0, (
        "نافذة السباق أطول من أن تُحتمَل: %s ثانية" % CONFIG["spec_refresh_s"])
