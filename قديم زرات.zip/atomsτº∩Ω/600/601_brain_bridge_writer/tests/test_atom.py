"""اختبارات الذرة 601 — كاتب جسر العقل.

العقد تغيّر: كان الجدول `trade_signals` يحمل رأيًا (bias/confidence/stability)
ويُقرأ منه آخر صف. صار `commands` طابور أوامر كاملة — لأن الطرف المنفِّذ ذراع
مأمور لا يحسب حجمًا ولا وقفًا، فلا بدّ أن يصله الأمر مبنيًّا.
"""

from __future__ import annotations

import ast
import importlib.util
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]

# اسم وحدة فريد: تحميل كل ذرة باسم "atom" يجعل الثانية في العملية نفسها
# تستورد وحدة الأولى من الذاكرة فتختبر كودًا غير كودها.
_MODULE_NAME = "_atom601"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]

TS = 1785600000.0


class Ctx:
    atom_id = 601

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _order(**over):
    """أمر بالشكل الذي يمرّره 553 بعد أن يبنيه 551."""
    body = {
        "action": "OPEN",
        "request_id": "req-1",
        "symbol": "USTEC",
        "side": "BUY",
        "bias": "BUY",
        "volume": 0.33,
        "reference_price": 28401.0,
        "stop_loss": 28330.0,
        "take_profit": 28543.0,
        "confidence": 0.82,
        "stability": 0.71,
        "strategy": 410,
        "timestamp": TS,
    }
    body.update(over)
    return body


async def _ready(**over):
    db = tempfile.mktemp(suffix=".db")
    cfg = {**CONFIG, "db_path": db}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    await atom.start()
    return atom, ctx, db


def _rows(db, sql="SELECT * FROM commands"):
    conn = sqlite3.connect(db)
    conn.row_factory = sqlite3.Row
    try:
        return [dict(r) for r in conn.execute(sql)]
    finally:
        conn.close()


# ---------------------------------------------------------------- البنية


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 601
    assert "trading.final_decision" in MANIFEST["subscribes"]
    assert "emergency.halt" in MANIFEST["subscribes"]


def test_no_longer_bypasses_the_execution_pipeline():
    """قرار محسوم: الطريق من 467 إلى الجسر مباشرةً أُزيل.

    كان يتخطّى بناء الأمر (551) وبوابة التوقف (553)، فيصل أمرٌ بلا سعر
    ولا وقف ولا هدف، ويظلّ يصل بعد emergency.halt.
    """
    assert "execution.order.requested" not in MANIFEST["subscribes"]


# ---------------------------------------------------------------- الكتابة


@pytest.mark.asyncio
async def test_full_order_lands_in_the_queue():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order())
    rows = _rows(db)
    assert len(rows) == 1
    r = rows[0]
    assert r["request_id"] == "req-1"
    assert r["action"] == "OPEN"
    assert r["symbol"] == "USTEC"
    assert r["side"] == "BUY"
    assert r["volume"] == 0.33
    assert r["stop_loss"] == 28330.0
    assert r["take_profit"] == 28543.0
    assert r["status"] == "PENDING"


@pytest.mark.asyncio
async def test_two_orders_do_not_overwrite_each_other():
    """سببُ اختيار الطابور على صفٍّ واحد يتحدّث: أمرٌ على الذهب لا يستبدل
    أمرًا على ناسداك لم يُلتقط بعد."""
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(request_id="a", symbol="USTEC"))
    await ctx.handlers["trading.final_decision"](_order(request_id="b", symbol="XAUUSD"))
    rows = _rows(db)
    assert [r["request_id"] for r in rows] == ["a", "b"]
    assert {r["symbol"] for r in rows} == {"USTEC", "XAUUSD"}


@pytest.mark.asyncio
async def test_order_without_volume_is_refused():
    """الحجم إلزامي. تعويضه برقم من هنا يعني حجمًا لم يقرّره أحد يقود صفقة."""
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(volume=None))
    assert _rows(db) == []
    assert atom.last_write_success is False


@pytest.mark.asyncio
async def test_order_without_symbol_is_refused():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(symbol=None))
    assert _rows(db) == []


@pytest.mark.asyncio
async def test_unknown_side_is_refused():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(side="MAYBE", bias="MAYBE"))
    assert _rows(db) == []


@pytest.mark.asyncio
async def test_bias_is_accepted_as_side_for_compatibility():
    """553 يرسل الحقلين. أيّهما وصل يكفي."""
    atom, ctx, db = await _ready()
    body = _order()
    del body["side"]
    await ctx.handlers["trading.final_decision"](body)
    assert _rows(db)[0]["side"] == "BUY"


@pytest.mark.asyncio
async def test_write_publishes_confirmation():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order())
    names = [n for n, _ in ctx.published]
    assert "platform.brain_signal.written" in names


@pytest.mark.asyncio
async def test_write_failure_is_reported_not_swallowed():
    atom, ctx, db = await _ready(db_path="/nonexistent/dir/nq.db")
    await ctx.handlers["trading.final_decision"](_order())
    assert atom.last_write_success is False
    assert (await atom.health_check()).state.name in ("UNHEALTHY", "DEGRADED")


# ---------------------------------------------------------- التوقف الطارئ


@pytest.mark.asyncio
async def test_halt_cancels_pending_orders():
    """قرار محسوم: NEUTRAL كانت تعني شيئًا حين كان الجدول رأيًا يُقرأ آخر
    صفٍّ منه. مع طابور أوامر، أمرٌ مكتوبٌ ينتظر التنفيذ لا يبطله رأيٌ
    يُكتب بعده — فالإلغاء صريح."""
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(request_id="a"))
    await ctx.handlers["trading.final_decision"](_order(request_id="b"))
    await ctx.handlers["emergency.halt"]({"reason": "RISK_DAILY_LIMIT", "timestamp": TS})
    rows = _rows(db)
    assert all(r["status"] == "CANCELLED" for r in rows)
    assert all(r["result"] == "EMERGENCY_HALT" for r in rows)


@pytest.mark.asyncio
async def test_halt_does_not_touch_taken_orders():
    """ما التُقط فعلًا إمّا نُفّذ عند الوسيط أو هو في الطريق، وتعليمه
    ملغيًا يكذب على السجل."""
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(request_id="taken"))
    conn = sqlite3.connect(db)
    conn.execute("UPDATE commands SET status='TAKEN' WHERE request_id='taken'")
    conn.commit()
    conn.close()

    await ctx.handlers["emergency.halt"]({"reason": "RISK_SYSTEM_LIMIT", "timestamp": TS})
    assert _rows(db)[0]["status"] == "TAKEN"


@pytest.mark.asyncio
async def test_halt_reports_how_many_it_cancelled():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(request_id="a"))
    await ctx.handlers["trading.final_decision"](_order(request_id="b"))
    await ctx.handlers["emergency.halt"]({"reason": "X", "timestamp": TS})
    halted = [p for n, p in ctx.published if n == "platform.brain_signal.halted"]
    assert halted and halted[0]["cancelled_commands"] == 2


@pytest.mark.asyncio
async def test_halt_counter_increments():
    atom, ctx, db = await _ready()
    await ctx.handlers["emergency.halt"]({"reason": "A", "timestamp": TS})
    await ctx.handlers["emergency.halt"]({"reason": "B", "timestamp": TS})
    assert atom.halted_writes_count == 2


# ---------------------------------------------------------------- الصحة


@pytest.mark.asyncio
async def test_health_before_any_write():
    atom, ctx, db = await _ready()
    assert (await atom.health_check()).state.name in ("UNKNOWN", "HEALTHY", "DEGRADED")


@pytest.mark.asyncio
async def test_healthy_after_a_successful_write():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order())
    assert (await atom.health_check()).state.name == "HEALTHY"


# ------------------------------------------------------------- دورة الحياة


@pytest.mark.asyncio
async def test_schema_survives_reinitialize_on_same_file():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order(request_id="first"))

    fresh = MODULE.Atom()
    fresh_ctx = Ctx({**CONFIG, "db_path": db})
    await fresh.initialize(fresh_ctx)
    await fresh.start()
    await fresh_ctx.handlers["trading.final_decision"](_order(request_id="second"))

    assert [r["request_id"] for r in _rows(db)] == ["first", "second"]


@pytest.mark.asyncio
async def test_snapshot_restore_round_trip():
    atom, ctx, db = await _ready()
    await ctx.handlers["trading.final_decision"](_order())
    state = await atom.snapshot()
    fresh = MODULE.Atom()
    await fresh.restore(state)
    assert isinstance(state, dict)


# ── نبضة النظام: الطرف الآخر ينتظر دليل حياة ────────────────────────

def test_the_manifest_declares_a_heartbeat_interval():
    """الإكسبرت يقرأ display.updated_at ليعرف أن النظام حيّ، وكان الجدول
    فارغًا دائمًا: لا ذرّة تكتب فيه. فتقول الشاشة "لا إشارة من النظام"
    والنظام يقرأ التكّات ويحذفها في الملف نفسه.

    والصمت التجاري ليس صمت حياة: النبضة تُكتب سواء صدر أمر أو لا."""
    assert "heartbeat_interval_s" in CONFIG
    assert CONFIG["heartbeat_interval_s"] > 0


def test_the_schema_creates_the_display_table():
    """الإكسبرت ينشئ display حين يبدأ أولًا، لكن ترتيب الإقلاع غير مضمون:
    قد يقلع النظام قبل المنصّة."""
    assert "display" in MODULE._DISPLAY_SCHEMA
    assert "INSERT OR IGNORE INTO display" in MODULE._DISPLAY_SEED


@pytest.mark.asyncio
async def test_the_heartbeat_is_written_off_the_event_loop():
    """كتابة متزامنة على الناقل تجمّده حتى تنتهي، وقد قيست فجوة بلغت
    1858 مللي ثانية قبل نقل الإدراج إلى خيط. والنبضة تتكرّر كل ثانية،
    فهي أكثر ما يُكتب في الجسر."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "_write_heartbeat" in src
    beat = src[src.index("async def _beat_loop"):]
    assert "to_thread" in beat.split("async def")[1]


@pytest.mark.asyncio
async def test_a_heartbeat_row_carries_a_timestamp():
    atom, ctx, db = await _ready()
    atom._write_heartbeat(1785683145.0)
    rows = _rows(db, "SELECT updated_at FROM display WHERE id=1")
    assert rows and rows[0]["updated_at"] == 1785683145.0


@pytest.mark.asyncio
async def test_the_heartbeat_updates_rather_than_accumulates():
    """صفّ واحد لا سجلّ: النبضة حالة لا تاريخ، وتراكمها يملأ القاعدة."""
    atom, ctx, db = await _ready()
    for stamp in (1785683145.0, 1785683146.0, 1785683147.0):
        atom._write_heartbeat(stamp)
    rows = _rows(db, "SELECT updated_at FROM display")
    assert len(rows) == 1
    assert rows[0]["updated_at"] == 1785683147.0


@pytest.mark.asyncio
async def test_a_failed_heartbeat_does_not_stop_the_atom():
    """القفل حالة عابرة والطرف الآخر يكتب كل عُشر ثانية. ونبضة ضائعة
    تُعوَّض بعد ثانية، أمّا ذرّة ساقطة فتوقف الأوامر كلّها."""
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    atom._write_heartbeat(1785683145.0)
    assert atom.heartbeat_failed >= 1


# ── الفشل يحمل هوية الأمر ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_a_write_failure_names_the_order_that_failed():
    """كان الفشل يُنشر بسببه وحده: {"reason": ...}.

    فمن يتتبّع حالة الأمر لا يعرف أي أمر فشل، ويبقى الأمر معلّقًا في
    "مُرسَل" بلا نهاية — لا يُغلق ولا يُعاد."""
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    await ctx.handlers["trading.final_decision"]({
        "request_id": "r-42", "symbol": "USTEC", "action": "OPEN",
        "side": "BUY", "volume": 0.5, "timestamp": TS})
    failed = [p for n, p in ctx.published
              if n == "platform.brain_signal.write_failed"]
    assert failed
    assert failed[-1]["request_id"] == "r-42"
    assert failed[-1]["symbol"] == "USTEC"
    assert "reason" in failed[-1]


@pytest.mark.asyncio
async def test_the_stamp_travels_with_the_failure():
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    await ctx.handlers["trading.final_decision"]({
        "request_id": "r-43", "symbol": "USTEC", "action": "OPEN",
        "side": "BUY", "volume": 0.5, "timestamp": TS})
    failed = [p for n, p in ctx.published
              if n == "platform.brain_signal.write_failed"][-1]
    assert failed["timestamp"] == TS


@pytest.mark.asyncio
async def test_a_write_failure_is_logged_not_only_published():
    """الفشل يُنشر حدثًا ولا يُكتب في السجلّ: فمن يقرأ السجلّ يرى أمرًا
    خرج من 553 ولا يرى لماذا لم يصل الجسر.

    وقيس على تشغيل حيّ: أمر واحد أُرسل، صفر صفوف في الطابور، ولا سطر
    واحد يقول السبب — واستغرق كشفه تشغيل ذرّة منفردة."""
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    logged = []
    atom._context.logger.error = lambda *a, **k: logged.append(str(a))
    await ctx.handlers["trading.final_decision"]({
        "request_id": "r-9", "symbol": "USTEC", "action": "OPEN",
        "side": "BUY", "volume": 0.5, "timestamp": TS})
    assert logged, "الفشل يجب أن يُسجَّل"
    assert any("r-9" in entry or "USTEC" in entry for entry in logged)


@pytest.mark.asyncio
async def test_no_order_yet_is_not_a_fault():
    """كانت تعلن UNKNOWN قبل أوّل أمر، والنواة تعدّه فشلًا: عتبتان ثم
    إعادة تشغيل، وثلاث إعادات ثم إزالة.

    فالذرّة التي لم يصلها أمر بعدُ — وهو الوضع الطبيعي في أوّل دقائق
    التشغيل — تُقتل قبل أن يصلها. وقيس على تشغيل حيّ: 553 أرسل أمرًا
    و601 كان قد أُعيد تشغيله مرّتين، فلم يُكتب شيء ولم يُسجَّل سبب."""
    atom, ctx, db = await _ready()
    status = await atom.health_check()
    assert status.state.name != "UNHEALTHY"
    assert status.state.name != "UNKNOWN"


@pytest.mark.asyncio
async def test_a_beating_heart_proves_the_bridge_is_writable():
    """النبضة تكتب في القاعدة نفسها كل ثانية: نجاحها دليل أن الذرّة حيّة
    وأن الملف قابل للكتابة — وهو ما تعنيه الصحّة هنا."""
    atom, ctx, db = await _ready()
    atom._write_heartbeat(1785683145.0)
    status = await atom.health_check()
    assert status.state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_a_failed_write_is_still_unhealthy():
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    await ctx.handlers["trading.final_decision"]({
        "request_id": "r-x", "symbol": "USTEC", "action": "OPEN",
        "side": "BUY", "volume": 0.5, "timestamp": TS})
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_one_locked_beat_does_not_condemn_the_atom():
    """القفل حالة عابرة: الإكسبرت يقرأ و618 يحذف والمغذّي يكتب، فنبضة
    تفشل ثم تنجح التي بعدها بعُشر ثانية.

    وكانت أوّل نبضة فاشلة تُبقي الذرّة معطوبة للأبد — عتبتان ثم إعادة،
    وثلاث إعادات ثم إزالة. وهي الذرّة الوحيدة التي توصل الأمر إلى
    المنصّة."""
    atom, ctx, db = await _ready()
    good = atom._db_path
    atom._db_path = "/nonexistent/dir/x.db"
    atom._write_heartbeat(1785683145.0)
    atom._db_path = good
    atom._write_heartbeat(1785683146.0)
    status = await atom.health_check()
    assert status.state.name == "HEALTHY"


@pytest.mark.asyncio
async def test_beats_failing_in_a_row_are_a_fault():
    """أمّا الفشل المتّصل فعطل حقيقي: الجسر لا يُكتب، والأوامر لن تصل."""
    atom, ctx, db = await _ready()
    atom._db_path = "/nonexistent/dir/x.db"
    for stamp in range(1785683145, 1785683150):
        atom._write_heartbeat(float(stamp))
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_a_failed_command_does_not_stick_after_a_good_beat():
    """كتابة أمر فشلت مرّة لا تُبقي الذرّة معطوبة: 554 يعلنها رفضًا و562
    يعيدها، والنبضة التالية تثبت أن الجسر يُكتب."""
    atom, ctx, db = await _ready()
    good = atom._db_path
    atom._db_path = "/nonexistent/dir/x.db"
    await ctx.handlers["trading.final_decision"]({
        "request_id": "r-1", "symbol": "USTEC", "action": "OPEN",
        "side": "BUY", "volume": 0.5, "timestamp": TS})
    assert (await atom.health_check()).state.name == "UNHEALTHY"
    atom._db_path = good
    atom._write_heartbeat(1785683146.0)
    # متدهورة لا معطوبة: الجسر يُكتب — النبضة تثبت ذلك — لكنّ أمرًا
    # بعينه لم يصل، و554 أعلنه رفضًا و562 يعيده. والنواة تعدّ UNHEALTHY
    # وحدها فشلًا، فالذرّة تبقى تعمل وتصل الحقيقة كاملة.
    assert (await atom.health_check()).state.name == "DEGRADED"
