"""
601 — كاتب جسر العقل (Brain Bridge Writer) — v2.1.0

تصميم سابق (Connection Manager، فتح اتصال Python مستقل لـMT5) ألغي
كليًا — قيد منصة حقيقي: MT5 لا تقبل غير اتصال واحد. الـEA (داخل MT5
نفسها) هي الاتصال الوحيد؛ بايثون لا "تتصل" بالمنصة إطلاقًا، فقط تكتب
قرارها الجاهز لملف SQLite مشترك (`nq_brain.db`)، والـEA تقرأه دوريًا
من جهتها (`ReadQuantBrainSignal()`، موثَّق بـea_watchdog_fix.md).

سكيما الجدول مطابقة **حرفيًا** لاستعلام الـEA الفعلي:
جدول `commands` (طابور أوامر يلتقطه الإكسبرت بالحالة PENDING) ونبضة `display.updated_at`

v2.1.0 — سدّ فجوة مؤكَّدة: بلا هذا التعديل، emergency.halt (516)
كانت توقف 601 عن الكتابة **بس بلا إعلام صريح فوري** — الـEA كانت تعتمد
فقط على حارس الصمت (ea_watchdog_fix.md، مهلة 15 ثانية افتراضيًا) لتكتشف
الانقطاع وتفرض NEUTRAL بنفسها. الآن: 601 تشترك بـemergency.halt مباشرة
وتكتب NEUTRAL (confidence=0, stability=0) **فورًا** بنفس الدورة —
يقلّل زمن الاستجابة من "حتى 15 ثانية" لـ"فورية عمليًا"، الحارس يبقى
شبكة أمان ثانية لا الآلية الوحيدة.

لا تبعية خارجية: sqlite3 من المكتبة القياسية.
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DB_TIMEOUT_S = 5.0

EVENT_FINAL_DECISION = "trading.final_decision"


_SCHEMA = """
CREATE TABLE IF NOT EXISTS commands (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id   TEXT    NOT NULL,
    action       TEXT    NOT NULL,
    symbol       TEXT    NOT NULL,
    side         TEXT,
    volume       REAL,
    price        REAL,
    stop_loss    REAL,
    take_profit  REAL,
    ticket       INTEGER,
    trail_dist   REAL,
    trail_step   REAL,
    params_json  TEXT,
    status       TEXT    NOT NULL DEFAULT 'PENDING',
    result       TEXT,
    created_at   REAL    NOT NULL,
    taken_at     REAL,
    done_at      REAL
)
"""

_INDEX = "CREATE INDEX IF NOT EXISTS idx_cmd_status ON commands(status, id)"

# جدول النبضة: صفّ واحد يحمل الطابع، لا سجلّ يتراكم. الطرف الآخر ينشئه
# أيضًا، لكن ترتيب الإقلاع غير مضمون — فقد يقلع النظام قبل المنصّة.
_DISPLAY_SCHEMA = """
CREATE TABLE IF NOT EXISTS display (
    id           INTEGER PRIMARY KEY CHECK (id = 1),
    daily_pct    REAL,
    wins         INTEGER,
    losses       INTEGER,
    trades       INTEGER,
    open_trades  INTEGER,
    kill_switch  TEXT,
    updated_at   REAL
)
"""
_DISPLAY_SEED = "INSERT OR IGNORE INTO display (id) VALUES (1)"
_HEARTBEAT_SQL = "UPDATE display SET updated_at = ? WHERE id = 1"

# كم نبضة متّصلة فاشلة قبل إعلان العطل. أقلّ من ذلك قفلٌ عابر: الطرف
# الآخر يكتب كل عُشر ثانية، والنبضة تتكرّر كل ثانية.
_BEAT_FAILURES_BEFORE_FAULT = 3

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last: Exception | None = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            if "locked" not in str(exc) and "busy" not in str(exc):
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("lock")



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._db_path = "nq_brain.db"
        self._beat_interval = 0.0
        self._beat_task: asyncio.Task | None = None
        self.heartbeat_written = 0
        self.heartbeat_failed = 0
        self._beats_failing = 0
        self.last_write_success: bool | None = None
        self.last_write_at: float | None = None
        self.last_write_error: str | None = None
        self.halted_writes_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._db_path = _resolve_db(str(context.config.get("db_path", "nq_brain.db")))
        self._beat_interval = float(context.config["heartbeat_interval_s"])
        # الحدث الفعلي الذي تُصدره سلسلة القرار (467). الاسم القديم
        # decision.signal.ready كان افتراضًا موثَّقًا في v2.1 ولم ينشره
        # أحد قط — يبقى مسموعًا للتوافق لو ظهر ناشر له لاحقًا.
        # العقد الرسمي للقرار النهائي قبل التنفيذ هو trading.final_decision:
        # الملحق الموحد (قاموس الأحداث: الناشر 553، المستقبل 601) وورقة بناء
        # 550. الاسم القديم decision.signal.ready كان افتراضًا من هذه الذرة
        # نفسها ولا وجود له في أي وثيقة، وPROJECT_STATE يصنّفه بندَ تنظيف.
        #
        # ولم يعد يُشترك في execution.order.requested: الطريق من 467 إلى هنا
        # مباشرةً كان يتخطّى بناء الأمر (551) وبوابة التوقف (553)، فيصل الجسر
        # أمر بلا سعر ولا وقف ولا هدف، ويظل يصل بعد emergency.halt فيكتب فوق
        # NEUTRAL. الإبقاء على الاشتراكَين معًا يكتب كل قرار مرتين — مقيسًا.
        context.subscribe(EVENT_FINAL_DECISION, self._on_final_decision)
        context.subscribe("emergency.halt", self._on_emergency_halt)
        self._ensure_schema()
        context.logger.info("BrainBridgeWriter(601) تمت تهيئته (db_path=%s)", self._db_path)

    def _ensure_schema(self) -> bool:
        """يُرجع نجاحه ولا يرمي.

        استثناءٌ من initialize أو start يمنع إقلاع الذرة كليًّا: مسار قاعدة
        خاطئ كان يُسقطها بدل أن يُعلن نفسه في الحالة الصحية. والمنصة تلتقط
        الفشل لاحقًا عند أول كتابة، وهناك مكانه.
        """
        try:
            conn = _bridge_connect(self._db_path, read_only=False)
            try:
                conn.execute(_SCHEMA)
                conn.execute(_INDEX)
                conn.execute(_DISPLAY_SCHEMA)
                conn.execute(_DISPLAY_SEED)
                conn.commit()
            finally:
                conn.close()
            return True
        except Exception as exc:  # noqa: BLE001
            self.last_write_success = False
            self.last_write_error = str(exc)
            return False

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("BrainBridgeWriter(601) بدأ الاستماع لـdecision.signal.ready وemergency.halt")
        self._beat_task = asyncio.create_task(self._beat_loop())

    def _now(self) -> float:
        """Wall clock, deliberately, and not the system's official time.

        Everywhere else an atom must take its stamp from the clock atom. Here
        the beat is compared against TimeCurrent() inside the terminal, which
        is the machine's own clock — so a beat stamped with an NTP-corrected
        time would read as drift to the far side and the system would look
        silent while it was writing.

        The stamp answers one question only: how long since this process last
        touched the file.
        """
        return time.time()

    def _write_heartbeat(self, stamp: float) -> None:
        """The blocking half of the beat, run off the event loop.

        A single row updated in place, never a log: the beat is a state, not
        a history, and accumulating it would fill the bridge database with
        one row per second for nothing.

        Failure is counted and swallowed. A lock is a passing state — the far
        side writes every hundred milliseconds — and a lost beat is made up a
        second later, while a raised exception would take down the atom that
        carries every order to the platform.
        """
        try:
            conn = _bridge_connect(self._db_path, read_only=False)
            try:
                conn.execute(_DISPLAY_SCHEMA)
                conn.execute(_DISPLAY_SEED)
                conn.execute(_HEARTBEAT_SQL, (float(stamp),))
                conn.commit()
            finally:
                conn.close()
            self.heartbeat_written += 1
            self._beats_failing = 0
        except Exception:  # noqa: BLE001
            self.heartbeat_failed += 1
            self._beats_failing += 1

    async def _beat_loop(self) -> None:
        """Proof of life for the far side.

        The expert advisor reads display.updated_at to know this process is
        alive. Opening the database proves nothing about it: the advisor is
        the one that creates the file. Before this loop the terminal read
        "no signal from the system" while the system was consuming ticks out
        of that same file every tick.

        It beats whether or not a decision was made — commercial silence is
        not the silence of death.
        """
        loop = asyncio.get_running_loop()
        deadline = loop.time()
        while True:
            try:
                deadline += self._beat_interval
                if deadline <= loop.time():
                    # تخطّت الحلقةُ موعدَها: تُعاد الجدولة من الآن بدل أن
                    # تدور بلا نوم تلاحق موعدًا فات.
                    deadline = loop.time() + self._beat_interval
                await asyncio.sleep(max(deadline - loop.time(), 0.0))
                await asyncio.to_thread(self._write_heartbeat, self._now())
            except asyncio.CancelledError:
                return

    async def stop(self) -> None:
        if self._beat_task is not None:
            self._beat_task.cancel()
            try:
                await self._beat_task
            except asyncio.CancelledError:
                pass
            self._beat_task = None
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        """Health here means the bridge is writable, not that an order came.

        It used to report UNKNOWN before the first command, and the kernel
        counts that against the failure threshold: two checks, a restart,
        three restarts, removed. So an atom in its perfectly normal opening
        state — no decision has been taken yet — was killed before one could
        arrive. Measured on a live run: 553 sent an order while 601 had
        already been restarted twice, so nothing was written and no reason
        was recorded.

        The heartbeat is the evidence. It writes into the same file every
        second, so a beat that lands proves both that this atom is running
        and that the file accepts writes — which is all health can mean
        before any order exists.
        """
        details = {"commands_written": self.last_write_success is True,
                   "heartbeats": self.heartbeat_written,
                   "heartbeat_failures": self.heartbeat_failed,
                   "beats_failing_in_a_row": self._beats_failing}

        # النبضة الأحدث هي الحكم، لا وجود فشل في التاريخ. القفل حالة
        # عابرة — الإكسبرت يقرأ و618 يحذف والمغذّي يكتب — فنبضة تفشل ثم
        # تنجح التي بعدها بعُشر ثانية. وكانت الأولى الفاشلة تُبقي الذرّة
        # معطوبة للأبد: عتبتان ثم إعادة، وثلاث إعادات ثم إزالة، وهي
        # الوحيدة التي توصل الأمر إلى المنصّة.
        if self._beats_failing >= _BEAT_FAILURES_BEFORE_FAULT:
            return HealthStatus(
                state=HealthState.UNHEALTHY,
                message="النبضة لا تصل الجسر منذ %d محاولة" % self._beats_failing,
                details=details)
        if self.last_write_success is False and not self.heartbeat_written:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=f"آخر كتابة فشلت: {self.last_write_error}",
                                details=details)
        if self.last_write_success is False:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"أمر لم يُكتب: {self.last_write_error}", details=details)
        if self.last_write_success:
            return HealthStatus(
                state=HealthState.HEALTHY,
                message=f"آخر كتابة ناجحة عند {self.last_write_at:.0f}",
                details=details)
        if self.heartbeat_written:
            return HealthStatus(state=HealthState.HEALTHY,
                                message="النبضة تصل — لا أمر بعد",
                                details=details)
        return HealthStatus(state=HealthState.DEGRADED,
                            message="لا نبضة ولا أمر بعد", details=details)

    async def snapshot(self) -> dict:
        return {
            "last_write_success": self.last_write_success,
            "last_write_at": self.last_write_at,
            "last_write_error": self.last_write_error,
            "halted_writes_count": self.halted_writes_count,
        }

    async def restore(self, state: dict) -> None:
        self.last_write_success = state.get("last_write_success")
        self.last_write_at = state.get("last_write_at")
        self.last_write_error = state.get("last_write_error")
        self.halted_writes_count = state.get("halted_writes_count", 0)

    # ------------------------------------------------------------------


    async def _on_final_decision(self, payload: dict) -> None:
        """العقد الرسمي: trading.final_decision من 553.

        الحقول الثلاثة إلزامية ولا تُستبدل بقيم افتراضية — 553 تُسقط أي أمر
        ناقصها قبل أن يصل إلى هنا، ورقمٌ لم يقسه أحد لا يسوق صفقة.
        """
        symbol = payload.get("symbol")
        side = payload.get("side") or payload.get("bias")
        if not symbol or side not in ("BUY", "SELL"):
            await self._record_failure(
                "أمر بلا رمز أو باتجاه غير معروف: symbol=%r side=%r" % (symbol, side),
                payload)
            return

        # الحجم إلزامي: أمرٌ بلا حجم لا يُنفَّذ، وتعويضه برقم من عندنا يعني
        # حجمًا لم يقرّره أحد. 551 يبنيه، و553 يمرّره — فغيابه هنا خلل في
        # المسار لا نقصٌ يُسدّ.
        if payload.get("volume") in (None, 0):
            await self._record_failure(
                "أمر بلا حجم — request_id=%r" % payload.get("request_id"), payload)
            return

        # الاتجاه المحسوم يُمرَّر، لا الحقل الخام: كان التحقق يقبل bias
        # بديلًا عن side ثم تكتب الدالة side وحده فينزل NULL.
        await self._write_command({**payload, "side": side},
                                  event_name="platform.brain_signal.written")

    async def _on_emergency_halt(self, payload: dict) -> None:
        """التوقف الطارئ: تُلغى الأوامر التي لم تُلتقط بعد.

        NEUTRAL كانت تعني شيئًا حين كان الجدول رأيًا يُقرأ آخر صف منه.
        مع طابور أوامر لا معنى لها — أمرٌ مكتوبٌ ينتظر التنفيذ، ولا
        يبطله رأيٌ يُكتب بعده. فالإلغاء صريح: كل أمر ما زال PENDING
        يُعلَّم CANCELLED فلا يلتقطه المنفِّذ.

        وما التُقط فعلًا (TAKEN) لا يُلمس: إمّا نُفّذ عند الوسيط أو هو في
        الطريق، وتعليمه ملغيًا يكذب على السجل. وأمرٌ جديد لن يصل أصلًا
        لأن بوابة 553 تُغلق على الحدث نفسه.

        ملاحظة صريحة: هذا يمنع أوامر جديدة ولا يغلق المراكز القائمة.
        إغلاقها قرارٌ لم يُتّخذ بعد، ولا يُخترع هنا.
        """
        self.halted_writes_count += 1
        cancelled = 0
        try:
            conn = _bridge_connect(self._db_path, read_only=False)
            try:
                cursor = conn.execute(
                    "UPDATE commands SET status='CANCELLED',"
                    " result='EMERGENCY_HALT', done_at=? WHERE status='PENDING'",
                    (time.time(),),
                )
                cancelled = cursor.rowcount
                conn.commit()
            finally:
                conn.close()
            self.last_write_at = time.time()
        except Exception as exc:  # noqa: BLE001
            await self._record_failure(str(exc))

        if self._context is not None:
            await self._context.publish("platform.brain_signal.halted", {
                "reason": payload.get("reason"),
                "cancelled_commands": cancelled,
            })
        if self._context is not None:
            self._context.logger.critical(
                "BrainBridgeWriter(601): emergency.halt استُلِم (reason=%s) — NEUTRAL كُتبت فورًا",
                payload.get("reason"),
            )

    def _insert_command(self, row: tuple) -> None:
        """The blocking half, run off the event loop.

        MT5 holds an exclusive lock on nq_brain.db while it reads. Calling
        sqlite3 straight from the handler froze the whole bus for the length
        of that lock: measured at 1858ms against 21ms through a thread. Every
        atom stopped processing ticks and risk checks for the duration.

        WAL lets a reader and a writer work at once, which is exactly the
        shape here: MT5 reads while this writes.
        """
        conn = _bridge_connect(self._db_path, read_only=False)
        try:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute(
                "INSERT INTO commands (request_id, action, symbol, side, volume,"
                " price, stop_loss, take_profit, status, created_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)", row)
            conn.commit()
        finally:
            conn.close()

    async def _write_command(self, order: dict, event_name: str) -> None:
        """يُدخل أمرًا واحدًا في الطابور.

        صفٌّ لكل أمر لا صفٌّ يُدهس: أمر على الذهب لا يستبدل أمرًا على
        ناسداك، وسطرٌ واحد يتحدّث كان يبتلع كل أمر لم يُقرأ بعد. والتنظيف
        بالاستهلاك — الطرف المنفِّذ يعلّم الحالة، والنظام يحذف المنتهي —
        فلا ينمو الطابور ولا يصير سجلًّا.

        وتُكتب القيم كما وصلت: الحجم والوقف والهدف بناها 551، وإعادة
        حسابها في أي نقطة بعده تعني رقمين مختلفين لأمر واحد.
        """
        if self._context is None:
            return
        row = (
            str(order.get("request_id") or ""),
            str(order.get("action") or "OPEN"),
            str(order.get("symbol") or ""),
            order.get("side"),
            order.get("volume"),
            order.get("reference_price"),
            order.get("stop_loss"),
            order.get("take_profit"),
            time.time(),
        )
        try:
            await asyncio.to_thread(self._insert_command, row)
            self.last_write_success = True
            self.last_write_at = time.time()
            self.last_write_error = None
            await self._context.publish(event_name, dict(order))
        except Exception as exc:  # noqa: BLE001
            await self._record_failure(str(exc), order)

    async def _record_failure(self, reason: str,
                              order: dict[str, Any] | None = None) -> None:
        """A failure carries the identity of the order that failed.

        It used to publish the reason alone. Whoever tracks order state could
        not tell which order died, so the order sat in "sent" forever: never
        closed, never retried. The identity is what lets 554 close it and 562
        decide whether to try again.

        The reason travels raw, unclassified: 561 owns the classification of
        retryable against terminal, and deciding it here would give two
        answers to one question.
        """
        self.last_write_success = False
        self.last_write_error = reason
        if self._context is None:
            return
        body: dict[str, Any] = {"reason": reason}
        if order:
            for field in ("request_id", "symbol", "side", "action", "volume"):
                if order.get(field) is not None:
                    body[field] = order[field]
            stamp = order.get("timestamp")
            if isinstance(stamp, (int, float)):
                body["timestamp"] = stamp
        await self._context.publish("platform.brain_signal.write_failed", body)
        # ويُكتب في السجلّ أيضًا. الحدث وحده يترك القارئ يرى أمرًا خرج من
        # 553 ولا يرى لماذا لم يصل الطابور — وكشفُ السبب استغرق تشغيل
        # ذرّة منفردة بينما الجواب كان في يد هذه الذرّة.
        self._context.logger.error(
            "601 لم يكتب الأمر %s على %s: %s",
            body.get("request_id"), body.get("symbol"), reason)

