"""Tests for atom 619 - Account State Reader."""

from __future__ import annotations

import ast
import asyncio
import importlib.util
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

ATOM_DIR = Path(__file__).resolve().parents[1]
_MODULE_NAME = "_atom619"


def _load():
    spec = importlib.util.spec_from_file_location(_MODULE_NAME, ATOM_DIR / "atom.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[_MODULE_NAME] = module
    spec.loader.exec_module(module)
    return module


MODULE = _load()
MANIFEST = yaml.safe_load((ATOM_DIR / "manifest.yaml").read_text(encoding="utf-8"))
CONFIG = MANIFEST["config"]


class Ctx:
    atom_id = 619

    class logger:
        info = warning = error = debug = critical = staticmethod(lambda *a, **k: None)

    def __init__(self, config):
        self.config = dict(config)
        self.published = []
        self.handlers = {}

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def subscribe(self, name, handler):
        self.handlers[name] = handler


def _make_db(rows=1, **over):
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute(
        "CREATE TABLE account (id INTEGER PRIMARY KEY, balance REAL, equity REAL,"
        " margin REAL, free_margin REAL, margin_level REAL, currency TEXT,"
        " leverage INTEGER, open_count INTEGER, updated_at REAL, account_id TEXT)"
    )
    if rows:
        v = {"balance": 1000.0, "equity": 1020.0, "margin": 50.0, "free_margin": 970.0,
             "margin_level": 2040.0, "currency": "USD", "leverage": 500,
             "open_count": 1, "updated_at": 1785600000.0,
             "account_id": "123456"}
        v.update(over)
        conn.execute(
            "INSERT INTO account VALUES (1,?,?,?,?,?,?,?,?,?,?)",
            (v["balance"], v["equity"], v["margin"], v["free_margin"], v["margin_level"],
             v["currency"], v["leverage"], v["open_count"], v["updated_at"],
             v["account_id"]))
    conn.commit()
    conn.close()
    return path


async def _ready(db_path, **over):
    cfg = {**CONFIG, "db_path": db_path}
    cfg.update(over)
    atom = MODULE.Atom()
    ctx = Ctx(cfg)
    await atom.initialize(ctx)
    return atom, ctx


def _states(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_OUT]


# ---------------------------------------------------------------- structure


def test_syntax_ok():
    ast.parse((ATOM_DIR / "atom.py").read_text(encoding="utf-8"))


def test_no_print():
    assert "print(" not in (ATOM_DIR / "atom.py").read_text(encoding="utf-8")


def test_manifest_matches_code():
    assert MANIFEST["id"] == 619
    # مخرَجان: حالة الحساب، وحالة المنصّة التي يتداول داخلها. والفصل
    # مقصود — الأولى تقول كم، والثانية تقول هل يمكن التصرّف أصلًا.
    assert MANIFEST["publishes"] == [MODULE.EVENT_OUT, MODULE.EVENT_TERMINAL]
    assert MANIFEST["subscribes"] == []


def test_reads_only_never_writes():
    """Settled decision: the account table belongs to the platform arm.
    A second writer invites contradiction, so the connection is mode=ro."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "mode=ro" in src
    for verb in ("INSERT", "UPDATE", "DELETE", "DROP"):
        assert verb not in src


def test_no_clock_reading():
    """3 and 806 are the only clock owners in this platform."""
    src = (ATOM_DIR / "atom.py").read_text(encoding="utf-8")
    assert "time.time()" not in src
    assert "datetime.now" not in src


# ---------------------------------------------------------------- reading


@pytest.mark.asyncio
async def test_publishes_the_account_snapshot():
    db = _make_db()
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()
    state = _states(ctx)[0]
    assert state["balance"] == 1000.0
    assert state["equity"] == 1020.0
    assert state["margin"] == 50.0
    assert state["margin_level"] == 2040.0
    assert state["measured_at"] == 1785600000.0


@pytest.mark.asyncio
async def test_balance_is_present_for_percentage_math():
    """The reason this atom exists. 517 needs a reference to turn an absolute
    loss into a percentage, and 516 refuses to compute one from a raw number -
    so without a balance the kill switch never fires."""
    db = _make_db()
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()
    assert _states(ctx)[0]["balance"] > 0


@pytest.mark.asyncio
async def test_unchanged_state_is_not_republished():
    db = _make_db()
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()
    await atom._read_once()
    await atom._read_once()
    assert len(_states(ctx)) == 1


@pytest.mark.asyncio
async def test_changed_state_is_republished():
    db = _make_db()
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()

    conn = sqlite3.connect(db)
    conn.execute("UPDATE account SET balance=990.0, updated_at=1785600060 WHERE id=1")
    conn.commit()
    conn.close()

    await atom._read_once()
    states = _states(ctx)
    assert len(states) == 2
    assert states[1]["balance"] == 990.0


@pytest.mark.asyncio
async def test_missing_file_does_not_raise():
    atom, ctx = await _ready("/nonexistent/path/nq.db")
    atom._running = True
    await atom._read_once()
    assert _states(ctx) == []
    assert atom.failure_count == 1


@pytest.mark.asyncio
async def test_missing_table_does_not_raise():
    path = tempfile.mktemp(suffix=".db")
    sqlite3.connect(path).close()
    atom, ctx = await _ready(path)
    atom._running = True
    await atom._read_once()
    assert _states(ctx) == []


@pytest.mark.asyncio
async def test_empty_table_publishes_nothing():
    db = _make_db(rows=0)
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()
    assert _states(ctx) == []


# ---------------------------------------------------------------- health


@pytest.mark.asyncio
async def test_health_unhealthy_before_start():
    atom, _ = await _ready(_make_db())
    assert (await atom.health_check()).state.name == "UNHEALTHY"


@pytest.mark.asyncio
async def test_missing_bridge_is_degraded_not_unhealthy():
    """Settled decision: an absent bridge is a starved input, not a fault here.
    Restarting this atom does not make the platform arm write."""
    atom, _ = await _ready("/nonexistent/path/nq.db")
    atom._running = True
    await atom._read_once()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_no_data_yet_is_degraded():
    db = _make_db(rows=0)
    atom, _ = await _ready(db)
    atom._running = True
    await atom._read_once()
    assert (await atom.health_check()).state.name == "DEGRADED"


@pytest.mark.asyncio
async def test_healthy_after_a_read():
    db = _make_db()
    atom, _ = await _ready(db)
    atom._running = True
    await atom._read_once()
    assert (await atom.health_check()).state.name == "HEALTHY"


# ---------------------------------------------------------------- lifecycle


@pytest.mark.asyncio
async def test_stop_then_start_still_reads():
    db = _make_db()
    atom, ctx = await _ready(db)
    await atom.start()
    await asyncio.sleep(0)
    await atom.stop()
    assert atom.failure_count == 0
    await atom.start()
    assert atom._running is True
    await atom.stop()


@pytest.mark.asyncio
async def test_snapshot_prevents_republish_after_restore():
    """Without the saved stamp, a restarted atom republishes state every
    consumer already has, the moment it comes back."""
    db = _make_db()
    atom, ctx = await _ready(db)
    atom._running = True
    await atom._read_once()
    state = await atom.snapshot()

    fresh = MODULE.Atom()
    fresh_ctx = Ctx({**CONFIG, "db_path": db})
    await fresh.initialize(fresh_ctx)
    await fresh.restore(state)
    fresh._running = True
    await fresh._read_once()
    assert [p for n, p in fresh_ctx.published if n == MODULE.EVENT_OUT] == []


# ── حالة المنصّة: أربعة أسئلة منفصلة ────────────────────────────────

def _make_db_v2(**over):
    """قاعدة بأعمدة الإكسبرت الجديدة."""
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute(
        "CREATE TABLE account (id INTEGER PRIMARY KEY, balance REAL, equity REAL,"
        " margin REAL, free_margin REAL, margin_level REAL, currency TEXT,"
        " leverage INTEGER, open_count INTEGER, updated_at REAL,"
        " connected INTEGER, trade_allowed INTEGER, expert_allowed INTEGER,"
        " bridge_beat REAL, account_id TEXT)")
    v = {"balance": 1000.0, "equity": 1020.0, "margin": 50.0, "free_margin": 970.0,
         "margin_level": 2040.0, "currency": "USD", "leverage": 500,
         "open_count": 1, "updated_at": 1785600000.0,
         "connected": 1, "trade_allowed": 1, "expert_allowed": 1,
         "bridge_beat": 1785683145.0, "account_id": "123456"}
    v.update(over)
    conn.execute("INSERT INTO account VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                 tuple(v[k] for k in ("balance", "equity", "margin", "free_margin",
                                      "margin_level", "currency", "leverage",
                                      "open_count", "updated_at", "connected",
                                      "trade_allowed", "expert_allowed",
                                      "bridge_beat", "account_id")))
    conn.commit(); conn.close()
    return path


def _terminal(ctx):
    return [p for n, p in ctx.published if n == MODULE.EVENT_TERMINAL]


def test_the_platform_columns_are_read():
    """كان النظام يعرف رصيده ولا يعرف شيئًا عن المنصّة التي يتداول
    داخلها: هل الوسيط متّصل؟ هل التداول الآلي مسموح؟ هل الجسر يكتب؟

    والفرق بين الأول والثالث هو الفرق بين "نم مرتاحًا" و"انهض"."""
    for column in ("connected", "trade_allowed", "expert_allowed", "bridge_beat"):
        assert column in MODULE._PLATFORM_COLUMNS


def test_the_terminal_state_event_is_declared():
    assert MODULE.EVENT_TERMINAL in MANIFEST["publishes"]


@pytest.mark.asyncio
async def test_the_terminal_state_is_published_beside_the_account():
    atom, ctx = await _ready(_make_db_v2())
    await atom._read_once()
    states = _terminal(ctx)
    assert states
    assert states[-1]["connected"] is True
    assert states[-1]["trade_allowed"] is True
    assert states[-1]["bridge_beat"] == 1785683145.0


@pytest.mark.asyncio
async def test_a_halted_terminal_is_told_apart_from_a_disconnected_one():
    """الحالتان توقفان التنفيذ، والفعل المطلوب مختلف تمامًا: الأولى قرار
    المالك، والثانية عطل يحتاج تدخّلًا."""
    atom, ctx = await _ready(_make_db_v2(trade_allowed=0))
    await atom._read_once()
    halted = _terminal(ctx)[-1]
    assert halted["connected"] is True and halted["trade_allowed"] is False

    atom2, ctx2 = await _ready(_make_db_v2(connected=0))
    await atom2._read_once()
    down = _terminal(ctx2)[-1]
    assert down["connected"] is False and down["trade_allowed"] is True


@pytest.mark.asyncio
async def test_an_old_database_without_the_platform_columns_still_reads():
    """قاعدة كتبها إكسبرت أقدم لا تحمل أعمدة المنصّة الأربعة. وحالة
    الحساب أهمّ من أن تسقط لأجل حقل إضافي — بخلاف الهوية، فبلا هوية
    يُرفض الصفّ كلّه."""
    atom, ctx = await _ready(_make_db())
    await atom._read_once()
    assert _states(ctx)


# ── هوية الحساب: ثلاثة حقول لا واحد ─────────────────────────────────

def _make_db_v3(**over):
    """قاعدة بأعمدة الهوية التي يكتبها الإكسبرت."""
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute(
        "CREATE TABLE account (id INTEGER PRIMARY KEY, balance REAL, equity REAL,"
        " margin REAL, free_margin REAL, margin_level REAL, currency TEXT,"
        " leverage INTEGER, open_count INTEGER, updated_at REAL,"
        " connected INTEGER, trade_allowed INTEGER, expert_allowed INTEGER,"
        " bridge_beat REAL, account_id TEXT, broker TEXT, account_server TEXT)")
    v = {"balance": 1000.0, "equity": 1020.0, "margin": 50.0, "free_margin": 970.0,
         "margin_level": 2040.0, "currency": "USD", "leverage": 500,
         "open_count": 1, "updated_at": 1785600000.0,
         "connected": 1, "trade_allowed": 1, "expert_allowed": 1,
         "bridge_beat": 1785683145.0, "account_id": "123456",
         "broker": "ICMarkets", "account_server": "ICMarkets-Live02"}
    v.update(over)
    conn.execute("INSERT INTO account VALUES (1," + ",".join("?" * 16) + ")",
                 tuple(v[k] for k in ("balance", "equity", "margin", "free_margin",
                                      "margin_level", "currency", "leverage",
                                      "open_count", "updated_at", "connected",
                                      "trade_allowed", "expert_allowed",
                                      "bridge_beat", "account_id", "broker",
                                      "account_server")))
    conn.commit(); conn.close()
    return path


def test_the_identity_columns_are_read():
    """الحساب والوسيط والخادم ثلاثة أشياء مختلفة، ودمجها يعود مشكلة عند
    تعدّد المنصّات: provider يقول من أعطى السعر، وbroker من ينفّذ،
    وaccount_id أي حساب عنده."""
    for column in ("account_id", "broker", "account_server"):
        assert column in MODULE._IDENTITY_COLUMNS


@pytest.mark.asyncio
async def test_the_account_state_carries_its_identity():
    atom, ctx = await _ready(_make_db_v3())
    await atom._read_once()
    state = _states(ctx)[-1]
    assert state["account_id"] == "123456"
    assert state["broker"] == "ICMarkets"
    assert state["server"] == "ICMarkets-Live02"


@pytest.mark.asyncio
async def test_the_terminal_state_carries_the_account_too():
    """حالة المنصّة بلا هوية الحساب لا تقول أي حساب توقّف تداوله."""
    atom, ctx = await _ready(_make_db_v3())
    await atom._read_once()
    terminal = _terminal(ctx)[-1]
    assert terminal["account_id"] == "123456"


@pytest.mark.asyncio
async def test_a_row_without_an_account_id_publishes_nothing():
    """Fail Closed. النسبة لحساب افتراضي تعني حجمًا محسوبًا من حقوق
    حساب ومرسَلًا إلى آخر — بمال حقيقي وبلا أن يظهر عطل."""
    atom, ctx = await _ready(_make_db_v3(account_id=None))
    await atom._read_once()
    assert not _states(ctx)
    assert atom.no_identity_count == 1


@pytest.mark.asyncio
async def test_an_older_database_without_identity_is_refused_too():
    """قاعدة كتبها إكسبرت أقدم لا تحمل عمود الهوية. والقاعدة نفسها
    تسري: لا يُنسَب ما لا هوية له."""
    path = tempfile.mktemp(suffix=".db")
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE account (id INTEGER PRIMARY KEY, balance REAL,"
                 " equity REAL, margin REAL, free_margin REAL,"
                 " margin_level REAL, currency TEXT, leverage INTEGER,"
                 " open_count INTEGER, updated_at REAL)")
    conn.execute("INSERT INTO account VALUES (1,1000.0,1020.0,50.0,970.0,"
                 "2040.0,'USD',500,1,1785600000.0)")
    conn.commit(); conn.close()
    atom, ctx = await _ready(path)
    await atom._read_once()
    assert not _states(ctx)
