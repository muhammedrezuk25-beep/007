"""
619 - Account State Reader
==========================
Single responsibility: read the account snapshot the platform arm writes, and
publish it. Nothing else.

Why it exists: three limits in 516 have been inert since the day it was built -
`max_exposure_pct`, `max_leverage`, `max_margin_usage_pct`. Its own manifest
says so: "stored only - no actual check yet (no live data source)". The source
it was waiting for is the account table.

And a second, sharper gap it closes. Measured on live data from this platform:
517 publishes an absolute loss figure, 516 consumes a percentage, and 516 says
in its own code that it "does not compute a percentage from a raw number - it
receives loss_pct ready". So after three stopped-out trades the platform read
daily_loss = 0.0 and consecutive_losses = 0. **The kill switch could not fire.**
A percentage needs a balance, and the balance lives here.

Settled decisions:

  * It reads, it never writes. The account table belongs to the arm, and a
    second writer opens the door to contradiction. `mode=ro` enforces it.

  * It publishes only on change. The balance does not move except with a
    trade, so a periodic publisher would flood the bus with identical state.

  * Missing table is DEGRADED, not UNHEALTHY. Before the arm runs its first
    cycle there is no table, and that is a starved input - not a fault here.
    Restarting this atom does not create the table.

  * It computes nothing. Exposure and margin ratios belong to 516, which owns
    the limits. This atom carries numbers across the boundary and stops.
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "platform.account.state"
EVENT_TERMINAL = "platform.terminal_state"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_FILE = "BRIDGE_FILE_MISSING"
REASON_NO_TABLE = "ACCOUNT_TABLE_MISSING"
REASON_NEVER_READ = "NO_ACCOUNT_DATA_YET"
REASON_STALE = "ACCOUNT_DATA_STALE"

_COLUMNS = ("balance", "equity", "margin", "free_margin", "margin_level",
            "currency", "leverage", "open_count", "updated_at")

# أعمدة الإكسبرت عن المنصّة نفسها. تُقرأ منفصلة لأن قاعدة كتبها إكسبرت
# أقدم لا تحملها، وحالة الحساب أهمّ من أن تسقط لأجل حقل إضافي.
_PLATFORM_COLUMNS = ("connected", "trade_allowed", "expert_allowed", "bridge_beat")

# هوية الحساب. ثلاثة حقول لا واحد: provider يقول من أعطى السعر، وbroker
# من ينفّذ الصفقة، وaccount_id أي حساب عنده. سعرٌ من بايننس وتنفيذٌ عند
# وسيط MT5 وحسابٌ ممول عنده — ثلاثة أطراف، ودمجها يعود مشكلة عند تعدّد
# المنصّات.
_IDENTITY_COLUMNS = ("account_id", "broker", "account_server")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_LOCK_RETRIES = 3
_LOCK_BACKOFF_S = 0.05


def _resolve_db(configured: str) -> str:
    """Path from the environment first, config second.

    The configured path names a Windows user, so the same manifest points at
    nothing on a VPS or a second machine: Python would write one file while
    MT5 reads another, and the two would never meet. NQ_BRIDGE_DB overrides
    it without editing a manifest per host.

    MT5 puts the shared file under the terminal's Common\\Files directory,
    which is where the expert advisor opens it by bare name.
    """
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str, read_only: bool = True,
                    timeout_s: float = _CONNECT_TIMEOUT_S) -> sqlite3.Connection:
    """A bridge connection with one locking discipline for every atom.

    Three settings, each with a measured reason:

    busy_timeout — without it the call fails the instant it meets a lock
    instead of waiting. The MT5 side writes every hundred milliseconds and
    seven atoms here read the same file, so a collision is certain. Three
    seconds covers the longest transaction the expert advisor opens.

    WAL — lets a reader and a writer work at once. In the default rollback
    journal any reader blocks the writer, and that is what appears in the
    terminal log as "database is locked". journal_mode lives in the file
    header, so whichever side sets it first governs both.

    synchronous=NORMAL — drops the fsync from every commit, which is the
    longest thing holding a lock on Windows. Durability stays sufficient
    under WAL.
    """
    uri = "file:%s?mode=ro" % db_path if read_only else db_path
    connection = sqlite3.connect(uri, uri=read_only, timeout=timeout_s)
    connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    if not read_only:
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
    return connection


def _with_retry(operation, attempts: int = _LOCK_RETRIES):
    """Retries a lock, and only a lock.

    A lock is a passing state, not a fault: the other side is writing and
    will finish. A real error — missing file, different schema — is raised
    at once, because retrying it hides the fault three times and then
    reports it late.
    """
    last = None
    for attempt in range(attempts):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            text = str(exc)
            if "locked" not in text and "busy" not in text:
                raise
            last = exc
            time.sleep(_LOCK_BACKOFF_S * (attempt + 1))
    raise last if last is not None else sqlite3.OperationalError("locked")


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._task: asyncio.Task | None = None

        self._db_path = ""
        self._table = "account"
        self._poll_interval_s = 0.0
        self._stale_after_s = 0.0

        self._last_state: dict[str, Any] | None = None
        self._last_updated_at: float | None = None
        self._last_error = ""
        self.read_count = 0
        self.terminal_count = 0
        self.no_identity_count = 0
        self.publish_count = 0
        self.failure_count = 0

    # ------------------------------------------------------------------

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._stale_after_s = float(cfg["stale_after_s"])
        self._initialized = True
        context.logger.info("619 initialised on %s", self._db_path)

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        self._context.logger.info("619 started")

    async def stop(self) -> None:
        """Reversible. failure_count is cleared so a restarted atom is not
        immediately UNHEALTHY on counters from its previous life."""
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""
        if self._context is not None:
            self._context.logger.info(
                "619 stopped (reads=%d, published=%d)", self.read_count, self.publish_count
            )

    async def shutdown(self) -> None:
        await self.stop()

    # ------------------------------------------------------------------

    def _read_row(self) -> dict[str, Any] | None:
        """Read-only. The arm owns this table; a second writer invites conflict."""
        columns = ", ".join(_COLUMNS)
        connection = _bridge_connect(self._db_path, read_only=True)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(
                f"SELECT {columns} FROM {self._table} WHERE id = 1"
            )
            row = cursor.fetchone()
            if row is None:
                return None
            result = dict(row)
            # محاولة ثانية منفصلة: عمود مفقود يرمي، والحساب يجب أن يمرّ.
            # عمودًا عمودًا لا مجموعةً: قاعدة كتبها إكسبرت أقدم قد تحمل
            # بعض الأعمدة دون بعض، وقراءتها معًا تُسقط الموجود بسبب
            # المفقود.
            for column in _PLATFORM_COLUMNS + _IDENTITY_COLUMNS:
                try:
                    row_extra = connection.execute(
                        "SELECT %s FROM %s WHERE id = 1" % (column, self._table)
                    ).fetchone()
                except sqlite3.Error:
                    continue
                if row_extra is not None:
                    result[column] = row_extra[0]
            return result
        finally:
            connection.close()

    async def _read_once(self) -> None:
        if self._context is None:
            return
        try:
            row = await asyncio.to_thread(self._read_row)
        except sqlite3.Error as exc:
            self.failure_count += 1
            message = str(exc)
            # Before the arm's first cycle the file or table does not exist.
            # That is a starved input, not a fault in this atom.
            self._last_error = (
                REASON_NO_TABLE if "no such table" in message.lower()
                else REASON_NO_FILE if "unable to open" in message.lower()
                else message
            )
            self._context.logger.warning("619 read failed: %s", message)
            return

        self._last_error = ""
        if row is None:
            return
        account_id = row.get("account_id")
        if account_id in (None, ""):
            # Fail Closed. Attributing this to a default account would size a
            # position from one account's equity and send it to another — real
            # money, and no fault visible anywhere.
            self.no_identity_count += 1
            self._context.logger.warning(
                "619 refuses a row with no account_id")
            return
        self.read_count += 1
        await self._publish_terminal(row)

        updated_at = _to_float(row.get("updated_at"))
        # Publish on change only: the balance does not move except with a trade,
        # and republishing identical state floods every consumer for nothing.
        if updated_at is not None and updated_at == self._last_updated_at:
            return

        state: dict[str, Any] = {
            "balance": _to_float(row.get("balance")),
            "equity": _to_float(row.get("equity")),
            "margin": _to_float(row.get("margin")),
            "free_margin": _to_float(row.get("free_margin")),
            "margin_level": _to_float(row.get("margin_level")),
            "currency": row.get("currency"),
            "leverage": row.get("leverage"),
            "open_count": row.get("open_count"),
            # الهوية تسافر مع الحالة: من يقرؤها لا يحتاج أن يسأل عن
            # صاحبها. وbroker منفصل عن provider — الأوّل ينفّذ والثاني
            # يعطي السعر.
            "account_id": str(row.get("account_id")),
            "broker": row.get("broker"),
            "server": row.get("account_server"),
            # The arm's own stamp, not ours. core.event_bus stamps the event
            # itself, so the two are kept distinct: one is when the platform
            # measured, the other is when the event crossed the bus.
            "measured_at": updated_at,
        }

        self._last_state = state
        self._last_updated_at = updated_at
        self.publish_count += 1
        await self._context.publish(EVENT_OUT, dict(state))

    async def _publish_terminal(self, row: dict[str, Any]) -> None:
        """State of the terminal, told apart from state of the account.

        Four separate questions, published together because they are read
        together, and separately from the account because they answer a
        different one: not "how much have I got" but "can I act at all".

        A halt the owner ordered and a broker outage both stop execution and
        call for opposite responses — sleep, or get up. Merging them into one
        flag would erase exactly the distinction that matters.

        Absent columns publish nothing rather than a guess: an older arm's
        database has no opinion about the terminal, and False would read as
        "disconnected" when the truth is "unknown".
        """
        if self._context is None:
            return
        if not any(column in row for column in _PLATFORM_COLUMNS):
            return
        beat = _to_float(row.get("bridge_beat"))
        await self._context.publish(EVENT_TERMINAL, {
            "account_id": str(row.get("account_id")),
            "connected": bool(row.get("connected")),
            "trade_allowed": bool(row.get("trade_allowed")),
            "expert_allowed": bool(row.get("expert_allowed")),
            "bridge_beat": beat,
            # الطابع مورَّث من الصفّ الذي كتبه الإكسبرت. لا ساعة جهاز هنا:
            # 3 و806 يملكان الساعة وحدهما، وختمُ هذه الذرّة بساعتها يجعل
            # حدثين عن اللحظة نفسها يحملان زمنين.
            "timestamp": _to_float(row.get("updated_at")),
        })
        self.terminal_count += 1

    async def _loop(self) -> None:
        try:
            while self._running:
                await self._read_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    # ------------------------------------------------------------------

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)

        details = {
            "reads": self.read_count,
            "published": self.publish_count,
            "failures": self.failure_count,
            "last_error": self._last_error,
            "balance": (self._last_state or {}).get("balance"),
            "equity": (self._last_state or {}).get("equity"),
        }

        # An absent bridge is starvation of an external input. Restarting does
        # not make the arm write, so this never reaches the restart path.
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=self._last_error, details=details)

        if self._last_state is None:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NEVER_READ, details=details)

        # Deliberately no staleness check here. Judging "too old" needs a clock
        # reading, and 3 and 806 are the only clock owners in this platform.
        # A silent bridge shows as a stalled publish_count to whoever watches.

        return HealthStatus(state=HealthState.HEALTHY,
                            message="published=%d" % self.publish_count,
                            details=details)

    async def snapshot(self) -> dict[str, Any]:
        return {
            "version": ATOM_VERSION,
            "reads": self.read_count,
            "published": self.publish_count,
            "last_updated_at": self._last_updated_at,
        }

    async def restore(self, state: dict[str, Any]) -> None:
        self.read_count = int(state.get("reads", 0))
        self.publish_count = int(state.get("published", 0))
        # Restoring the last stamp prevents republishing a state the consumers
        # already have the moment the atom comes back.
        self._last_updated_at = state.get("last_updated_at")
