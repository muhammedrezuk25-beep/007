"""
153 — تحليل التذبذب (Volatility)

يشترك: market_data.candle_closed. منطق: انحراف معياري متحرك عبر
نافذة شموع (افتراضي 20). ينشر: analysis.volatility_calculated.
"""

from __future__ import annotations

import math

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 20


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._closes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("Volatility(153) تمت تهيئته (window=%d)", self._window)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("Volatility(153) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(payload["close"])
        if len(closes) > self._window:
            closes.pop(0)
        if len(closes) < self._window:
            return

        mean = sum(closes) / len(closes)
        variance = sum((c - mean) ** 2 for c in closes) / len(closes)
        std_dev = math.sqrt(variance)

        self.calculations_count += 1
        await self._context.publish(
            "analysis.volatility_calculated", {"symbol": symbol, "std_dev": round(std_dev, 6), "window": self._window}
        )
