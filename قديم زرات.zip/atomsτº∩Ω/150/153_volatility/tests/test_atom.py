import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom153"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=153, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed(atom, symbol, closes):
    for c in closes:
        await atom._on_candle({"symbol": symbol, "close": c})


async def test_constant_prices_zero_volatility():
    print("\n--- test_constant_prices_zero_volatility ---")
    context, published = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 100, 100, 100, 100])
    events = [p for n, p in published if n == "analysis.volatility_calculated"]
    assert events[0]["std_dev"] == 0.0
    print(f"OK — أسعار ثابتة تمامًا → انحراف معياري صفر: {events[0]}")


async def test_volatile_prices_nonzero_std_dev():
    print("\n--- test_volatile_prices_nonzero_std_dev ---")
    context, published = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 110, 90, 105, 95])
    events = [p for n, p in published if n == "analysis.volatility_calculated"]
    assert events[0]["std_dev"] > 0
    print(f"OK — أسعار متقلّبة → انحراف معياري موجب: {events[0]}")


async def test_higher_volatility_produces_higher_std_dev():
    print("\n--- test_higher_volatility_produces_higher_std_dev ---")
    context1, published1 = make_context({"window": 5})
    atom1 = Atom()
    await atom1.initialize(context1)
    await _feed(atom1, "NQ", [100, 101, 99, 100.5, 99.5])  # تقلّب ضئيل

    context2, published2 = make_context({"window": 5})
    atom2 = Atom()
    await atom2.initialize(context2)
    await _feed(atom2, "NQ", [100, 150, 50, 120, 80])  # تقلّب كبير

    std1 = [p for n, p in published1 if n == "analysis.volatility_calculated"][0]["std_dev"]
    std2 = [p for n, p in published2 if n == "analysis.volatility_calculated"][0]["std_dev"]
    assert std2 > std1
    print(f"OK — تقلّب أكبر أنتج انحرافًا معياريًا أعلى: {std1} < {std2}")


async def test_insufficient_candles_no_calculation():
    print("\n--- test_insufficient_candles_no_calculation ---")
    context, published = make_context({"window": 20})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101])
    events = [p for n, p in published if n == "analysis.volatility_calculated"]
    assert len(events) == 0
    print("OK — شموع غير كافية → صفر حساب بعد")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._closes["NQ"] == [100, 101]
    print("OK — restore() نقل النافذة الجارية بدقّة")


async def main():
    tests = [
        test_constant_prices_zero_volatility,
        test_volatile_prices_nonzero_std_dev,
        test_higher_volatility_produces_higher_std_dev,
        test_insufficient_candles_no_calculation,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
