"""
161 — تحليل القوة النسبية (Relative Strength)

يشترك: market_data.candle_closed. ينشر:
analysis.relative_strength_calculated.

منطق مُستنتَج: RSI قياسي (Relative Strength Index) — متوسط
المكاسب مقابل متوسط الخسائر عبر نافذة (افتراضي 14)،
RSI = 100 - (100 / (1 + RS))، RS = متوسط_مكسب / متوسط_خسارة.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_PERIOD = 14


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._period = _DEFAULT_PERIOD
        self._changes: dict[str, list[float]] = {}
        self._previous_close: dict[str, float] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._period = int(context.config.get("period", _DEFAULT_PERIOD))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("RelativeStrength(161) تمت تهيئته (period=%d)", self._period)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("RelativeStrength(161) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"changes": self._changes, "previous_close": self._previous_close, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._changes = state.get("changes", {})
        self._previous_close = state.get("previous_close", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        close = candle["close"]
        previous = self._previous_close.get(symbol)

        if previous is not None:
            changes = self._changes.setdefault(symbol, [])
            changes.append(close - previous)
            if len(changes) > self._period:
                changes.pop(0)

            if len(changes) == self._period:
                gains = [c for c in changes if c > 0]
                losses = [-c for c in changes if c < 0]
                avg_gain = sum(gains) / self._period
                avg_loss = sum(losses) / self._period

                if avg_loss == 0:
                    rsi = 100.0
                else:
                    rs = avg_gain / avg_loss
                    rsi = 100 - (100 / (1 + rs))

                self.calculations_count += 1
                await self._context.publish("analysis.relative_strength_calculated", {"symbol": symbol, "rsi": round(rsi, 2)})

        self._previous_close[symbol] = close
