"""
160 — تحليل الارتباط (Correlation)

يشترك: market_data.candle_closed (بيانات أدوات متعددة — يحتاج 101
يغذّي أكتر من رمز بالتوازي، مدعوم فعليًا: 101 يتتبّع كل رمز بمفتاح
مستقل). ينشر: analysis.correlation_calculated.

منطق مُستنتَج: معامل ارتباط بيرسون (Pearson) بين كل زوج رموز
معروف، محسوب على آخر N إغلاق لكل رمز (افتراضي 20) — **محاذاة بالعدّ
لا بالتوقيت الحرفي** (أحدث N قيمة لكل رمز، بغض النظر عن تزامن وصولها
لحظيًا؛ لا آلية مزامنة أدق أُعطيت).
"""

from __future__ import annotations

import math

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 20


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._closes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("Correlation(160) تمت تهيئته (window=%d)", self._window)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("Correlation(160) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"رموز_مُتابَعة={list(self._closes.keys())} حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(candle["close"])
        if len(closes) > self._window:
            closes.pop(0)

        if len(closes) < self._window:
            return

        for other_symbol, other_closes in self._closes.items():
            if other_symbol == symbol or len(other_closes) < self._window:
                continue
            correlation = self._pearson(closes, other_closes[-self._window:])
            self.calculations_count += 1
            await self._context.publish(
                "analysis.correlation_calculated",
                {"symbol_a": symbol, "symbol_b": other_symbol, "correlation": round(correlation, 4)},
            )

    @staticmethod
    def _pearson(a: list[float], b: list[float]) -> float:
        n = len(a)
        mean_a, mean_b = sum(a) / n, sum(b) / n
        cov = sum((a[i] - mean_a) * (b[i] - mean_b) for i in range(n))
        std_a = math.sqrt(sum((x - mean_a) ** 2 for x in a))
        std_b = math.sqrt(sum((x - mean_b) ** 2 for x in b))
        if std_a == 0 or std_b == 0:
            return 0.0
        return cov / (std_a * std_b)
