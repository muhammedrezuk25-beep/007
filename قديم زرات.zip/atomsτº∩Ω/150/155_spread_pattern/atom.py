"""
155 — تحليل السبريد (Spread Pattern)

يشترك: market_data.spread_updated (105). ينشر:
analysis.spread_pattern_detected.

منطق مُستنتَج (نفس نمط 154 حرفيًا، مصدر مختلف): اتساع سبريد غير
طبيعي = سبريد حالي أكبر من N× متوسط آخر K حدث (افتراضي: 3× متوسط
آخر 10).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 10
_DEFAULT_WIDENING_MULTIPLIER = 3.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._widening_multiplier = _DEFAULT_WIDENING_MULTIPLIER
        self._recent_spreads: dict[str, list[float]] = {}
        self.patterns_detected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        self._widening_multiplier = float(context.config.get("widening_multiplier", _DEFAULT_WIDENING_MULTIPLIER))
        context.subscribe("market_data.spread_updated", self._on_spread)
        context.logger.info("SpreadPattern(155) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SpreadPattern(155) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"أنماط_مكتشَفة={self.patterns_detected}")

    async def snapshot(self) -> dict:
        return {"recent_spreads": self._recent_spreads, "patterns_detected": self.patterns_detected}

    async def restore(self, state: dict) -> None:
        self._recent_spreads = state.get("recent_spreads", {})
        self.patterns_detected = state.get("patterns_detected", 0)

    # ------------------------------------------------------------------

    async def _on_spread(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        spread = float(payload["spread"])
        recent = self._recent_spreads.setdefault(symbol, [])

        if recent:
            avg = sum(recent) / len(recent)
            if avg > 0 and spread > avg * self._widening_multiplier:
                self.patterns_detected += 1
                await self._context.publish(
                    "analysis.spread_pattern_detected",
                    {"symbol": symbol, "pattern": "spread_widening", "spread": spread, "average": round(avg, 4)},
                )

        recent.append(spread)
        if len(recent) > self._window:
            recent.pop(0)
