"""
158 — تحليل الجلسات (Session Analysis)

السبك الأصلي: "يشترك: market_session (026، قسم 101 موسَّع)" — لا
"026" موجودة بأي مكان بنطاق 101-116 المبني فعليًا، ولا حدث بهذا الاسم
وُثِّق بأي مكان تاني بالمشروع. **انحراف صريح عن السبك الحرفي**: بدل
انتظار حدث غير موجود، 158 تحسب الجلسة مباشرة من الوقت الفعلي (UTC)
وقت استقبال إغلاق الشمعة — تصميم أكثر اكتفاءً ذاتيًا، بلا تبعية على
حدث غير مؤكَّد الوجود.

يشترك: market_data.candle_closed. ينشر: analysis.session_context.

تقسيم الجلسات (UTC، بلا تداخل، افتراض مبسَّط شائع): آسيوية 00-08،
لندن 08-16، نيويورك 16-24.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_ASIA_END_HOUR = 8
_LONDON_END_HOUR = 16


def _session_for_utc_hour(hour: int) -> str:
    if 0 <= hour < _ASIA_END_HOUR:
        return "asian"
    if _ASIA_END_HOUR <= hour < _LONDON_END_HOUR:
        return "london"
    return "new_york"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_session: dict[str, str] = {}
        self.session_changes_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("SessionAnalysis(158) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SessionAnalysis(158) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"جلسات_مُتابَعة={self._last_session}")

    async def snapshot(self) -> dict:
        return {"last_session": self._last_session, "session_changes_count": self.session_changes_count}

    async def restore(self, state: dict) -> None:
        self._last_session = state.get("last_session", {})
        self.session_changes_count = state.get("session_changes_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        current_hour_utc = time.gmtime().tm_hour
        session = _session_for_utc_hour(current_hour_utc)

        if self._last_session.get(symbol) == session:
            return  # Edge-triggered — بلا تغيّر جلسة فعلي، بلا نشر
        self._last_session[symbol] = session
        self.session_changes_count += 1
        await self._context.publish("analysis.session_context", {"symbol": symbol, "session": session})
