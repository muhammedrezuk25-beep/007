import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom158"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
_session_for_utc_hour = _mod._session_for_utc_hour
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=158, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_session_mapping_pure_function():
    print("\n--- test_session_mapping_pure_function ---")
    assert _session_for_utc_hour(0) == "asian"
    assert _session_for_utc_hour(7) == "asian"
    assert _session_for_utc_hour(8) == "london"
    assert _session_for_utc_hour(15) == "london"
    assert _session_for_utc_hour(16) == "new_york"
    assert _session_for_utc_hour(23) == "new_york"
    print("OK — تقسيم الساعات الثلاثة (آسيوية/لندن/نيويورك) صحيح بحدوده كلها")


async def test_first_candle_publishes_session_context():
    print("\n--- test_first_candle_publishes_session_context ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    events = [p for n, p in published if n == "analysis.session_context"]
    assert len(events) == 1
    assert events[0]["session"] in {"asian", "london", "new_york"}
    print(f"OK — أول شمعة نشرت سياق الجلسة الحالية فعليًا: {events[0]}")


async def test_edge_triggered_no_republish_within_same_session():
    print("\n--- test_edge_triggered_no_republish_within_same_session ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    await atom._on_candle({"symbol": "NQ", "close": 101})  # لسا بنفس الجلسة (تنفيذ فوري، الوقت الفعلي ما تغيّر)
    events = [p for n, p in published if n == "analysis.session_context"]
    assert len(events) == 1, "نفس الجلسة — Edge-triggered، بلا نشر تكراري"
    print("OK — شمعة تانية بنفس الجلسة لم تُعِد النشر (Edge-triggered)")


async def test_symbols_tracked_independently():
    print("\n--- test_symbols_tracked_independently ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    await atom._on_candle({"symbol": "ES", "close": 5000})
    events = [p for n, p in published if n == "analysis.session_context"]
    assert len(events) == 2, "رمزان مختلفان، كل واحد ينشر سياقه الخاص أول مرة"
    print(f"OK — NQ وES كل واحد نشر سياقه الخاص: {[e['symbol'] for e in events]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._last_session["NQ"] == atom._last_session["NQ"]
    print("OK — restore() نقل آخر جلسة معروفة بدقّة")


async def main():
    tests = [
        test_session_mapping_pure_function,
        test_first_candle_publishes_session_context,
        test_edge_triggered_no_republish_within_same_session,
        test_symbols_tracked_independently,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
