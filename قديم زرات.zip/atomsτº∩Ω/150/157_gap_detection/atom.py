"""
157 — تحليل الفجوات (Gap Detection)

يشترك: market_data.candle_closed. منطق: كشف Gap بين إغلاق شمعة وفتح
التالية. ينشر: analysis.gap_detected.

منطق مُستنتَج: فجوة = |open الحالي - close السابق| > عتبة % من
close السابق (افتراضي 0.1%).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_THRESHOLD_PCT = 0.1


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._threshold_pct = _DEFAULT_THRESHOLD_PCT
        self._previous_close: dict[str, float] = {}
        self.gaps_detected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._threshold_pct = float(context.config.get("threshold_pct", _DEFAULT_THRESHOLD_PCT))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("GapDetection(157) تمت تهيئته (threshold=%.3f%%)", self._threshold_pct)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("GapDetection(157) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"فجوات_مكتشَفة={self.gaps_detected}")

    async def snapshot(self) -> dict:
        return {"previous_close": self._previous_close, "gaps_detected": self.gaps_detected}

    async def restore(self, state: dict) -> None:
        self._previous_close = state.get("previous_close", {})
        self.gaps_detected = state.get("gaps_detected", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        previous_close = self._previous_close.get(symbol)

        if previous_close is not None and previous_close != 0:
            gap_pct = (candle["open"] - previous_close) / previous_close * 100
            if abs(gap_pct) > self._threshold_pct:
                self.gaps_detected += 1
                direction = "up" if gap_pct > 0 else "down"
                await self._context.publish(
                    "analysis.gap_detected",
                    {"symbol": symbol, "direction": direction, "gap_pct": round(gap_pct, 4), "previous_close": previous_close, "open": candle["open"]},
                )

        self._previous_close[symbol] = candle["close"]
