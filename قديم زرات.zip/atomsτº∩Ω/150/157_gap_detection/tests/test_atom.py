import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom157"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=157, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


def _candle(symbol, o, c):
    return {"symbol": symbol, "open": o, "high": max(o, c), "low": min(o, c), "close": c, "volume": 1, "timeframe": "60s"}


async def test_gap_up_detected():
    print("\n--- test_gap_up_detected ---")
    context, published = make_context({"threshold_pct": 0.5})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, c=100))
    await atom._on_candle(_candle("NQ", o=102, c=103))  # فتح 102 مقابل إغلاق سابق 100 → +2%
    events = [p for n, p in published if n == "analysis.gap_detected"]
    assert len(events) == 1
    assert events[0]["direction"] == "up"
    print(f"OK — فجوة صعودية اكتُشِفت: {events[0]}")


async def test_gap_down_detected():
    print("\n--- test_gap_down_detected ---")
    context, published = make_context({"threshold_pct": 0.5})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, c=100))
    await atom._on_candle(_candle("NQ", o=97, c=96))  # فتح 97 مقابل إغلاق سابق 100 → -3%
    events = [p for n, p in published if n == "analysis.gap_detected"]
    assert events[0]["direction"] == "down"
    print(f"OK — فجوة هبوطية اكتُشِفت: {events[0]}")


async def test_no_gap_when_open_matches_previous_close():
    print("\n--- test_no_gap_when_open_matches_previous_close ---")
    context, published = make_context({"threshold_pct": 0.5})
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, c=101))
    await atom._on_candle(_candle("NQ", o=101, c=102))  # فتح = إغلاق سابق بالضبط، صفر فجوة
    events = [p for n, p in published if n == "analysis.gap_detected"]
    assert len(events) == 0
    print("OK — استمرارية طبيعية (فتح=إغلاق سابق) → صفر فجوة")


async def test_first_candle_never_a_gap():
    print("\n--- test_first_candle_never_a_gap ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, c=105))  # أول شمعة، بلا سابقة للمقارنة
    events = [p for n, p in published if n == "analysis.gap_detected"]
    assert len(events) == 0
    print("OK — أول شمعة بلا سابقة للمقارنة → صفر فجوة")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, c=105))
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._previous_close["NQ"] == 105
    print("OK — restore() نقل آخر إغلاق مرجعي بدقّة")


async def main():
    tests = [
        test_gap_up_detected,
        test_gap_down_detected,
        test_no_gap_when_open_matches_previous_close,
        test_first_candle_never_a_gap,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
