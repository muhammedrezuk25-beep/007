"""
164 — تحليل الحجم الحقيقي (Real Volume)

يشترك: market_data.volume_received (104 — الحجم الفعلي المُبلَّغ من
المصدر). ينشر: analysis.real_volume_calculated.

سبب وجودها منفصلة عن 154 (نمط الحجم): تمايز صريح عن "حجم التكات"
(Tick Volume، البديل المستخدَم بـ103/بناء الشموع بسبب غياب حجم فعلي
بـmarket.tick الخام) — هذه الذرة تتعامل حصرًا مع الحجم **الحقيقي**
المُبلَّغ فعليًا (104)، وتحسب متوسطًا متحركًا للسياق.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 10


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._recent_volumes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        context.subscribe("market_data.volume_received", self._on_volume)
        context.logger.info("RealVolume(164) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("RealVolume(164) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"recent_volumes": self._recent_volumes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._recent_volumes = state.get("recent_volumes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_volume(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        volume = float(payload["volume"])
        recent = self._recent_volumes.setdefault(symbol, [])
        recent.append(volume)
        if len(recent) > self._window:
            recent.pop(0)

        average = sum(recent) / len(recent)
        self.calculations_count += 1
        await self._context.publish(
            "analysis.real_volume_calculated", {"symbol": symbol, "real_volume": volume, "rolling_average": round(average, 2)}
        )
