"""
150 — مدير التحليل (Analysis Manager)

يشترك: كل أحداث 151-165 (**يشمل 151 الخام**، بعكس 166 يلي يستثنيه
عمدًا). ينشر: analysis.unified — اللقطة العائلية الكاملة، بما فيها
المؤشر الخام.
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}


_SOURCE_EVENTS = {
    "trend.detected": "trend_raw",  # 151 — الخام، يشمله 150 بعكس 166
    "analysis.momentum_calculated": "momentum",
    "analysis.volatility_calculated": "volatility",
    "analysis.volume_pattern_detected": "volume_pattern",
    "analysis.spread_pattern_detected": "spread_pattern",
    "analysis.candle_pattern_detected": "candle_pattern",
    "analysis.gap_detected": "gap",
    "analysis.session_context": "session",
    "analysis.time_effect_calculated": "time_effect",
    "analysis.correlation_calculated": "correlation",
    "analysis.relative_strength_calculated": "relative_strength",
    "analysis.speed_calculated": "speed",
    "analysis.acceleration_calculated": "acceleration",
    "analysis.real_volume_calculated": "real_volume",
    "analysis.noise_level_calculated": "noise_level",
}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._state: dict[str, dict] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name, field_key in _SOURCE_EVENTS.items():
            context.subscribe(event_name, self._make_collector(field_key))
        context.logger.info("AnalysisManager(150) تمت تهيئته (يجمّع %d نوع حدث، يشمل 151 الخام)", len(_SOURCE_EVENTS))

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("AnalysisManager(150) بدأ التجميع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"رموز_مُتابَعة={len(self._state)} منشور={self.published_count}")

    async def snapshot(self) -> dict:
        return {"state": self._state, "published_count": self.published_count}

    async def restore(self, state: dict) -> None:
        self._state = state.get("state", {})
        self.published_count = state.get("published_count", 0)

    # ------------------------------------------------------------------

    def _make_collector(self, field_key: str):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            symbol = str(payload.get("symbol", "_global"))
            symbol_state = self._state.setdefault(symbol, {})
            symbol_state[field_key] = payload

            self.published_count += 1
            await self._context.publish(
                "analysis.unified", {"symbol": symbol, "state": dict(symbol_state), **_ts_from(payload)}
            )

        return handler
