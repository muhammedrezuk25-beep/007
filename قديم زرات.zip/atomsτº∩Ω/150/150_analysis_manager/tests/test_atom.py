import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom150"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers: dict[str, list] = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=150, config={}, logger=_NullLogger(), publish=self.publish, subscribe=self.subscribe)


async def test_fifteen_event_types_no_late_binding():
    print("\n--- test_fifteen_event_types_no_late_binding ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())

    events = [
        "trend.detected", "analysis.momentum_calculated", "analysis.volatility_calculated",
        "analysis.volume_pattern_detected", "analysis.spread_pattern_detected", "analysis.candle_pattern_detected",
        "analysis.gap_detected", "analysis.session_context", "analysis.time_effect_calculated",
        "analysis.correlation_calculated", "analysis.relative_strength_calculated", "analysis.speed_calculated",
        "analysis.acceleration_calculated", "analysis.real_volume_calculated", "analysis.noise_level_calculated",
    ]
    for name in events:
        await bus.publish(name, {"symbol": "NQ"})

    expected_keys = {
        "trend_raw", "momentum", "volatility", "volume_pattern", "spread_pattern", "candle_pattern", "gap",
        "session", "time_effect", "correlation", "relative_strength", "speed", "acceleration", "real_volume", "noise_level",
    }
    assert set(atom._state["NQ"].keys()) == expected_keys, (
        f"كل نوع حدث (بما فيه 151 الخام) لازم يُخزَّن بمفتاحه الصحيح: {set(atom._state['NQ'].keys())}"
    )
    print(f"OK — الـ15 نوعًا (بما فيهم 151 الخام) خُزِّنوا كل واحد بمفتاحه الصحيح: {sorted(atom._state['NQ'].keys())}")


async def test_raw_trend_151_included_unlike_166():
    print("\n--- test_raw_trend_151_included_unlike_166 ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("trend.detected", {"symbol": "NQ", "direction": "up"})
    unified = [p for n, p in bus.published if n == "analysis.unified"]
    assert len(unified) == 1, "150 (بعكس 166) تشمل 151 الخام — لازم تنشر"
    assert unified[0]["state"]["trend_raw"]["direction"] == "up"
    print(f"OK — 151 (خام) أثّرت فعليًا هون، بعكس 166: {unified[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish("trend.detected", {"symbol": "NQ", "direction": "up"})
    await bus.publish("analysis.momentum_calculated", {"symbol": "NQ", "momentum_pct": 5})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert set(atom2._state["NQ"].keys()) == {"trend_raw", "momentum"}
    print("OK — restore() نقل الحالة العائلية الكاملة (بما فيها الخام) بدقّة")


async def main():
    tests = [test_fifteen_event_types_no_late_binding, test_raw_trend_151_included_unlike_166, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
