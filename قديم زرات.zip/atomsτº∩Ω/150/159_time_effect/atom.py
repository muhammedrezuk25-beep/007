"""
159 — تحليل الوقت (Time Effect)

يشترك: kernel.clock.sys_tick (CLOCK، id=3 — **مبنية فعليًا ومعتمَدة**،
أول تبعية حقيقية 100% بهذا القسم، لا افتراض). ينشر:
analysis.time_effect_calculated.

منطق مُستنتَج: تصنيف "تأثير الوقت" بحسب ساعة اليوم (UTC) — بعض
الساعات معروفة بنشاط أعلى (افتتاح لندن/نيويورك تحديدًا: 8، 13 UTC)
أو أقل (منتصف الليل/عطلة نهاية أسبوع تقريبية). تصنيف مبسَّط: HIGH
(ساعات الافتتاح)، NORMAL (باقي ساعات النهار)، LOW (الفترة الهادئة).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_HIGH_ACTIVITY_HOURS = {8, 13}     # افتتاح لندن ونيويورك تقريبًا (UTC)
_LOW_ACTIVITY_HOURS = {0, 1, 2, 3, 4, 5}  # فترة هادئة نسبيًا


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._last_effect: str | None = None
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("kernel.clock.sys_tick", self._on_sys_tick)
        context.logger.info("TimeEffect(159) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TimeEffect(159) بدأ الاستماع لـkernel.clock.sys_tick")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"آخر_تصنيف={self._last_effect} حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"last_effect": self._last_effect, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._last_effect = state.get("last_effect")
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_sys_tick(self, payload: dict) -> None:
        if self._context is None:
            return
        official_time = payload.get("official_time")
        if official_time is None:
            return
        import time as _time
        hour = _time.gmtime(official_time).tm_hour

        if hour in _HIGH_ACTIVITY_HOURS:
            effect = "HIGH"
        elif hour in _LOW_ACTIVITY_HOURS:
            effect = "LOW"
        else:
            effect = "NORMAL"

        if effect == self._last_effect:
            return  # Edge-triggered
        self._last_effect = effect
        self.calculations_count += 1
        await self._context.publish("analysis.time_effect_calculated", {"effect": effect, "hour_utc": hour})
