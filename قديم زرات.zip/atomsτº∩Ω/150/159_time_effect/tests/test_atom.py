import asyncio
import calendar
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
import time

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom159"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=159, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


def _timestamp_at_utc_hour(hour: int) -> float:
    """يبني timestamp حقيقي بالساعة UTC المطلوبة بالضبط، لتحكّم كامل بالاختبار."""
    now = time.gmtime()
    return calendar.timegm((now.tm_year, now.tm_mon, now.tm_mday, hour, 0, 0, 0, 0, 0))


async def test_high_activity_hour_classified_correctly():
    print("\n--- test_high_activity_hour_classified_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(8)})  # افتتاح لندن
    events = [p for n, p in published if n == "analysis.time_effect_calculated"]
    assert events[0]["effect"] == "HIGH"
    print(f"OK — الساعة 8 UTC (افتتاح لندن) → HIGH: {events[0]}")


async def test_low_activity_hour_classified_correctly():
    print("\n--- test_low_activity_hour_classified_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(2)})  # منتصف الليل تقريبًا
    events = [p for n, p in published if n == "analysis.time_effect_calculated"]
    assert events[0]["effect"] == "LOW"
    print(f"OK — الساعة 2 UTC (فترة هادئة) → LOW: {events[0]}")


async def test_normal_hour_classified_correctly():
    print("\n--- test_normal_hour_classified_correctly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(11)})  # لا افتتاح، لا فترة هادئة
    events = [p for n, p in published if n == "analysis.time_effect_calculated"]
    assert events[0]["effect"] == "NORMAL"
    print(f"OK — الساعة 11 UTC (لا افتتاح، لا فترة هادئة) → NORMAL: {events[0]}")


async def test_edge_triggered_no_republish_within_same_hour_category():
    print("\n--- test_edge_triggered_no_republish_within_same_hour_category ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(11)})
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(11) + 30})  # نفس الساعة، 30 ثانية بعدها
    events = [p for n, p in published if n == "analysis.time_effect_calculated"]
    assert len(events) == 1, "نفس التصنيف (NORMAL) — Edge-triggered، بلا تكرار"
    print("OK — نبضتان بنفس ساعة NORMAL لم تُكرِّرا النشر (Edge-triggered)")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sys_tick({"official_time": _timestamp_at_utc_hour(8)})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._last_effect == "HIGH"
    print("OK — restore() نقل آخر تصنيف بدقّة")


async def main():
    tests = [
        test_high_activity_hour_classified_correctly,
        test_low_activity_hour_classified_correctly,
        test_normal_hour_classified_correctly,
        test_edge_triggered_no_republish_within_same_hour_category,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
