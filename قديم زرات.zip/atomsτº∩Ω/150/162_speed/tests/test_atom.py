import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom162"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=162, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_positive_speed_calculated():
    print("\n--- test_positive_speed_calculated ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    await atom._on_candle({"symbol": "NQ", "close": 105})
    events = [p for n, p in published if n == "analysis.speed_calculated"]
    assert events[0]["speed"] == 5
    print(f"OK — سرعة موجبة (فرق فترة واحدة): {events[0]}")


async def test_first_candle_no_speed():
    print("\n--- test_first_candle_no_speed ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    events = [p for n, p in published if n == "analysis.speed_calculated"]
    assert len(events) == 0
    print("OK — أول شمعة بلا سابقة → صفر حساب")


async def test_multiple_consecutive_speeds():
    print("\n--- test_multiple_consecutive_speeds ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for c in [100, 105, 103, 108]:
        await atom._on_candle({"symbol": "NQ", "close": c})
    events = [p for n, p in published if n == "analysis.speed_calculated"]
    assert [e["speed"] for e in events] == [5, -2, 5]
    print(f"OK — سلسلة سرعات متتالية دقيقة: {[e['speed'] for e in events]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle({"symbol": "NQ", "close": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._previous_close["NQ"] == 100
    print("OK — restore() نقل آخر إغلاق مرجعي بدقّة")


async def main():
    tests = [test_positive_speed_calculated, test_first_candle_no_speed, test_multiple_consecutive_speeds, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
