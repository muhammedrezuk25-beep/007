"""
162 — تحليل السرعة (Speed)

يشترك: market_data.candle_closed. ينشر: analysis.speed_calculated.

منطق مُستنتَج: "سرعة" = معدّل تغيّر لحظي، الفرق بين الإغلاق الحالي
والإغلاق السابق **مباشرة** (فترة واحدة فقط — بعكس 152/الزخم يلي على
نافذة N فترة).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._previous_close: dict[str, float] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("Speed(162) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("Speed(162) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"previous_close": self._previous_close, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._previous_close = state.get("previous_close", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        close = candle["close"]
        previous = self._previous_close.get(symbol)

        if previous is not None:
            speed = close - previous
            self.calculations_count += 1
            await self._context.publish("analysis.speed_calculated", {"symbol": symbol, "speed": round(speed, 6)})

        self._previous_close[symbol] = close
