import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom165"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=165, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed(atom, symbol, closes):
    for c in closes:
        await atom._on_candle({"symbol": symbol, "close": c})


async def test_pure_directional_movement_zero_noise():
    print("\n--- test_pure_directional_movement_zero_noise ---")
    context, published = make_context({"window": 4})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101, 102, 103, 104])  # صعود متواصل خطوة واحدة كل مرة — كفاءة تامة
    events = [p for n, p in published if n == "analysis.noise_level_calculated"]
    assert events[0]["efficiency_ratio"] == 1.0
    assert events[0]["noise_level"] == 0.0
    print(f"OK — حركة اتجاهية خالصة → ضوضاء=0، كفاءة=1: {events[0]}")


async def test_oscillating_back_to_start_max_noise():
    print("\n--- test_oscillating_back_to_start_max_noise ---")
    context, published = make_context({"window": 4})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 110, 90, 110, 100])  # تذبذب كبير، يرجع لنفس النقطة — صفر تغيّر صافٍ
    events = [p for n, p in published if n == "analysis.noise_level_calculated"]
    assert events[0]["efficiency_ratio"] == 0.0
    assert events[0]["noise_level"] == 1.0
    print(f"OK — تذبذب يرجع لنقطة البداية → ضوضاء=1 (الحد الأقصى): {events[0]}")


async def test_insufficient_candles_no_calculation():
    print("\n--- test_insufficient_candles_no_calculation ---")
    context, published = make_context({"window": 10})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101])
    events = [p for n, p in published if n == "analysis.noise_level_calculated"]
    assert len(events) == 0
    print("OK — شموع غير كافية → صفر حساب بعد")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"window": 4})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._closes["NQ"] == [100, 101]
    print("OK — restore() نقل النافذة الجارية بدقّة")


async def main():
    tests = [
        test_pure_directional_movement_zero_noise,
        test_oscillating_back_to_start_max_noise,
        test_insufficient_candles_no_calculation,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
