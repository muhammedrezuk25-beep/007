"""
165 — تحليل الضوضاء (Noise Level)

يشترك: market_data.candle_closed. منطق: يفصل حركة عشوائية عن حركة
ذات دلالة — مثال مُقترَح بالسبك: معامل هيرست أولي، **قبل** 358
(الحساب الكامل، قسم الاحتمالات). ينشر:
analysis.noise_level_calculated.

منطق مُستنتَج (نسخة أولية مبسَّطة، لا Hurst كامل — ذاك حصرًا 358):
نسبة الكفاءة (Efficiency Ratio، مفهوم Kaufman قياسي) — |التغيّر
الصافي| ÷ مجموع |التغيّرات الفردية| عبر نافذة. قريبة من 1 = حركة
اتجاهية كفوءة (ضوضاء منخفضة)؛ قريبة من 0 = حركة عشوائية متذبذبة
(ضوضاء عالية). noise_level = 1 - efficiency_ratio.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 10


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._closes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("NoiseLevel(165) تمت تهيئته (window=%d)", self._window)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("NoiseLevel(165) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(candle["close"])
        if len(closes) > self._window + 1:
            closes.pop(0)
        if len(closes) <= self._window:
            return

        net_change = abs(closes[-1] - closes[0])
        sum_abs_changes = sum(abs(closes[i] - closes[i - 1]) for i in range(1, len(closes)))
        efficiency_ratio = (net_change / sum_abs_changes) if sum_abs_changes > 0 else 0.0
        noise_level = 1 - efficiency_ratio

        self.calculations_count += 1
        await self._context.publish(
            "analysis.noise_level_calculated", {"symbol": symbol, "noise_level": round(noise_level, 4), "efficiency_ratio": round(efficiency_ratio, 4)}
        )
