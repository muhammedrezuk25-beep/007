import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom154"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=154, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_normal_volume_no_pattern():
    print("\n--- test_normal_volume_no_pattern ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for v in [100, 105, 98, 102, 99]:
        await atom._on_volume({"symbol": "NQ", "volume": v})
    events = [p for n, p in published if n == "analysis.volume_pattern_detected"]
    assert len(events) == 0
    print("OK — أحجام طبيعية متقاربة → صفر أنماط")


async def test_volume_spike_detected():
    print("\n--- test_volume_spike_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    for v in [100, 100, 100, 100, 100]:
        await atom._on_volume({"symbol": "NQ", "volume": v})
    await atom._on_volume({"symbol": "NQ", "volume": 500})  # 5× المتوسط
    events = [p for n, p in published if n == "analysis.volume_pattern_detected"]
    assert len(events) == 1
    assert events[0]["pattern"] == "volume_spike"
    print(f"OK — قفزة حجم (5× المتوسط) اكتُشِفت: {events[0]}")


async def test_first_volume_never_a_spike():
    print("\n--- test_first_volume_never_a_spike ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_volume({"symbol": "NQ", "volume": 100000})  # ضخم، بس لا خط أساس للمقارنة
    events = [p for n, p in published if n == "analysis.volume_pattern_detected"]
    assert len(events) == 0
    print("OK — أول حجم بلا خط أساس للمقارنة → صفر نمط")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_volume({"symbol": "NQ", "volume": 100})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._recent_volumes["NQ"] == [100]
    print("OK — restore() نقل النافذة الجارية بدقّة")


async def main():
    tests = [test_normal_volume_no_pattern, test_volume_spike_detected, test_first_volume_never_a_spike, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
