"""
154 — تحليل الحجم (Volume Pattern)

يشترك: market_data.volume_received (104). ينشر:
analysis.volume_pattern_detected.

منطق مُستنتَج: قفزة حجم = حجم حالي أكبر من N× متوسط آخر K حدث
(افتراضي: 3× متوسط آخر 10).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 10
_DEFAULT_SPIKE_MULTIPLIER = 3.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._spike_multiplier = _DEFAULT_SPIKE_MULTIPLIER
        self._recent_volumes: dict[str, list[float]] = {}
        self.patterns_detected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        self._spike_multiplier = float(context.config.get("spike_multiplier", _DEFAULT_SPIKE_MULTIPLIER))
        context.subscribe("market_data.volume_received", self._on_volume)
        context.logger.info("VolumePattern(154) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("VolumePattern(154) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"أنماط_مكتشَفة={self.patterns_detected}")

    async def snapshot(self) -> dict:
        return {"recent_volumes": self._recent_volumes, "patterns_detected": self.patterns_detected}

    async def restore(self, state: dict) -> None:
        self._recent_volumes = state.get("recent_volumes", {})
        self.patterns_detected = state.get("patterns_detected", 0)

    # ------------------------------------------------------------------

    async def _on_volume(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        volume = float(payload["volume"])
        recent = self._recent_volumes.setdefault(symbol, [])

        if recent:
            avg = sum(recent) / len(recent)
            if avg > 0 and volume > avg * self._spike_multiplier:
                self.patterns_detected += 1
                await self._context.publish(
                    "analysis.volume_pattern_detected",
                    {"symbol": symbol, "pattern": "volume_spike", "volume": volume, "average": round(avg, 2)},
                )

        recent.append(volume)
        if len(recent) > self._window:
            recent.pop(0)
