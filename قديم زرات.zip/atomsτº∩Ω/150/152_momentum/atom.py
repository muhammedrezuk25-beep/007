"""
152 — تحليل الزخم (Momentum)

يشترك: market_data.candle_closed. ينشر: analysis.momentum_calculated.

منطق مُستنتَج: معدّل التغيّر (Rate of Change) — الفرق بين الإغلاق
الحالي وإغلاق قبل N شمعة (افتراضي 10)، كنسبة مئوية.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_PERIOD = 10


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._period = _DEFAULT_PERIOD
        self._closes: dict[str, list[float]] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._period = int(context.config.get("period", _DEFAULT_PERIOD))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("Momentum(152) تمت تهيئته (period=%d)", self._period)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("Momentum(152) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(payload["close"])
        if len(closes) > self._period + 1:
            closes.pop(0)
        if len(closes) <= self._period:
            return

        reference = closes[0]
        current = closes[-1]
        momentum_pct = ((current - reference) / reference * 100) if reference != 0 else 0.0

        self.calculations_count += 1
        await self._context.publish(
            "analysis.momentum_calculated", {"symbol": symbol, "momentum_pct": round(momentum_pct, 4), "period": self._period}
        )
