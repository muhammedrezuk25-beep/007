import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom151"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=151, config=config or {}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed(atom, symbol, closes):
    for c in closes:
        await atom._on_candle({"symbol": symbol, "close": c, "open": c, "high": c, "low": c, "volume": 1, "timeframe": "60s"})


async def test_clear_uptrend_detected():
    print("\n--- test_clear_uptrend_detected ---")
    context, published = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101, 102, 103, 110])  # +10% عبر النافذة
    events = [p for n, p in published if n == "trend.detected"]
    assert len(events) == 1
    assert events[0]["direction"] == "up"
    print(f"OK — اتجاه صاعد واضح اكتُشِف: {events[0]}")


async def test_clear_downtrend_detected():
    print("\n--- test_clear_downtrend_detected ---")
    context, published = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 99, 98, 97, 90])  # -10%
    events = [p for n, p in published if n == "trend.detected"]
    assert events[0]["direction"] == "down"
    print(f"OK — اتجاه هابط واضح اكتُشِف: {events[0]}")


async def test_sideways_movement_is_none():
    print("\n--- test_sideways_movement_is_none ---")
    context, published = make_context({"window": 5, "threshold_pct": 2.0})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 100.2, 99.9, 100.1, 100.15])  # تغيّر ضئيل جدًا
    events = [p for n, p in published if n == "trend.detected"]
    assert events[0]["direction"] == "none"
    print(f"OK — حركة عرضية ضئيلة → none: {events[0]}")


async def test_insufficient_candles_no_signal_yet():
    print("\n--- test_insufficient_candles_no_signal_yet ---")
    context, published = make_context({"window": 10})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 105, 110])  # 3 شموع بس، تحت النافذة (10)
    events = [p for n, p in published if n == "trend.detected"]
    assert len(events) == 0
    print("OK — شموع غير كافية → صفر إشارة بعد")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context({"window": 5})
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [100, 101, 102])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._closes["NQ"] == [100, 101, 102]
    print("OK — restore() نقل النافذة الجارية بدقّة")


async def main():
    tests = [
        test_clear_uptrend_detected,
        test_clear_downtrend_detected,
        test_sideways_movement_is_none,
        test_insufficient_candles_no_signal_yet,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
