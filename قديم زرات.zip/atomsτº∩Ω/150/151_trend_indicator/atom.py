"""
151 — تحليل الاتجاه (Trend Indicator، خام)

محسوم سابقًا: مؤشر خام بس (trend.detected)، **ما تعلن الاتجاه
الرسمي** — هاي مسؤولية 207 (قسم 200) حصرًا. 207 تستهلك هذا كحالة
افتراضية أولية بس، لا كحكم نهائي.

منطق مُستنتَج: نافذة متحركة من الإغلاقات (N شمعة، افتراضي 10) —
مقارنة أقدم إغلاق بأحدث إغلاق بالنافذة. تغيّر أكبر من عتبة % = اتجاه
واضح، أقل = "none" (بلا اتجاه واضح، حركة عرضية على الأرجح).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_WINDOW = 10
_DEFAULT_THRESHOLD_PCT = 0.5  # % تغيّر أدنى ليُعتبَر اتجاهًا واضحًا


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._window = _DEFAULT_WINDOW
        self._threshold_pct = _DEFAULT_THRESHOLD_PCT
        self._closes: dict[str, list[float]] = {}
        self.signals_published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config.get("window", _DEFAULT_WINDOW))
        self._threshold_pct = float(context.config.get("threshold_pct", _DEFAULT_THRESHOLD_PCT))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("TrendIndicator(151) تمت تهيئته (window=%d, threshold=%.2f%%)", self._window, self._threshold_pct)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("TrendIndicator(151) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"إشارات_منشورة={self.signals_published}")

    async def snapshot(self) -> dict:
        return {"closes": self._closes, "signals_published": self.signals_published}

    async def restore(self, state: dict) -> None:
        self._closes = state.get("closes", {})
        self.signals_published = state.get("signals_published", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        closes = self._closes.setdefault(symbol, [])
        closes.append(payload["close"])
        if len(closes) > self._window:
            closes.pop(0)
        if len(closes) < self._window:
            return

        oldest, newest = closes[0], closes[-1]
        if oldest == 0:
            return
        change_pct = (newest - oldest) / oldest * 100

        if change_pct > self._threshold_pct:
            direction = "up"
        elif change_pct < -self._threshold_pct:
            direction = "down"
        else:
            direction = "none"

        self.signals_published += 1
        await self._context.publish("trend.detected", {"symbol": symbol, "direction": direction, "change_pct": round(change_pct, 3)})
