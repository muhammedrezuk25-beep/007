"""
163 — تحليل التسارع (Acceleration)

يشترك: مخرجات 162 (analysis.speed_calculated). منطق: فرق السرعة عبر
الزمن (المشتقة الثانية للسعر عمليًا). ينشر:
analysis.acceleration_calculated.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._previous_speed: dict[str, float] = {}
        self.calculations_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("analysis.speed_calculated", self._on_speed)
        context.logger.info("Acceleration(163) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("Acceleration(163) بدأ الاستماع لـanalysis.speed_calculated")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"حسابات={self.calculations_count}")

    async def snapshot(self) -> dict:
        return {"previous_speed": self._previous_speed, "calculations_count": self.calculations_count}

    async def restore(self, state: dict) -> None:
        self._previous_speed = state.get("previous_speed", {})
        self.calculations_count = state.get("calculations_count", 0)

    # ------------------------------------------------------------------

    async def _on_speed(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        speed = payload["speed"]
        previous = self._previous_speed.get(symbol)

        if previous is not None:
            acceleration = speed - previous
            self.calculations_count += 1
            await self._context.publish("analysis.acceleration_calculated", {"symbol": symbol, "acceleration": round(acceleration, 6)})

        self._previous_speed[symbol] = speed
