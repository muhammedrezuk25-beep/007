import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom163"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=163, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_speeding_up_positive_acceleration():
    print("\n--- test_speeding_up_positive_acceleration ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_speed({"symbol": "NQ", "speed": 2})
    await atom._on_speed({"symbol": "NQ", "speed": 5})  # سرعة أكبر — تسارع موجب
    events = [p for n, p in published if n == "analysis.acceleration_calculated"]
    assert events[0]["acceleration"] == 3
    print(f"OK — سرعة تزايدت (2→5) → تسارع موجب: {events[0]}")


async def test_slowing_down_negative_acceleration():
    print("\n--- test_slowing_down_negative_acceleration ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_speed({"symbol": "NQ", "speed": 5})
    await atom._on_speed({"symbol": "NQ", "speed": 2})  # سرعة أقل — تباطؤ
    events = [p for n, p in published if n == "analysis.acceleration_calculated"]
    assert events[0]["acceleration"] == -3
    print(f"OK — سرعة تناقصت (5→2) → تسارع سالب (تباطؤ): {events[0]}")


async def test_first_speed_no_acceleration():
    print("\n--- test_first_speed_no_acceleration ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_speed({"symbol": "NQ", "speed": 5})
    events = [p for n, p in published if n == "analysis.acceleration_calculated"]
    assert len(events) == 0
    print("OK — أول قراءة سرعة بلا سابقة → صفر تسارع")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_speed({"symbol": "NQ", "speed": 5})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._previous_speed["NQ"] == 5
    print("OK — restore() نقل آخر سرعة مرجعية بدقّة")


async def main():
    tests = [test_speeding_up_positive_acceleration, test_slowing_down_negative_acceleration, test_first_speed_no_acceleration, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
