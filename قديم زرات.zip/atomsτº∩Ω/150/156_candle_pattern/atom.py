"""
156 — تحليل الشموع (Candle Pattern)

يشترك: market_data.candle_closed. منطق: كشف أنماط شموع معروفة
(Doji، Engulfing). ينشر: analysis.candle_pattern_detected.

تعريفات مُستنتَجة (لا سبك حسابي دقيق أُعطي):
- Doji: |open-close| <= 10% من المدى الكامل (high-low) — تردد/تعادل قوى.
- Bullish Engulfing: شمعة سابقة هابطة (close<open)، شمعة حالية صاعدة
  (close>open) وجسمها يُحيط بجسم السابقة بالكامل (open الحالي <=
  close السابق، close الحالي >= open السابق).
- Bearish Engulfing: عكس ذلك تمامًا.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


def _to_float(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


_DOJI_BODY_RATIO_THRESHOLD = 0.1


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._previous_candle: dict[str, dict] = {}
        self.patterns_detected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("CandlePattern(156) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("CandlePattern(156) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        self._previous_candle.clear()

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"أنماط_مكتشَفة={self.patterns_detected}")

    async def snapshot(self) -> dict:
        return {"previous_candle": self._previous_candle, "patterns_detected": self.patterns_detected}

    async def restore(self, state: dict) -> None:
        self._previous_candle = state.get("previous_candle", {})
        self.patterns_detected = state.get("patterns_detected", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]

        if self._is_doji(candle):
            await self._publish_pattern(symbol, "doji", candle)

        previous = self._previous_candle.get(symbol)
        if previous is not None:
            engulfing = self._check_engulfing(previous, candle)
            if engulfing is not None:
                await self._publish_pattern(symbol, engulfing, candle)

        self._previous_candle[symbol] = candle

    def _is_doji(self, candle: dict) -> bool:
        high = _to_float(candle.get("high"))
        low = _to_float(candle.get("low"))
        if high is None or low is None:
            return False
        full_range = high - low
        if full_range <= 0:
            return False
        body = abs((_to_float(candle.get("close")) or 0.0) - (_to_float(candle.get("open")) or 0.0))
        return (body / full_range) <= _DOJI_BODY_RATIO_THRESHOLD

    @staticmethod
    def _check_engulfing(previous: dict, current: dict) -> str | None:
        prev_bearish = previous["close"] < previous["open"]
        prev_bullish = previous["close"] > previous["open"]
        curr_bullish = current["close"] > current["open"]
        curr_bearish = current["close"] < current["open"]

        if prev_bearish and curr_bullish and current["open"] <= previous["close"] and current["close"] >= previous["open"]:
            return "bullish_engulfing"
        if prev_bullish and curr_bearish and current["open"] >= previous["close"] and current["close"] <= previous["open"]:
            return "bearish_engulfing"
        return None

    async def _publish_pattern(self, symbol: str, pattern: str, candle: dict) -> None:
        self.patterns_detected += 1
        await self._context.publish(
            "analysis.candle_pattern_detected", {"symbol": symbol, "pattern": pattern, "close": (_to_float(candle.get("close")) or 0.0)}
        )
