import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom156"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=156, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


def _candle(symbol, o, h, low, c):
    return {"symbol": symbol, "open": o, "high": h, "low": low, "close": c, "volume": 1, "timeframe": "60s"}


async def test_doji_detected():
    print("\n--- test_doji_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # جسم ضئيل جدًا (0.05) مقابل مدى كامل كبير (10) — 0.5% << عتبة 10%
    await atom._on_candle(_candle("NQ", o=100.0, h=105, low=95, c=100.05))
    events = [p for n, p in published if n == "analysis.candle_pattern_detected" and p["pattern"] == "doji"]
    assert len(events) == 1
    print(f"OK — Doji اكتُشِفت (جسم ضئيل جدًا مقابل مدى كامل): {events[0]}")


async def test_bullish_engulfing_detected():
    print("\n--- test_bullish_engulfing_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, h=101, low=95, c=96))    # هابطة (open>close)
    await atom._on_candle(_candle("NQ", o=95, h=105, low=94, c=101))    # صاعدة تُحيط بالسابقة بالكامل
    events = [p for n, p in published if n == "analysis.candle_pattern_detected" and p["pattern"] == "bullish_engulfing"]
    assert len(events) == 1
    print(f"OK — Bullish Engulfing اكتُشِفت: {events[0]}")


async def test_bearish_engulfing_detected():
    print("\n--- test_bearish_engulfing_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=95, h=101, low=94, c=100))    # صاعدة
    await atom._on_candle(_candle("NQ", o=101, h=102, low=90, c=94))    # هابطة تُحيط بالسابقة
    events = [p for n, p in published if n == "analysis.candle_pattern_detected" and p["pattern"] == "bearish_engulfing"]
    assert len(events) == 1
    print(f"OK — Bearish Engulfing اكتُشِفت: {events[0]}")


async def test_normal_candle_no_pattern():
    print("\n--- test_normal_candle_no_pattern ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, h=105, low=98, c=103))  # جسم واضح، لا انحسار
    await atom._on_candle(_candle("NQ", o=103, h=106, low=101, c=105))  # استمرارية عادية، لا انعكاس مُحيط
    events = [p for n, p in published if n == "analysis.candle_pattern_detected"]
    assert len(events) == 0
    print("OK — شمعتان عاديتان متتاليتان → صفر أنماط")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_candle(_candle("NQ", o=100, h=105, low=98, c=103))
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._previous_candle["NQ"]["close"] == 103
    print("OK — restore() نقل الشمعة السابقة المرجعية بدقّة")


async def main():
    tests = [
        test_doji_detected,
        test_bullish_engulfing_detected,
        test_bearish_engulfing_detected,
        test_normal_candle_no_pattern,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


# ── شمعة مشوّهة: لا تُسقط المعالج ────────────────────────────────────

import importlib.util as _iu156
import sys as _sys156
from pathlib import Path as _P156

_D156 = _P156(__file__).resolve().parents[1]
_S156 = _iu156.spec_from_file_location("_saf156", _D156 / "atom.py")
_M156 = _iu156.module_from_spec(_S156)
_sys156.modules["_saf156"] = _M156
_sys156.path.insert(0, str(_D156))
try:
    _S156.loader.exec_module(_M156)
finally:
    _sys156.path.remove(str(_D156))


def test_a_candle_with_a_missing_field_does_not_raise():
    """A partial candle used to raise TypeError inside the handler with no
    try/except around it: the atom stopped detecting patterns entirely from
    that moment on, silently."""
    atom = _M156.Atom()
    for bad in ({"high": None, "low": 100.0, "open": 100.0, "close": 100.0},
                {"high": 101.0, "low": None, "open": 100.0, "close": 100.0},
                {"open": 100.0, "close": 100.0},
                {"high": "abc", "low": 100.0, "open": 100.0, "close": 100.0}):
        assert atom._is_doji(bad) is False


def test_a_complete_candle_still_classifies():
    atom = _M156.Atom()
    assert atom._is_doji({"high": 105.0, "low": 95.0,
                          "open": 100.0, "close": 100.05}) in (True, False)
