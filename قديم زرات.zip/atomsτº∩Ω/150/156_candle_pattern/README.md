# 156 — Candle Pattern (تحليل الشموع)

⚠️ تعريفات مُستنتَجة: Doji (جسم ≤10% من المدى الكامل)، Bullish/Bearish
Engulfing (جسم الشمعة الحالية يُحيط بجسم السابقة بالكامل، باتجاه معاكس).

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
5 اختبارات: Doji، Bullish Engulfing، Bearish Engulfing، شمعتان
عاديتان (صفر)، `snapshot`/`restore`. **نتيجة: 5/5.**
