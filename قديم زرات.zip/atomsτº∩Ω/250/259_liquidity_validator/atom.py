"""
259 — Liquidity Validator (مدقق السيولة)

يشترك: كل مخرجات 251-258 (8 أحداث). ينشر liquidity.validated أو
liquidity.validation_failed — **كلاهما، نفس نمط 209 حرفيًا** (قرار
صريح بكل مرة، لا صمت).

فحوصات مُستنتَجة (لا سبك دقيق أُعطي لكل نوع): أسعار موجبة، قيم من
مجموعات ثابتة صحيحة (type، direction)، تناسق منطقي (gap_high >=
gap_low لـFVG).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_VALID_POOL_TYPES = {"high", "low"}
_VALID_SWEEP_DIRECTIONS = {"buy_side", "sell_side"}
_VALID_IMBALANCE_DIRECTIONS = {"bullish", "bearish"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.validated_count = 0
        self.failed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.liquidity.updated", self._make_checker(self._check_pool))
        context.subscribe("liquidity.buy_side_detected", self._make_checker(self._check_price_positive))
        context.subscribe("liquidity.sell_side_detected", self._make_checker(self._check_price_positive))
        context.subscribe("market.sweep.detected", self._make_checker(self._check_sweep))
        context.subscribe("market.imbalance.detected", self._make_checker(self._check_imbalance))
        context.subscribe("market.delta.updated", self._make_checker(lambda p: None))
        context.subscribe("market.cvd.updated", self._make_checker(lambda p: None))
        context.subscribe("market.absorption.detected", self._make_checker(lambda p: None))
        context.logger.info("LiquidityValidator(259) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("LiquidityValidator(259) بدأ التحقق")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"مُتحقَّق={self.validated_count} فشل={self.failed_count}")

    async def snapshot(self) -> dict:
        return {"validated_count": self.validated_count, "failed_count": self.failed_count}

    async def restore(self, state: dict) -> None:
        self.validated_count = state.get("validated_count", 0)
        self.failed_count = state.get("failed_count", 0)

    # ------------------------------------------------------------------

    def _make_checker(self, check_fn):
        async def handler(payload: dict) -> None:
            if self._context is None:
                return
            problem = check_fn(payload)
            if problem is None:
                self.validated_count += 1
                await self._context.publish("liquidity.validated", {"payload": payload})
            else:
                self.failed_count += 1
                await self._context.publish("liquidity.validation_failed", {"problem": problem, "payload": payload})

        return handler

    @staticmethod
    def _check_price_positive(payload: dict) -> str | None:
        if payload.get("price", 0) <= 0:
            return f"سعر غير موجب: {payload.get('price')}"
        return None

    @staticmethod
    def _check_pool(payload: dict) -> str | None:
        if payload.get("price", 0) <= 0:
            return f"سعر غير موجب: {payload.get('price')}"
        if payload.get("type") not in _VALID_POOL_TYPES:
            return f"نوع مجمع غير صالح: {payload.get('type')}"
        return None

    @staticmethod
    def _check_sweep(payload: dict) -> str | None:
        if payload.get("price", 0) <= 0:
            return f"سعر غير موجب: {payload.get('price')}"
        if payload.get("direction") not in _VALID_SWEEP_DIRECTIONS:
            return f"اتجاه اكتساح غير صالح: {payload.get('direction')}"
        return None

    @staticmethod
    def _check_imbalance(payload: dict) -> str | None:
        if payload.get("direction") not in _VALID_IMBALANCE_DIRECTIONS:
            return f"اتجاه فجوة غير صالح: {payload.get('direction')}"
        if payload.get("gap_high", 0) < payload.get("gap_low", 0):
            return f"تناقض: gap_high({payload.get('gap_high')}) < gap_low({payload.get('gap_low')})"
        return None
