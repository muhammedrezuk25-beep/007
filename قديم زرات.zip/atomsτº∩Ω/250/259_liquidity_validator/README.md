# 259 — Liquidity Validator (مدقق السيولة)

يشترك بكل الثمانية مخرجات (251-258). نفس نمط 209 حرفيًا: قرار صريح
بكل مرة — `liquidity.validated` أو `liquidity.validation_failed`.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
5 اختبارات: مجمع سليم، سعر اكتساح سالب، تناقض FVG، **الثمانية أنواع
معًا بلا عيب إغلاق متأخر**، `snapshot`/`restore`. **نتيجة: 5/5.**
