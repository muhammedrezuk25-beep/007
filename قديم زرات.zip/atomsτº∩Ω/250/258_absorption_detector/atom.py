"""
258 — Absorption Detector (كاشف الامتصاص)

نفس قيد 256 (يحتاج Delta/CVD كمدخل — 256/257، كلاهما UNAVAILABLE
حاليًا لغياب مصدر Order Flow حقيقي). Absorption = حجم تداول كبير
بلا حركة سعرية مقابلة (السوق "يمتص" ضغط بيع/شراء) — يحتاج Delta/CVD
حقيقيين، غير متوفرين. ينشر: market.absorption.detected.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._order_flow_available = False

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._order_flow_available = bool(context.config.get("order_flow_available", False))
        if not self._order_flow_available:
            context.logger.warning("AbsorptionDetector(258): بلا Delta/CVD حقيقيين (256/257) — UNAVAILABLE صراحة")
        else:
            context.logger.info("AbsorptionDetector(258) تمت تهيئته — مصدر Order Flow متاح")

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        if not self._order_flow_available:
            return HealthStatus(state=HealthState.UNKNOWN, message="UNAVAILABLE — بلا Delta/CVD حقيقيين (256/257)")
        return HealthStatus(state=HealthState.HEALTHY, message="جاهزة — مصدر Order Flow متاح")

    async def snapshot(self) -> dict:
        return {"order_flow_available": self._order_flow_available}

    async def restore(self, state: dict) -> None:
        self._order_flow_available = state.get("order_flow_available", False)
