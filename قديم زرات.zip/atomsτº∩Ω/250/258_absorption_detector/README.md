# 258 — Absorption Detector (كاشف الامتصاص)

نفس قيد 256 — يحتاج Delta/CVD حقيقيين (256/257)، غير متوفرين.
Absorption = حجم تداول كبير بلا حركة سعرية مقابلة.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
3 اختبارات: UNAVAILABLE افتراضيًا، HEALTHY لو متاح، `snapshot`/`restore`.
**نتيجة: 3/3.**
