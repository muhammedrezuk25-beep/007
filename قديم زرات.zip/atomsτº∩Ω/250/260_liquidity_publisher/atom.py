"""
260 — Liquidity Publisher (ناشر السيولة)

يشترك: مخرجات 259 (liquidity.validated **بس**). ينشر: الحدث الموحَّد
النهائي لقسم السيولة كامل — نفس نمط 210 حرفيًا.

**انحراف صريح عن النص الحرفي**: السبك يذكر اسم الحدث النهائي كـ
"market.liquidity.updated (تجميعي)" — **نفس اسم حدث 251 الخام
حرفيًا**. إعادة استخدام نفس الاسم بشكلين مختلفين تمامًا للـpayload
(251: {symbol,type,price,index} لقطة مفردة؛ هنا: {symbol,state,
timestamp} تجميع كامل) يخلق غموضًا حقيقيًا لأي مشترك مستقبلي — نفس
مشكلة انهيار قابلة للحدوث لو تعامل مشترك واحد مع الاسم بافتراض شكل
واحد. استخدمت اسمًا مميَّزًا (`liquidity.section_summary`) بدل ذلك،
نفس مبدأ التعامل مع 158 (انحراف موثَّق صراحة عند تعارض حقيقي بالسبك).
"""

from __future__ import annotations

import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

def _ts_from(payload: dict) -> dict:
    """Propagate the upstream timestamp instead of taking a fresh clock reading.

    Two atoms reading the same instant with their own time.time() get two
    different numbers, and a downstream freshness check then rejects one of
    them as stale. Inheriting keeps a whole chain on the single reading taken
    at its origin.

    When the inbound event carries none, the key is omitted: core.event_bus
    stamps it via setdefault, so the event is still stamped exactly once and
    never with a value invented here.
    """
    ts = payload.get("timestamp")
    return {"timestamp": ts} if isinstance(ts, (int, float)) else {}



class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._state: dict[str, dict] = {}
        self.published_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("liquidity.validated", self._on_validated)
        context.logger.info("LiquidityPublisher(260) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("LiquidityPublisher(260) بدأ الاستماع لـliquidity.validated")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"رموز_مُتابَعة={len(self._state)} منشور={self.published_count}")

    async def snapshot(self) -> dict:
        return {"state": self._state, "published_count": self.published_count}

    async def restore(self, state: dict) -> None:
        self._state = state.get("state", {})
        self.published_count = state.get("published_count", 0)

    # ------------------------------------------------------------------

    async def _on_validated(self, payload: dict) -> None:
        if self._context is None:
            return
        inner = payload.get("payload", {})
        symbol = str(inner.get("symbol", "_global"))
        symbol_state = self._state.setdefault(symbol, {})
        symbol_state.update({k: v for k, v in inner.items() if k != "symbol"})

        self.published_count += 1
        await self._context.publish(
            "liquidity.section_summary", {"symbol": symbol, "state": dict(symbol_state), **_ts_from(payload)}
        )
