import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom260"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=260, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_validated_pool_produces_summary_event():
    print("\n--- test_validated_pool_produces_summary_event ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "type": "high", "price": 100}})
    events = [p for n, p in published if n == "liquidity.section_summary"]
    assert len(events) == 1
    assert events[0]["state"] == {"type": "high", "price": 100}
    print(f"OK — لقطة مُتحقَّق منها أنتجت حدث ملخّص: {events[0]}")


async def test_distinct_from_251_raw_event_name():
    """يثبت الانحراف المتعمَّد: لا نشر إطلاقًا لـmarket.liquidity.updated
    (اسم 251 الخام) — تجنّبًا لغموض تعارض الشكل."""
    print("\n--- test_distinct_from_251_raw_event_name ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "type": "high", "price": 100}})
    raw_name_events = [p for n, p in published if n == "market.liquidity.updated"]
    assert len(raw_name_events) == 0, "لا يجب إعادة استخدام اسم 251 الخام إطلاقًا — انحراف متعمَّد لتجنّب الغموض"
    print("OK — لا تعارض اسم مع 251 — اسم مميَّز تمامًا (liquidity.section_summary)")


async def test_state_accumulates_across_multiple_validated_updates():
    print("\n--- test_state_accumulates_across_multiple_validated_updates ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "type": "high", "price": 100}})
    await atom._on_validated({"payload": {"symbol": "NQ", "direction": "buy_side"}})
    last_state = published[-1][1]["state"]
    assert last_state == {"type": "high", "price": 100, "direction": "buy_side"}
    print(f"OK — الحالة تراكمت من تحديثين مختلفين: {last_state}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_validated({"payload": {"symbol": "NQ", "type": "high", "price": 100}})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._state["NQ"]["price"] == 100
    print("OK — restore() نقل الحالة الموحَّدة بدقّة")


async def main():
    tests = [
        test_validated_pool_produces_summary_event,
        test_distinct_from_251_raw_event_name,
        test_state_accumulates_across_multiple_validated_updates,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
