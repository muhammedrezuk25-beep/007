"""
256 — Delta Analyzer (محلّل الدلتا)

Graceful Degradation إلزامي (بالسبك حرفيًا): UNAVAILABLE لو
المصدر بلا Order Flow حقيقي. نفس مبدأ 106 (DOM، مؤجَّلة لغياب
Rithmic Level 2 حقيقي) — هون بالمثل: بلا مصدر Order Flow حقيقي
(Bid/Ask Volume لكل صفقة)، الذرة **لا تخترع حسابًا وهميًا** — تُعلن
UNAVAILABLE صراحة وتتوقف، بانتظار مصدر حقيقي لاحقًا.

منطق (لو توفّر مصدر حقيقي مستقبلاً، عبر order_flow_available=true):
Delta = حجم الشراء بسعر Ask - حجم البيع بسعر Bid لكل شمعة/فترة. لا
سبك حسابي دقيق أُعطي لشكل بيانات Order Flow الفعلي — يُبنى وقت توفّر
مصدر حقيقي فعلي، لا تخمينًا الآن.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._order_flow_available = False

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._order_flow_available = bool(context.config.get("order_flow_available", False))
        if not self._order_flow_available:
            context.logger.warning("DeltaAnalyzer(256): بلا مصدر Order Flow حقيقي — UNAVAILABLE صراحة، لا حساب وهمي")
        else:
            context.logger.info("DeltaAnalyzer(256) تمت تهيئته — مصدر Order Flow متاح")

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        if not self._order_flow_available:
            return HealthStatus(state=HealthState.UNKNOWN, message="UNAVAILABLE — بلا مصدر Order Flow حقيقي")
        return HealthStatus(state=HealthState.HEALTHY, message="جاهزة — مصدر Order Flow متاح")

    async def snapshot(self) -> dict:
        return {"order_flow_available": self._order_flow_available}

    async def restore(self, state: dict) -> None:
        self._order_flow_available = state.get("order_flow_available", False)
