# 256 — Delta Analyzer (محلّل الدلتا)

## ⚠️ Graceful Degradation إلزامي

بلا مصدر Order Flow حقيقي (Bid/Ask Volume لكل صفقة) — الذرة **لا
تخترع حسابًا وهميًا**، تُعلن UNAVAILABLE صراحة (`health_check` يرجع
UNKNOWN). نفس مبدأ 106 (DOM). منطق الحساب الفعلي يُبنى وقت توفّر
مصدر Order Flow حقيقي فعلًا — لا تخمين الآن.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
3 اختبارات: UNAVAILABLE افتراضيًا، HEALTHY لو المصدر متاح صراحة،
`snapshot`/`restore`. **نتيجة: 3/3.**
