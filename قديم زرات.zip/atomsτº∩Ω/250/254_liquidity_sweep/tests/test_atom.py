import asyncio
import pytest
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom254"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=254, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def test_price_crossing_above_buy_side_pool_sweeps_it():
    print("\n--- test_price_crossing_above_buy_side_pool_sweeps_it ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 100, "index": 5})
    await atom._on_price({"symbol": "NQ", "bid": 100.9, "ask": 101.1})  # mid=101 > 100
    events = [p for n, p in published if n == "market.sweep.detected"]
    assert len(events) == 1
    _required = {"symbol": "NQ", "direction": "buy_side", "price": 100}
    for _k, _v in _required.items():
        assert events[0][_k] == _v
    print(f"OK — سعر تجاوز بركة buy-side → اكتساح مكتشَف: {events[0]}")


async def test_price_crossing_below_sell_side_pool_sweeps_it():
    print("\n--- test_price_crossing_below_sell_side_pool_sweeps_it ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sell_side({"symbol": "NQ", "price": 50, "index": 3})
    await atom._on_price({"symbol": "NQ", "bid": 48.9, "ask": 49.1})  # mid=49 < 50
    events = [p for n, p in published if n == "market.sweep.detected"]
    _required = {"symbol": "NQ", "direction": "sell_side", "price": 50}
    for _k, _v in _required.items():
        assert events[0][_k] == _v
    print(f"OK — سعر هبط تحت بركة sell-side → اكتساح مكتشَف: {events[0]}")


async def test_price_not_crossing_pool_no_sweep():
    print("\n--- test_price_not_crossing_pool_no_sweep ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 100, "index": 5})
    await atom._on_price({"symbol": "NQ", "bid": 98.9, "ask": 99.1})  # mid=99 < 100 — لسا ما وصل
    events = [p for n, p in published if n == "market.sweep.detected"]
    assert len(events) == 0
    print("OK — سعر لسا تحت البركة → صفر اكتساح")


async def test_swept_pool_removed_no_double_sweep():
    print("\n--- test_swept_pool_removed_no_double_sweep ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 100, "index": 5})
    await atom._on_price({"symbol": "NQ", "bid": 100.9, "ask": 101.1})  # اكتساح أول
    await atom._on_price({"symbol": "NQ", "bid": 102.9, "ask": 103.1})  # سعر استمر بالصعود
    events = [p for n, p in published if n == "market.sweep.detected"]
    assert len(events) == 1, "البركة اكتُسحت مرة وحدة، أُزيلت من التتبّع — لا تكتسَح تاني"
    print("OK — البركة المكتسَحة أُزيلت، لم تُكتسَح ثانية مع صعود السعر أكتر")


async def test_multiple_pools_only_crossed_ones_swept():
    print("\n--- test_multiple_pools_only_crossed_ones_swept ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 100, "index": 1})
    await atom._on_buy_side({"symbol": "NQ", "price": 200, "index": 2})
    await atom._on_price({"symbol": "NQ", "bid": 149.9, "ask": 150.1})  # mid=150 — يكتسح 100 بس، لا 200
    events = [p for n, p in published if n == "market.sweep.detected"]
    assert len(events) == 1
    assert events[0]["price"] == 100
    print(f"OK — بركتان، وحدة بس اكتُسحت بدقّة: {events[0]}")


async def test_payload_shape_matches_354_expectation_exactly():
    """354 reads symbol and direction and nothing else. This test guards that
    contract, not an exact payload shape: 407 needs level and penetration to
    compute strength, and an exact match would forbid adding them."""
    print("\n--- test_payload_shape_matches_354_expectation_exactly ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_sell_side({"symbol": "NQ", "price": 50, "index": 1})
    await atom._on_price({"symbol": "NQ", "bid": 48.9, "ask": 49.1})
    events = [p for n, p in published if n == "market.sweep.detected"]
    # Superset, not equality: 354 needs these three and adding fields for
    # 407 must stay allowed. Equality here forbids every extension.
    assert {"symbol", "direction", "price"} <= set(events[0].keys())
    assert events[0]["direction"] in {"buy_side", "sell_side"}
    print(f"OK — الشكل مطابق حرفيًا لتوقّع 354: {events[0]}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 100, "index": 1})
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert atom2._buy_side_pools["NQ"] == [100]
    print("OK — restore() نقل البرك النشطة بدقّة")


async def main():
    tests = [
        test_price_crossing_above_buy_side_pool_sweeps_it,
        test_price_crossing_below_sell_side_pool_sweeps_it,
        test_price_not_crossing_pool_no_sweep,
        test_swept_pool_removed_no_double_sweep,
        test_multiple_pools_only_crossed_ones_swept,
        test_payload_shape_matches_354_expectation_exactly,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())


@pytest.mark.asyncio
async def test_sweep_carries_level_and_penetration():
    """407 measures sweep depth from how far price went past the pool, so both
    the level and the price that swept it must travel with the event."""
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_buy_side({"symbol": "NQ", "price": 28400.0})
    await atom._on_price({"symbol": "NQ", "bid": 28439.0, "ask": 28441.0,
                          "timestamp": 1.0})
    event = [p for n, p in published if n == "market.sweep.detected"][0]
    assert event["level"] == 28400.0
    assert event["current_price"] == 28440.0
    assert round(event["penetration"], 6) == 40.0
    assert event["price"] == 28400.0
