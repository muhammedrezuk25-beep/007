"""
254 — Liquidity Sweep (اكتساح السيولة)

يشترك: مخرجات 252/253 (liquidity.buy_side_detected،
liquidity.sell_side_detected) + السعر الحالي (market_data.
price_received، 102). ينشر: market.sweep.detected.

**مهم**: هذه الذرة يترقّبها 354 (نموذج الارتداد الاحتمالي، مبنية
سابقًا بأحداث مُصطنَعة) — شكل الـpayload هنا مطابق **حرفيًا** لما
افترضه 354 وقتها: {symbol, direction: "buy_side"|"sell_side", price}.
بمجرد اعتماد هذه الذرة، 354 تصبح متكاملة بمدخل حقيقي فعليًا، لا مُصطنَع.

منطق: يتتبّع برك سيولة نشطة (من 252/253). عند وصول سعر حالي يتجاوز
بركة معروفة فعليًا (أعلى من بركة buy-side، أو أدنى من بركة sell-side)
— اكتساح، تُزال البركة من التتبّع (اكتُسحت، لن تُكتسَح ثانية).
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._buy_side_pools: dict[str, list[float]] = {}
        self._sell_side_pools: dict[str, list[float]] = {}
        self.sweeps_detected_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("liquidity.buy_side_detected", self._on_buy_side)
        context.subscribe("liquidity.sell_side_detected", self._on_sell_side)
        context.subscribe("market_data.price_received", self._on_price)
        context.logger.info("LiquiditySweep(254) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("LiquiditySweep(254) بدأ الاستماع لـ252/253 + السعر الحالي")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total_pools = sum(len(v) for v in self._buy_side_pools.values()) + sum(len(v) for v in self._sell_side_pools.values())
        return HealthStatus(state=HealthState.HEALTHY, message=f"برك_نشطة={total_pools} اكتساحات={self.sweeps_detected_count}")

    async def snapshot(self) -> dict:
        return {
            "buy_side_pools": self._buy_side_pools, "sell_side_pools": self._sell_side_pools,
            "sweeps_detected_count": self.sweeps_detected_count,
        }

    async def restore(self, state: dict) -> None:
        self._buy_side_pools = state.get("buy_side_pools", {})
        self._sell_side_pools = state.get("sell_side_pools", {})
        self.sweeps_detected_count = state.get("sweeps_detected_count", 0)

    # ------------------------------------------------------------------

    async def _on_buy_side(self, payload: dict) -> None:
        symbol = payload["symbol"]
        self._buy_side_pools.setdefault(symbol, []).append(payload["price"])

    async def _on_sell_side(self, payload: dict) -> None:
        symbol = payload["symbol"]
        self._sell_side_pools.setdefault(symbol, []).append(payload["price"])

    async def _on_price(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        # bid/ask متاحان — نستخدم منتصف السعر كـ"السعر الحالي" (نفس اصطلاح 103)
        current_price = (payload["bid"] + payload["ask"]) / 2

        buy_side = self._buy_side_pools.get(symbol, [])
        swept_buy = [p for p in buy_side if current_price > p]
        for swept_price in swept_buy:
            # قد يكون العنصر أُزيل سابقًا (سباق بين معالجات) — الإزالة الآمنة
            try:
                buy_side.remove(swept_price)
            except ValueError:
                pass
            await self._publish_sweep(symbol, "buy_side", swept_price,
                                      current_price, payload)

        sell_side = self._sell_side_pools.get(symbol, [])
        swept_sell = [p for p in sell_side if current_price < p]
        for swept_price in swept_sell:
            try:
                sell_side.remove(swept_price)
            except ValueError:
                pass  # أُزيل سابقًا في سباق معالجات
            await self._publish_sweep(symbol, "sell_side", swept_price,
                                      current_price, payload)

    async def _publish_sweep(self, symbol: str, direction: str, level: float,
                             current_price: float, payload: dict) -> None:
        self.sweeps_detected_count += 1
        body = {
            "symbol": symbol,
            "direction": direction,
            "price": level,
            "level": level,
            "current_price": current_price,
            "penetration": round(abs(current_price - level), 10),
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish("market.sweep.detected", body)
