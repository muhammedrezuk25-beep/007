"""
253 — Sell Side Liquidity (سيولة جهة البيع)

يشترك: مخرجات 251 (market.liquidity.updated). ينشر:
liquidity.sell_side_detected.

تعريف SMC قياسي: سيولة جهة البيع = تجمع أوامر وقف الخسارة لمشترين
(Long) — تستقر **تحت** القيعان الأخيرة (type="low"). كسرها يُطلِق
أوامر بيع. فلتر بحت فوق 251 — مرآة 252 تمامًا.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.detected_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market.liquidity.updated", self._on_liquidity)
        context.logger.info("SellSideLiquidity(253) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("SellSideLiquidity(253) بدأ الاستماع لـ251")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"مكتشَف={self.detected_count}")

    async def snapshot(self) -> dict:
        return {"detected_count": self.detected_count}

    async def restore(self, state: dict) -> None:
        self.detected_count = state.get("detected_count", 0)

    # ------------------------------------------------------------------

    async def _on_liquidity(self, payload: dict) -> None:
        if self._context is None:
            return
        if payload["type"] != "low":
            return  # سيولة جهة البيع = تحت القيعان بس
        self.detected_count += 1
        await self._context.publish(
            "liquidity.sell_side_detected", {"symbol": payload["symbol"], "price": payload["price"], "index": payload["index"]}
        )
