"""
255 — Imbalance / FVG (فجوة القيمة العادلة)

يشترك: market_data.candle_closed (3 شموع متتالية). ينشر:
market.imbalance.detected.

تعريف SMC قياسي (FVG — Fair Value Gap): عبر 3 شموع متتالية —
Bullish FVG: قمة الشمعة الأولى < قاع الشمعة الثالثة (فجوة صعودية،
الشمعة الوسطى اندفاعية). Bearish FVG: قاع الشمعة الأولى > قمة
الشمعة الثالثة.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_CANDLES_IN_PATTERN = 3


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._candle_windows: dict[str, list[dict]] = {}
        self.imbalances_detected_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.logger.info("ImbalanceFVG(255) تمت تهيئته")

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("ImbalanceFVG(255) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY, message=f"فجوات_مكتشَفة={self.imbalances_detected_count}")

    async def snapshot(self) -> dict:
        return {"candle_windows": self._candle_windows, "imbalances_detected_count": self.imbalances_detected_count}

    async def restore(self, state: dict) -> None:
        self._candle_windows = state.get("candle_windows", {})
        self.imbalances_detected_count = state.get("imbalances_detected_count", 0)

    # ------------------------------------------------------------------

    async def _on_candle(self, candle: dict) -> None:
        if self._context is None:
            return
        symbol = candle["symbol"]
        window = self._candle_windows.setdefault(symbol, [])
        window.append({"high": candle["high"], "low": candle["low"]})
        if len(window) > _CANDLES_IN_PATTERN:
            window.pop(0)
        if len(window) < _CANDLES_IN_PATTERN:
            return

        first, _middle, third = window

        if first["high"] < third["low"]:
            await self._publish_imbalance(symbol, "bullish", first["high"], third["low"])
        elif first["low"] > third["high"]:
            await self._publish_imbalance(symbol, "bearish", third["high"], first["low"])

    async def _publish_imbalance(self, symbol: str, direction: str, gap_low: float, gap_high: float) -> None:
        self.imbalances_detected_count += 1
        await self._context.publish(
            "market.imbalance.detected",
            {"symbol": symbol, "direction": direction, "gap_low": gap_low, "gap_high": gap_high},
        )
