import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom255"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=255, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed(atom, symbol, candles):
    for h, low in candles:
        await atom._on_candle({"symbol": symbol, "high": h, "low": low, "open": h, "close": low, "volume": 1, "timeframe": "60s"})


async def test_bullish_fvg_detected():
    print("\n--- test_bullish_fvg_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # شمعة1: high=100 — شمعة2: اندفاعية — شمعة3: low=105 (فجوة 100-105 صعودية)
    await _feed(atom, "NQ", [(100, 95), (110, 102), (115, 105)])
    events = [p for n, p in published if n == "market.imbalance.detected"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "direction": "bullish", "gap_low": 100, "gap_high": 105}
    print(f"OK — فجوة صعودية (FVG) مكتشَفة: {events[0]}")


async def test_bearish_fvg_detected():
    print("\n--- test_bearish_fvg_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    # شمعة1: low=105 — شمعة3: high=100 (فجوة 100-105 هبوطية)
    await _feed(atom, "NQ", [(110, 105), (100, 92), (100, 90)])
    events = [p for n, p in published if n == "market.imbalance.detected"]
    assert events[0] == {"symbol": "NQ", "direction": "bearish", "gap_low": 100, "gap_high": 105}
    print(f"OK — فجوة هبوطية (FVG) مكتشَفة: {events[0]}")


async def test_overlapping_candles_no_gap():
    print("\n--- test_overlapping_candles_no_gap ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [(100, 95), (102, 98), (101, 96)])  # تداخل واضح، بلا فجوة
    events = [p for n, p in published if n == "market.imbalance.detected"]
    assert len(events) == 0
    print("OK — شموع متداخلة → صفر فجوة")


async def test_insufficient_candles_no_detection():
    print("\n--- test_insufficient_candles_no_detection ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [(100, 95), (110, 102)])  # شمعتان بس
    events = [p for n, p in published if n == "market.imbalance.detected"]
    assert len(events) == 0
    print("OK — شمعتان بس (تحت 3) → صفر كشف بعد")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed(atom, "NQ", [(100, 95), (110, 102)])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert len(atom2._candle_windows["NQ"]) == 2
    print("OK — restore() نقل نافذة الشموع الجارية بدقّة")


async def main():
    tests = [
        test_bullish_fvg_detected,
        test_bearish_fvg_detected,
        test_overlapping_candles_no_gap,
        test_insufficient_candles_no_detection,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
