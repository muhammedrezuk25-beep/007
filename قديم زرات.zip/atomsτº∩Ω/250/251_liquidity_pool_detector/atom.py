"""
251 — Liquidity Pool Detector (كاشف مجمعات السيولة)

يشترك: market.structure.updated (210) + market_data.candle_closed.
ينشر: market.liquidity.updated.

منطق مُستنتَج: "مجمع سيولة" (Liquidity Pool) = قمة/قاع محلي مؤكَّد
(نفس تقنية 201 حرفيًا — نافذة متمركزة) لم تُكتسَح بعد — منطقة تجمّع
أوامر وقف الخسارة النموذجية (SMC قياسي). حساب مستقل عن 210 عمدًا
(نفس مبدأ 202/203: لا اعتماد على قراءة قيم مُبهَمة من قاموس 210
المُجمَّع العام — نعيد حساب القمم/القيعان محليًا من market_data.
candle_closed مباشرة، أدق وأوثق). 210 تُستهلَك فقط كمؤشر "هل الهيكل
نشط حاليًا" (سياق عام، بلا استخراج قيم محدَّدة منها).

بركة سيولة تُعتبَر "مكتسَحة" (تُزال من التتبّع) لما سعر لاحق يتجاوزها
فعليًا — هذا دور 254 (Sweep) لاحقًا، هون بس الكشف والتتبّع.
"""

from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

_DEFAULT_LOOKBACK = 2


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._lookback = _DEFAULT_LOOKBACK
        self._windows: dict[str, list[dict]] = {}
        self._index_counters: dict[str, int] = {}
        self._active_pools: dict[str, list[dict]] = {}
        self.pools_detected_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._lookback = int(context.config.get("lookback", _DEFAULT_LOOKBACK))
        context.subscribe("market_data.candle_closed", self._on_candle)
        context.subscribe("market.structure.updated", self._on_structure_context)
        context.logger.info("LiquidityPoolDetector(251) تمت تهيئته (lookback=%d)", self._lookback)

    async def start(self) -> None:
        if self._context is not None:
            self._context.logger.info("LiquidityPoolDetector(251) بدأ الاستماع")

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        total_active = sum(len(v) for v in self._active_pools.values())
        return HealthStatus(state=HealthState.HEALTHY, message=f"برك_نشطة={total_active} مكتشَفة_إجمالًا={self.pools_detected_count}")

    async def snapshot(self) -> dict:
        return {
            "windows": self._windows, "index_counters": self._index_counters,
            "active_pools": self._active_pools, "pools_detected_count": self.pools_detected_count,
        }

    async def restore(self, state: dict) -> None:
        self._windows = state.get("windows", {})
        self._index_counters = state.get("index_counters", {})
        self._active_pools = state.get("active_pools", {})
        self.pools_detected_count = state.get("pools_detected_count", 0)

    # ------------------------------------------------------------------

    async def _on_structure_context(self, payload: dict) -> None:
        pass  # سياق عام بس — بلا استخراج قيم محدَّدة، توثيقيًا فقط حسب السبك

    async def _on_candle(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload["symbol"]
        window = self._windows.setdefault(symbol, [])
        idx = self._index_counters.get(symbol, 0)
        window.append({"index": idx, "high": payload["high"], "low": payload["low"]})
        self._index_counters[symbol] = idx + 1

        window_size = 2 * self._lookback + 1
        if len(window) > window_size:
            window.pop(0)
        if len(window) < window_size:
            return

        center = window[self._lookback]
        others = window[: self._lookback] + window[self._lookback + 1:]

        if all(center["high"] >= o["high"] for o in others) and any(center["high"] > o["high"] for o in others):
            await self._register_pool(symbol, "high", center["high"], center["index"])
        elif all(center["low"] <= o["low"] for o in others) and any(center["low"] < o["low"] for o in others):
            await self._register_pool(symbol, "low", center["low"], center["index"])

    async def _register_pool(self, symbol: str, pool_type: str, price: float, index: int) -> None:
        pools = self._active_pools.setdefault(symbol, [])
        pools.append({"type": pool_type, "price": price, "index": index})
        self.pools_detected_count += 1
        await self._context.publish(
            "market.liquidity.updated", {"symbol": symbol, "type": pool_type, "price": price, "index": index}
        )
