import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom251"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context():
    published = []

    async def publish(name, payload):
        published.append((name, payload))

    return AtomContext(atom_id=251, config={}, logger=_NullLogger(), publish=publish, subscribe=lambda n, h: None), published


async def _feed_candles(atom, symbol, highs, lows):
    for h, low in zip(highs, lows):
        await atom._on_candle({"symbol": symbol, "high": h, "low": low, "open": h, "close": low, "volume": 1, "timeframe": "60s"})


async def test_high_liquidity_pool_detected():
    print("\n--- test_high_liquidity_pool_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 15, 20, 15, 10], lows=[5, 5, 5, 5, 5])
    events = [p for n, p in published if n == "market.liquidity.updated"]
    assert len(events) == 1
    assert events[0] == {"symbol": "NQ", "type": "high", "price": 20, "index": 2}
    print(f"OK — مجمع سيولة علوي مكتشَف: {events[0]}")


async def test_low_liquidity_pool_detected():
    print("\n--- test_low_liquidity_pool_detected ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[25, 25, 25, 25, 25], lows=[20, 15, 10, 15, 20])
    events = [p for n, p in published if n == "market.liquidity.updated"]
    assert events[0] == {"symbol": "NQ", "type": "low", "price": 10, "index": 2}
    print(f"OK — مجمع سيولة سفلي مكتشَف: {events[0]}")


async def test_monotonic_sequence_no_pool():
    print("\n--- test_monotonic_sequence_no_pool ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 12, 14, 16, 18], lows=[5, 7, 9, 11, 13])
    events = [p for n, p in published if n == "market.liquidity.updated"]
    assert len(events) == 0
    print("OK — اتجاه صاعد بحت → صفر مجمعات سيولة")


async def test_structure_context_event_does_not_error():
    print("\n--- test_structure_context_event_does_not_error ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await atom._on_structure_context({"symbol": "NQ", "state": {"anything": "here"}})  # سياق عام بس، بلا استخراج
    print("OK — حدث 210 لم يسبب أي خطأ (استهلاك سياقي بس، بلا استخراج قيم)")


async def test_detected_pool_tracked_as_active():
    print("\n--- test_detected_pool_tracked_as_active ---")
    context, published = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 15, 20, 15, 10], lows=[5, 5, 5, 5, 5])
    assert len(atom._active_pools["NQ"]) == 1
    assert atom._active_pools["NQ"][0]["type"] == "high"
    print(f"OK — المجمع المكتشَف يبقى متتبَّعًا كـ'نشط': {atom._active_pools['NQ']}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    context, _ = make_context()
    atom = Atom()
    await atom.initialize(context)
    await _feed_candles(atom, "NQ", highs=[10, 15, 20, 15, 10], lows=[5, 5, 5, 5, 5])
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    assert len(atom2._active_pools["NQ"]) == 1
    assert atom2.pools_detected_count == 1
    print("OK — restore() نقل البرك النشطة والعدّاد بدقّة")


async def main():
    tests = [
        test_high_liquidity_pool_detected,
        test_low_liquidity_pool_detected,
        test_monotonic_sequence_no_pool,
        test_structure_context_event_does_not_error,
        test_detected_pool_tracked_as_active,
        test_snapshot_restore,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
