# 257 — CVD Analyzer (محلّل الدلتا التراكمية)

نفس قيد 256 حرفيًا. CVD = تراكم Delta عبر الزمن — يحتاج نفس المصدر
الحقيقي غير المتوفر بعد.

## طريقة الاختبار
```bash
python3 tests/test_atom.py
```
3 اختبارات: UNAVAILABLE افتراضيًا، HEALTHY لو متاح، `snapshot`/`restore`.
**نتيجة: 3/3.**
