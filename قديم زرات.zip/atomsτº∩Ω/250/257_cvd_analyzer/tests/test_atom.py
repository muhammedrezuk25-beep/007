import asyncio
import os
import sys

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
import sys as _sys  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402
_MOD_NAME = "_atom257"
_spec = _ilu.spec_from_file_location(
    _MOD_NAME, _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
_sys.modules[_MOD_NAME] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


def make_context(config=None):
    return AtomContext(atom_id=257, config=config or {}, logger=_NullLogger(), publish=lambda n, p: None, subscribe=lambda n, h: None)


async def test_unavailable_by_default():
    print("\n--- test_unavailable_by_default ---")
    atom = Atom()
    await atom.initialize(make_context())
    h = await atom.health_check()
    assert h.state.value == "unknown"
    print(f"OK — بلا تكوين مصدر Order Flow → UNKNOWN صراحة: {h.message}")


async def test_available_when_configured():
    print("\n--- test_available_when_configured ---")
    atom = Atom()
    await atom.initialize(make_context({"order_flow_available": True}))
    h = await atom.health_check()
    assert h.state.value == "healthy"
    print(f"OK — مصدر متاح صراحة → HEALTHY: {h.message}")


async def test_snapshot_restore():
    print("\n--- test_snapshot_restore ---")
    atom = Atom()
    await atom.initialize(make_context({"order_flow_available": True}))
    snap = await atom.snapshot()
    atom2 = Atom()
    await atom2.restore(snap)
    h = await atom2.health_check()
    assert h.state.value == "healthy"
    print("OK — restore() نقل حالة توفّر المصدر بدقّة")


async def main():
    tests = [test_unavailable_by_default, test_available_when_configured, test_snapshot_restore]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
