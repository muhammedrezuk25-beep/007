# Muhammed_Rezuk_NQ

بوت تيليجرام عربي لمتابعة ناسداك، مع تقرير صباحي، أخبار، أجندة يومية، وإدارة مستخدمين.

## المزايا الحالية
- بوت تيليجرام عربي
- إدارة مستخدمين وصلاحيات
- تقرير صباحي يومي مجدول
- أمر لعرض الأخبار `/news`
- أمر لعرض الأجندة `/calendar`
- أمر لإظهار المعرّف `/id`
- سجل logs
- تخزين محلي للمستخدمين والإعدادات

## الأوامر
### للمستخدمين المسموح لهم
- `/start`
- `/help`
- `/morning`
- `/news`
- `/calendar`
- `/status`
- `/id`

### للمالك فقط
- `/add_user <chat_id>`
- `/remove_user <chat_id>`
- `/list_users`

## الإعداد
1. ثبّت Python 3.12.
2. أنشئ بيئة افتراضية:
   ```bash
   py -3.12 -m venv .venv
   .venv\Scripts\activate
   ```
3. ثبّت المتطلبات:
   ```bash
   pip install -r requirements.txt
   ```
4. انسخ `.env.example` إلى `.env` ثم عدل القيم.
5. شغّل البوت:
   ```bash
   python main.py
   ```

## ملف .env
```env
BOT_TOKEN=ضع_توكن_البوت_هنا
OWNER_CHAT_ID=ضع_رقمك_هنا
TIMEZONE=Europe/Istanbul
MORNING_REPORT_HOUR=14
MORNING_REPORT_MINUTE=00
DATA_DIR=data
LOG_DIR=logs
```

## ملاحظات
- الترجمة الحالية Placeholder وتعرض النص كما هو.
- الأجندة الحالية أولية/تجريبية وجاهزة للربط بمصدر حي لاحقًا.
- الأخبار من RSS وقد تختلف جودتها حسب المصدر.
