from __future__ import annotations

from typing import List, Dict


class AnalysisService:
    def __init__(self) -> None:
        self.positive_keywords = ["beat", "growth", "surge", "gain", "optimism", "rally"]
        self.negative_keywords = ["drop", "fall", "selloff", "fear", "inflation", "hawkish", "yield"]

    def score_headline(self, title: str, summary: str = "") -> str:
        text = f"{title} {summary}".lower()
        pos = sum(1 for k in self.positive_keywords if k in text)
        neg = sum(1 for k in self.negative_keywords if k in text)
        if pos > neg:
            return "إيجابي مبدئيًا على ناسداك"
        if neg > pos:
            return "سلبي مبدئيًا على ناسداك"
        return "محايد أو يحتاج تأكيد من السوق"

    def build_news_digest(self, news_items: List[Dict[str, str]]) -> str:
        if not news_items:
            return "لا توجد أخبار متاحة حاليًا."

        lines = ["📰 أهم أخبار ناسداك الآن:\n"]
        for idx, item in enumerate(news_items[:8], start=1):
            impact = self.score_headline(
                item.get("title_ar", item.get("title", "")),
                item.get("summary_ar", item.get("summary", "")),
            )
            lines.append(
                f"{idx}) {item.get('title_ar', item.get('title', ''))}\n"
                f"- التقييم: {impact}\n"
                f"- الرابط: {item.get('link', '')}\n"
            )
        return "\n".join(lines)
