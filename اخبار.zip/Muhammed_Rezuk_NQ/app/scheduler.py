from __future__ import annotations

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from telegram.ext import Application

from app.reporting import build_morning_report
from app.state_manager import StateManager
from app.storage import JsonStorage


async def send_morning_report(application: Application, storage: JsonStorage, state: StateManager) -> None:
    message = build_morning_report()
    for chat_id in storage.list_users():
        try:
            await application.bot.send_message(chat_id=chat_id, text=message)
        except Exception:
            pass
    state.touch("last_morning_report")


async def heartbeat(state: StateManager) -> None:
    state.touch("last_heartbeat")


def build_scheduler(
    application: Application,
    storage: JsonStorage,
    state: StateManager,
    timezone: str,
    hour: int,
    minute: int,
) -> AsyncIOScheduler:
    scheduler = AsyncIOScheduler(timezone=timezone)
    scheduler.add_job(
        send_morning_report,
        CronTrigger(hour=hour, minute=minute, timezone=timezone),
        args=[application, storage, state],
        id="morning_report",
        replace_existing=True,
    )
    scheduler.add_job(
        heartbeat,
        CronTrigger(minute="*/5", timezone=timezone),
        args=[state],
        id="heartbeat",
        replace_existing=True,
    )
    return scheduler
