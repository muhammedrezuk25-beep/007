from __future__ import annotations

import logging

from telegram import ReplyKeyboardMarkup, Update
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

from app.analysis_service import AnalysisService
from app.calendar_service import CalendarService
from app.macro_bridge import MacroBridge
from app.news_service import NewsService
from app.reporting import build_morning_report
from app.routing_service import RoutingService
from app.state_manager import StateManager
from app.storage import JsonStorage
from app.translator import TranslatorService


logger = logging.getLogger("Muhammed_Rezuk_NQ")


class TelegramBot:
    def __init__(self, application: Application, storage: JsonStorage, state: StateManager):
        self.application = application
        self.storage = storage
        self.state = state
        self.news_service = NewsService()
        self.analysis_service = AnalysisService()
        self.calendar_service = CalendarService()
        self.routing_service = RoutingService()
        self.translator = TranslatorService()
        self.macro_bridge = MacroBridge()

    def main_keyboard(self, is_owner: bool = False) -> ReplyKeyboardMarkup:
        rows = [
            ["📊 التقرير الصباحي", "📰 الأخبار"],
            ["📅 الأجندة", "⚙️ الحالة"],
            ["🩺 الصحة", "🆔 معرفي"],
            ["📘 المساعدة"],
        ]
        if is_owner:
            rows.append(["👥 المستخدمون"])
        return ReplyKeyboardMarkup(rows, resize_keyboard=True)

    def register_handlers(self) -> None:
        self.application.add_handler(CommandHandler("start", self.start))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CommandHandler("morning", self.morning_report))
        self.application.add_handler(CommandHandler("news", self.news))
        self.application.add_handler(CommandHandler("calendar", self.calendar))
        self.application.add_handler(CommandHandler("status", self.status))
        self.application.add_handler(CommandHandler("health", self.health))
        self.application.add_handler(CommandHandler("id", self.my_id))
        self.application.add_handler(CommandHandler("add_user", self.add_user))
        self.application.add_handler(CommandHandler("remove_user", self.remove_user))
        self.application.add_handler(CommandHandler("list_users", self.list_users))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.text_router))

    async def _notify_owner_new_request(self, update: Update) -> None:
        owner_data = self.storage.get_users()
        owner_chat_id = int(owner_data.get("owner_chat_id", 0) or 0)
        if not owner_chat_id:
            return
        user = update.effective_user
        chat = update.effective_chat
        if not user or not chat:
            return
        username = f"@{user.username}" if user.username else "لا يوجد"
        full_name = user.full_name if user.full_name else "غير معروف"
        chat_id = chat.id
        text = (
            "🔔 طلب انضمام جديد للبوت\n\n"
            f"- الاسم: {full_name}\n"
            f"- اليوزر: {username}\n"
            f"- chat_id: {chat_id}\n\n"
            f"لإضافة هذا المستخدم:\n/add_user {chat_id}"
        )
        await self.application.bot.send_message(chat_id=owner_chat_id, text=text)

    async def _ensure_allowed(self, update: Update) -> bool:
        chat_id = update.effective_chat.id if update.effective_chat else 0
        if self.storage.is_allowed(chat_id):
            return True
        if update.message:
            await update.message.reply_text("عذرًا، أنت غير مضاف حاليًا. أرسل /start لطلب الانضمام.")
        return False

    async def _ensure_owner(self, update: Update) -> bool:
        chat_id = update.effective_chat.id if update.effective_chat else 0
        if self.storage.is_owner(chat_id):
            return True
        if update.message:
            await update.message.reply_text("هذا الأمر متاح للمالك فقط.")
        return False

    async def start(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id if update.effective_chat else 0
        logger.info("/start from chat_id=%s", chat_id)
        if self.storage.is_allowed(chat_id):
            await update.message.reply_text(
                "أهلًا بك في Muhammed_Rezuk_NQ\nبوت عربي لمتابعة ناسداك.",
                reply_markup=self.main_keyboard(self.storage.is_owner(chat_id)),
            )
        else:
            await update.message.reply_text(
                f"تم استلام طلبك ✅\nمعرّفك هو: {chat_id}\nسيصل طلبك إلى المالك."
            )
            await self._notify_owner_new_request(update)

    async def text_router(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not update.message:
            return
        text = update.message.text.strip()
        mapping = {
            "📊 التقرير الصباحي": self.morning_report,
            "📰 الأخبار": self.news,
            "📅 الأجندة": self.calendar,
            "⚙️ الحالة": self.status,
            "🩺 الصحة": self.health,
            "🆔 معرفي": self.my_id,
            "📘 المساعدة": self.help_command,
            "👥 المستخدمون": self.list_users,
        }
        handler = mapping.get(text)
        if handler:
            await handler(update, context)

    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        await update.message.reply_text(
            "📘 الأوامر:\n"
            "/start\n/help\n/morning\n/news\n/calendar\n/status\n/health\n/id\n\n"
            "الإدارة:\n/add_user <chat_id>\n/remove_user <chat_id>\n/list_users",
            reply_markup=self.main_keyboard(self.storage.is_owner(update.effective_chat.id if update.effective_chat else 0)),
        )

    async def morning_report(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        self.state.touch("last_morning_report")
        await update.message.reply_text(build_morning_report())

    def _format_news_message(self, item: dict) -> str:
        analyzed = self.analysis_service.analyze_news_item(item)
        return (
            f"🟢 الخبر بالعربي:\n{analyzed.get('title_ar', analyzed.get('title', ''))}\n\n"
            f"🔹 English:\n{analyzed.get('title', '')}\n\n"
            f"📌 الطبقة: {analyzed.get('layer', 5)}\n"
            f"🔒 الموثوقية: {analyzed.get('credibility', 'غير معروف')}\n"
            f"📊 الأثر على ناسداك: {analyzed.get('impact', 'غير محدد')}\n"
            f"🧠 السبب: {analyzed.get('reason', 'لا يوجد تفسير')}\n"
            f"🔗 الرابط: {analyzed.get('link', '')}"
        )

    async def news(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        raw_news = self.news_service.fetch_latest_news(limit=20)
        self.state.touch("last_news_fetch")
        if not raw_news:
            await update.message.reply_text("لا توجد أخبار متاحة حاليًا.")
            return
        sent_count = 0
        translated_news = self.translator.translate_news_batch(raw_news)
        for item in translated_news:
            logger.info("تم تجهيز الخبر للقبو: %s", item.get("title", ""))
            decision = self.routing_service.get_routing_decision(item)
            if not decision.get("send_to_telegram", False):
                continue
            await update.message.reply_text(self._format_news_message(item))
            self.state.touch("last_news_sent")
            sent_count += 1
            if sent_count >= 5:
                break
        if sent_count == 0:
            await update.message.reply_text("لا توجد أخبار تستحق الإرسال حاليًا.")

    async def calendar(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        await update.message.reply_text(self.calendar_service.build_calendar_report())

    async def status(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        if self.calendar_service.is_event_lock_active():
            active_event = self.calendar_service.get_active_lock_event()
            event_name = active_event["event"] if active_event else "حدث اقتصادي قوي"
            await update.message.reply_text(f"البوت يعمل ✅\nEvent Lock مفعل بسبب: {event_name}")
        else:
            await update.message.reply_text("البوت يعمل بشكل طبيعي ✅\nلا يوجد Event Lock الآن.")

    async def health(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_allowed(update):
            return
        self.state.set("bot_running", True)
        self.state.set("scheduler_running", True)
        self.state.set("event_lock", self.calendar_service.is_event_lock_active())
        self.state.set("macro_bridge_available", self.macro_bridge.is_available())
        state = self.state.get_all()
        users_count = len(self.storage.list_users())
        msg = (
            "🩺 لوحة الصحة التشغيلية\n\n"
            f"- البوت: {'يعمل ✅' if state.get('bot_running') else 'متوقف ❌'}\n"
            f"- المجدول: {'يعمل ✅' if state.get('scheduler_running') else 'متوقف ❌'}\n"
            f"- Event Lock: {'مفعل' if state.get('event_lock') else 'غير مفعل'}\n"
            f"- Macro Bridge: {'متاح' if state.get('macro_bridge_available') else 'غير متاح'}\n"
            f"- آخر جلب أخبار: {state.get('last_news_fetch') or 'لا يوجد'}\n"
            f"- آخر خبر مرسل: {state.get('last_news_sent') or 'لا يوجد'}\n"
            f"- آخر تقرير صباحي: {state.get('last_morning_report') or 'لا يوجد'}\n"
            f"- آخر نبضة: {state.get('last_heartbeat') or 'لا يوجد'}\n"
            f"- آخر خطأ: {state.get('last_error') or 'لا يوجد'}\n"
            f"- عدد المستخدمين: {users_count}"
        )
        await update.message.reply_text(msg)

    async def my_id(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        chat_id = update.effective_chat.id if update.effective_chat else 0
        await update.message.reply_text(f"معرّفك هو: {chat_id}")

    async def add_user(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_owner(update):
            return
        if not context.args:
            await update.message.reply_text("استخدم الأمر هكذا:\n/add_user 123456789")
            return
        try:
            chat_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("chat_id غير صالح.")
            return
        added = self.storage.add_user(chat_id)
        if added:
            await update.message.reply_text(f"تمت إضافة المستخدم {chat_id} ✅")
            try:
                await self.application.bot.send_message(chat_id=chat_id, text="تمت الموافقة على انضمامك ✅")
            except Exception:
                pass
        else:
            await update.message.reply_text("المستخدم موجود بالفعل أو تعذر إضافته.")

    async def remove_user(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_owner(update):
            return
        if not context.args:
            await update.message.reply_text("استخدم الأمر هكذا:\n/remove_user 123456789")
            return
        try:
            chat_id = int(context.args[0])
        except ValueError:
            await update.message.reply_text("chat_id غير صالح.")
            return
        removed = self.storage.remove_user(chat_id)
        if removed:
            await update.message.reply_text(f"تم حذف المستخدم {chat_id} ✅")
        else:
            await update.message.reply_text("تعذر حذف المستخدم. ربما غير موجود أو أنه المالك.")

    async def list_users(self, update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
        if not await self._ensure_owner(update):
            return
        users = self.storage.list_users()
        text = "\n".join(str(u) for u in users) if users else "لا يوجد مستخدمون."
        await update.message.reply_text(f"📋 قائمة المستخدمين:\n{text}")
