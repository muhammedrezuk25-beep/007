from __future__ import annotations

from datetime import datetime
from typing import List, Dict


class CalendarService:
    def __init__(self) -> None:
        pass

    def get_today_events(self) -> List[Dict[str, str]]:
        return [
            {
                "time": "15:30",
                "event": "بيانات أمريكية مهمة",
                "importance": "عالية",
                "note": "قد تؤثر على العوائد وناسداك",
            },
            {
                "time": "17:00",
                "event": "مؤشر اقتصادي أمريكي",
                "importance": "متوسطة",
                "note": "قد يؤثر على شهية المخاطرة أثناء الجلسة",
            },
            {
                "time": "21:00",
                "event": "تصريحات عضو فيدرالي",
                "importance": "عالية",
                "note": "أي نبرة متشددة قد تضغط على أسهم النمو",
            },
        ]

    def build_calendar_report(self) -> str:
        today = datetime.now().strftime("%Y-%m-%d")
        events = self.get_today_events()

        if not events:
            return f"📅 أجندة اليوم {today}\n\nلا توجد أحداث اقتصادية مهمة اليوم."

        lines = [f"📅 أجندة اليوم {today}\n"]
        for idx, event in enumerate(events, start=1):
            lines.append(
                f"{idx}) الوقت: {event['time']}\n"
                f"- الحدث: {event['event']}\n"
                f"- الأهمية: {event['importance']}\n"
                f"- ملاحظة: {event['note']}\n"
            )

        return "\n".join(lines)
