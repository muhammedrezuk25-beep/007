from __future__ import annotations

from typing import List, Dict

try:
    from deep_translator import GoogleTranslator
except Exception:
    GoogleTranslator = None


class TranslatorService:
    def __init__(self) -> None:
        self.translator = None
        if GoogleTranslator is not None:
            try:
                self.translator = GoogleTranslator(source="auto", target="ar")
            except Exception:
                self.translator = None

    def translate_text(self, text: str) -> str:
        if not text:
            return ""
        if self.translator is None:
            return text
        try:
            out = self.translator.translate(text)
            return out if out else text
        except Exception:
            return text

    def translate_news_batch(self, news_items: List[Dict[str, str]]) -> List[Dict[str, str]]:
        translated = []
        for item in news_items:
            translated.append({
                **item,
                "title_ar": self.translate_text(item.get("title", "")),
                "summary_ar": self.translate_text(item.get("summary", "")),
            })
        return translated
