from __future__ import annotations

from typing import List, Dict
import feedparser


NASDAQ_FEEDS = [
    "https://feeds.finance.yahoo.com/rss/2.0/headline?s=%5ENDX&region=US&lang=en-US",
    "https://finance.yahoo.com/topic/stock-market-news/rssindex",
    "https://finance.yahoo.com/topic/tech/rssindex",
]


class NewsService:
    def __init__(self) -> None:
        pass

    def fetch_latest_news(self, limit: int = 10) -> List[Dict[str, str]]:
        items: List[Dict[str, str]] = []
        seen = set()

        for feed_url in NASDAQ_FEEDS:
            try:
                feed = feedparser.parse(feed_url)
                for entry in feed.entries:
                    title = getattr(entry, "title", "").strip()
                    link = getattr(entry, "link", "").strip()
                    summary = getattr(entry, "summary", "").strip()
                    if not title or title in seen:
                        continue
                    seen.add(title)
                    items.append(
                        {
                            "title": title,
                            "link": link,
                            "summary": summary,
                        }
                    )
                    if len(items) >= limit:
                        return items
            except Exception:
                continue
        return items
