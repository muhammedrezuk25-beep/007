from __future__ import annotations

import asyncio
import os

from telegram.ext import Application

from app.config import load_config
from app.logger import setup_logger
from app.scheduler import build_scheduler
from app.state_manager import StateManager
from app.storage import JsonStorage
from app.telegram_bot import TelegramBot


async def main() -> None:
    config = load_config()
    logger = setup_logger(config.log_dir)

    os.makedirs(config.data_dir, exist_ok=True)
    os.makedirs(config.log_dir, exist_ok=True)

    storage = JsonStorage(config.data_dir)
    storage.set_owner_if_empty(config.owner_chat_id)
    state = StateManager(config.data_dir)

    if not config.bot_token:
        raise ValueError("BOT_TOKEN غير موجود داخل ملف .env")
    if not config.owner_chat_id:
        logger.warning("OWNER_CHAT_ID غير مضبوط بعد. يجب ضبطه داخل .env")

    application = Application.builder().token(config.bot_token).build()

    bot = TelegramBot(application, storage, state)
    bot.register_handlers()

    scheduler = build_scheduler(
        application=application,
        storage=storage,
        state=state,
        timezone=config.timezone,
        hour=config.morning_report_hour,
        minute=config.morning_report_minute,
    )
    scheduler.start()

    state.set("bot_running", True)
    state.set("scheduler_running", True)
    logger.info("Muhammed_Rezuk_NQ started successfully")

    await application.initialize()
    await application.start()
    await application.updater.start_polling()

    try:
        while True:
            await asyncio.sleep(3600)
    finally:
        state.set("bot_running", False)
        state.set("scheduler_running", False)
        await application.updater.stop()
        await application.stop()
        await application.shutdown()
        scheduler.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
