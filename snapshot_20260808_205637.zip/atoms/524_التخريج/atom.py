from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LEDGER = "risk.asset_ledger.state"
EVENT_STATE = "asset.extraction.state"
EVENT_PARTIAL = "asset.extraction.requested"
EVENT_FULL = "asset.full_extraction.requested"

KIND_PARTIAL = "partial"
KIND_FULL = "full"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_LEDGER_YET"

_KEY_SEP = "|"
_MONEY_DP = 4
_LOOP_CAP = 60


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._mult = 2.0
        self._fraction = 0.5
        self._full_targets: dict[str, float] = {}
        self._default_full = 0.0
        self._highest: dict[str, int] = {}
        self._full_fired: dict[str, bool] = {}
        self._last: dict[str, Any] | None = None
        self._partials = 0
        self._fulls = 0
        self._updates = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._mult = float(cfg.get("milestone_mult", 2.0))
        self._fraction = float(cfg.get("extract_fraction", 0.5))
        self._default_full = _to_float(cfg.get("default_full_target", 0.0)) or 0.0
        raw = cfg.get("full_targets") if isinstance(cfg.get("full_targets"), dict) else {}
        for key, value in raw.items():
            amount = _to_float(value)
            if amount is not None and amount > 0.0:
                self._full_targets[str(key)] = amount
        context.subscribe(EVENT_LEDGER, self._on_ledger)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _highest_k(self, net: float, budget: float) -> int:
        if net < budget or budget <= 0.0 or self._mult <= 1.0:
            return -1
        k = -1
        level = budget
        guard = 0
        while net >= level and guard < _LOOP_CAP:
            k += 1
            level *= self._mult
            guard += 1
        return k

    def _full_target_for(self, key: str) -> float:
        if key in self._full_targets:
            return self._full_targets[key]
        return self._default_full

    async def _on_ledger(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        ledgers = payload.get("ledgers")
        if not isinstance(ledgers, list):
            return
        requests: list[dict[str, Any]] = []
        levels: list[dict[str, Any]] = []
        for led in ledgers:
            if not isinstance(led, dict):
                continue
            symbol = str(led.get("symbol") or "")
            if not symbol:
                continue
            account_id = str(led.get("account_id") or "")
            key = account_id + _KEY_SEP + symbol
            budgeted = bool(led.get("budgeted"))
            budget = _to_float(led.get("budget"))
            net = _to_float(led.get("net"))
            if not budgeted or budget is None or budget <= 0.0 or net is None:
                levels.append({"account_id": account_id, "symbol": symbol, "net": net,
                               "highest_milestone": self._highest.get(key, -1),
                               "eligible": False})
                continue
            await self._maybe_partial(key, account_id, symbol, net, budget, requests)
            await self._maybe_full(key, account_id, symbol, net, requests)
            k = self._highest.get(key, -1)
            levels.append({
                "account_id": account_id, "symbol": symbol, "net": round(net, _MONEY_DP),
                "budget": budget, "highest_milestone": k,
                "next_milestone": round(budget * (self._mult ** (k + 1)), _MONEY_DP),
                "full_target": self._full_target_for(key),
                "full_fired": self._full_fired.get(key, False), "eligible": True})
        out: dict[str, Any] = {"levels": levels, "requests": requests,
                               "count": len(levels), "request_count": len(requests)}
        stamp = payload.get("timestamp")
        if stamp is not None:
            out["timestamp"] = stamp
        self._last = out
        self._updates += 1
        await self._context.publish(EVENT_STATE, out)

    async def _maybe_partial(self, key: str, account_id: str, symbol: str,
                             net: float, budget: float, requests: list[dict[str, Any]]) -> None:
        k = self._highest_k(net, budget)
        if k < 0 or k <= self._highest.get(key, -1):
            return
        milestone = budget * (self._mult ** k)
        amount = self._fraction * milestone
        self._highest[key] = k
        self._partials += 1
        request = {"account_id": account_id, "symbol": symbol, "kind": KIND_PARTIAL,
                   "amount": round(amount, _MONEY_DP), "milestone_k": k,
                   "milestone": round(milestone, _MONEY_DP), "net": round(net, _MONEY_DP)}
        requests.append(request)
        await self._context.publish(EVENT_PARTIAL, request)

    async def _maybe_full(self, key: str, account_id: str, symbol: str,
                          net: float, requests: list[dict[str, Any]]) -> None:
        target = self._full_target_for(key)
        if target <= 0.0 or net < target or self._full_fired.get(key, False):
            return
        self._full_fired[key] = True
        self._fulls += 1
        request = {"account_id": account_id, "symbol": symbol, "kind": KIND_FULL,
                   "target": target, "net": round(net, _MONEY_DP)}
        requests.append(request)
        await self._context.publish(EVENT_FULL, request)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"updates": self._updates, "partials": self._partials, "fulls": self._fulls}
        if self._last is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="partials=%d fulls=%d" % (self._partials, self._fulls),
                            details=details)
