from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_ACTIVATE = "perpetual.asset.activate"
EVENT_DEACTIVATE = "perpetual.asset.deactivate"
EVENT_DIAL = "dial.profile.state"
EVENT_SPECS = "market.symbol_specs"
EVENT_CANDLE = "market_data.candle_closed"
EVENT_LEDGER = "risk.asset_ledger.state"
EVENT_DECISION = "trading.final_decision"
EVENT_STATE = "perpetual.entry.state"

ACTION_OPEN = "OPEN"
SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

ST_OPENED = "OPENED"
ST_ALREADY = "ALREADY_ACTIVE"
ST_MISSING = "MISSING_INPUTS"
ST_LOT_SMALL = "LOT_TOO_SMALL"

REASON_NOT_STARTED = "NOT_STARTED"

_KEY_SEP = "|"
_PRICE_DP = 6
_LOT_DP = 2


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._lot_step = 0.01
        self._min_lot = 0.01
        self._max_lot = 20.0
        self._vpu: dict[str, float] = {}
        self._price: dict[str, float] = {}
        self._stopfrac: dict[str, float] = {}
        self._budget: dict[str, float] = {}
        self._active: set[str] = set()
        self._counter = 0
        self._opened = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._lot_step = float(cfg.get("lot_step", 0.01))
        self._min_lot = float(cfg.get("min_lot", 0.01))
        self._max_lot = float(cfg.get("max_lot", 20.0))
        context.subscribe(EVENT_DIAL, self._on_dial)
        context.subscribe(EVENT_SPECS, self._on_specs)
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_LEDGER, self._on_ledger)
        context.subscribe(EVENT_ACTIVATE, self._on_activate)
        context.subscribe(EVENT_DEACTIVATE, self._on_deactivate)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_dial(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        for prof in payload.get("profiles", []) if isinstance(payload.get("profiles"), list) else []:
            if not isinstance(prof, dict):
                continue
            symbol = str(prof.get("symbol") or "")
            frac = _to_float(prof.get("stop_distance_frac"))
            if symbol and frac is not None:
                self._stopfrac[str(prof.get("account_id") or "") + _KEY_SEP + symbol] = frac

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        for row in payload.get("symbols", []) if isinstance(payload.get("symbols"), list) else []:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            tick_value = _to_float(row.get("tick_value"))
            tick_size = _to_float(row.get("tick_size"))
            if symbol and tick_value is not None and tick_size and tick_size > 0.0:
                vpu = tick_value / tick_size
                if vpu > 0.0:
                    self._vpu[str(symbol)] = vpu

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        close = _to_float(payload.get("close"))
        if symbol and close is not None and close > 0.0:
            self._price[str(symbol)] = close

    async def _on_ledger(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        for led in payload.get("ledgers", []) if isinstance(payload.get("ledgers"), list) else []:
            if not isinstance(led, dict):
                continue
            symbol = str(led.get("symbol") or "")
            budget = _to_float(led.get("budget"))
            if symbol and budget is not None and budget > 0.0:
                self._budget[str(led.get("account_id") or "") + _KEY_SEP + symbol] = budget

    async def _on_deactivate(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        if not symbol:
            return
        self._active.discard(str(payload.get("account_id") or "") + _KEY_SEP + symbol)

    def _size(self, key: str, symbol: str, budget: float) -> tuple[float, float, float] | None:
        price = self._price.get(symbol)
        vpu = self._vpu.get(symbol)
        stop_frac = self._stopfrac.get(key)
        if price is None or vpu is None or stop_frac is None or stop_frac <= 0.0:
            return None
        stop_distance = price * stop_frac
        denom = stop_distance * vpu
        if denom <= 0.0:
            return None
        raw = budget / denom
        stepped = round(raw / self._lot_step) * self._lot_step
        lot = min(self._max_lot, max(0.0, stepped))
        return round(lot, _LOT_DP), price, stop_distance

    async def _on_activate(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        account_id = str(payload.get("account_id") or "")
        if not symbol or not account_id:
            return
        key = account_id + _KEY_SEP + symbol
        if key in self._active:
            await self._emit_state(account_id, symbol, ST_ALREADY, {})
            return
        budget = _to_float(payload.get("budget")) or self._budget.get(key)
        if budget is None or budget <= 0.0:
            await self._emit_state(account_id, symbol, ST_MISSING, {"budget": budget})
            return
        sized = self._size(key, symbol, budget)
        if sized is None:
            await self._emit_state(account_id, symbol, ST_MISSING, {
                "price": self._price.get(symbol), "vpu": self._vpu.get(symbol),
                "stop_frac": self._stopfrac.get(key)})
            return
        lot, price, stop_distance = sized
        if lot < self._min_lot:
            await self._emit_state(account_id, symbol, ST_LOT_SMALL, {"lot": lot, "budget": budget})
            return
        await self._open(account_id, symbol, SIDE_BUY, lot, price)
        await self._open(account_id, symbol, SIDE_SELL, lot, price)
        self._active.add(key)
        self._opened += 1
        await self._emit_state(account_id, symbol, ST_OPENED, {
            "lot": lot, "price": round(price, _PRICE_DP),
            "stop_distance": round(stop_distance, _PRICE_DP)})

    async def _open(self, account_id: str, symbol: str, side: str, lot: float, price: float) -> None:
        if self._context is None:
            return
        self._counter += 1
        await self._context.publish(EVENT_DECISION, {
            "request_id": "perp-%s-%s-%d" % (symbol, side, self._counter),
            "account_id": account_id, "action": ACTION_OPEN, "symbol": symbol,
            "side": side, "volume": lot, "reference_price": round(price, _PRICE_DP),
            "stop_loss": None, "take_profit": None, "origin": "perpetual"})

    async def _emit_state(self, account_id: str, symbol: str, status: str,
                          extra: dict[str, Any]) -> None:
        if self._context is None:
            return
        body = {"account_id": account_id, "symbol": symbol, "status": status}
        body.update(extra)
        await self._context.publish(EVENT_STATE, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="active=%d opened=%d" % (len(self._active), self._opened),
            details={"active": len(self._active), "opened": self._opened,
                     "prices": len(self._price), "specs": len(self._vpu)})
