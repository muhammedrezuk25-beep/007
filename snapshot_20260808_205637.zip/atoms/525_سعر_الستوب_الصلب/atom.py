from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LEDGER = "risk.asset_ledger.state"
EVENT_SPECS = "market.symbol_specs"
EVENT_OUT = "risk.hard_stop.price"

DIR_LONG = "LONG"
DIR_SHORT = "SHORT"

R_OK = "OK"
R_NO_BUDGET = "NO_BUDGET"
R_NO_SPECS = "NO_SPECS"
R_FLAT = "FLAT_NO_PRICE_STOP"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_LEDGER_YET"

_PRICE_DP = 8


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._min_abs_v_net = 1e-9
        self._vpu: dict[str, float] = {}
        self._last: dict[str, Any] | None = None
        self._updates = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_abs_v_net = float(context.config.get("min_abs_v_net", 1e-9))
        context.subscribe(EVENT_SPECS, self._on_specs)
        context.subscribe(EVENT_LEDGER, self._on_ledger)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbols = payload.get("symbols")
        if not isinstance(symbols, list):
            return
        for row in symbols:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            tick_value = _to_float(row.get("tick_value"))
            tick_size = _to_float(row.get("tick_size"))
            if not symbol or tick_value is None or tick_size is None or tick_size <= 0.0:
                continue
            vpu = tick_value / tick_size
            if vpu > 0.0:
                self._vpu[str(symbol)] = vpu

    def _compute(self, led: dict[str, Any]) -> dict[str, Any]:
        account_id = str(led.get("account_id") or "")
        symbol = str(led.get("symbol") or "")
        v_net = _to_float(led.get("v_net"))
        w = _to_float(led.get("w"))
        budget = _to_float(led.get("budget"))
        buffer_k = _to_float(led.get("buffer_k")) or 0.0
        commission = _to_float(led.get("commission_est")) or 0.0
        base = {"account_id": account_id, "symbol": symbol, "v_net": v_net,
                "budget": budget, "buffer_k": buffer_k, "commission_est": commission,
                "computable": False, "p_stop": None, "delta_p": None,
                "avg_entry": None, "direction": None, "vpu": self._vpu.get(symbol)}
        if not bool(led.get("budgeted")) or budget is None or budget <= 0.0:
            base["reason"] = R_NO_BUDGET
            return base
        vpu = self._vpu.get(symbol)
        if vpu is None or vpu <= 0.0:
            base["reason"] = R_NO_SPECS
            return base
        if v_net is None or w is None or abs(v_net) < self._min_abs_v_net:
            base["reason"] = R_FLAT
            return base
        room = budget + buffer_k - commission
        delta_p = room / (vpu * abs(v_net))
        p_stop = (w + (-budget - buffer_k + commission) / vpu) / v_net
        avg_entry = w / v_net
        base.update({
            "computable": True, "reason": R_OK,
            "p_stop": round(p_stop, _PRICE_DP), "delta_p": round(delta_p, _PRICE_DP),
            "avg_entry": round(avg_entry, _PRICE_DP),
            "direction": DIR_LONG if v_net > 0.0 else DIR_SHORT, "vpu": vpu,
        })
        return base

    async def _on_ledger(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        ledgers = payload.get("ledgers")
        if not isinstance(ledgers, list):
            return
        stops = []
        for led in ledgers:
            if isinstance(led, dict) and led.get("symbol"):
                stops.append(self._compute(led))
        computable = sum(1 for s in stops if s["computable"])
        out: dict[str, Any] = {"stops": stops, "count": len(stops),
                               "computable_count": computable}
        stamp = payload.get("timestamp")
        if stamp is not None:
            out["timestamp"] = stamp
        self._last = out
        self._updates += 1
        await self._context.publish(EVENT_OUT, out)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"updates": self._updates, "specs": len(self._vpu),
                   "computable": (self._last or {}).get("computable_count")}
        if self._last is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="stops=%d computable=%d" % (self._last.get("count", 0),
                                                self._last.get("computable_count", 0)),
            details=details)
