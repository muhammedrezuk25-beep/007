from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.6.0"

EVENT_IN = "decision.scored.state"
EVENT_OUT = "decision.filtered.state"

_FILTER_EVENTS = (
    "decision.filter.confidence.state",
    "decision.filter.conditions.state",
    "decision.filter.timing.state",
    "decision.filter.position.state",
    "decision.filter.freshness.state",
    "decision.filter.asset.state",
)
_FILTER_IDS = ("confidence_filter", "conditions_filter", "timing_filter",
               "position_filter", "freshness_filter", "asset_filter")
# Symbol-scoped filters: no timeframe concept (positions, bridge freshness,
# asset whitelist), so their verdicts apply to the symbol across all timeframes.
_SYMBOL_FILTER_IDS = ("position_filter", "freshness_filter", "asset_filter")

METHOD = "score_gate_and_filters"
ID_FILTER = "decision_filter"

DIR_WAIT = "wait"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._min_score = 60
        self._filters: dict[tuple, dict[str, bool]] = {}
        self._symbol_filters: dict[str, dict[str, bool]] = {}
        self._seen = 0
        self._passed = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_score = int(context.config["min_score"])
        context.subscribe(EVENT_IN, self._on_scored)
        for event in _FILTER_EVENTS:
            context.subscribe(event, self._on_filter)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_filter(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        fid = str(payload.get("id", ""))
        if fid not in _FILTER_IDS:
            return
        meta = payload.get("metadata")
        passed = bool(meta.get("passed")) if isinstance(meta, dict) else False
        symbol = str(payload.get("symbol", ""))
        if fid in _SYMBOL_FILTER_IDS:
            self._symbol_filters.setdefault(symbol, {})[fid] = passed
            return
        key = (symbol, str(payload.get("timeframe", "")))
        self._filters.setdefault(key, {})[fid] = passed

    async def _on_scored(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        key = (symbol, timeframe)
        self._seen += 1
        direction = str(payload.get("signal", DIR_WAIT))
        score = _to_int(payload.get("score"))
        gate = direction != DIR_WAIT and score >= self._min_score
        verdicts = dict(self._filters.get(key, {}))
        verdicts.update(self._symbol_filters.get(symbol, {}))
        blocked_by = [fid for fid in _FILTER_IDS if not verdicts.get(fid, True)]
        passed = gate and not blocked_by
        if passed:
            self._passed += 1
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_FILTER, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": direction, "score": score,
            "confidence": 1.0 if passed else 0.0,
            "quality": QUALITY_GOOD if passed else QUALITY_LOW, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": timeframe, "direction": direction,
                         "passed": passed, "score_gate": gate, "blocked_by": blocked_by,
                         "min_score": self._min_score}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d passed=%d emitted=%d" % (
                self._seen, self._passed, self._emitted),
            details={"seen": self._seen, "passed": self._passed,
                     "emitted": self._emitted})
