from __future__ import annotations

import asyncio
import os
import sqlite3
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "decision.filter.freshness.state"

METHOD = "price_staleness_vs_newest"
ID_FILTER = "freshness_filter"

SIGNAL_PASS = "pass"
SIGNAL_BLOCK = "block"

STATUS_OK = "ok"
QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_READ_YET"

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = ""
        self._poll_interval_s = 0.0
        self._threshold_s = 0.0
        self._verdict: dict[str, bool] = {}
        self._read_count = 0
        self._emitted = 0
        self._blocked_now = 0
        self._last_error = ""

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._threshold_s = float(cfg["stale_threshold_s"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        await self._check_once()
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None

    async def shutdown(self) -> None:
        await self.stop()

    def _read(self) -> list[tuple[str, float | None]]:
        conn = _connect(self._db_path)
        try:
            rows = conn.execute(
                f"SELECT symbol, updated_at FROM {self._table}").fetchall()
            return [(str(r[0]), _to_float(r[1])) for r in rows if r[0]]
        finally:
            conn.close()

    async def _check_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._read)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return
        self._last_error = ""
        stamps = [ts for _, ts in rows if ts is not None]
        if not stamps:
            return
        self._read_count += 1
        newest = max(stamps)
        blocked = 0
        for symbol, ts in rows:
            if ts is None:
                continue
            fresh = (newest - ts) <= self._threshold_s
            if not fresh:
                blocked += 1
            if self._verdict.get(symbol) != fresh:
                self._verdict[symbol] = fresh
                await self._emit(symbol, fresh)
        self._blocked_now = blocked

    async def _emit(self, symbol: str, passed: bool) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_FILTER, "cycle_id": "",
            "status": STATUS_OK, "signal": SIGNAL_PASS if passed else SIGNAL_BLOCK,
            "score": 0, "confidence": 1.0 if passed else 0.0,
            "quality": QUALITY_GOOD if passed else QUALITY_LOW, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": "", "passed": passed,
                         "stale_threshold_s": self._threshold_s}})
        self._emitted += 1

    async def _loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._poll_interval_s)
                if self._running:
                    await self._check_once()
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"reads": self._read_count, "emitted": self._emitted,
                   "blocked_now": self._blocked_now,
                   "blocked_symbols": sorted(s for s, f in self._verdict.items() if not f),
                   "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error,
                                details=details)
        if self._read_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA,
                                details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="reads=%d blocked=%d emitted=%d" % (
                self._read_count, self._blocked_now, self._emitted),
            details=details)
