from __future__ import annotations

import asyncio
import os
import sqlite3
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_OUT = "platform.account.state"
EVENT_TERMINAL = "platform.terminal_state"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_FILE = "BRIDGE_FILE_MISSING"
REASON_NO_TABLE = "ACCOUNT_TABLE_MISSING"
REASON_NEVER_READ = "NO_ACCOUNT_DATA_YET"

_COLUMNS = ("balance", "equity", "margin", "free_margin", "margin_level",
            "currency", "leverage", "open_count", "updated_at")
_PLATFORM_COLUMNS = ("connected", "trade_allowed", "expert_allowed", "bridge_beat")
_IDENTITY_COLUMNS = ("account_id", "broker", "account_server", "margin_mode")

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _bridge_connect(db_path: str) -> sqlite3.Connection:
    uri = f"file:{db_path}?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=_CONNECT_TIMEOUT_S)
    connection.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    return connection


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = "account"
        self._poll_interval_s = 0.0
        self._last_state: dict[str, Any] | None = None
        self._last_updated_at: float | None = None
        self._last_error = ""
        self.read_count = 0
        self.terminal_count = 0
        self.no_identity_count = 0
        self.publish_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""

    async def shutdown(self) -> None:
        await self.stop()

    def _read_row(self) -> dict[str, Any] | None:
        columns = ", ".join(_COLUMNS)
        connection = _bridge_connect(self._db_path)
        try:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(f"SELECT {columns} FROM {self._table} WHERE id = 1")
            row = cursor.fetchone()
            if row is None:
                return None
            result = dict(row)
            for column in _PLATFORM_COLUMNS + _IDENTITY_COLUMNS:
                try:
                    extra = connection.execute(
                        f"SELECT {column} FROM {self._table} WHERE id = 1").fetchone()
                except sqlite3.Error:
                    continue
                if extra is not None:
                    result[column] = extra[0]
            return result
        finally:
            connection.close()

    async def _read_once(self) -> None:
        if self._context is None:
            return
        try:
            row = await asyncio.to_thread(self._read_row)
        except sqlite3.Error as exc:
            self.failure_count += 1
            message = str(exc)
            self._last_error = (
                REASON_NO_TABLE if "no such table" in message.lower()
                else REASON_NO_FILE if "unable to open" in message.lower()
                else message)
            self._context.logger.warning("619 read failed: %s", message)
            return
        self._last_error = ""
        if row is None:
            return
        account_id = row.get("account_id")
        if account_id in (None, ""):
            self.no_identity_count += 1
            self._context.logger.warning("619 refuses a row with no account_id")
            return
        self.read_count += 1
        await self._publish_terminal(row)
        updated_at = _to_float(row.get("updated_at"))
        if updated_at is not None and updated_at == self._last_updated_at:
            return
        state: dict[str, Any] = {
            "account_id": str(row.get("account_id")),
            "balance": _to_float(row.get("balance")),
            "equity": _to_float(row.get("equity")),
            "margin": _to_float(row.get("margin")),
            "free_margin": _to_float(row.get("free_margin")),
            "margin_level": _to_float(row.get("margin_level")),
            "currency": row.get("currency"),
            "leverage": row.get("leverage"),
            "open_count": row.get("open_count"),
            "broker": row.get("broker"),
            "server": row.get("account_server"),
            "margin_mode": row.get("margin_mode"),
            "measured_at": updated_at,
        }
        self._last_state = state
        self._last_updated_at = updated_at
        self.publish_count += 1
        await self._context.publish(EVENT_OUT, dict(state))

    async def _publish_terminal(self, row: dict[str, Any]) -> None:
        if self._context is None:
            return
        if not any(column in row for column in _PLATFORM_COLUMNS):
            return
        await self._context.publish(EVENT_TERMINAL, {
            "account_id": str(row.get("account_id")),
            "connected": bool(row.get("connected")),
            "trade_allowed": bool(row.get("trade_allowed")),
            "expert_allowed": bool(row.get("expert_allowed")),
            "bridge_beat": _to_float(row.get("bridge_beat")),
            "timestamp": _to_float(row.get("updated_at")),
        })
        self.terminal_count += 1

    async def _loop(self) -> None:
        try:
            while self._running:
                await self._read_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {
            "reads": self.read_count,
            "published": self.publish_count,
            "failures": self.failure_count,
            "no_identity": self.no_identity_count,
            "last_error": self._last_error,
            "balance": (self._last_state or {}).get("balance"),
            "equity": (self._last_state or {}).get("equity"),
        }
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error, details=details)
        if self._last_state is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NEVER_READ, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message=f"published={self.publish_count}", details=details)
