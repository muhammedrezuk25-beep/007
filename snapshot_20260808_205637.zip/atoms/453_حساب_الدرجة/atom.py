from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "decision.aggregated.state"
EVENT_OUT = "decision.scored.state"

METHOD = "vote_and_backing"
ID_SCORE = "score_calculator"

DIR_WAIT = "wait"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

_PERCENT = 100.0


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._vote_weight = 20
        self._prob_bonus = 20
        self._seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._vote_weight = int(context.config["vote_weight"])
        self._prob_bonus = int(context.config["prob_bonus"])
        context.subscribe(EVENT_IN, self._on_aggregated)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_aggregated(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        direction = str(payload.get("signal", DIR_WAIT))
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        votes = meta.get("strategy_votes") if isinstance(meta.get("strategy_votes"), dict) else {}
        prob_backed = bool(meta.get("prob_backed"))
        if direction == DIR_WAIT:
            score = 0
        else:
            winning = _to_int(votes.get(direction))
            raw = winning * self._vote_weight + (self._prob_bonus if prob_backed else 0)
            score = int(min(_PERCENT, float(raw)))
        timeframe = str(payload.get("timeframe", ""))
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_SCORE, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": direction, "score": score,
            "confidence": round(score / _PERCENT, 2),
            "quality": QUALITY_GOOD if score > 0 else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "prob_backed": prob_backed}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d emitted=%d" % (self._seen, self._emitted),
            details={"seen": self._seen, "emitted": self._emitted})
