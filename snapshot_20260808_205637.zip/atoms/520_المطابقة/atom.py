from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_POSITIONS = "platform.positions.state"
EVENT_ACTIVATE = "perpetual.asset.activate"
EVENT_DEACTIVATE = "perpetual.asset.deactivate"
EVENT_ENTRY = "perpetual.entry.state"
EVENT_OUT = "execution.reconcile.state"

ST_MATCH = "MATCH"
ST_MISSING = "MISSING_AT_BROKER"
ST_EXTRA = "EXTRA_AT_BROKER"
ENTRY_OPENED = "OPENED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_POSITIONS_YET"

_KEY_SEP = "|"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._active: set[str] = set()
        self._broker: dict[str, int] = {}
        self._last: dict[str, Any] | None = None
        self._updates = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_ACTIVATE, self._on_activate)
        context.subscribe(EVENT_DEACTIVATE, self._on_deactivate)
        context.subscribe(EVENT_ENTRY, self._on_entry)
        context.subscribe(EVENT_POSITIONS, self._on_positions)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> str:
        return str(payload.get("account_id") or "") + _KEY_SEP + str(payload.get("symbol") or "")

    async def _on_activate(self, payload: dict[str, Any]) -> None:
        if self._running and isinstance(payload, dict) and payload.get("symbol"):
            self._active.add(self._key(payload))

    async def _on_deactivate(self, payload: dict[str, Any]) -> None:
        if self._running and isinstance(payload, dict) and payload.get("symbol"):
            self._active.discard(self._key(payload))

    async def _on_entry(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        if str(payload.get("status") or "") == ENTRY_OPENED and payload.get("symbol"):
            self._active.add(self._key(payload))

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        positions = payload.get("positions")
        if not isinstance(positions, list):
            return
        broker: dict[str, int] = {}
        for pos in positions:
            if not isinstance(pos, dict) or not pos.get("symbol"):
                continue
            key = self._key(pos)
            broker[key] = broker.get(key, 0) + 1
        self._broker = broker
        items = []
        escalations = []
        for key in sorted(set(self._active) | set(broker)):
            account_id, _, symbol = key.partition(_KEY_SEP)
            legs = broker.get(key, 0)
            active = key in self._active
            if active and legs > 0:
                status = ST_MATCH
            elif active and legs == 0:
                status = ST_MISSING
            else:
                status = ST_EXTRA
            row = {"account_id": account_id, "symbol": symbol, "status": status,
                   "broker_legs": legs, "active": active}
            items.append(row)
            if status != ST_MATCH:
                escalations.append(row)
        out: dict[str, Any] = {"items": items, "count": len(items),
                               "escalations": escalations, "escalation_count": len(escalations)}
        stamp = payload.get("timestamp")
        if stamp is not None:
            out["timestamp"] = stamp
        self._last = out
        self._updates += 1
        await self._context.publish(EVENT_OUT, out)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"updates": self._updates, "active": len(self._active),
                   "escalations": (self._last or {}).get("escalation_count", 0)}
        if self._last is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="items=%d escalations=%d" % (self._last.get("count", 0),
                                                 self._last.get("escalation_count", 0)),
            details=details)
