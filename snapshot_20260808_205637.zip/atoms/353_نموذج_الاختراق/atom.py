from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_BOS = "structure.bos.state"
EVENT_FVG = "liquidity.fvg.state"
EVENT_OUT = "probability.breakout.state"

METHOD = "breakout_heuristic"
ID_MODEL = "breakout_model"

SIGNAL_BREAKOUT = "breakout"
SIGNAL_NEUTRAL = "neutral"

DIR_UP = "up"
DIR_DOWN = "down"
DIR_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

BOS = "bos"
FVG_BULL = "fvg_bullish"
FVG_BEAR = "fvg_bearish"
NONE = "none"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._base = 0.6
        self._boost = 0.15
        self._max = 0.9
        self._bos: dict[tuple, str] = {}
        self._fvg: dict[tuple, str] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base = float(cfg["base_prob"])
        self._boost = float(cfg["fvg_boost"])
        self._max = float(cfg["max_prob"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_BOS, self._on_bos)
        context.subscribe(EVENT_FVG, self._on_fvg)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_bos(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._bos[self._key(payload)] = str(payload.get("signal", NONE))

    async def _on_fvg(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._fvg[self._key(payload)] = str(payload.get("signal", NONE))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        bos = self._bos.get(key, NONE)
        fvg = self._fvg.get(key, NONE)
        if bos == BOS:
            prob = self._base
            if fvg in (FVG_BULL, FVG_BEAR):
                prob = min(self._max, prob + self._boost)
            direction = DIR_UP if fvg == FVG_BULL else DIR_DOWN if fvg == FVG_BEAR else DIR_NONE
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_BREAKOUT, direction,
                             prob, _FULL, bos, fvg)
            return
        await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, DIR_NONE,
                         _NEUTRAL_PROB, _LOW, bos, fvg)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    direction: str, prob: float, confidence: float, bos: str,
                    fvg: str) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "probability": round(prob, _DP),
                                         "bos": bos, "fvg": fvg}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._bos)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._bos)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._bos)})
