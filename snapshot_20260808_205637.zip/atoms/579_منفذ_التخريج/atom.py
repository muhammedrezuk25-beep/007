from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PARTIAL_REQ = "asset.extraction.requested"
EVENT_FULL_REQ = "asset.full_extraction.requested"
EVENT_POSITIONS = "platform.positions.state"
EVENT_MANAGE = "execution.manage.command"
EVENT_DEACTIVATE = "perpetual.asset.deactivate"

ACTION_PARTIAL = "CLOSE_PARTIAL"
ACTION_CLOSE = "CLOSE"

REASON_NOT_STARTED = "NOT_STARTED"

_KEY_SEP = "|"
_LOT_DP = 2
_FULL_ONE = 1.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._lot_step = 0.01
        self._legs: dict[str, list[dict[str, Any]]] = {}
        self._partials = 0
        self._fulls = 0
        self._skipped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._lot_step = float(context.config.get("lot_step", 0.01))
        context.subscribe(EVENT_POSITIONS, self._on_positions)
        context.subscribe(EVENT_PARTIAL_REQ, self._on_partial)
        context.subscribe(EVENT_FULL_REQ, self._on_full)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        positions = payload.get("positions")
        if not isinstance(positions, list):
            return
        legs: dict[str, list[dict[str, Any]]] = {}
        for pos in positions:
            if not isinstance(pos, dict):
                continue
            symbol = str(pos.get("symbol") or "")
            ticket = _to_int(pos.get("ticket"))
            if not symbol or ticket is None:
                continue
            key = str(pos.get("account_id") or "") + _KEY_SEP + symbol
            legs.setdefault(key, []).append({
                "ticket": ticket, "side": str(pos.get("side") or ""),
                "volume": _to_float(pos.get("volume")) or 0.0,
                "profit": _to_float(pos.get("profit")) or 0.0})
        self._legs = legs

    def _round_lot(self, volume: float) -> float:
        stepped = round(volume / self._lot_step) * self._lot_step
        return round(stepped, _LOT_DP)

    async def _on_partial(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        amount = _to_float(payload.get("amount"))
        symbol = str(payload.get("symbol") or "")
        if amount is None or amount <= 0.0 or not symbol:
            return
        key = str(payload.get("account_id") or "") + _KEY_SEP + symbol
        winners = [leg for leg in self._legs.get(key, []) if leg["profit"] > 0.0 and leg["volume"] > 0.0]
        if not winners:
            self._skipped += 1
            return
        best = max(winners, key=lambda leg: leg["profit"])
        frac = amount / best["profit"] if best["profit"] > 0.0 else _FULL_ONE
        frac = min(_FULL_ONE, max(0.0, frac))
        close_vol = self._round_lot(best["volume"] * frac)
        if close_vol < self._lot_step:
            close_vol = self._lot_step
        if close_vol > best["volume"]:
            close_vol = self._round_lot(best["volume"])
        self._partials += 1
        await self._context.publish(EVENT_MANAGE, {
            "action": ACTION_PARTIAL, "ticket": best["ticket"], "symbol": symbol,
            "side": best["side"], "volume": close_vol, "origin": "perpetual-extract",
            "target_amount": amount})

    async def _on_full(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        if not symbol:
            return
        account_id = str(payload.get("account_id") or "")
        key = account_id + _KEY_SEP + symbol
        legs = self._legs.get(key, [])
        for leg in legs:
            await self._context.publish(EVENT_MANAGE, {
                "action": ACTION_CLOSE, "ticket": leg["ticket"], "symbol": symbol,
                "side": leg["side"], "volume": leg["volume"], "origin": "perpetual-full"})
        self._fulls += 1
        await self._context.publish(EVENT_DEACTIVATE, {"account_id": account_id, "symbol": symbol})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="partials=%d fulls=%d skipped=%d" % (self._partials, self._fulls, self._skipped),
            details={"partials": self._partials, "fulls": self._fulls, "skipped": self._skipped,
                     "tracked": sum(len(v) for v in self._legs.values())})
