from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_SCORE = "decision.scored.state"
EVENT_POSITIONS = "platform.positions.state"
EVENT_MANAGE = "execution.manage.command"

ACTION_PARTIAL = "CLOSE_PARTIAL"
SIDE_BUY = "BUY"
SIDE_SELL = "SELL"
SIG_BUY = "buy"
SIG_SELL = "sell"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_SCORE_YET"

_KEY_SEP = "|"
_LOT_DP = 2


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _norm_side(side: Any) -> str:
    text = str(side).strip().lower()
    if text in ("sell", "short", "1"):
        return SIDE_SELL
    if text in ("buy", "long", "0"):
        return SIDE_BUY
    return ""


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._score_threshold = 50.0
        self._tilt_fraction = 0.5
        self._lot_step = 0.01
        self._legs: dict[str, list[dict[str, Any]]] = {}
        self._last_tilt: dict[str, str] = {}
        self._tilts = 0
        self._seen_score = False

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._score_threshold = float(cfg.get("score_threshold", 50.0))
        self._tilt_fraction = float(cfg.get("tilt_fraction", 0.5))
        self._lot_step = float(cfg.get("lot_step", 0.01))
        context.subscribe(EVENT_POSITIONS, self._on_positions)
        context.subscribe(EVENT_SCORE, self._on_score)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        positions = payload.get("positions")
        if not isinstance(positions, list):
            return
        legs: dict[str, list[dict[str, Any]]] = {}
        for pos in positions:
            if not isinstance(pos, dict):
                continue
            symbol = str(pos.get("symbol") or "")
            ticket = _to_int(pos.get("ticket"))
            side = _norm_side(pos.get("side"))
            if not symbol or ticket is None or not side:
                continue
            key = str(pos.get("account_id") or "") + _KEY_SEP + symbol
            legs.setdefault(key, []).append({
                "ticket": ticket, "side": side, "volume": _to_float(pos.get("volume")) or 0.0})
        self._legs = legs

    def _round_lot(self, volume: float) -> float:
        return round(round(volume / self._lot_step) * self._lot_step, _LOT_DP)

    async def _on_score(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen_score = True
        symbol = str(payload.get("symbol") or "")
        signal = str(payload.get("signal") or "").strip().lower()
        score = _to_float(payload.get("score")) or 0.0
        if not symbol or signal not in (SIG_BUY, SIG_SELL) or score < self._score_threshold:
            return
        bias_side = SIDE_BUY if signal == SIG_BUY else SIDE_SELL
        opposite = SIDE_SELL if bias_side == SIDE_BUY else SIDE_BUY
        suffix = _KEY_SEP + symbol
        for key in [k for k in self._legs if k.endswith(suffix)]:
            if self._last_tilt.get(key) == bias_side:
                continue
            opp_legs = [leg for leg in self._legs[key]
                        if leg["side"] == opposite and leg["volume"] > 0.0]
            if not opp_legs:
                continue
            biggest = max(opp_legs, key=lambda leg: leg["volume"])
            reduce_vol = self._round_lot(biggest["volume"] * self._tilt_fraction)
            if reduce_vol < self._lot_step:
                reduce_vol = self._lot_step
            if reduce_vol > biggest["volume"]:
                reduce_vol = self._round_lot(biggest["volume"])
            self._last_tilt[key] = bias_side
            self._tilts += 1
            await self._context.publish(EVENT_MANAGE, {
                "action": ACTION_PARTIAL, "ticket": biggest["ticket"], "symbol": symbol,
                "side": opposite, "volume": reduce_vol, "origin": "perpetual-tilt",
                "bias": bias_side, "score": score})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"tilts": self._tilts, "tracked": sum(len(v) for v in self._legs.values())}
        if not self._seen_score:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="tilts=%d" % self._tilts, details=details)
