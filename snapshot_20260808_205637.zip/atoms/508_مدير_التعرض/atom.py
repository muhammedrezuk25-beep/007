from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_POSITIONS = "platform.positions.state"
EVENT_ACCOUNT = "platform.account.state"
EVENT_SPECS = "market.symbol_specs"

EVENT_OUT = "risk.exposure.state"
EVENT_HALT = "emergency.halt"

ID_EXPOSURE = "exposure_manager"
REASON_BREACH = "MAX_EXPOSURE"
STATUS_OK = "ok"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_ACCOUNT = "NO_ACCOUNT_DATA"
REASON_NO_SPECS = "NO_SYMBOL_SPECS"

_PERCENT = 100.0
_DP = 4


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._max_exposure_pct = 0.0
        self._specs: dict[str, float] = {}
        self._equity: dict[str, float] = {}
        self._breached: set[str] = set()
        self._last: dict[str, dict[str, Any]] = {}
        self._seen = 0
        self._emitted = 0
        self._halts = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_exposure_pct = float(context.config["max_exposure_pct"])
        context.subscribe(EVENT_SPECS, self._on_specs)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_POSITIONS, self._on_positions)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbols = payload.get("symbols")
        if not isinstance(symbols, list):
            return
        for row in symbols:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            size = _to_float(row.get("contract_size"))
            if symbol and size is not None and size > 0.0:
                self._specs[str(symbol)] = size

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        account_id = payload.get("account_id")
        equity = _to_float(payload.get("equity"))
        if account_id and equity is not None and equity > 0.0:
            self._equity[str(account_id)] = equity

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        positions = payload.get("positions")
        if not isinstance(positions, list):
            return
        self._seen += 1
        notional: dict[str, float] = {}
        counts: dict[str, int] = {}
        for entry in positions:
            if not isinstance(entry, dict):
                continue
            account_id = str(entry.get("account_id") or "")
            symbol = str(entry.get("symbol") or "")
            volume = _to_float(entry.get("volume"))
            price = _to_float(entry.get("current_price")) or _to_float(entry.get("entry_price"))
            size = self._specs.get(symbol)
            if not account_id or volume is None or price is None or size is None:
                continue
            notional[account_id] = notional.get(account_id, 0.0) + abs(volume) * price * size
            counts[account_id] = counts.get(account_id, 0) + 1
        stamp = _to_float(payload.get("timestamp"))
        for account_id in set(list(notional) + list(self._equity)):
            await self._evaluate(account_id, notional.get(account_id, 0.0),
                                 counts.get(account_id, 0), stamp)

    async def _evaluate(self, account_id: str, notional: float, count: int,
                        stamp: float | None) -> None:
        if self._context is None:
            return
        equity = self._equity.get(account_id)
        exposure_pct = round(notional / equity * _PERCENT, _DP) if equity else 0.0
        over = self._max_exposure_pct > 0.0 and exposure_pct >= self._max_exposure_pct
        body = {"account_id": account_id, "id": ID_EXPOSURE, "status": STATUS_OK,
                "notional": round(notional, _DP), "equity": equity,
                "exposure_pct": exposure_pct, "max_exposure_pct": self._max_exposure_pct,
                "open_positions": count, "breached": over}
        if stamp is not None:
            body["timestamp"] = stamp
        self._last[account_id] = body
        await self._context.publish(EVENT_OUT, body)
        self._emitted += 1
        if over and account_id not in self._breached:
            self._breached.add(account_id)
            self._halts += 1
            halt = {"reason": REASON_BREACH, "account_id": account_id,
                    "exposure_pct": exposure_pct, "limit": self._max_exposure_pct}
            if stamp is not None:
                halt["timestamp"] = stamp
            await self._context.publish(EVENT_HALT, halt)
        elif not over and account_id in self._breached:
            self._breached.discard(account_id)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"accounts": len(self._equity), "specs": len(self._specs),
                   "breached": sorted(self._breached), "emitted": self._emitted,
                   "halts": self._halts}
        if not self._specs:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_SPECS,
                                details=details)
        if not self._equity:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_ACCOUNT,
                                details=details)
        if self._breached:
            return HealthStatus(state=HealthState.DEGRADED,
                                message="exposure breached: %s" % ",".join(sorted(self._breached)),
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="accounts=%d emitted=%d" % (len(self._equity), self._emitted),
                            details=details)
