from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "decision.filtered.state"
EVENT_OUT = "decision.buy.state"

METHOD = "terminal_buy"
ID_DECISION = "buy_decision"

TARGET = "buy"
SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._issued = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_filtered)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        passed = bool(meta.get("passed"))
        direction = str(payload.get("signal", ""))
        fire = passed and direction == TARGET
        if fire:
            self._issued += 1
        timeframe = str(payload.get("timeframe", ""))
        cycle_id = str(payload.get("cycle_id", ""))
        try:
            score = int(payload.get("score", 0))
        except (TypeError, ValueError):
            score = 0
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_DECISION, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": TARGET if fire else SIGNAL_NONE, "score": score if fire else 0,
            "confidence": 1.0 if fire else 0.0,
            "quality": QUALITY_GOOD if fire else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": TARGET, "issued": fire}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d issued=%d emitted=%d" % (
                self._seen, self._issued, self._emitted),
            details={"seen": self._seen, "issued": self._issued,
                     "emitted": self._emitted})
