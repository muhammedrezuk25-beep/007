from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "market_data.candle_closed"
EVENT_OUT = "strategy.news.state"

METHOD = "news_hook"
ID_STRAT = "news_strategy"

SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_LOW = "low"

WARN_UNAVAILABLE = "news_sentiment_unavailable"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"
REASON_UNAVAILABLE = "NEWS_UNAVAILABLE"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_candle)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        self._seen += 1
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_STRAT, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": SIGNAL_NONE, "score": 0, "confidence": 0.0,
            "quality": QUALITY_LOW, "warnings": [WARN_UNAVAILABLE],
            "metadata": {"method": METHOD, "timeframe": timeframe, "context": SIGNAL_NONE,
                         "source": WARN_UNAVAILABLE}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.DEGRADED, message=REASON_UNAVAILABLE,
            details={"seen": self._seen, "emitted": self._emitted,
                     "note": "honest hook — no directional news sentiment feed (108)"})
