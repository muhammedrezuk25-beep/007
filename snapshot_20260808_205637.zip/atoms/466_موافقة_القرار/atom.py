from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "decision.filtered.state"
EVENT_OUT = "decision.approved.state"

METHOD = "final_gate"
ID_APPROVAL = "decision_approval"

DIR_BUY = "buy"
DIR_SELL = "sell"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._approved = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_filtered)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        passed = bool(meta.get("passed"))
        direction = str(payload.get("signal", ""))
        approved = passed and direction in (DIR_BUY, DIR_SELL)
        if approved:
            self._approved += 1
        timeframe = str(payload.get("timeframe", ""))
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_APPROVAL, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": direction if approved else "none",
            "score": _to_int(payload.get("score")) if approved else 0,
            "confidence": 1.0 if approved else 0.0,
            "quality": QUALITY_GOOD if approved else QUALITY_LOW, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": timeframe, "direction": direction,
                         "approved": approved, "request_id": cycle_id}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d approved=%d emitted=%d" % (
                self._seen, self._approved, self._emitted),
            details={"seen": self._seen, "approved": self._approved,
                     "emitted": self._emitted})
