from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_FILTER = "decision.filter.asset.state"
EVENT_WHITELIST = "allowed.symbols.state"

ID_FILTER = "asset_filter"
STATUS_OK = "ok"
SIGNAL_ALLOW = "allow"
SIGNAL_BLOCK = "block"
METHOD = "whitelist"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_EMPTY = "EMPTY_WHITELIST_BLOCKS_ALL"

CONFIDENCE_PASS = 1.0
CONFIDENCE_FAIL = 0.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._allowed: set[str] = set()
        self._seen = 0
        self._blocked = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._allowed = {str(s) for s in context.config.get("allowed_symbols", [])}
        context.subscribe(EVENT_CANDLE, self._on_candle)

    async def start(self) -> None:
        self._running = True
        await self._publish_whitelist()

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _publish_whitelist(self) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_WHITELIST, {
            "id": ID_FILTER, "status": STATUS_OK, "allowed": sorted(self._allowed)})

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        passed = symbol in self._allowed
        self._seen += 1
        if not passed:
            self._blocked += 1
        await self._context.publish(EVENT_FILTER, {
            "symbol": symbol, "id": ID_FILTER, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": SIGNAL_ALLOW if passed else SIGNAL_BLOCK,
            "confidence": CONFIDENCE_PASS if passed else CONFIDENCE_FAIL,
            "warnings": [],
            "metadata": {"method": METHOD, "timeframe": timeframe, "passed": passed}})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"allowed_symbols": sorted(self._allowed), "seen": self._seen,
                   "blocked": self._blocked}
        if not self._allowed:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_EMPTY,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="allowed=%d seen=%d blocked=%d" % (
                                len(self._allowed), self._seen, self._blocked),
                            details=details)
