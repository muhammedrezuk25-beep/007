from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.3.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_ACCOUNT = "platform.account.state"
EVENT_SPECS = "market.symbol_specs"
EVENT_STOP = "risk.structure_stop.state"
EVENT_OUT = "risk.position_size.state"

METHOD = "risk_percent_sizing"
ID_SIZE = "position_sizing"

STATUS_OK = "ok"

QUALITY_GOOD = "good"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_EQUITY = "NO_EQUITY_YET"
REASON_NO_SPECS = "NO_SYMBOL_SPECS"

_PERCENT = 100.0
_DP = 6


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._risk_pct = 1.0
        self._stop_pct = 0.5
        self._min_lot = 0.01
        self._max_lot = 1.0
        self._lot_step = 0.01
        self._equity = 0.0
        self._specs: dict[str, dict[str, float]] = {}
        self._stops: dict[str, dict[str, Any]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._risk_pct = float(cfg["risk_per_trade_pct"])
        self._stop_pct = float(cfg["default_stop_pct"])
        self._min_lot = float(cfg["min_lot"])
        self._max_lot = float(cfg["max_lot"])
        self._lot_step = float(cfg["lot_step"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_ACCOUNT, self._on_account)
        context.subscribe(EVENT_SPECS, self._on_specs)
        context.subscribe(EVENT_STOP, self._on_stop)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        equity = _to_float(payload.get("equity"))
        if equity is not None and equity > 0.0:
            self._equity = equity

    async def _on_specs(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbols = payload.get("symbols")
        if not isinstance(symbols, list):
            return
        for row in symbols:
            if not isinstance(row, dict):
                continue
            symbol = row.get("symbol")
            tick_value = _to_float(row.get("tick_value"))
            tick_size = _to_float(row.get("tick_size"))
            if not symbol or tick_value is None or tick_size is None or tick_size <= 0.0:
                continue
            self._specs[str(symbol)] = {"tick_value": tick_value, "tick_size": tick_size}

    async def _on_stop(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        self._stops[str(symbol)] = {"buy_stop": _to_float(meta.get("buy_stop")),
                                    "sell_stop": _to_float(meta.get("sell_stop"))}

    def _lot_from_distance(self, stop_distance: float, tick_value: float,
                           tick_size: float) -> float:
        risk_amount = self._equity * self._risk_pct / _PERCENT
        value_per_unit = tick_value / tick_size
        denom = stop_distance * value_per_unit
        if denom <= 0.0:
            return 0.0
        raw = risk_amount / denom
        stepped = round(raw / self._lot_step) * self._lot_step
        lot = max(self._min_lot, min(self._max_lot, stepped))
        return round(lot, _DP)

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        close = _to_float(payload.get("close"))
        if not symbol or close is None or close <= 0.0:
            return
        symbol = str(symbol)
        self._candles_seen += 1
        if self._equity <= 0.0:
            return
        specs = self._specs.get(symbol)
        if specs is None:
            return
        tick_value = specs["tick_value"]
        tick_size = specs["tick_size"]
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        risk_amount = self._equity * self._risk_pct / _PERCENT
        default_distance = close * self._stop_pct / _PERCENT
        lot = self._lot_from_distance(default_distance, tick_value, tick_size)
        buy_stop = None
        sell_stop = None
        buy_lot = None
        sell_lot = None
        stops = self._stops.get(symbol)
        if stops is not None:
            candidate_buy = stops.get("buy_stop")
            candidate_sell = stops.get("sell_stop")
            if candidate_buy is not None and candidate_buy < close:
                buy_stop = candidate_buy
                buy_lot = self._lot_from_distance(close - candidate_buy, tick_value, tick_size)
            if candidate_sell is not None and candidate_sell > close:
                sell_stop = candidate_sell
                sell_lot = self._lot_from_distance(candidate_sell - close, tick_value, tick_size)
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_SIZE, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": "sized", "score": 0, "confidence": 1.0, "quality": QUALITY_GOOD,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "lot": lot, "risk_amount": round(risk_amount, 2),
                                         "stop_distance": round(default_distance, _DP),
                                         "equity": round(self._equity, 2),
                                         "risk_pct": self._risk_pct, "price": close,
                                         "buy_lot": buy_lot, "buy_stop": buy_stop,
                                         "sell_lot": sell_lot, "sell_stop": sell_stop}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"equity": round(self._equity, 2), "specs": len(self._specs),
                   "emitted": self._emitted}
        if self._equity <= 0.0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_EQUITY,
                                details=details)
        if not self._specs:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_SPECS,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="sized=%d equity=%.2f" % (self._emitted, self._equity),
                            details=details)
