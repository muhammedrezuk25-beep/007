from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "probability.confidence.state"

_MODEL_EVENTS = (
    "probability.trend.state",
    "probability.reversal.state",
    "probability.breakout.state",
    "probability.pullback.state",
    "probability.momentum.state",
    "probability.range.state",
)

_MODEL_IDS = ("trend_model", "reversal_model", "breakout_model", "pullback_model",
              "momentum_model", "range_model")

METHOD = "confidence_coverage"
ID_AGG = "confidence_aggregator"

SIGNAL_HIGH = "high_confidence"
SIGNAL_LOW = "low_confidence"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_PERCENT = 100.0
_EXPECTED_MODELS = 6


def _to_float(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return 0.0
    return result if result == result else 0.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._min_conf = 0.5
        self._conf: dict[tuple, dict[str, float]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_conf = float(context.config["min_confidence"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        for event in _MODEL_EVENTS:
            context.subscribe(event, self._on_model)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_model(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        model_id = str(payload.get("id", ""))
        if model_id not in _MODEL_IDS:
            return
        key = (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))
        self._conf.setdefault(key, {})[model_id] = _to_float(payload.get("confidence"))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        confs = self._conf.get(key, {})
        present = len(confs)
        if present == 0:
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_LOW, 0.0, 0.0, 0)
            return
        mean_conf = sum(confs.values()) / present
        coverage = present / _EXPECTED_MODELS
        overall = mean_conf * coverage
        signal = SIGNAL_HIGH if overall >= self._min_conf else SIGNAL_LOW
        await self._emit(symbol, timeframe, cycle_id, signal, overall, mean_conf, present)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    overall: float, mean_conf: float, present: int) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_AGG, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, overall * _PERCENT))),
            "confidence": round(overall, 2),
            "quality": QUALITY_GOOD if signal == SIGNAL_HIGH else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "overall": round(overall, 4),
                                         "mean_confidence": round(mean_conf, 4),
                                         "present": present,
                                         "expected": _EXPECTED_MODELS}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._conf)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._conf)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._conf)})
