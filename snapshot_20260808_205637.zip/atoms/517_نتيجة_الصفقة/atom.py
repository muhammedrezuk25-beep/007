from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_OUTCOME = "market.outcome.realized"
EVENT_ACCOUNT = "platform.account.state"
EVENT_OUT = "risk.loss_reported"

ID_OUTCOME = "trade_outcome"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRADES = "NO_TRADES_YET"
REASON_NO_CAPITAL = "NO_REFERENCE_CAPITAL"

_PERCENT = 100.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._reference_capital = 0.0
        self._outcomes = 0
        self._emitted = 0
        self._dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_ACCOUNT, self._on_account)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        equity = _to_float(payload.get("equity"))
        if equity is not None and equity > 0.0:
            self._reference_capital = equity

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._outcomes += 1
        pnl = _to_float(payload.get("profit"))
        if pnl is None or self._reference_capital <= 0.0:
            self._dropped += 1
            return
        loss_pct = -(pnl / self._reference_capital) * _PERCENT
        await self._context.publish(EVENT_OUT, {
            "id": ID_OUTCOME, "symbol": str(payload.get("symbol", "")),
            "account_id": payload.get("account_id"),
            "loss_pct": round(loss_pct, 4), "is_loss": pnl < 0.0,
            "pnl": round(pnl, 2),
            "metadata": {"reference_capital": round(self._reference_capital, 2)}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"outcomes": self._outcomes, "emitted": self._emitted,
                   "dropped": self._dropped,
                   "reference_capital": round(self._reference_capital, 2)}
        if self._outcomes == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_TRADES,
                                details=details)
        if self._reference_capital <= 0.0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CAPITAL,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="reported=%d" % self._emitted, details=details)
