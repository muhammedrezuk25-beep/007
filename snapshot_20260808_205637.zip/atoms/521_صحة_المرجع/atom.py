from __future__ import annotations

import asyncio
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_TICK = "feed.mt5.tick"
EVENT_OUT = "reference.health.state"

ST_HEALTHY = "HEALTHY"
ST_STALE = "STALE"
ST_INVALID = "INVALID"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_FEED_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._max_age_s = 10.0
        self._max_spread_frac = 0.01
        self._check_interval_s = 2.0
        self._feeds: dict[str, dict[str, Any]] = {}
        self._publishes = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._max_age_s = float(cfg.get("max_age_s", 10.0))
        self._max_spread_frac = float(cfg.get("max_spread_frac", 0.01))
        self._check_interval_s = float(cfg.get("check_interval_s", 2.0))
        context.subscribe(EVENT_TICK, self._on_tick)

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_tick(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        if not symbol:
            return
        bid = _to_float(payload.get("bid"))
        ask = _to_float(payload.get("ask"))
        price = _to_float(payload.get("price"))
        received = _to_float(payload.get("received_at"))
        invalid = None
        if price is None or price <= 0.0:
            invalid = "bad_price"
        elif bid is not None and ask is not None and price > 0.0:
            spread = ask - bid
            if spread < 0.0:
                invalid = "crossed"
            elif spread / price > self._max_spread_frac:
                invalid = "wide_spread"
        self._feeds[symbol] = {"received": received if received is not None else 0.0,
                               "price": price, "invalid": invalid}

    def _classify(self, feed: dict[str, Any], now: float) -> tuple[str, float]:
        age = now - float(feed.get("received") or 0.0)
        if feed.get("invalid"):
            return ST_INVALID, age
        if age > self._max_age_s:
            return ST_STALE, age
        return ST_HEALTHY, age

    async def _publish_once(self) -> None:
        if self._context is None:
            return
        now = time.time()
        rows = []
        for symbol, feed in self._feeds.items():
            status, age = self._classify(feed, now)
            rows.append({"symbol": symbol, "status": status, "age_s": round(age, 3),
                         "price": feed.get("price"), "invalid": feed.get("invalid")})
        healthy = sum(1 for r in rows if r["status"] == ST_HEALTHY)
        self._publishes += 1
        await self._context.publish(EVENT_OUT, {"symbols": rows, "count": len(rows),
                                                "healthy": healthy})

    async def _loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._check_interval_s)
                if self._running and self._feeds:
                    await self._publish_once()
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if not self._feeds:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA,
                                details={"publishes": self._publishes})
        now = time.time()
        healthy = sum(1 for f in self._feeds.values() if self._classify(f, now)[0] == ST_HEALTHY)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="feeds=%d healthy=%d" % (len(self._feeds), healthy),
                            details={"feeds": len(self._feeds), "healthy": healthy,
                                     "publishes": self._publishes})
