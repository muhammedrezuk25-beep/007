from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "market_data.candle_closed"
EVENT_OUT = "probability.hurst.state"

METHOD = "rescaled_range_analysis"
ID_HURST = "hurst"

SIGNAL_TRENDING = "trending"
SIGNAL_MEAN_REVERTING = "mean_reverting"
SIGNAL_RANDOM = "random_walk"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

WARN_INSUFFICIENT = "insufficient_data_points"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_MIN_CHUNK = 8
_MIN_RETURNS = 32
_MID = 0.5
_PERCENT = 100.0
_DP = 4


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _rs(chunk: list) -> float | None:
    m = len(chunk)
    if m == 0:
        return None
    mean = sum(chunk) / m
    cum = 0.0
    zmin = 0.0
    zmax = 0.0
    sq = 0.0
    first = True
    for value in chunk:
        dev = value - mean
        cum += dev
        sq += dev * dev
        if first:
            zmin = cum
            zmax = cum
            first = False
        else:
            if cum < zmin:
                zmin = cum
            if cum > zmax:
                zmax = cum
    spread = zmax - zmin
    std = math.sqrt(sq / m)
    return spread / std if std > 0.0 else None


def _hurst(returns: list) -> float | None:
    total = len(returns)
    xs = []
    ys = []
    n = _MIN_CHUNK
    while n <= total // 2:
        rss = []
        idx = 0
        while idx + n <= total:
            value = _rs(returns[idx:idx + n])
            if value is not None and value > 0.0:
                rss.append(value)
            idx += n
        if rss:
            xs.append(math.log(n))
            ys.append(math.log(sum(rss) / len(rss)))
        n *= 2
    k = len(xs)
    if k < 2:
        return None
    mx = sum(xs) / k
    my = sum(ys) / k
    sxx = 0.0
    sxy = 0.0
    for a, b in zip(xs, ys):
        dx = a - mx
        sxx += dx * dx
        sxy += dx * (b - my)
    return sxy / sxx if sxx > 0.0 else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._window = 128
        self._band = 0.05
        self._state: dict[tuple, dict[str, Any]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window = int(context.config["window"])
        self._band = float(context.config["band"])
        context.subscribe(EVENT_IN, self._on_candle)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        close = _to_float(payload.get("close"))
        if not symbol or close is None:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        st = self._state.get(key)
        if st is None:
            st = {"prev": close, "rets": deque(maxlen=self._window)}
            self._state[key] = st
            self._candles_seen += 1
            await self._emit_insufficient(symbol, timeframe, cycle_id)
            return
        prev = st["prev"]
        st["prev"] = close
        self._candles_seen += 1
        if prev:
            st["rets"].append((close - prev) / prev)
        await self._emit(symbol, timeframe, cycle_id, st["rets"])

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str,
                    rets: deque) -> None:
        if self._context is None:
            return
        count = len(rets)
        if count < _MIN_RETURNS:
            await self._emit_insufficient(symbol, timeframe, cycle_id)
            return
        h = _hurst(list(rets))
        if h is None:
            await self._emit_insufficient(symbol, timeframe, cycle_id)
            return
        if h >= _MID + self._band:
            signal = SIGNAL_TRENDING
        elif h <= _MID - self._band:
            signal = SIGNAL_MEAN_REVERTING
        else:
            signal = SIGNAL_RANDOM
        confidence = round(min(1.0, count / self._window), 2) if self._window > 0 else 0.0
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_HURST, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, max(0.0, h) * _PERCENT))),
            "confidence": confidence, "quality": QUALITY_GOOD, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": timeframe, "window": self._window,
                         "count": count, "value": round(h, _DP), "band": self._band}})
        self._emitted += 1

    async def _emit_insufficient(self, symbol: str, timeframe: str,
                                 cycle_id: str) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_HURST, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_INSUFFICIENT, "signal": SIGNAL_RANDOM, "score": 0,
            "confidence": 0.0, "quality": QUALITY_LOW, "warnings": [WARN_INSUFFICIENT],
            "metadata": {"method": METHOD, "timeframe": timeframe, "window": self._window}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._state)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._state)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._state)})
