from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_POSITIONS = "platform.positions.state"
EVENT_TRADE = "platform.trade_event"
EVENT_OUT = "risk.asset_ledger.state"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_POSITIONS_YET"

_KEY_SEP = "|"
_MONEY_DP = 4
_VOL_DP = 8
_RATIO_DP = 6
_ROUND_TRIP = 2.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _side_sign(side: Any) -> int:
    text = str(side).strip().lower()
    if text in ("sell", "short", "1", "-1"):
        return -1
    if text in ("buy", "long", "0"):
        return 1
    return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._budgets: dict[str, float] = {}
        self._default_budget = 0.0
        self._warn_ratio = 0.95
        self._est_commission_per_lot = 0.0
        self._count_realized = False
        self._realized: dict[str, float] = {}
        self._seen_trades: set[Any] = set()
        self._last: dict[str, Any] | None = None
        self._updates = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        raw = cfg.get("risk_budgets") if isinstance(cfg.get("risk_budgets"), dict) else {}
        for key, value in raw.items():
            amount = _to_float(value)
            if amount is not None and amount > 0.0:
                self._budgets[str(key)] = amount
        self._default_budget = _to_float(cfg.get("default_budget", 0.0)) or 0.0
        self._warn_ratio = float(cfg.get("warn_ratio", 0.95))
        self._est_commission_per_lot = float(cfg.get("est_commission_per_lot", 0.0))
        self._count_realized = bool(cfg.get("count_realized_in_buffer", False))
        context.subscribe(EVENT_POSITIONS, self._on_positions)
        context.subscribe(EVENT_TRADE, self._on_trade)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _budget_for(self, account_id: str, symbol: str) -> float:
        key = account_id + _KEY_SEP + symbol
        if key in self._budgets:
            return self._budgets[key]
        return self._default_budget

    async def _on_trade(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        profit = _to_float(payload.get("profit"))
        if profit is None:
            return
        row_id = payload.get("source_row_id")
        if row_id is not None:
            if row_id in self._seen_trades:
                return
            self._seen_trades.add(row_id)
        symbol = str(payload.get("symbol") or "")
        if not symbol:
            return
        key = str(payload.get("account_id") or "") + _KEY_SEP + symbol
        self._realized[key] = self._realized.get(key, 0.0) + profit

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        positions = payload.get("positions")
        if not isinstance(positions, list):
            return
        groups: dict[str, dict[str, Any]] = {}
        for pos in positions:
            if not isinstance(pos, dict):
                continue
            symbol = str(pos.get("symbol") or "")
            if not symbol:
                continue
            account_id = str(pos.get("account_id") or "")
            key = account_id + _KEY_SEP + symbol
            group = groups.get(key)
            if group is None:
                group = {"account_id": account_id, "symbol": symbol, "floating": 0.0,
                         "swap": 0.0, "abs_vol": 0.0, "v_net": 0.0, "w": 0.0,
                         "legs": 0, "incomplete": False,
                         "commission_real": 0.0, "has_commission": False}
                groups[key] = group
            self._fold(group, pos)
        ledgers = [self._build(g) for g in groups.values()]
        worst = None
        for led in ledgers:
            if led["u"] is not None and (worst is None or led["u"] > worst):
                worst = led["u"]
        real_comm = any(led.get("commission_source") == "real" for led in ledgers)
        out: dict[str, Any] = {"ledgers": ledgers, "count": len(ledgers),
                               "commission_available": real_comm or self._est_commission_per_lot > 0.0,
                               "worst_u": worst}
        stamp = payload.get("timestamp")
        if stamp is not None:
            out["timestamp"] = stamp
        self._last = out
        self._updates += 1
        await self._context.publish(EVENT_OUT, out)

    def _fold(self, group: dict[str, Any], pos: dict[str, Any]) -> None:
        profit = _to_float(pos.get("profit"))
        if profit is None:
            group["incomplete"] = True
        else:
            group["floating"] += profit
        swap = _to_float(pos.get("swap"))
        if swap is not None:
            group["swap"] += swap
        commission = _to_float(pos.get("commission"))
        if commission is not None:
            group["commission_real"] += abs(commission)
            group["has_commission"] = True
        vol = _to_float(pos.get("volume"))
        entry = _to_float(pos.get("entry_price"))
        sign = _side_sign(pos.get("side"))
        if vol is not None:
            group["abs_vol"] += abs(vol)
            if sign != 0:
                group["v_net"] += sign * vol
                if entry is not None:
                    group["w"] += sign * vol * entry
            else:
                group["incomplete"] = True
        group["legs"] += 1

    def _build(self, group: dict[str, Any]) -> dict[str, Any]:
        account_id = group["account_id"]
        symbol = group["symbol"]
        key = account_id + _KEY_SEP + symbol
        if group["has_commission"]:
            commission_est = group["commission_real"] * _ROUND_TRIP
            commission_source = "real"
        elif self._est_commission_per_lot > 0.0:
            commission_est = self._est_commission_per_lot * _ROUND_TRIP * group["abs_vol"]
            commission_source = "estimate"
        else:
            commission_est = 0.0
            commission_source = "none"
        economic = group["floating"] + group["swap"] - commission_est
        realized = self._realized.get(key, 0.0)
        buffer_k = realized if self._count_realized else 0.0
        net = buffer_k + economic
        loss_exposure = max(0.0, -net)
        budget = self._budget_for(account_id, symbol)
        if budget > 0.0:
            ratio = loss_exposure / budget
            u: float | None = round(ratio, _RATIO_DP)
            warning = ratio >= self._warn_ratio
            breached = ratio >= 1.0
            budgeted = True
        else:
            u = None
            warning = False
            breached = False
            budgeted = False
        return {
            "account_id": account_id, "symbol": symbol,
            "net": round(net, _MONEY_DP), "loss_exposure": round(loss_exposure, _MONEY_DP),
            "budget": budget if budgeted else None, "u": u, "budgeted": budgeted,
            "warning": warning, "breached": breached,
            "floating": round(group["floating"], _MONEY_DP), "swap": round(group["swap"], _MONEY_DP),
            "commission_est": round(commission_est, _MONEY_DP),
            "commission_source": commission_source,
            "economic": round(economic, _MONEY_DP), "realized_pnl": round(realized, _MONEY_DP),
            "buffer_k": round(buffer_k, _MONEY_DP), "v_net": round(group["v_net"], _VOL_DP),
            "w": round(group["w"], _MONEY_DP), "open_legs": group["legs"],
            "incomplete": group["incomplete"],
        }

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"updates": self._updates, "budgets": len(self._budgets),
                   "worst_u": (self._last or {}).get("worst_u")}
        if self._last is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="ledgers=%d worst_u=%s" % (self._last.get("count", 0), self._last.get("worst_u")),
            details=details)
