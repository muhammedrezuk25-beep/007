from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "platform.trade_event"
EVENT_OUT = "market.outcome.realized"

ID_CONFIRM = "execution_confirm"

EVT_OPENED = "OPENED"
EVT_CLOSED = "CLOSED"
EVT_PARTIAL = "PARTIAL"

RESULT_WIN = "WIN"
RESULT_LOSS = "LOSS"
RESULT_FLAT = "BREAKEVEN"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TRADES = "NO_TRADES_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._opened = 0
        self._realized = 0
        self._dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_event)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_event(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        event_type = str(payload.get("event_type", ""))
        if event_type == EVT_OPENED:
            self._opened += 1
            return
        if event_type not in (EVT_CLOSED, EVT_PARTIAL):
            return
        symbol = payload.get("symbol")
        profit = _to_float(payload.get("profit"))
        if not symbol or profit is None:
            self._dropped += 1
            return
        result = RESULT_WIN if profit > 0.0 else RESULT_LOSS if profit < 0.0 else RESULT_FLAT
        await self._context.publish(EVENT_OUT, {
            "id": ID_CONFIRM, "symbol": str(symbol), "profit": round(profit, 2),
            "account_id": payload.get("account_id"), "result": result,
            "side": str(payload.get("side", "")),
            "volume": _to_float(payload.get("volume")),
            "entry_price": _to_float(payload.get("entry_price")),
            "exit_price": _to_float(payload.get("exit_price")),
            "event_type": event_type, "reason": str(payload.get("reason") or ""),
            "ticket": payload.get("ticket")})
        self._realized += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"seen": self._seen, "opened": self._opened,
                   "realized": self._realized, "dropped": self._dropped}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_TRADES,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="realized=%d opened=%d dropped=%d" % (
                                self._realized, self._opened, self._dropped),
                            details=details)
