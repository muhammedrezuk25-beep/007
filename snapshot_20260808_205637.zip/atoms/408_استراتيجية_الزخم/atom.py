from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "analysis.momentum.state"
EVENT_OUT = "strategy.momentum.state"

METHOD = "momentum_follow"
ID_STRAT = "momentum_strategy"

SIGNAL_BUY = "buy"
SIGNAL_SELL = "sell"
SIGNAL_NONE = "none"

DIR_UP = "up"
DIR_DOWN = "down"
DIR_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

MOM_UP = "up"
MOM_DOWN = "down"

_CONVICTION = 100


def _to_float(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return 0.0
    return result if result == result else 0.0


def _cycle_id(payload: dict[str, Any], symbol: str) -> str:
    cid = payload.get("cycle_id")
    if cid:
        return str(cid)
    timeframe = str(payload.get("timeframe", ""))
    period_start = payload.get("period_start", payload.get("timestamp", ""))
    return "%s|%s|%s" % (symbol, timeframe, period_start)


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._signals = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_input)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_input(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        src = str(payload.get("signal", ""))
        if src == MOM_UP:
            signal, out_dir = SIGNAL_BUY, DIR_UP
        elif src == MOM_DOWN:
            signal, out_dir = SIGNAL_SELL, DIR_DOWN
        else:
            signal, out_dir = SIGNAL_NONE, DIR_NONE
        if signal != SIGNAL_NONE:
            self._signals += 1
        await self._emit(symbol, payload, signal, out_dir, src,
                         _to_float(payload.get("confidence")))

    async def _emit(self, symbol: str, payload: dict[str, Any], signal: str,
                    direction: str, source: str, confidence: float) -> None:
        if self._context is None:
            return
        timeframe = str(payload.get("timeframe", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_STRAT, "cycle_id": _cycle_id(payload, symbol),
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": _CONVICTION if signal != SIGNAL_NONE else 0,
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NONE else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "source": source}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d signals=%d emitted=%d" % (
                self._seen, self._signals, self._emitted),
            details={"seen": self._seen, "signals": self._signals,
                     "emitted": self._emitted})
