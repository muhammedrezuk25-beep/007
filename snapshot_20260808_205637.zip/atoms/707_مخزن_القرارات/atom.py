from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.1.0"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000

EVENT_APPROVED = "decision.approved.state"
EVENT_ORDER_REQUESTED = "execution.order.requested"
EVENT_ORDER_BUILT = "execution.order.built"
EVENT_ORDER_REJECTED = "execution.order.rejected"
EVENT_FINAL = "trading.final_decision"
EVENT_OUT = "storage.decisions_saved"

STAGE_APPROVED = "APPROVED"
STAGE_ORDER_REQUESTED = "ORDER_REQUESTED"
STAGE_ORDER_BUILT = "ORDER_BUILT"
STAGE_ORDER_REJECTED = "ORDER_REJECTED"
STAGE_SENT = "SENT"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NO_ACTIVITY = "NO_DECISIONS_YET"

_STAGES = (
    (EVENT_APPROVED, STAGE_APPROVED),
    (EVENT_ORDER_REQUESTED, STAGE_ORDER_REQUESTED),
    (EVENT_ORDER_BUILT, STAGE_ORDER_BUILT),
    (EVENT_ORDER_REJECTED, STAGE_ORDER_REJECTED),
    (EVENT_FINAL, STAGE_SENT),
)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS decisions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    stage        TEXT NOT NULL,
    request_id   TEXT,
    account_id   TEXT,
    symbol       TEXT,
    direction    TEXT,
    approved     INTEGER,
    reason       TEXT,
    confidence   REAL,
    strategy_id  TEXT,
    model_id     TEXT,
    volume       REAL,
    stop_loss    REAL,
    take_profit  REAL,
    payload_json TEXT,
    decided_at   REAL
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_decisions_request ON decisions(request_id)",
    "CREATE INDEX IF NOT EXISTS idx_decisions_account ON decisions(account_id, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_decisions_stage ON decisions(stage, id DESC)",
)

_COLUMNS = ("stage", "request_id", "account_id", "symbol", "direction", "approved",
            "reason", "confidence", "strategy_id", "model_id", "volume", "stop_loss",
            "take_profit", "payload_json", "decided_at")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _text(value: Any) -> str | None:
    return str(value) if value not in (None, "") else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._keep_payload = True
        self._store_ready = False
        self._last_error = ""
        self.stored_count = 0
        self.failure_count = 0
        self._per_stage: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._keep_payload = bool(cfg["keep_full_payload"])
        for event, stage in _STAGES:
            context.subscribe(event, self._make_writer(stage))
        self._store_ready = self._ensure_store()
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        if not self._store_ready:
            self._store_ready = self._ensure_store()

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            return False

    def _insert(self, row: dict[str, Any]) -> None:
        connection = self._connect()
        try:
            columns = ", ".join(_COLUMNS)
            marks = ", ".join("?" for _ in _COLUMNS)
            connection.execute(
                "INSERT INTO decisions (%s) VALUES (%s)" % (columns, marks),
                tuple(row.get(name) for name in _COLUMNS))
            connection.commit()
        finally:
            connection.close()

    def _make_writer(self, stage: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._store(stage, payload)
        return handler

    def _row(self, stage: str, payload: dict[str, Any]) -> dict[str, Any]:
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        approved = payload.get("approved")
        if approved is None:
            approved = meta.get("approved")
        decided_at = _to_float(payload.get("timestamp"))
        payload_json = None
        if self._keep_payload:
            try:
                payload_json = json.dumps(payload, ensure_ascii=False,
                                          sort_keys=True, default=str)
            except (TypeError, ValueError):
                payload_json = None
        return {
            "stage": stage,
            "request_id": _text(payload.get("request_id")),
            "account_id": _text(payload.get("account_id")),
            "symbol": _text(payload.get("symbol")),
            "direction": _text(payload.get("direction") or payload.get("side")
                               or payload.get("bias") or meta.get("direction")),
            "approved": None if approved is None else int(bool(approved)),
            "reason": _text(payload.get("reason") or meta.get("reason")),
            "confidence": _to_float(payload.get("confidence")
                                    if payload.get("confidence") is not None
                                    else meta.get("confidence")),
            "strategy_id": _text(payload.get("strategy_id")),
            "model_id": _text(payload.get("model_id")),
            "volume": _to_float(payload.get("volume")),
            "stop_loss": _to_float(payload.get("stop_loss")),
            "take_profit": _to_float(payload.get("take_profit")),
            "payload_json": payload_json,
            "decided_at": decided_at,
        }

    async def _store(self, stage: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
        if not self._store_ready:
            self.failure_count += 1
            return
        row = self._row(stage, payload)
        try:
            await asyncio.to_thread(self._insert, row)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            return
        self.stored_count += 1
        self._per_stage[stage] = self._per_stage.get(stage, 0) + 1
        body: dict[str, Any] = {"stage": stage, "request_id": row["request_id"],
                                "account_id": row["account_id"], "symbol": row["symbol"]}
        if row["decided_at"] is not None:
            body["timestamp"] = row["decided_at"]
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"stored": self.stored_count, "per_stage": dict(self._per_stage),
                   "failures": self.failure_count, "store_ready": self._store_ready,
                   "last_error": self._last_error}
        if not self._store_ready:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=self._last_error or REASON_STORE_UNAVAILABLE, details=details)
        if self.stored_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_ACTIVITY, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="stored=%d" % self.stored_count, details=details)
