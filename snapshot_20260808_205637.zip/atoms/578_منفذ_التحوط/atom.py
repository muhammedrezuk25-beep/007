from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PLAN = "perpetual.plan.state"
EVENT_DECISION = "trading.final_decision"

ACTION_OPEN = "OPEN"
ACT_HEDGE = "HEDGE"
SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_PLAN_YET"

_KEY_SEP = "|"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._hedged: set[str] = set()
        self._counter = 0
        self._sent = 0
        self._seen_plan = False

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_PLAN, self._on_plan)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_plan(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        plans = payload.get("plans")
        if not isinstance(plans, list):
            return
        self._seen_plan = True
        for plan in plans:
            if isinstance(plan, dict):
                await self._handle(plan)

    async def _handle(self, plan: dict[str, Any]) -> None:
        symbol = str(plan.get("symbol") or "")
        if not symbol:
            return
        account_id = str(plan.get("account_id") or "")
        key = account_id + _KEY_SEP + symbol
        action = str(plan.get("primary_action") or "")
        volume = _to_float(plan.get("hedge_volume"))
        side = plan.get("hedge_side")
        if action != ACT_HEDGE or not volume or volume <= 0.0 or side not in (SIDE_BUY, SIDE_SELL):
            self._hedged.discard(key)
            return
        if key in self._hedged:
            return
        self._hedged.add(key)
        self._counter += 1
        self._sent += 1
        await self._context.publish(EVENT_DECISION, {
            "request_id": "perp-hedge-%s-%d" % (symbol, self._counter),
            "account_id": account_id, "action": ACTION_OPEN, "symbol": symbol,
            "side": side, "volume": volume, "reference_price": None,
            "stop_loss": None, "take_profit": None, "origin": "perpetual-hedge"})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"sent": self._sent, "active_hedges": len(self._hedged)}
        if not self._seen_plan:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="hedges_sent=%d" % self._sent, details=details)
