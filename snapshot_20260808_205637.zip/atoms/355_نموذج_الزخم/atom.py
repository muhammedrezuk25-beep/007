from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_REGRESSION = "stats.regression.state"
EVENT_RSQUARED = "stats.r_squared.state"
EVENT_OUT = "probability.momentum.state"

METHOD = "momentum_regression_fit"
ID_MODEL = "momentum_model"

SIGNAL_STRONG = "strong"
SIGNAL_WEAK = "weak"
SIGNAL_NEUTRAL = "neutral"

DIR_UP = "up"
DIR_DOWN = "down"
DIR_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

RISING = "rising"
FALLING = "falling"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


def _to_float(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return 0.0
    return result if result == result else 0.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._base = 0.5
        self._r2_weight = 0.4
        self._max = 0.95
        self._strong_thr = 0.7
        self._reg: dict[tuple, str] = {}
        self._r2: dict[tuple, float] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base = float(cfg["base_prob"])
        self._r2_weight = float(cfg["r_squared_weight"])
        self._max = float(cfg["max_prob"])
        self._strong_thr = float(cfg["strong_threshold"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_REGRESSION, self._on_regression)
        context.subscribe(EVENT_RSQUARED, self._on_rsquared)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_regression(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._reg[self._key(payload)] = str(payload.get("signal", ""))

    async def _on_rsquared(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        meta = payload.get("metadata", {})
        value = meta.get("value") if isinstance(meta, dict) else None
        self._r2[self._key(payload)] = _to_float(value)

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        reg = self._reg.get(key, "")
        r2 = self._r2.get(key, 0.0)
        if reg in (RISING, FALLING):
            prob = min(self._max, self._base + self._r2_weight * r2)
            direction = DIR_UP if reg == RISING else DIR_DOWN
            signal = SIGNAL_STRONG if prob >= self._strong_thr else SIGNAL_WEAK
            await self._emit(symbol, timeframe, cycle_id, signal, direction, prob,
                             _FULL, r2)
            return
        await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, DIR_NONE,
                         _NEUTRAL_PROB, _LOW, r2)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    direction: str, prob: float, confidence: float, r2: float) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "probability": round(prob, _DP),
                                         "r_squared": round(r2, _DP)}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._reg)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._reg)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._reg)})
