from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "decision.filtered.state"
EVENT_OUT = "decision.wait.state"

METHOD = "terminal_wait"
ID_DECISION = "wait_decision"

SIGNAL_WAIT = "wait"
SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

DIR_WAIT = "wait"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._waits = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_filtered)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_filtered(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        passed = bool(meta.get("passed"))
        direction = str(payload.get("signal", ""))
        fire = (not passed) or direction == DIR_WAIT
        if fire:
            self._waits += 1
        timeframe = str(payload.get("timeframe", ""))
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_DECISION, "cycle_id": cycle_id, "status": STATUS_OK,
            "timeframe": timeframe,
            "signal": SIGNAL_WAIT if fire else SIGNAL_NONE, "score": 0,
            "confidence": 1.0 if fire else 0.0,
            "quality": QUALITY_GOOD if fire else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": SIGNAL_WAIT, "issued": fire}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d waits=%d emitted=%d" % (
                self._seen, self._waits, self._emitted),
            details={"seen": self._seen, "waits": self._waits,
                     "emitted": self._emitted})
