from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_CHOCH = "structure.choch.state"
EVENT_MSS = "structure.mss.state"
EVENT_OUT = "probability.reversal.state"

METHOD = "reversal_heuristic"
ID_MODEL = "reversal_model"

SIGNAL_REVERSAL = "reversal"
SIGNAL_NEUTRAL = "neutral"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

CHOCH = "choch"
MSS_SHIFT = "shift"
NONE = "none"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._base = 0.6
        self._boost = 0.2
        self._max = 0.9
        self._choch: dict[tuple, str] = {}
        self._mss: dict[tuple, str] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base = float(cfg["base_prob"])
        self._boost = float(cfg["confluence_boost"])
        self._max = float(cfg["max_prob"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_CHOCH, self._on_choch)
        context.subscribe(EVENT_MSS, self._on_mss)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_choch(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._choch[self._key(payload)] = str(payload.get("signal", NONE))

    async def _on_mss(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._mss[self._key(payload)] = str(payload.get("signal", NONE))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        choch = self._choch.get(key, NONE)
        mss = self._mss.get(key, NONE)
        choch_rev = choch == CHOCH
        mss_rev = mss in (CHOCH, MSS_SHIFT)
        if choch_rev or mss_rev:
            prob = self._base
            if choch_rev and mss_rev:
                prob = min(self._max, prob + self._boost)
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_REVERSAL, prob,
                             _FULL, choch, mss)
            return
        await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, _NEUTRAL_PROB,
                         _LOW, choch, mss)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    prob: float, confidence: float, choch: str, mss: str) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "timeframe": timeframe,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "probability": round(prob, _DP),
                                         "choch": choch, "mss": mss}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._choch)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._choch)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._choch)})
