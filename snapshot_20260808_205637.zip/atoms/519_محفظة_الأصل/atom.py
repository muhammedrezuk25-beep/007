from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LEDGER = "risk.asset_ledger.state"
EVENT_TERMINAL = "platform.terminal_state"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_requested"
EVENT_COMMAND = "risk.asset.command"
EVENT_OUT = "asset.portfolio.state"

STATE_NORMAL = "NORMAL"
STATE_WARNING = "WARNING"
STATE_HEDGING = "HEDGING"
STATE_FROZEN = "FROZEN"
STATE_PAUSED = "PAUSED"

INTENT_NONE = "NONE"
INTENT_REQUEST_HEDGE = "REQUEST_HEDGE"
INTENT_HOLD = "HOLD"
INTENT_FREEZE = "FREEZE"

CMD_RELEASE = "release"
CMD_PAUSE = "pause"
CMD_RESUME = "resume"
CMD_FORCE_HEDGE = "force_hedge"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_LEDGER_YET"

_KEY_SEP = "|"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._exit_ratio = 0.90
        self._states: dict[str, str] = {}
        self._emitted: dict[str, str] = {}
        self._alive: dict[str, bool] = {}
        self._halted = False
        self._last: dict[str, Any] | None = None
        self._updates = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._exit_ratio = float(cfg.get("exit_ratio", 0.90))
        context.subscribe(EVENT_LEDGER, self._on_ledger)
        context.subscribe(EVENT_TERMINAL, self._on_terminal)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)
        context.subscribe(EVENT_COMMAND, self._on_command)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_terminal(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        account_id = str(payload.get("account_id") or "")
        alive = bool(payload.get("connected")) and bool(payload.get("trade_allowed"))
        self._alive[account_id] = alive

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._halted = True

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        self._halted = False

    async def _on_command(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        if not symbol:
            return
        key = str(payload.get("account_id") or "") + _KEY_SEP + symbol
        command = str(payload.get("command") or "").strip().lower()
        if command == CMD_RELEASE and self._states.get(key) in (STATE_FROZEN, STATE_HEDGING, STATE_PAUSED):
            self._states[key] = STATE_NORMAL
        elif command == CMD_PAUSE:
            self._states[key] = STATE_PAUSED
        elif command == CMD_RESUME and self._states.get(key) == STATE_PAUSED:
            self._states[key] = STATE_NORMAL
        elif command == CMD_FORCE_HEDGE:
            self._states[key] = STATE_HEDGING

    def _alive_for(self, account_id: str) -> bool:
        return self._alive.get(account_id, True)

    def _next_state(self, current: str, u: float | None, warning: bool,
                    breached: bool, alive: bool) -> tuple[str, str]:
        if current == STATE_PAUSED:
            return STATE_PAUSED, INTENT_NONE
        if breached:
            return STATE_FROZEN, INTENT_FREEZE
        if current == STATE_FROZEN:
            return STATE_FROZEN, INTENT_FREEZE
        hedge_intent = INTENT_REQUEST_HEDGE if alive else INTENT_HOLD
        if current == STATE_HEDGING:
            return STATE_HEDGING, hedge_intent
        if warning:
            return STATE_WARNING, hedge_intent
        if current == STATE_WARNING:
            if u is not None and u <= self._exit_ratio:
                return STATE_NORMAL, INTENT_NONE
            return STATE_WARNING, hedge_intent
        return STATE_NORMAL, INTENT_NONE

    async def _on_ledger(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        ledgers = payload.get("ledgers")
        if not isinstance(ledgers, list):
            return
        portfolios = []
        for led in ledgers:
            if not isinstance(led, dict):
                continue
            symbol = str(led.get("symbol") or "")
            if not symbol:
                continue
            account_id = str(led.get("account_id") or "")
            key = account_id + _KEY_SEP + symbol
            current = self._states.get(key, STATE_NORMAL)
            u = _to_float(led.get("u"))
            warning = bool(led.get("warning"))
            breached = bool(led.get("breached"))
            alive = self._alive_for(account_id)
            new_state, intent = self._next_state(current, u, warning, breached, alive)
            self._states[key] = new_state
            if self._halted:
                out_state, out_intent = STATE_FROZEN, INTENT_FREEZE
            else:
                out_state, out_intent = new_state, intent
            prev_out = self._emitted.get(key, STATE_NORMAL)
            self._emitted[key] = out_state
            portfolios.append({
                "account_id": account_id, "symbol": symbol, "state": out_state,
                "prev_state": prev_out, "changed": out_state != prev_out,
                "protection_intent": out_intent, "u": u, "warning": warning,
                "breached": breached, "budgeted": bool(led.get("budgeted")),
                "v_net": led.get("v_net"), "open_legs": led.get("open_legs"),
                "loss_exposure": led.get("loss_exposure"), "system_alive": alive,
            })
        out = {"portfolios": portfolios, "count": len(portfolios), "halted": self._halted}
        stamp = payload.get("timestamp")
        if stamp is not None:
            out["timestamp"] = stamp
        self._last = out
        self._updates += 1
        await self._context.publish(EVENT_OUT, out)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"updates": self._updates, "tracked": len(self._states), "halted": self._halted}
        if self._last is None:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="portfolios=%d halted=%s" % (self._last.get("count", 0), self._halted),
                            details=details)
