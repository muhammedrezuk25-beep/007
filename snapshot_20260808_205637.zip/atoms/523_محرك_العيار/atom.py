from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LEDGER = "risk.asset_ledger.state"
EVENT_COMMAND = "dial.command"
EVENT_OUT = "dial.profile.state"

REASON_NOT_STARTED = "NOT_STARTED"

_KEY_SEP = "|"
_DIAL_MIN = 0.0
_DIAL_MAX = 100.0
_MID = 0.5
_FRAC_DP = 8
_SEC_DP = 3


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _clamp(value: float, low: float, high: float) -> float:
    return low if value < low else high if value > high else value


def _lerp(low: float, high: float, t: float) -> float:
    return low + (high - low) * t


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._dials: dict[str, float] = {}
        self._active: set[str] = set()
        self._cfg: dict[str, float] = {}
        self._default_dial = 50.0
        self._emits = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        raw = cfg.get("dials") if isinstance(cfg.get("dials"), dict) else {}
        for key, value in raw.items():
            dial = _to_float(value)
            if dial is not None:
                self._dials[str(key)] = _clamp(dial, _DIAL_MIN, _DIAL_MAX)
        self._default_dial = _clamp(float(cfg.get("default_dial", 50.0)), _DIAL_MIN, _DIAL_MAX)
        self._cfg = {
            "horizon_min_s": float(cfg.get("horizon_min_s", 180.0)),
            "horizon_max_s": float(cfg.get("horizon_max_s", 14400.0)),
            "horizon_shape": float(cfg.get("horizon_shape", 1.0)),
            "filter_min": float(cfg.get("filter_min", 0.2)),
            "filter_max": float(cfg.get("filter_max", 0.9)),
            "stop_min_frac": float(cfg.get("stop_min_frac", 0.001)),
            "stop_max_frac": float(cfg.get("stop_max_frac", 0.01)),
            "cadence_fast_s": float(cfg.get("cadence_fast_s", 5.0)),
            "cadence_slow_s": float(cfg.get("cadence_slow_s", 60.0)),
        }
        context.subscribe(EVENT_LEDGER, self._on_ledger)
        context.subscribe(EVENT_COMMAND, self._on_command)

    async def start(self) -> None:
        self._running = True
        if self._dials:
            await self._emit()

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _profile(self, key: str) -> dict[str, Any]:
        account_id, _, symbol = key.partition(_KEY_SEP)
        dial = self._dials.get(key, self._default_dial)
        x = _clamp(dial, _DIAL_MIN, _DIAL_MAX) / _DIAL_MAX
        cfg = self._cfg
        shape = cfg["horizon_shape"] if cfg["horizon_shape"] > 0.0 else 1.0
        horizon = _lerp(cfg["horizon_min_s"], cfg["horizon_max_s"], x ** shape)
        filter_strength = _lerp(cfg["filter_min"], cfg["filter_max"], x)
        stop_frac = _lerp(cfg["stop_min_frac"], cfg["stop_max_frac"], x)
        cadence = _lerp(cfg["cadence_fast_s"], cfg["cadence_slow_s"], x)
        return {
            "account_id": account_id, "symbol": symbol, "dial": dial,
            "horizon_seconds": round(horizon, _SEC_DP),
            "filter_strength": round(filter_strength, _FRAC_DP),
            "stop_distance_frac": round(stop_frac, _FRAC_DP),
            "mgmt_cadence_s": round(cadence, _SEC_DP),
            "lot_bias": "large" if x < _MID else "small",
        }

    async def _emit(self) -> None:
        if self._context is None:
            return
        keys = sorted(set(self._dials) | self._active)
        profiles = [self._profile(key) for key in keys]
        self._emits += 1
        await self._context.publish(EVENT_OUT, {"profiles": profiles, "count": len(profiles)})

    async def _on_ledger(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        ledgers = payload.get("ledgers")
        if not isinstance(ledgers, list):
            return
        changed = False
        for led in ledgers:
            if not isinstance(led, dict):
                continue
            symbol = str(led.get("symbol") or "")
            if not symbol:
                continue
            key = str(led.get("account_id") or "") + _KEY_SEP + symbol
            if key not in self._active:
                self._active.add(key)
                changed = True
        if changed or self._active:
            await self._emit()

    async def _on_command(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = str(payload.get("symbol") or "")
        dial = _to_float(payload.get("dial"))
        if not symbol or dial is None:
            return
        key = str(payload.get("account_id") or "") + _KEY_SEP + symbol
        self._dials[key] = _clamp(dial, _DIAL_MIN, _DIAL_MAX)
        await self._emit()

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="dials=%d active=%d emits=%d" % (len(self._dials), len(self._active), self._emits),
            details={"dials": len(self._dials), "active": len(self._active), "emits": self._emits})
