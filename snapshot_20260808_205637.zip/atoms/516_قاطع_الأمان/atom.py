from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_VALIDATE = "execution.order.requested"
EVENT_LOSS = "risk.loss_reported"
EVENT_DAY = "SYS_DAY"
EVENT_RESET = "risk.kill_switch.reset_requested"
EVENT_POSITIONS = "platform.positions.state"

EVENT_VALIDATED = "risk.validation.completed"
EVENT_HALT = "emergency.halt"

REASON_KILL = "KILL_SWITCH"
REASON_DAILY = "RISK_DAILY_LIMIT"
REASON_CONSEC = "MAX_CONSECUTIVE_LOSSES"
REASON_MAX_DAILY = "MAX_DAILY_TRADES"
REASON_MAX_OPEN = "MAX_OPEN_TRADES"
REASON_NONE = ""

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._max_daily_loss_pct = 5.0
        self._max_consecutive_losses = 3
        self._max_daily_trades = 20
        self._max_open_trades = 5
        self._daily_loss_pct = 0.0
        self._consecutive_losses = 0
        self._daily_trade_count = 0
        self._open_trade_count = 0
        self._kill = False
        self._reason = REASON_NONE
        self._seen = 0
        self._validations = 0
        self._rejections = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._max_daily_loss_pct = float(cfg["max_daily_loss_pct"])
        self._max_consecutive_losses = int(cfg["max_consecutive_losses"])
        self._max_daily_trades = int(cfg["max_daily_trades"])
        self._max_open_trades = int(cfg["max_open_trades"])
        context.subscribe(EVENT_VALIDATE, self._on_validate)
        context.subscribe(EVENT_LOSS, self._on_loss)
        context.subscribe(EVENT_DAY, self._on_day)
        context.subscribe(EVENT_RESET, self._on_reset)
        context.subscribe(EVENT_POSITIONS, self._on_positions)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _reject_reason(self) -> str:
        if self._kill:
            return REASON_KILL
        if self._daily_trade_count >= self._max_daily_trades:
            return REASON_MAX_DAILY
        if self._open_trade_count >= self._max_open_trades:
            return REASON_MAX_OPEN
        return REASON_NONE

    async def _on_validate(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        reason = self._reject_reason()
        approved = reason == REASON_NONE
        self._validations += 1
        if not approved:
            self._rejections += 1
        await self._context.publish(EVENT_VALIDATED, {
            "request_id": str(payload.get("request_id", "")),
            "symbol": str(payload.get("symbol", "")), "side": str(payload.get("side", "")),
            "approved": approved, "reason": reason,
            "kill_switch_state": self._kill})

    async def _on_loss(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._seen += 1
        loss_pct = _to_float(payload.get("loss_pct"))
        is_loss = bool(payload.get("is_loss"))
        if loss_pct is not None:
            self._daily_loss_pct += loss_pct
        if is_loss:
            self._consecutive_losses += 1
        else:
            self._consecutive_losses = 0
        self._daily_trade_count += 1
        if self._daily_loss_pct >= self._max_daily_loss_pct:
            await self._trip(REASON_DAILY)
        elif self._consecutive_losses >= self._max_consecutive_losses:
            await self._trip(REASON_CONSEC)

    async def _trip(self, reason: str) -> None:
        if self._kill or self._context is None:
            return
        self._kill = True
        self._reason = reason
        await self._context.publish(EVENT_HALT, {
            "reason": reason, "daily_loss_pct": round(self._daily_loss_pct, 4),
            "consecutive_losses": self._consecutive_losses})

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._daily_loss_pct = 0.0
        self._daily_trade_count = 0
        # kill switch is NEVER auto-cleared on a day roll (manual reset only)

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._kill = False
        self._reason = REASON_NONE
        self._consecutive_losses = 0

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        count = payload.get("open_count")
        if isinstance(count, int) and not isinstance(count, bool) and count >= 0:
            self._open_trade_count = count

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"kill_switch": self._kill, "reason": self._reason,
                   "daily_loss_pct": round(self._daily_loss_pct, 4),
                   "consecutive_losses": self._consecutive_losses,
                   "validations": self._validations, "rejections": self._rejections}
        if self._kill:
            return HealthStatus(state=HealthState.DEGRADED, message="KILL_SWITCH_ACTIVE",
                                details=details)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="validations=%d rejections=%d" % (
                                self._validations, self._rejections), details=details)

    async def snapshot(self) -> dict:
        return {"daily_loss_pct": self._daily_loss_pct,
                "consecutive_losses": self._consecutive_losses,
                "daily_trade_count": self._daily_trade_count,
                "open_trade_count": self._open_trade_count,
                "kill_switch_state": self._kill, "kill_switch_reason": self._reason}

    async def restore(self, state: dict) -> None:
        self._daily_loss_pct = float(state.get("daily_loss_pct", 0.0))
        self._consecutive_losses = int(state.get("consecutive_losses", 0))
        self._daily_trade_count = int(state.get("daily_trade_count", 0))
        self._open_trade_count = int(state.get("open_trade_count", 0))
        self._kill = bool(state.get("kill_switch_state", False))
        self._reason = str(state.get("kill_switch_reason", REASON_NONE))
