from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_ENTRY = "strategy.entry.state"
EVENT_CONF = "probability.confidence.state"
EVENT_OUT = "decision.aggregated.state"

METHOD = "strategy_direction_prob_backing"
ID_AGG = "decision_aggregator"

DIR_BUY = "buy"
DIR_SELL = "sell"
DIR_WAIT = "wait"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

ENTRY_BUY = "buy"
ENTRY_SELL = "sell"
CONF_HIGH = "high_confidence"

_HALF_CONF = 0.5


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._entry: dict[str, dict[str, Any]] = {}
        self._conf: dict[str, str] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_ENTRY, self._on_entry)
        context.subscribe(EVENT_CONF, self._on_conf)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> str:
        return str(payload.get("symbol", ""))

    async def _on_entry(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        meta = payload.get("metadata")
        votes = {"buy": 0, "sell": 0}
        if isinstance(meta, dict):
            votes = {"buy": _to_int(meta.get("buy_votes")),
                     "sell": _to_int(meta.get("sell_votes"))}
        self._entry[self._key(payload)] = {"signal": str(payload.get("signal", "")),
                                           "votes": votes}

    async def _on_conf(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._conf[self._key(payload)] = str(payload.get("signal", ""))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = symbol
        self._candles_seen += 1
        entry = self._entry.get(key, {"signal": "", "votes": {"buy": 0, "sell": 0}})
        prob_conf = self._conf.get(key, "")
        src = entry["signal"]
        if src == ENTRY_BUY:
            direction = DIR_BUY
        elif src == ENTRY_SELL:
            direction = DIR_SELL
        else:
            direction = DIR_WAIT
        prob_backed = prob_conf == CONF_HIGH
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_AGG, "cycle_id": cycle_id, "status": STATUS_OK,
            "signal": direction, "score": 0,
            "confidence": 1.0 if prob_backed else _HALF_CONF,
            "quality": QUALITY_GOOD if direction != DIR_WAIT else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction,
                                         "strategy_votes": entry["votes"],
                                         "prob_confidence": prob_conf,
                                         "prob_backed": prob_backed}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._entry)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._entry)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._entry)})
