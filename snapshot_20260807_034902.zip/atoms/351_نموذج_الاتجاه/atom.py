from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_TREND = "structure.trend.state"
EVENT_PHASE = "structure.phase.state"
EVENT_OUT = "probability.trend.state"

METHOD = "trend_continuation_heuristic"
ID_MODEL = "trend_model"

SIGNAL_CONTINUATION = "continuation"
SIGNAL_EXHAUSTION = "exhaustion"
SIGNAL_NEUTRAL = "neutral"

DIR_UP = "up"
DIR_DOWN = "down"
DIR_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

TREND_UP = "uptrend"
TREND_DOWN = "downtrend"
PHASE_EXTENDED = "extended"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._base = 0.55
        self._step = 0.05
        self._max = 0.9
        self._ext_factor = 0.6
        self._trend: dict[tuple, dict[str, Any]] = {}
        self._phase: dict[tuple, str] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base = float(cfg["base_prob"])
        self._step = float(cfg["confirmation_step"])
        self._max = float(cfg["max_prob"])
        self._ext_factor = float(cfg["exhaustion_factor"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_TREND, self._on_trend)
        context.subscribe(EVENT_PHASE, self._on_phase)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_trend(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        meta = payload.get("metadata", {})
        confirmations = meta.get("confirmations", 0) if isinstance(meta, dict) else 0
        try:
            confirmations = int(confirmations)
        except (TypeError, ValueError):
            confirmations = 0
        self._trend[self._key(payload)] = {
            "signal": str(payload.get("signal", "")), "confirmations": confirmations}

    async def _on_phase(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._phase[self._key(payload)] = str(payload.get("signal", ""))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        tr = self._trend.get(key)
        phase = self._phase.get(key, "")
        if tr is None or tr["signal"] not in (TREND_UP, TREND_DOWN):
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, DIR_NONE,
                             _NEUTRAL_PROB, _LOW, tr, phase)
            return
        prob = min(self._max, self._base + self._step * tr["confirmations"])
        direction = DIR_UP if tr["signal"] == TREND_UP else DIR_DOWN
        signal = SIGNAL_CONTINUATION
        if phase == PHASE_EXTENDED:
            prob = prob * self._ext_factor
            signal = SIGNAL_EXHAUSTION
        await self._emit(symbol, timeframe, cycle_id, signal, direction, prob, _FULL,
                         tr, phase)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    direction: str, prob: float, confidence: float,
                    tr: dict[str, Any] | None, phase: str) -> None:
        if self._context is None:
            return
        confirmations = tr["confirmations"] if tr else 0
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "probability": round(prob, _DP),
                                         "confirmations": confirmations, "phase": phase}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._trend)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._trend)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._trend)})
