from __future__ import annotations

import asyncio
import os
import sqlite3
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_OUT = "platform.positions.state"
EVENT_OPENED = "platform.position.appeared"
EVENT_CLOSED = "platform.position.vanished"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_READ_YET"

_COLUMNS = ("ticket", "symbol", "side", "volume", "entry_price",
            "current_price", "stop_loss", "take_profit", "profit",
            "swap", "magic", "opened_at", "updated_at")

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_VOL_DP = 8
_PNL_DP = 6


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = ""
        self._poll_interval_s = 0.0
        self._positions: dict[str, dict[str, Any]] = {}
        self._last_read_at: float | None = None
        self._last_error = ""
        self.read_count = 0
        self.appeared_count = 0
        self.vanished_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        await self._read_once()
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None

    async def shutdown(self) -> None:
        await self.stop()

    def _read_rows(self) -> list[dict[str, Any]]:
        columns = ", ".join(_COLUMNS)
        conn = _connect(self._db_path)
        try:
            conn.row_factory = sqlite3.Row
            rows = [dict(r) for r in conn.execute(f"SELECT {columns} FROM {self._table}").fetchall()]
            for row in rows:
                row["account_id"] = None
            try:
                ident = conn.execute(f"SELECT ticket, account_id FROM {self._table}").fetchall()
                by_ticket = {r[0]: r[1] for r in ident}
                for row in rows:
                    row["account_id"] = by_ticket.get(row.get("ticket"))
            except sqlite3.Error:
                pass
            return rows
        finally:
            conn.close()

    async def _read_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._read_rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return
        self._last_error = ""
        self.read_count += 1
        fresh: dict[str, dict[str, Any]] = {}
        newest: float | None = None
        for row in rows:
            ticket = row.get("ticket")
            if ticket is None:
                continue
            updated = _to_float(row.get("updated_at"))
            if updated is not None and (newest is None or updated > newest):
                newest = updated
            fresh[str(ticket)] = {
                "ticket": ticket, "symbol": row.get("symbol"), "side": row.get("side"),
                "volume": _to_float(row.get("volume")), "entry_price": _to_float(row.get("entry_price")),
                "current_price": _to_float(row.get("current_price")),
                "stop_loss": _to_float(row.get("stop_loss")), "take_profit": _to_float(row.get("take_profit")),
                "profit": _to_float(row.get("profit")), "swap": _to_float(row.get("swap")),
                "magic": row.get("magic"), "opened_at": _to_float(row.get("opened_at")),
                "account_id": row.get("account_id"),
            }
        appeared = [k for k in fresh if k not in self._positions]
        vanished = [k for k in self._positions if k not in fresh]
        previous = dict(self._positions)
        self._positions = fresh
        self._last_read_at = newest
        stamp = {"timestamp": newest} if newest is not None else {}
        for key in appeared:
            self.appeared_count += 1
            await self._context.publish(EVENT_OPENED, {**fresh[key], **stamp})
        for key in vanished:
            self.vanished_count += 1
            await self._context.publish(EVENT_CLOSED, {**previous[key], **stamp})
        await self._context.publish(EVENT_OUT, {**self.state(), **stamp})

    async def _loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._poll_interval_s)
                if self._running:
                    await self._read_once()
        except asyncio.CancelledError:
            pass

    def state(self) -> dict[str, Any]:
        by_symbol: dict[str, int] = {}
        total_volume = 0.0
        floating = 0.0
        for entry in self._positions.values():
            symbol = str(entry.get("symbol"))
            by_symbol[symbol] = by_symbol.get(symbol, 0) + 1
            if entry.get("volume"):
                total_volume += abs(entry["volume"])
            if entry.get("profit") is not None:
                floating += entry["profit"]
        return {
            "open_count": len(self._positions),
            "tickets": sorted(self._positions),
            "by_symbol": by_symbol,
            "total_volume": round(total_volume, _VOL_DP),
            "floating_pnl": round(floating, _PNL_DP),
            "positions": [dict(v) for v in self._positions.values()],
            "read_at": self._last_read_at,
        }

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = self.state()
        details["reads"] = self.read_count
        details["last_error"] = self._last_error
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error, details=details)
        if self.read_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message=f"open={len(self._positions)} floating={details['floating_pnl']:.2f}",
                            details=details)
