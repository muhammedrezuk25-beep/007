from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "probability.merged.state"

_MODEL_EVENTS = (
    "probability.trend.state",
    "probability.reversal.state",
    "probability.breakout.state",
    "probability.pullback.state",
    "probability.momentum.state",
    "probability.range.state",
)

_SCENARIO = {
    "trend_model": "trend",
    "reversal_model": "reversal",
    "breakout_model": "breakout",
    "pullback_model": "pullback",
    "momentum_model": "momentum",
    "range_model": "range",
}

METHOD = "dominant_scenario"
ID_MERGER = "models_merged"

SIGNAL_NEUTRAL = "neutral"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_PERCENT = 100.0
_EXPECTED_MODELS = 6


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._neutral_band = 0.05
        self._scores: dict[tuple, dict[str, int]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._neutral_band = float(context.config["neutral_band"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        for event in _MODEL_EVENTS:
            context.subscribe(event, self._on_model)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_model(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        model_id = str(payload.get("id", ""))
        if model_id not in _SCENARIO:
            return
        key = (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))
        try:
            score = int(payload.get("score", 0))
        except (TypeError, ValueError):
            score = 0
        self._scores.setdefault(key, {})[model_id] = score

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        scores = self._scores.get(key, {})
        labelled = {_SCENARIO[mid]: sc for mid, sc in scores.items()}
        if not scores:
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, 0, 0.0,
                             labelled, "none", 0.0)
            return
        ordered = sorted(scores.values(), reverse=True)
        top_score = ordered[0]
        second = ordered[1] if len(ordered) > 1 else 0
        margin = (top_score - second) / _PERCENT
        dominant_id = ""
        for mid, sc in scores.items():
            if sc == top_score:
                dominant_id = mid
                break
        dominant = _SCENARIO.get(dominant_id, "none")
        if margin < self._neutral_band:
            signal = SIGNAL_NEUTRAL
        else:
            signal = dominant
        confidence = round(min(1.0, len(scores) / _EXPECTED_MODELS), 2)
        await self._emit(symbol, timeframe, cycle_id, signal, top_score, confidence,
                         labelled, dominant, margin)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    score: int, confidence: float, labelled: dict[str, int],
                    dominant: str, margin: float) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MERGER, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal, "score": score,
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "dominant": dominant, "margin": round(margin, 4),
                                         "scores": labelled,
                                         "present": len(labelled)}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._scores)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._scores)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._scores)})
