from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "market_data.candle_closed"
EVENT_OUT = "stats.period_compare.state"

METHOD = "rolling_half_compare"
ID_PERIOD = "period_compare"

SIGNAL_RISING = "rising"
SIGNAL_FALLING = "falling"
SIGNAL_STABLE = "stable"

VOL_EXPANDING = "expanding"
VOL_CONTRACTING = "contracting"
VOL_STABLE = "stable"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

WARN_INSUFFICIENT = "insufficient_data_points"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_MIN_POINTS = 4
_VALUE_DP = 6


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _mean_std(vals: list) -> tuple:
    n = len(vals)
    if n == 0:
        return 0.0, 0.0
    mean = sum(vals) / n
    if n < 2:
        return mean, 0.0
    variance = sum((x - mean) ** 2 for x in vals) / (n - 1)
    return mean, math.sqrt(variance)


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._window_size = 20
        self._drift_band = 0.001
        self._vol_band = 0.1
        self._state: dict[tuple, deque] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._window_size = int(context.config["window_size"])
        self._drift_band = float(context.config["drift_band"])
        self._vol_band = float(context.config["vol_band"])
        context.subscribe(EVENT_IN, self._on_candle)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        close = _to_float(payload.get("close"))
        if not symbol or close is None:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        window = self._state.get(key)
        if window is None:
            window = deque(maxlen=self._window_size)
            self._state[key] = window
        window.append(close)
        self._candles_seen += 1
        await self._emit(symbol, timeframe, cycle_id, window)

    def _vol_state(self, ostd: float, rstd: float) -> tuple:
        if ostd <= 0.0:
            ratio = 0.0
            state = VOL_EXPANDING if rstd > 0.0 else VOL_STABLE
            return state, ratio
        ratio = rstd / ostd
        if ratio >= 1.0 + self._vol_band:
            state = VOL_EXPANDING
        elif ratio <= 1.0 - self._vol_band:
            state = VOL_CONTRACTING
        else:
            state = VOL_STABLE
        return state, ratio

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str,
                    window: deque) -> None:
        if self._context is None:
            return
        count = len(window)
        base = {"symbol": symbol, "id": ID_PERIOD, "cycle_id": cycle_id}
        meta = {"method": METHOD, "timeframe": timeframe, "window": self._window_size,
                "count": count}
        if count < _MIN_POINTS:
            await self._context.publish(EVENT_OUT, {
                **base, "status": STATUS_INSUFFICIENT, "signal": SIGNAL_STABLE,
                "score": 0, "confidence": 0.0, "quality": QUALITY_LOW,
                "warnings": [WARN_INSUFFICIENT], "metadata": meta})
            self._emitted += 1
            return
        data = list(window)
        mid = count // 2
        older = data[:mid]
        recent = data[mid:]
        omean, ostd = _mean_std(older)
        rmean, rstd = _mean_std(recent)
        drift = (rmean - omean) / abs(omean) if omean != 0 else 0.0
        if drift >= self._drift_band:
            signal = SIGNAL_RISING
        elif drift <= -self._drift_band:
            signal = SIGNAL_FALLING
        else:
            signal = SIGNAL_STABLE
        vol_state, vol_ratio = self._vol_state(ostd, rstd)
        confidence = round(count / self._window_size, 2) if self._window_size > 0 else 0.0
        meta.update({"older_mean": round(omean, _VALUE_DP), "recent_mean": round(rmean, _VALUE_DP),
                     "drift": round(drift, _VALUE_DP), "older_std": round(ostd, _VALUE_DP),
                     "recent_std": round(rstd, _VALUE_DP), "vol_ratio": round(vol_ratio, _VALUE_DP),
                     "vol_state": vol_state})
        await self._context.publish(EVENT_OUT, {
            **base, "status": STATUS_OK, "signal": signal, "score": 0,
            "confidence": min(1.0, confidence), "quality": QUALITY_GOOD,
            "warnings": [], "metadata": meta})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._state)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._state)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._state)})
