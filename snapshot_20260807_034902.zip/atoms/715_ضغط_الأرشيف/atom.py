from __future__ import annotations

import asyncio
import gzip
import shutil
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_IN = "storage.archived"
EVENT_OUT = "storage.compressed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NEVER_RAN"

_SUFFIX = ".gz"


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._min_size_bytes = 0
        self._level = 0
        self._keep_original = True
        self._runs = 0
        self._compressed_count = 0
        self._saved_bytes = 0
        self._last_error = ""
        self._last_result: dict[str, Any] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._min_size_bytes = int(cfg["min_size_bytes"])
        self._level = int(cfg["compression_level"])
        self._keep_original = bool(cfg["keep_original"])
        context.subscribe(EVENT_IN, self._on_archived)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _compress(self, source: str) -> dict[str, Any]:
        path = Path(source)
        if not path.is_file():
            return {"compressed": False, "reason": "MISSING"}
        size = path.stat().st_size
        if size < self._min_size_bytes:
            return {"compressed": False, "reason": "BELOW_MIN_SIZE", "size_bytes": size}
        target = path.with_suffix(path.suffix + _SUFFIX)
        try:
            with path.open("rb") as raw, gzip.open(
                    target, "wb", compresslevel=self._level) as packed:
                shutil.copyfileobj(raw, packed)
            packed_size = target.stat().st_size
            if not self._keep_original:
                path.unlink()
            self._last_error = ""
            return {"compressed": True, "path": str(target), "size_bytes": size,
                    "packed_bytes": packed_size,
                    "saved_bytes": max(0, size - packed_size),
                    "original_kept": self._keep_original}
        except OSError as exc:
            self._last_error = str(exc)
            return {"compressed": False, "reason": "WRITE_FAILED"}

    async def _on_archived(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        rows = _to_int(payload.get("rows"))
        source = payload.get("archive_path")
        if not source or not rows:
            return
        result = await asyncio.to_thread(self._compress, str(source))
        self._runs += 1
        self._last_result = result
        if result.get("compressed"):
            self._compressed_count += 1
            self._saved_bytes += int(result.get("saved_bytes") or 0)
        body: dict[str, Any] = dict(result)
        body["total_compressed"] = self._compressed_count
        body["total_saved_bytes"] = self._saved_bytes
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"runs": self._runs, "compressed": self._compressed_count,
                   "saved_bytes": self._saved_bytes, "keep_original": self._keep_original,
                   "last_result": dict(self._last_result), "last_error": self._last_error}
        if self._runs == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NEVER_RAN, details=details)
        if self._last_error:
            return HealthStatus(
                state=HealthState.DEGRADED, message=self._last_error, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="compressed=%d saved=%d" % (self._compressed_count, self._saved_bytes),
            details=details)
