from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000
_SECONDS_PER_DAY = 86400.0

EVENT_IN = "portfolio.summary"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "storage.portfolio_saved"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NOTHING_STORED = "NOTHING_STORED_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS portfolio (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id   TEXT,
    equity       REAL,
    balance      REAL,
    realised_pnl REAL,
    open_count   INTEGER,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_portfolio_account ON portfolio(account_id, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_portfolio_time ON portfolio(occurred_at)",
)

_INSERT = (
    "INSERT INTO portfolio (account_id, equity, balance, realised_pnl, open_count,"
    " occurred_at, payload_json) VALUES (?,?,?,?,?,?,?)"
)

_PRUNE = "DELETE FROM portfolio WHERE occurred_at IS NOT NULL AND occurred_at < ?"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._min_interval_s = 0.0
        self._retention_days = 0
        self._last_written: dict[str, float] = {}
        self._store_ready = False
        self._last_error = ""
        self.stored_count = 0
        self.skipped_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._min_interval_s = float(cfg["min_write_interval_s"])
        self._retention_days = int(cfg["retention_days"])
        context.subscribe(EVENT_IN, self._on_summary)
        context.subscribe(EVENT_DAY, self._on_day)
        self._store_ready = self._ensure_store()
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            return False

    def _write(self, row: tuple) -> bool:
        try:
            connection = self._connect()
            try:
                connection.execute(_INSERT, row)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return False

    def _prune(self, now: float) -> int:
        if self._retention_days <= 0:
            return 0
        cutoff = now - self._retention_days * _SECONDS_PER_DAY
        try:
            connection = self._connect()
            try:
                cursor = connection.execute(_PRUNE, (cutoff,))
                connection.commit()
                return cursor.rowcount or 0
            finally:
                connection.close()
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return 0

    async def _on_summary(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        account_id = payload.get("account_id")
        key = str(account_id) if account_id else ""
        occurred = _to_float(payload.get("timestamp"))
        if occurred is not None and key in self._last_written:
            if occurred - self._last_written[key] < self._min_interval_s:
                self.skipped_count += 1
                return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
            if not self._store_ready:
                self.dropped_count += 1
                return
        row = (
            key or None,
            _to_float(payload.get("equity")),
            _to_float(payload.get("balance")),
            _to_float(payload.get("realised_pnl")),
            _to_int(payload.get("open_count")),
            occurred,
            json.dumps(payload, ensure_ascii=False, default=str),
        )
        if not await asyncio.to_thread(self._write, row):
            self.dropped_count += 1
            return
        self.stored_count += 1
        if occurred is not None:
            self._last_written[key] = occurred
        body: dict[str, Any] = {"rows": 1, "total": self.stored_count,
                                "account_id": account_id, "skipped": self.skipped_count}
        if occurred is not None:
            body["timestamp"] = occurred
        await self._context.publish(EVENT_OUT, body)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        if now is None:
            return
        pruned = await asyncio.to_thread(self._prune, now)
        await self._context.publish(EVENT_OUT, {
            "rows": 0, "total": self.stored_count, "pruned": pruned, "timestamp": now})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"stored": self.stored_count, "skipped": self.skipped_count,
                   "dropped": self.dropped_count, "accounts": len(self._last_written),
                   "db_path": self._db_path, "last_error": self._last_error}
        if not self._store_ready:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=self._last_error or REASON_STORE_UNAVAILABLE, details=details)
        if self.stored_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NOTHING_STORED, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="stored=%d skipped=%d" % (self.stored_count, self.skipped_count),
            details=details)
