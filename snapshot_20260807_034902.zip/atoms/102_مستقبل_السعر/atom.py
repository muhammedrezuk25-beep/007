from __future__ import annotations

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_IN = "market.tick"
EVENT_OUT = "market_data.price_received"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self.received_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_tick)

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        if self.received_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message="NO_TICKS_YET")
        return HealthStatus(state=HealthState.HEALTHY, message=f"received={self.received_count}")

    async def _on_tick(self, payload: dict) -> None:
        if self._context is None:
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        out = {"symbol": symbol, "bid": payload.get("bid"), "ask": payload.get("ask")}
        ts = payload.get("timestamp")
        if ts is not None:
            out["timestamp"] = ts
        prov = payload.get("provider")
        if prov is not None:
            out["provider"] = prov
        self.received_count += 1
        await self._context.publish(EVENT_OUT, out)
