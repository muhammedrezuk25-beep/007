from __future__ import annotations

import math
from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "market_data.candle_closed"
EVENT_OUT = "analysis.volatility.state"

METHOD = "atr_relative"

LEVEL_LOW = "low"
LEVEL_NORMAL = "normal"
LEVEL_HIGH = "high"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

WARN_INSUFFICIENT = "insufficient_candles"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_PERCENT = 100.0
_SCORE_MAX = 100.0
_ATR_PCT_SCALE = 120.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _stddev(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    avg = _mean(values)
    return math.sqrt(sum((v - avg) ** 2 for v in values) / len(values))


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._atr_window = 14
        self._baseline_window = 50
        self._stddev_window = 20
        self._high_mult = 1.5
        self._low_mult = 0.6
        self._min_candles = 20
        self._state: dict[tuple, dict[str, Any]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._atr_window = int(cfg["atr_window"])
        self._baseline_window = int(cfg["baseline_window"])
        self._stddev_window = int(cfg["stddev_window"])
        self._high_mult = float(cfg["high_mult"])
        self._low_mult = float(cfg["low_mult"])
        self._min_candles = int(cfg["min_candles"])
        context.subscribe(EVENT_IN, self._on_candle)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        high = _to_float(payload.get("high"))
        low = _to_float(payload.get("low"))
        close = _to_float(payload.get("close"))
        if not symbol or high is None or low is None or close is None:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        st = self._state.get(key)
        if st is None:
            st = {"tr": deque(maxlen=self._baseline_window),
                  "closes": deque(maxlen=self._baseline_window), "prev_close": None}
            self._state[key] = st
        prev_close = st["prev_close"]
        if prev_close is None:
            true_range = high - low
        else:
            true_range = max(high - low, abs(high - prev_close), abs(low - prev_close))
        st["tr"].append(true_range)
        st["closes"].append(close)
        st["prev_close"] = close
        self._candles_seen += 1
        await self._emit(symbol, timeframe, cycle_id, close, high, low, st)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, close: float,
                    high: float, low: float, st: dict[str, Any]) -> None:
        if self._context is None:
            return
        base = {"symbol": symbol, "id": "volatility", "cycle_id": cycle_id}
        meta = {"method": METHOD, "timeframe": timeframe}
        tr = list(st["tr"])
        if len(tr) < self._min_candles:
            await self._context.publish(EVENT_OUT, {
                **base, "status": STATUS_INSUFFICIENT, "signal": LEVEL_NORMAL,
                "score": 0, "confidence": 0.0, "quality": QUALITY_LOW,
                "warnings": [WARN_INSUFFICIENT], "metadata": meta})
            self._emitted += 1
            return
        current_atr = _mean(tr[-self._atr_window:])
        baseline_atr = _mean(tr)
        ratio = current_atr / baseline_atr if baseline_atr > 0 else 1.0
        if ratio >= self._high_mult:
            level = LEVEL_HIGH
        elif ratio <= self._low_mult:
            level = LEVEL_LOW
        else:
            level = LEVEL_NORMAL
        atr_pct = current_atr / close * _PERCENT if close > 0 else 0.0
        score = int(round(min(_SCORE_MAX, atr_pct * _ATR_PCT_SCALE)))
        confidence = round(min(1.0, len(tr) / self._baseline_window), 2)
        stddev = _stddev(list(st["closes"])[-self._stddev_window:])
        meta.update({"atr": round(current_atr, 5), "atr_pct": round(atr_pct, 4),
                     "baseline_atr": round(baseline_atr, 5), "ratio": round(ratio, 2),
                     "range": round(high - low, 5), "stddev": round(stddev, 5)})
        await self._context.publish(EVENT_OUT, {
            **base, "status": STATUS_OK, "signal": level, "score": score,
            "confidence": confidence, "quality": QUALITY_GOOD, "warnings": [],
            "metadata": meta})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._state)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._state)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._state)})
