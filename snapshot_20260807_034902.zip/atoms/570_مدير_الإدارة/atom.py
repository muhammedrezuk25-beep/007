from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_INTENT = "execution.manage.intent"
EVENT_VANISH = "platform.position.vanished"
EVENT_OUT = "execution.manage.command"

ACTION_MODIFY = "MODIFY_SL"
ACTION_PARTIAL = "CLOSE_PARTIAL"
ACTION_CLOSE = "CLOSE"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._state: dict[str, dict[str, Any]] = {}
        self._seen = 0
        self._commands = 0
        self._dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_INTENT, self._on_intent)
        context.subscribe(EVENT_VANISH, self._on_vanish)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_vanish(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        ticket = payload.get("ticket")
        if ticket is not None:
            self._state.pop(str(ticket), None)

    async def _on_intent(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        ticket = payload.get("ticket")
        action = str(payload.get("action", ""))
        side = str(payload.get("side", ""))
        if ticket is None or side not in (SIDE_BUY, SIDE_SELL):
            self._dropped += 1
            return
        key = str(ticket)
        st = self._state.get(key)
        if st is None:
            st = {"side": side, "best_sl": None, "partialed": False, "closed": False}
            self._state[key] = st
        if st["closed"]:
            self._dropped += 1
            return
        symbol = str(payload.get("symbol", ""))
        reason = str(payload.get("reason", ""))
        if action == ACTION_MODIFY:
            new_sl = _to_float(payload.get("stop_loss"))
            if new_sl is None:
                self._dropped += 1
                return
            best = st["best_sl"]
            tighter = best is None or (side == SIDE_BUY and new_sl > best) or \
                (side == SIDE_SELL and new_sl < best)
            if not tighter:
                self._dropped += 1
                return
            st["best_sl"] = new_sl
            await self._context.publish(EVENT_OUT, {
                "ticket": ticket, "symbol": symbol, "side": side,
                "action": ACTION_MODIFY, "stop_loss": new_sl, "reason": reason})
            self._commands += 1
        elif action == ACTION_PARTIAL:
            if st["partialed"]:
                self._dropped += 1
                return
            volume = _to_float(payload.get("volume"))
            if volume is None or volume <= 0.0:
                self._dropped += 1
                return
            st["partialed"] = True
            await self._context.publish(EVENT_OUT, {
                "ticket": ticket, "symbol": symbol, "side": side,
                "action": ACTION_PARTIAL, "volume": volume, "reason": reason})
            self._commands += 1
        elif action == ACTION_CLOSE:
            st["closed"] = True
            await self._context.publish(EVENT_OUT, {
                "ticket": ticket, "symbol": symbol, "side": side,
                "action": ACTION_CLOSE, "reason": reason})
            self._commands += 1
        else:
            self._dropped += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"tracked": len(self._state), "seen": self._seen,
                   "commands": self._commands, "dropped": self._dropped}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="commands=%d dropped=%d" % (
                                self._commands, self._dropped), details=details)
