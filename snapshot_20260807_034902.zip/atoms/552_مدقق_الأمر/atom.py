from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_BUILT = "execution.order.built"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_requested"

EVENT_FINAL = "trading.final_decision"
EVENT_PREVIEW = "execution.order.preview"
EVENT_REJECTED = "execution.order.rejected"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

GATE_DISABLED = "disabled"
GATE_HALTED = "halted"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

_ORDER_FIELDS = ("account_id", "request_id", "action", "symbol", "side",
                 "volume", "reference_price", "stop_loss", "take_profit")


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _validate(order: dict[str, Any]) -> str:
    symbol = order.get("symbol")
    side = str(order.get("side", ""))
    ref = _to_float(order.get("reference_price"))
    stop = _to_float(order.get("stop_loss"))
    target = _to_float(order.get("take_profit"))
    volume = _to_float(order.get("volume"))
    if not symbol:
        return "NO_SYMBOL"
    if side not in (SIDE_BUY, SIDE_SELL):
        return "BAD_SIDE"
    if volume is None or volume <= 0.0:
        return "BAD_VOLUME"
    if ref is None or ref <= 0.0:
        return "BAD_PRICE"
    if stop is None or stop <= 0.0:
        return "NO_STOP"
    if target is None or target <= 0.0:
        return "NO_TARGET"
    if side == SIDE_BUY and not (stop < ref < target):
        return "BUY_LEVELS"
    if side == SIDE_SELL and not (target < ref < stop):
        return "SELL_LEVELS"
    return ""


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._enabled = False
        self._halted = False
        self._seen = 0
        self._sent = 0
        self._preview = 0
        self._rejected = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._enabled = bool(context.config["enabled"])
        context.subscribe(EVENT_BUILT, self._on_built)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._halted = True

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._halted = False

    async def _on_built(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        reason = _validate(payload)
        if reason:
            self._rejected += 1
            await self._context.publish(EVENT_REJECTED, {
                "request_id": str(payload.get("request_id", "")),
                "symbol": str(payload.get("symbol", "")),
                "side": str(payload.get("side", "")), "reason": reason})
            return
        body = {key: payload.get(key) for key in _ORDER_FIELDS}
        if not payload.get("action"):
            body["action"] = "OPEN"
        if not self._enabled:
            self._preview += 1
            await self._context.publish(EVENT_PREVIEW, {**body, "gate": GATE_DISABLED})
            return
        if self._halted:
            self._preview += 1
            await self._context.publish(EVENT_PREVIEW, {**body, "gate": GATE_HALTED})
            return
        self._sent += 1
        await self._context.publish(EVENT_FINAL, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"enabled": self._enabled, "halted": self._halted, "seen": self._seen,
                   "sent": self._sent, "preview": self._preview, "rejected": self._rejected}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        gate = "LIVE" if self._enabled else "PREVIEW_ONLY"
        return HealthStatus(state=HealthState.HEALTHY,
                            message="%s sent=%d preview=%d rejected=%d" % (
                                gate, self._sent, self._preview, self._rejected),
                            details=details)
