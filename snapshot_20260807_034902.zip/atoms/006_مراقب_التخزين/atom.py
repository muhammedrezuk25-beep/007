from __future__ import annotations

import shutil

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_LOW = "tools.storage.low"
EVENT_RECOVERED = "tools.storage.recovered"

_DEFAULT_WARN_PCT = 80.0
_DEFAULT_CRITICAL_PCT = 90.0
_PERCENT = 100.0
_ROUND_DP = 2

_STATE_HEALTHY = "healthy"
_STATE_DEGRADED = "degraded"
_STATE_UNHEALTHY = "unhealthy"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._path = "."
        self._warn_threshold_pct = _DEFAULT_WARN_PCT
        self._critical_threshold_pct = _DEFAULT_CRITICAL_PCT
        self._last_published_state = _STATE_HEALTHY

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._path = context.config.get("path", ".")
        self._warn_threshold_pct = float(context.config.get("warn_threshold_pct", _DEFAULT_WARN_PCT))
        self._critical_threshold_pct = float(context.config.get("critical_threshold_pct", _DEFAULT_CRITICAL_PCT))

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    async def health_check(self) -> HealthStatus:
        try:
            usage = shutil.disk_usage(self._path)
        except OSError as exc:
            return HealthStatus(state=HealthState.UNKNOWN, message=f"cannot read path {self._path}: {exc}")
        used_pct = (usage.used / usage.total) * _PERCENT if usage.total > 0 else 0.0
        if used_pct >= self._critical_threshold_pct:
            new_state, health = _STATE_UNHEALTHY, HealthState.UNHEALTHY
        elif used_pct >= self._warn_threshold_pct:
            new_state, health = _STATE_DEGRADED, HealthState.DEGRADED
        else:
            new_state, health = _STATE_HEALTHY, HealthState.HEALTHY
        if self._context is not None:
            payload = {
                "path": self._path,
                "used_pct": round(used_pct, _ROUND_DP),
                "used_bytes": usage.used,
                "total_bytes": usage.total,
            }
            if new_state != _STATE_HEALTHY and self._last_published_state == _STATE_HEALTHY:
                await self._context.publish(EVENT_LOW, payload)
            elif new_state == _STATE_HEALTHY and self._last_published_state != _STATE_HEALTHY:
                await self._context.publish(EVENT_RECOVERED, payload)
        self._last_published_state = new_state
        return HealthStatus(state=health, message=f"disk usage: {used_pct:.1f}%")
