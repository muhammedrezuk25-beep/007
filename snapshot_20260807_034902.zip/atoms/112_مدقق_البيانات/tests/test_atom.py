import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom112", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom112"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_OUT = _mod.EVENT_OUT


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for h in self._handlers.get(name, []):
            r = h(payload)
            if inspect.isawaitable(r):
                await r

    def make_context(self):
        return AtomContext(atom_id=112, config={}, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def _make(bus):
    atom = Atom()
    await atom.initialize(bus.make_context())
    await atom.start()
    return atom


def _fails(bus):
    return [p for n, p in bus.published if n == EVENT_OUT]


async def test_silent_when_valid():
    print("\n--- test_silent_when_valid ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 100, "ask": 101})
    assert not _fails(bus), "edge-triggered: valid data -> no publish"
    print("OK — بيانات سليمة → صمت (edge-triggered)")


async def test_flags_negative_price():
    print("\n--- test_flags_negative_price ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": -5, "ask": 101})
    f = _fails(bus)
    assert len(f) == 1 and "negative_bid" in f[0]["problems"], f
    print(f"OK — سعر سالب → validation_failed: {f[0]['problems']}")


async def test_flags_candle_high_below_low():
    print("\n--- test_flags_candle_high_below_low ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("market_data.candle_closed",
                      {"symbol": "NQ", "open": 100, "high": 98, "low": 99,
                       "close": 100, "volume": 5})
    f = _fails(bus)
    assert f and "high_below_low" in f[-1]["problems"], f
    print("OK — شمعة high<low → validation_failed")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY -> HEALTHY (مدقّق edge-triggered)")


async def main():
    tests = [test_silent_when_valid, test_flags_negative_price,
             test_flags_candle_high_below_low, test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e))); print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e))); print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}"); sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
