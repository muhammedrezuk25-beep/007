from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_OUT = "market_data.validation_failed"

REASON_NOT_STARTED = "NOT_STARTED"

_PRICE_FIELDS_BY_EVENT = {
    "market_data.price_received": ["bid", "ask"],
    "market_data.spread_updated": ["spread"],
    "market_data.candle_closed": ["open", "high", "low", "close", "volume"],
    "market_data.volume_received": ["volume"],
    "market_data.depth_updated": [],
    "market_data.trade_tape_updated": [],
    "market_data.news_received": [],
    "market_data.calendar_event": [],
    "market_data.reference_index_updated": [],
}


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self.checked_count = 0
        self.failed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _PRICE_FIELDS_BY_EVENT:
            context.subscribe(event_name, self._make_validator(event_name))

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _make_validator(self, source_event: str):
        fields = _PRICE_FIELDS_BY_EVENT[source_event]

        async def handler(payload: dict[str, Any]) -> None:
            if not self._running or self._context is None:
                return
            if not isinstance(payload, dict):
                return
            self.checked_count += 1
            problems = self._validate(source_event, payload, fields)
            if problems:
                self.failed_count += 1
                await self._context.publish(EVENT_OUT, {
                    "source_event": source_event, "problems": problems,
                    "payload": payload})

        return handler

    @staticmethod
    def _validate(source_event: str, payload: dict[str, Any],
                  fields: list[str]) -> list[str]:
        problems: list[str] = []
        for field in fields:
            value = _to_float(payload.get(field))
            if value is not None and value < 0:
                problems.append("negative_" + field)
        if source_event == "market_data.candle_closed":
            high = _to_float(payload.get("high"))
            low = _to_float(payload.get("low"))
            if high is not None and low is not None and high < low:
                problems.append("high_below_low")
        return problems

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="checked=%d failed=%d" % (self.checked_count, self.failed_count),
            details={"checked": self.checked_count, "failed": self.failed_count})
