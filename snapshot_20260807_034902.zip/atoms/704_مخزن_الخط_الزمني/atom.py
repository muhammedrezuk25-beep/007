from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000
_SECONDS_PER_DAY = 86400.0

EVENT_DAY = "SYS_DAY"
EVENT_OUT = "storage.timeline_saved"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NO_ACTIVITY = "NO_EVENTS_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS timeline (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    event_name   TEXT NOT NULL,
    account_id   TEXT,
    symbol       TEXT,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_timeline_event ON timeline(event_name, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_timeline_account ON timeline(account_id, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_timeline_time ON timeline(occurred_at)",
)

_INSERT = (
    "INSERT INTO timeline (event_name, account_id, symbol, occurred_at, payload_json)"
    " VALUES (?,?,?,?,?)"
)

_PRUNE = "DELETE FROM timeline WHERE occurred_at IS NOT NULL AND occurred_at < ?"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._watch_events: list[str] = []
        self._flush_size = 0
        self._retention_days = 0.0
        self._buffer: list[tuple] = []
        self._store_ready = False
        self._last_error = ""
        self.recorded_count = 0
        self.flushed_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._watch_events = [str(e) for e in cfg["watch_events"]]
        self._flush_size = int(cfg["flush_size"])
        self._retention_days = float(cfg["retention_days"])
        for event_name in self._watch_events:
            context.subscribe(event_name, self._make_recorder(event_name))
        context.subscribe(EVENT_DAY, self._on_day)
        self._store_ready = self._ensure_store()
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False
        if self._buffer:
            await asyncio.to_thread(self._flush)

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            return False

    def _flush(self) -> int:
        if not self._buffer:
            return 0
        rows, self._buffer = self._buffer, []
        try:
            connection = self._connect()
            try:
                connection.executemany(_INSERT, rows)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return len(rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            self.dropped_count += len(rows)
            return 0

    def _prune(self, now: float) -> int:
        if self._retention_days <= 0:
            return 0
        cutoff = now - self._retention_days * _SECONDS_PER_DAY
        try:
            connection = self._connect()
            try:
                cursor = connection.execute(_PRUNE, (cutoff,))
                connection.commit()
                return cursor.rowcount or 0
            finally:
                connection.close()
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return 0

    def _make_recorder(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            await self._record(event_name, payload)
        return handler

    async def _record(self, event_name: str, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
            if not self._store_ready:
                self.dropped_count += 1
                return
        account_id = None
        symbol = None
        occurred = None
        if isinstance(payload, dict):
            account_id = payload.get("account_id")
            symbol = payload.get("symbol")
            occurred = _to_float(payload.get("timestamp"))
        try:
            payload_json = json.dumps(payload, ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            payload_json = None
        self._buffer.append((
            event_name,
            str(account_id) if account_id else None,
            str(symbol) if symbol else None,
            occurred,
            payload_json,
        ))
        self.recorded_count += 1
        if len(self._buffer) >= self._flush_size:
            self.flushed_count += await asyncio.to_thread(self._flush)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.flushed_count += await asyncio.to_thread(self._flush)
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        pruned = 0
        if now is not None:
            pruned = await asyncio.to_thread(self._prune, now)
        body: dict[str, Any] = {
            "recorded": self.recorded_count, "flushed": self.flushed_count,
            "pruned": pruned,
        }
        if now is not None:
            body["timestamp"] = now
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {
            "recorded": self.recorded_count, "flushed": self.flushed_count,
            "buffered": len(self._buffer), "dropped": self.dropped_count,
            "watching": len(self._watch_events), "db_path": self._db_path,
            "last_error": self._last_error,
        }
        if not self._store_ready:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=self._last_error or REASON_STORE_UNAVAILABLE, details=details)
        if self.recorded_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_ACTIVITY, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="recorded=%d flushed=%d" % (self.recorded_count, self.flushed_count),
            details=details)
