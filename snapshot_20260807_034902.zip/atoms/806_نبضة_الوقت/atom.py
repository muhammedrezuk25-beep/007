from __future__ import annotations

import asyncio
import time

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SYNCED = "time.utc.synced"

SOURCE_LOCAL = "LOCAL_CLOCK"
SOURCE_NTP = "NTP_SYNCED"

_SECOND_S = 1.0
_MINUTE_S = 60.0
_HOUR_S = 3600.0
_DAY_S = 86400.0
_DRIFT_WARNING_THRESHOLD_S = 1.0

_CADENCES = {
    "SYS_SECOND": _SECOND_S,
    "SYS_5MIN": 5 * _MINUTE_S,
    "SYS_15MIN": 15 * _MINUTE_S,
    "SYS_HOUR": _HOUR_S,
    "SYS_DAY": _DAY_S,
}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._tasks: list[asyncio.Task] = []
        self.tick_counts: dict[str, int] = {name: 0 for name in _CADENCES}
        self._max_observed_drift_s = 0.0
        self._offset_s = 0.0
        self._time_source = SOURCE_LOCAL
        self._synced_at: float | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_SYNCED, self._on_synced)

    async def start(self) -> None:
        for event_name, interval_s in _CADENCES.items():
            self._tasks.append(asyncio.create_task(self._scheduled_loop(event_name, interval_s)))

    async def stop(self) -> None:
        for task in self._tasks:
            task.cancel()
        for task in self._tasks:
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._tasks = []

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_synced(self, payload: dict) -> None:
        offset = payload.get("offset_s")
        if not isinstance(offset, (int, float)):
            return
        self._offset_s = float(offset)
        self._time_source = SOURCE_NTP
        self._synced_at = payload.get("measured_at")

    def _official_now(self) -> float:
        return time.time() + self._offset_s

    async def health_check(self) -> HealthStatus:
        if not self._tasks or any(t.done() for t in self._tasks):
            return HealthStatus(state=HealthState.UNHEALTHY, message="at least one pulse loop stopped")
        if self._max_observed_drift_s > _DRIFT_WARNING_THRESHOLD_S:
            return HealthStatus(state=HealthState.DEGRADED, message=f"drift={self._max_observed_drift_s:.3f}s")
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=f"{self._time_source} {self.tick_counts}",
            details={"time_source": self._time_source, "offset_s": self._offset_s,
                     "synced_at": self._synced_at, "ticks": dict(self.tick_counts)})

    async def _emit_tick(self, event_name: str) -> None:
        self.tick_counts[event_name] += 1
        if self._context is not None:
            await self._context.publish(event_name, {
                "count": self.tick_counts[event_name],
                "official_time": self._official_now(),
                "time_source": self._time_source,
                "offset_s": self._offset_s})

    async def _scheduled_loop(self, event_name: str, interval_s: float) -> None:
        loop = asyncio.get_running_loop()
        next_deadline = loop.time() + (interval_s - time.time() % interval_s)
        try:
            while True:
                sleep_for = next_deadline - loop.time()
                if sleep_for > 0:
                    await asyncio.sleep(sleep_for)
                else:
                    self._max_observed_drift_s = max(self._max_observed_drift_s, -sleep_for)
                    next_deadline = loop.time()
                try:
                    await self._emit_tick(event_name)
                except Exception as exc:
                    if self._context is not None:
                        self._context.logger.error("time_tick publish %s failed: %s", event_name, exc)
                next_deadline += interval_s
                if next_deadline <= loop.time():
                    next_deadline = loop.time() + interval_s
        except asyncio.CancelledError:
            pass
