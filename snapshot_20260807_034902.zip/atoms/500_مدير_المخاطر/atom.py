from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_LOSS = "risk.loss_reported"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_requested"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "risk.unified.state"

ID_RISK = "risk_manager"
STATUS_OK = "ok"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"
REASON_KILL_ACTIVE = "KILL_SWITCH_ACTIVE"

REASON_NONE = ""


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._daily_loss_pct = 0.0
        self._consecutive_losses = 0
        self._daily_trade_count = 0
        self._kill = False
        self._reason = REASON_NONE
        self._seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_LOSS, self._on_loss)
        context.subscribe(EVENT_HALT, self._on_halt)
        context.subscribe(EVENT_RESET, self._on_reset)
        context.subscribe(EVENT_DAY, self._on_day)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_loss(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._seen += 1
        loss_pct = _to_float(payload.get("loss_pct"))
        if loss_pct is not None:
            self._daily_loss_pct += loss_pct
        if bool(payload.get("is_loss")):
            self._consecutive_losses += 1
        else:
            self._consecutive_losses = 0
        self._daily_trade_count += 1
        await self._publish()

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._seen += 1
        self._kill = True
        self._reason = str(payload.get("reason", REASON_NONE))
        await self._publish()

    async def _on_reset(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._seen += 1
        self._kill = False
        self._reason = REASON_NONE
        self._consecutive_losses = 0
        await self._publish()

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._daily_loss_pct = 0.0
        self._daily_trade_count = 0
        await self._publish()

    async def _publish(self) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "id": ID_RISK, "status": STATUS_OK,
            "daily_loss_pct": round(self._daily_loss_pct, 4),
            "consecutive_losses": self._consecutive_losses,
            "daily_trade_count": self._daily_trade_count,
            "kill_switch_state": self._kill, "kill_switch_reason": self._reason})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"daily_loss_pct": round(self._daily_loss_pct, 4),
                   "consecutive_losses": self._consecutive_losses,
                   "kill_switch": self._kill, "emitted": self._emitted}
        if self._kill:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_KILL_ACTIVE,
                                details=details)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="collecting emitted=%d" % self._emitted,
                            details=details)
