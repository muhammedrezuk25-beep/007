from __future__ import annotations

import asyncio
import json
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000
_SECONDS_PER_DAY = 86400.0

EVENT_IN = "execution.order.built"
EVENT_DAY = "SYS_DAY"
EVENT_OUT = "storage.orders_saved"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_STORE_UNAVAILABLE = "STORE_UNAVAILABLE"
REASON_NOTHING_STORED = "NOTHING_STORED_YET"

_SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    account_id   TEXT,
    symbol       TEXT,
    side         TEXT,
    volume       REAL,
    occurred_at  REAL,
    payload_json TEXT
)
"""

_INDEXES = (
    "CREATE INDEX IF NOT EXISTS idx_orders_account ON orders(account_id, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_orders_symbol ON orders(symbol, id DESC)",
    "CREATE INDEX IF NOT EXISTS idx_orders_time ON orders(occurred_at)",
)

_INSERT = (
    "INSERT INTO orders (account_id, symbol, side, volume, occurred_at, payload_json)"
    " VALUES (?,?,?,?,?,?)"
)

_PRUNE = "DELETE FROM orders WHERE occurred_at IS NOT NULL AND occurred_at < ?"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._db_path = ""
        self._flush_size = 0
        self._retention_days = 0
        self._buffer: list[tuple] = []
        self._store_ready = False
        self._last_error = ""
        self.stored_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = str(cfg["db_path"])
        self._flush_size = int(cfg["flush_size"])
        self._retention_days = int(cfg["retention_days"])
        context.subscribe(EVENT_IN, self._on_order)
        context.subscribe(EVENT_DAY, self._on_day)
        self._store_ready = self._ensure_store()
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False
        if self._buffer:
            await asyncio.to_thread(self._flush)

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self._db_path, timeout=_DB_TIMEOUT_S)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
        connection.execute("PRAGMA synchronous=NORMAL")
        return connection

    def _ensure_store(self) -> bool:
        try:
            Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
            connection = self._connect()
            try:
                connection.execute(_SCHEMA)
                for statement in _INDEXES:
                    connection.execute(statement)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return True
        except (sqlite3.Error, OSError) as exc:
            self._last_error = str(exc)
            return False

    def _flush(self) -> int:
        if not self._buffer:
            return 0
        rows, self._buffer = self._buffer, []
        try:
            connection = self._connect()
            try:
                connection.executemany(_INSERT, rows)
                connection.commit()
            finally:
                connection.close()
            self._last_error = ""
            return len(rows)
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            self.dropped_count += len(rows)
            return 0

    def _prune(self, now: float) -> int:
        if self._retention_days <= 0:
            return 0
        cutoff = now - self._retention_days * _SECONDS_PER_DAY
        try:
            connection = self._connect()
            try:
                cursor = connection.execute(_PRUNE, (cutoff,))
                connection.commit()
                return cursor.rowcount or 0
            finally:
                connection.close()
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            return 0

    async def _on_order(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if not isinstance(payload, dict):
            return
        account_id = payload.get("account_id")
        symbol = payload.get("symbol")
        if not account_id and not symbol:
            return
        if not self._store_ready:
            self._store_ready = self._ensure_store()
            if not self._store_ready:
                self.dropped_count += 1
                return
        occurred = _to_float(payload.get("timestamp"))
        self._buffer.append((
            str(account_id) if account_id else None,
            str(symbol) if symbol else None,
            str(payload.get("side")) if payload.get("side") else None,
            _to_float(payload.get("volume")),
            occurred,
            json.dumps(payload, ensure_ascii=False, default=str),
        ))
        if len(self._buffer) >= self._flush_size:
            await self._flush_and_report(occurred)

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        await self._flush_and_report(now, prune_at=now)

    async def _flush_and_report(
        self, stamp: float | None, prune_at: float | None = None
    ) -> None:
        if self._context is None:
            return
        written = await asyncio.to_thread(self._flush)
        self.stored_count += written
        pruned = 0
        if prune_at is not None:
            pruned = await asyncio.to_thread(self._prune, prune_at)
        if written == 0 and prune_at is None:
            return
        body: dict[str, Any] = {
            "rows": written, "total": self.stored_count, "pruned": pruned,
        }
        if stamp is not None:
            body["timestamp"] = stamp
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {
            "stored": self.stored_count, "dropped": self.dropped_count,
            "buffered": len(self._buffer), "db_path": self._db_path,
            "last_error": self._last_error,
        }
        if not self._store_ready:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=self._last_error or REASON_STORE_UNAVAILABLE, details=details)
        if self.stored_count == 0 and not self._buffer:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NOTHING_STORED, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="stored=%d buffered=%d" % (self.stored_count, len(self._buffer)),
            details=details)
