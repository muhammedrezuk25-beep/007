from __future__ import annotations

import asyncio
import os
import tarfile
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_SECONDS_PER_DAY = 86400.0

EVENT_DAY = "SYS_DAY"
EVENT_DONE = "tools.file_archive.completed"
EVENT_FAILED = "tools.file_archive.failed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NEVER_RAN"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._archive_dir = ""
        self._source_dirs: list[str] = []
        self._older_than_days = 0
        self._interval_days = 0
        self._last_run: float | None = None
        self._last_error = ""
        self.run_count = 0
        self.archived_total = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._archive_dir = str(cfg["archive_dir"])
        self._source_dirs = [str(s) for s in cfg["source_dirs"]]
        self._older_than_days = int(cfg["older_than_days"])
        self._interval_days = int(cfg["interval_days"])
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _collect_old(self, cutoff: float) -> list[tuple[str, str]]:
        archive_abs = os.path.abspath(self._archive_dir)
        found: list[tuple[str, str]] = []
        for src in self._source_dirs:
            if not os.path.isdir(src):
                continue
            root_name = os.path.basename(os.path.normpath(src))
            for root, _dirs, files in os.walk(src):
                if os.path.abspath(root).startswith(archive_abs):
                    continue
                for name in files:
                    path = os.path.join(root, name)
                    try:
                        if os.path.getmtime(path) < cutoff:
                            arc = (root_name + "/" + os.path.relpath(path, src))
                            found.append((path, arc.replace(os.sep, "/")))
                    except OSError:
                        pass
        return found

    def _run_archive(self, now: float) -> tuple[int, int, str | None]:
        cutoff = now - self._older_than_days * _SECONDS_PER_DAY
        old = self._collect_old(cutoff)
        if not old:
            return 0, 0, None
        os.makedirs(self._archive_dir, exist_ok=True)
        archive_path = os.path.join(self._archive_dir, "archive_%d.tar.gz" % int(now))
        with tarfile.open(archive_path, "w:gz") as tar:
            for path, arc in old:
                tar.add(path, arcname=arc)
        freed = 0
        for path, _arc in old:
            try:
                freed += os.path.getsize(path)
                os.remove(path)
            except OSError:
                pass
        return len(old), freed, archive_path

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        if now is None or self._older_than_days <= 0:
            return
        if self._last_run is not None:
            if now - self._last_run < self._interval_days * _SECONDS_PER_DAY:
                return
        try:
            count, freed, path = await asyncio.to_thread(self._run_archive, now)
        except (OSError, tarfile.TarError) as exc:
            self._last_error = str(exc)
            await self._context.publish(EVENT_FAILED, {"reason": str(exc),
                                                       "timestamp": now})
            return
        self._last_run = now
        self._last_error = ""
        self.run_count += 1
        self.archived_total += count
        await self._context.publish(EVENT_DONE, {
            "files_archived": count, "space_freed_bytes": freed,
            "archive_path": path, "total": self.archived_total, "timestamp": now})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"runs": self.run_count, "archived": self.archived_total,
                   "last_run": self._last_run, "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(
                state=HealthState.DEGRADED, message=self._last_error, details=details)
        if self.run_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NEVER_RAN, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="runs=%d archived=%d" % (self.run_count, self.archived_total),
            details=details)
