from __future__ import annotations

import asyncio
import os
import re
import sqlite3
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_OUT = "market_data.candle_closed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_HISTORY = "NO_HISTORY_YET"
REASON_NO_FILE = "BRIDGE_FILE_MISSING"
REASON_BAD_TABLE = "BAD_TABLE_NAME"

_COLUMNS = ("symbol", "period_seconds", "period_start", "open", "high", "low",
            "close", "volume")

_IDENT = re.compile(r"^[A-Za-z0-9_]+$")

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    uri = "file:%s?mode=ro" % db_path
    conn = sqlite3.connect(uri, uri=True, timeout=_CONNECT_TIMEOUT_S)
    conn.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = "candles_history"
        self._last_error = ""
        self._replayed = False
        self._symbols: set[str] = set()
        self.published_count = 0
        self.dropped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._replay_once())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None

    async def shutdown(self) -> None:
        await self.stop()

    def _fetch_all(self) -> list[dict[str, Any]]:
        if not _IDENT.match(self._table):
            raise ValueError(REASON_BAD_TABLE)
        columns = ", ".join(_COLUMNS)
        conn = _connect(self._db_path)
        try:
            conn.row_factory = sqlite3.Row
            query = "SELECT %s FROM %s" % (columns, self._table)
            return [dict(r) for r in conn.execute(query).fetchall()]
        finally:
            conn.close()

    async def _replay_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._fetch_all)
        except ValueError:
            self._last_error = REASON_BAD_TABLE
            return
        except sqlite3.Error as exc:
            message = str(exc).lower()
            self._last_error = (REASON_NO_HISTORY if "no such table" in message
                                else REASON_NO_FILE if "unable to open" in message
                                else str(exc))
            self._context.logger.warning("602 history read failed: %s", exc)
            return
        self._replayed = True
        if not rows:
            self._last_error = REASON_NO_HISTORY
            return
        self._last_error = ""
        for candle in self._prepare(rows):
            if not self._running or self._context is None:
                return
            await self._context.publish(EVENT_OUT, candle)
            self.published_count += 1
            self._symbols.add(candle["symbol"])

    def _prepare(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        candles = []
        for row in rows:
            symbol = row.get("symbol")
            period_start = _to_float(row.get("period_start"))
            open_p = _to_float(row.get("open"))
            high_p = _to_float(row.get("high"))
            low_p = _to_float(row.get("low"))
            close_p = _to_float(row.get("close"))
            period_seconds = _to_float(row.get("period_seconds"))
            if not symbol or period_start is None or open_p is None or high_p is None \
                    or low_p is None or close_p is None or period_seconds is None:
                self.dropped_count += 1
                continue
            volume = _to_float(row.get("volume"))
            candles.append({
                "symbol": str(symbol), "open": open_p, "high": high_p,
                "low": low_p, "close": close_p,
                "volume": volume if volume is not None else 0,
                "timeframe": "%ds" % int(period_seconds),
                "period_start": period_start, "timestamp": period_start,
                "warmup": True})
        candles.sort(key=self._sort_key)
        return candles

    @staticmethod
    def _sort_key(candle: dict[str, Any]) -> tuple:
        return (candle["symbol"], candle["period_start"])

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"published": self.published_count, "dropped": self.dropped_count,
                   "symbols": len(self._symbols), "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error,
                                details=details)
        if self.published_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_HISTORY,
                                details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="warmup published=%d symbols=%d" % (
                self.published_count, len(self._symbols)),
            details=details)
