from __future__ import annotations

import asyncio
import fnmatch
import os
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_SECONDS_PER_DAY = 86400.0

EVENT_DAY = "SYS_DAY"
EVENT_DONE = "tools.file_cleanup.completed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NEVER_RAN"
REASON_NO_PATTERNS = "NO_PATTERNS_CONFIGURED"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._scan_dirs: list[str] = []
        self._older_than_days = 0
        self._patterns: list[str] = []
        self._interval_days = 0
        self._last_run: float | None = None
        self._last_error = ""
        self.run_count = 0
        self.deleted_total = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._scan_dirs = [str(s) for s in cfg["scan_dirs"]]
        self._older_than_days = int(cfg["older_than_days"])
        self._patterns = [str(p) for p in cfg["patterns"]]
        self._interval_days = int(cfg["interval_days"])
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _run_cleanup(self, now: float) -> int:
        if not self._patterns:
            return 0
        cutoff = now - self._older_than_days * _SECONDS_PER_DAY
        deleted = 0
        for scan_dir in self._scan_dirs:
            if not os.path.isdir(scan_dir):
                continue
            for root, _dirs, files in os.walk(scan_dir):
                for name in files:
                    if not any(fnmatch.fnmatch(name, pat) for pat in self._patterns):
                        continue
                    path = os.path.join(root, name)
                    try:
                        if os.path.getmtime(path) < cutoff:
                            os.remove(path)
                            deleted += 1
                    except OSError:
                        pass
        return deleted

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        if now is None:
            return
        if self._last_run is not None:
            if now - self._last_run < self._interval_days * _SECONDS_PER_DAY:
                return
        deleted = await asyncio.to_thread(self._run_cleanup, now)
        self._last_run = now
        self.run_count += 1
        self.deleted_total += deleted
        body: dict[str, Any] = {"deleted_count": deleted, "total": self.deleted_total,
                                "timestamp": now}
        if not self._patterns:
            body["reason"] = REASON_NO_PATTERNS
        await self._context.publish(EVENT_DONE, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"runs": self.run_count, "deleted": self.deleted_total,
                   "patterns": len(self._patterns), "last_run": self._last_run,
                   "last_error": self._last_error}
        if not self._patterns:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_PATTERNS, details=details)
        if self.run_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NEVER_RAN, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="runs=%d deleted=%d" % (self.run_count, self.deleted_total),
            details=details)
