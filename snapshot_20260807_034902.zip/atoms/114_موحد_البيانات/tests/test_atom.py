import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom114", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom114"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_IN = _mod.EVENT_IN
EVENT_OUT = _mod.EVENT_OUT


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for h in self._handlers.get(name, []):
            r = h(payload)
            if inspect.isawaitable(r):
                await r

    def make_context(self):
        return AtomContext(atom_id=114, config={}, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def _make(bus):
    atom = Atom()
    await atom.initialize(bus.make_context())
    await atom.start()
    return atom


def _norm(bus):
    return [p for n, p in bus.published if n == EVENT_OUT]


async def test_normalizes_type_and_data():
    print("\n--- test_normalizes_type_and_data ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish(EVENT_IN, {"source_event": "market_data.price_received",
                      "payload": {"symbol": "NQ", "bid": 1, "ask": 2, "timestamp": 9.0}})
    o = _norm(bus)
    assert len(o) == 1, o
    assert o[0] == {"type": "price_received",
                    "data": {"symbol": "NQ", "bid": 1, "ask": 2, "timestamp": 9.0},
                    "timestamp": 9.0}, o[0]
    print(f"OK — وحّد النوع + البيانات + ورّث الوقت: type={o[0]['type']}")


async def test_no_self_timestamp():
    print("\n--- test_no_self_timestamp ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish(EVENT_IN, {"source_event": "market_data.spread_updated",
                      "payload": {"symbol": "NQ", "spread": 1}})  # no timestamp
    o = _norm(bus)[-1]
    assert "timestamp" not in o, "no self-stamped time (Rule 13)"
    assert o["type"] == "spread_updated"
    print("OK — بلا timestamp ذاتي (قاعدة ١٣)")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.DEGRADED
    await bus.publish(EVENT_IN, {"source_event": "market_data.price_received",
                      "payload": {"symbol": "NQ"}})
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY -> DEGRADED -> HEALTHY")


async def main():
    tests = [test_normalizes_type_and_data, test_no_self_timestamp, test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e))); print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e))); print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}"); sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
