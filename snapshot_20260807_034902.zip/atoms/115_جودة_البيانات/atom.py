from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_IN = "market.tick"
EVENT_OUT = "market_data.quality_alert"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_DATA = "NO_TICKS_YET"

KIND_DUPLICATE = "duplicate"
KIND_GAP = "time_gap"
KIND_SPIKE = "price_spike"
KIND_SPREAD = "abnormal_spread"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._gap_threshold_s = 0.0
        self._spike_pct = 0.0
        self._spread_pct = 0.0
        self._last_price: dict[str, float] = {}
        self._last_ts: dict[str, float] = {}
        self._last_key: dict[str, tuple] = {}
        self._checked = 0
        self._alerts = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._gap_threshold_s = float(cfg["gap_threshold_s"])
        self._spike_pct = float(cfg["spike_pct"])
        self._spread_pct = float(cfg["spread_pct"])
        context.subscribe(EVENT_IN, self._on_tick)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_tick(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        bid = _to_float(payload.get("bid"))
        ask = _to_float(payload.get("ask"))
        if not symbol or bid is None or ask is None:
            return
        symbol = str(symbol)
        ts = _to_float(payload.get("timestamp"))
        price = (bid + ask) / 2.0
        self._checked += 1
        key = (bid, ask, ts)
        if key == self._last_key.get(symbol):
            await self._alert(KIND_DUPLICATE, symbol, {}, ts)
        self._last_key[symbol] = key
        if ts is not None:
            prev_ts = self._last_ts.get(symbol)
            if prev_ts is not None and (ts - prev_ts) > self._gap_threshold_s:
                await self._alert(KIND_GAP, symbol, {"gap_s": round(ts - prev_ts, 2)}, ts)
            self._last_ts[symbol] = ts
        prev_price = self._last_price.get(symbol)
        if prev_price and price:
            change = abs(price - prev_price) / prev_price * 100.0
            if change > self._spike_pct:
                await self._alert(KIND_SPIKE, symbol, {"change_pct": round(change, 3)}, ts)
        if price:
            self._last_price[symbol] = price
        if price and (ask < bid or (ask - bid) / price * 100.0 > self._spread_pct):
            spread_pct = round((ask - bid) / price * 100.0, 4)
            await self._alert(KIND_SPREAD, symbol, {"spread_pct": spread_pct}, ts)

    async def _alert(self, kind: str, symbol: str, details: dict[str, Any],
                     ts: float | None) -> None:
        if self._context is None:
            return
        self._alerts += 1
        body: dict[str, Any] = {"kind": kind, "symbol": symbol}
        body.update(details)
        if ts is not None:
            body["timestamp"] = ts
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._checked == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="checked=%d alerts=%d" % (self._checked, self._alerts),
            details={"checked": self._checked, "alerts": self._alerts})
