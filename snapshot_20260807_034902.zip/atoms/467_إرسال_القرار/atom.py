from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "decision.approved.state"
EVENT_OUT = "execution.order.requested"

METHOD = "decision_to_execution_boundary"
ID_DISPATCH = "decision_dispatch"

DIR_BUY = "buy"
DIR_SELL = "sell"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

_SIDE = {DIR_BUY: "BUY", DIR_SELL: "SELL"}


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._dispatched = 0
        self._skipped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_approved)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_approved(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        if not meta.get("approved"):
            self._skipped += 1
            return
        direction = str(meta.get("direction", ""))
        symbol = payload.get("symbol")
        if not symbol or direction not in _SIDE:
            self._skipped += 1
            return
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "request_id": str(meta.get("request_id", cycle_id)),
            "symbol": str(symbol), "side": _SIDE[direction], "cycle_id": cycle_id,
            "source": ID_DISPATCH})
        self._dispatched += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d dispatched=%d skipped=%d" % (
                self._seen, self._dispatched, self._skipped),
            details={"seen": self._seen, "dispatched": self._dispatched,
                     "skipped": self._skipped,
                     "note": "boundary to 550 — inert until execution is built + owner-approved"})
