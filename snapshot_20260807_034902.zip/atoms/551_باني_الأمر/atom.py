from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_VALIDATED = "risk.validation.completed"
EVENT_SIZE = "risk.position_size.state"
EVENT_ACCOUNT = "platform.account.state"
EVENT_OUT = "execution.order.built"

ID_BUILD = "order_builder"
ACTION_OPEN = "OPEN"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

_PRICE_DP = 6


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._reward_risk = 2.0
        self._sizes: dict[str, dict[str, Any]] = {}
        self._account_id = ""
        self._seen = 0
        self._built = 0
        self._skipped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._reward_risk = float(context.config["reward_risk"])
        context.subscribe(EVENT_VALIDATED, self._on_validated)
        context.subscribe(EVENT_SIZE, self._on_size)
        context.subscribe(EVENT_ACCOUNT, self._on_account)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_account(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        account_id = payload.get("account_id")
        if account_id:
            self._account_id = str(account_id)

    async def _on_size(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        self._sizes[str(symbol)] = {
            "price": _to_float(meta.get("price")),
            "buy_lot": _to_float(meta.get("buy_lot")),
            "buy_stop": _to_float(meta.get("buy_stop")),
            "sell_lot": _to_float(meta.get("sell_lot")),
            "sell_stop": _to_float(meta.get("sell_stop"))}

    async def _on_validated(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._seen += 1
        if not payload.get("approved"):
            self._skipped += 1
            return
        side = str(payload.get("side", ""))
        symbol = payload.get("symbol")
        if not symbol or side not in (SIDE_BUY, SIDE_SELL):
            self._skipped += 1
            return
        symbol = str(symbol)
        size = self._sizes.get(symbol)
        if size is None:
            self._skipped += 1
            return
        price = size.get("price")
        if side == SIDE_BUY:
            volume = size.get("buy_lot")
            stop = size.get("buy_stop")
        else:
            volume = size.get("sell_lot")
            stop = size.get("sell_stop")
        if price is None or volume is None or stop is None or volume <= 0.0:
            self._skipped += 1
            return
        risk_dist = (price - stop) if side == SIDE_BUY else (stop - price)
        if risk_dist <= 0.0:
            self._skipped += 1
            return
        target = (price + self._reward_risk * risk_dist) if side == SIDE_BUY \
            else (price - self._reward_risk * risk_dist)
        await self._context.publish(EVENT_OUT, {
            "request_id": str(payload.get("request_id", "")),
            "account_id": self._account_id, "action": ACTION_OPEN,
            "symbol": symbol, "side": side, "volume": volume,
            "reference_price": round(price, _PRICE_DP),
            "stop_loss": round(stop, _PRICE_DP),
            "take_profit": round(target, _PRICE_DP),
            "reward_risk": self._reward_risk,
            "cycle_id": str(payload.get("cycle_id", ""))})
        self._built += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"seen": self._seen, "built": self._built, "skipped": self._skipped,
                   "sized_symbols": len(self._sizes), "account": self._account_id}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="built=%d skipped=%d" % (self._built, self._skipped),
                            details=details)
