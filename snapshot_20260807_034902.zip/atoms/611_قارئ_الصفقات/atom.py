from __future__ import annotations

import asyncio
import os
import sqlite3
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_OUT = "platform.trade_event"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_READ = "BRIDGE_UNREADABLE"
REASON_NO_DATA = "NO_READ_YET"

_COLUMNS = ("id", "event_type", "ticket", "symbol", "side", "volume",
            "entry_price", "exit_price", "open_time", "close_time", "reason")

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    return conn


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
    return row is not None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = ""
        self._poll_interval_s = 0.0
        self._batch_limit = 0
        self._last_id = 0
        self._last_error = ""
        self.read_count = 0
        self.published_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._batch_limit = int(cfg["batch_limit"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None

    async def shutdown(self) -> None:
        await self.stop()

    def _fetch(self) -> list[dict[str, Any]]:
        columns = ", ".join(_COLUMNS)
        conn = _connect(self._db_path)
        try:
            conn.row_factory = sqlite3.Row
            if not _table_exists(conn, self._table):
                return []
            rows = [dict(r) for r in conn.execute(
                f"SELECT {columns} FROM {self._table} WHERE id > ? ORDER BY id LIMIT ?",
                (self._last_id, self._batch_limit)).fetchall()]
            for row in rows:
                row["account_id"] = None
                row["profit"] = None
            try:
                ident = conn.execute(
                    f"SELECT id, account_id FROM {self._table} WHERE id > ? ORDER BY id LIMIT ?",
                    (self._last_id, self._batch_limit)).fetchall()
                by_id = {r[0]: r[1] for r in ident}
                for row in rows:
                    row["account_id"] = by_id.get(row.get("id"))
            except sqlite3.Error:
                pass
            try:
                prof = conn.execute(
                    f"SELECT id, profit FROM {self._table} WHERE id > ? ORDER BY id LIMIT ?",
                    (self._last_id, self._batch_limit)).fetchall()
                by_id_p = {r[0]: r[1] for r in prof}
                for row in rows:
                    row["profit"] = by_id_p.get(row.get("id"))
            except sqlite3.Error:
                pass
            return rows
        finally:
            conn.close()

    async def _drain_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._fetch)
        except sqlite3.Error as exc:
            self.failure_count += 1
            self._last_error = str(exc)
            self._context.logger.warning("611 read failed: %s", exc)
            return
        self._last_error = ""
        if not rows:
            return
        self.read_count += len(rows)
        for row in rows:
            row_id = row.get("id")
            if isinstance(row_id, int) and row_id > self._last_id:
                self._last_id = row_id
            body = {key: row.get(key) for key in _COLUMNS if key != "id"}
            body["account_id"] = row.get("account_id")
            body["profit"] = row.get("profit")
            body["source_row_id"] = row_id
            stamp = _to_float(row.get("close_time")) or _to_float(row.get("open_time"))
            if stamp is not None:
                body["timestamp"] = stamp
            self.published_count += 1
            await self._context.publish(EVENT_OUT, body)

    async def _loop(self) -> None:
        try:
            while self._running:
                await self._drain_once()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            return

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"read": self.read_count, "published": self.published_count,
                   "failures": self.failure_count, "last_id": self._last_id}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_READ, details=details)
        if self.read_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message=f"published={self.published_count}", details=details)

    async def snapshot(self) -> dict:
        return {"last_id": self._last_id, "read": self.read_count,
                "published": self.published_count, "failures": self.failure_count}

    async def restore(self, state: dict) -> None:
        self._last_id = int(state.get("last_id", 0))
        self.read_count = int(state.get("read", 0))
        self.published_count = int(state.get("published", 0))
        self.failure_count = int(state.get("failures", 0))
