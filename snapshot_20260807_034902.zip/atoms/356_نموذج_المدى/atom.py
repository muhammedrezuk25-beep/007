from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_HURST = "probability.hurst.state"
EVENT_TREND = "structure.trend.state"
EVENT_OUT = "probability.range.state"

METHOD = "range_hurst_structure"
ID_MODEL = "range_model"

SIGNAL_RANGING = "ranging"
SIGNAL_TRENDING = "trending"
SIGNAL_NEUTRAL = "neutral"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

HURST_MR = "mean_reverting"
HURST_TRENDING = "trending"
TREND_RANGE = "range"
TREND_UP = "uptrend"
TREND_DOWN = "downtrend"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._base = 0.5
        self._mr_weight = 0.25
        self._range_weight = 0.2
        self._max = 0.95
        self._trending_prob = 0.25
        self._hurst: dict[tuple, str] = {}
        self._trend: dict[tuple, str] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._base = float(cfg["base_prob"])
        self._mr_weight = float(cfg["mean_reverting_weight"])
        self._range_weight = float(cfg["range_structure_weight"])
        self._max = float(cfg["max_prob"])
        self._trending_prob = float(cfg["trending_prob"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_HURST, self._on_hurst)
        context.subscribe(EVENT_TREND, self._on_trend)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_hurst(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._hurst[self._key(payload)] = str(payload.get("signal", ""))

    async def _on_trend(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        self._trend[self._key(payload)] = str(payload.get("signal", ""))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        hurst = self._hurst.get(key, "")
        trend = self._trend.get(key, "")
        if hurst == HURST_MR or trend == TREND_RANGE:
            prob = self._base
            if hurst == HURST_MR:
                prob += self._mr_weight
            if trend == TREND_RANGE:
                prob += self._range_weight
            prob = min(self._max, prob)
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_RANGING, prob,
                             _FULL, hurst, trend)
            return
        if hurst == HURST_TRENDING and trend in (TREND_UP, TREND_DOWN):
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_TRENDING,
                             self._trending_prob, _FULL, hurst, trend)
            return
        await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, _NEUTRAL_PROB,
                         _LOW, hurst, trend)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    prob: float, confidence: float, hurst: str, trend: str) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "probability": round(prob, _DP),
                                         "hurst": hurst, "trend": trend}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._hurst)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._hurst)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._hurst)})
