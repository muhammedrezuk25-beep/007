from __future__ import annotations

import asyncio
import socket
import struct
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SYNCED = "time.utc.synced"
EVENT_DRIFT = "time.utc.drift"

_NTP_EPOCH_OFFSET = 2_208_988_800
_NTP_PACKET_BYTES = 48
_NTP_PORT = 123
_NTP_REQUEST = b"\x1b" + 47 * b"\0"
_NTP_TX_START = 40
_NTP_TX_END = 48
_NTP_FRACTION_DIVISOR = 2 ** 32
_HALF_ROUND_TRIP = 2.0
_ROUND_DP = 6

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_SYNCED = "NEVER_SYNCED"
REASON_UNREACHABLE = "REFERENCE_UNREACHABLE"
REASON_STALE = "LAST_SYNC_STALE"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._servers: list[str] = []
        self._sync_interval_s = 0.0
        self._query_timeout_s = 0.0
        self._drift_alert_s = 0.0
        self._stale_after_s = 0.0
        self._last_offset_s: float | None = None
        self._last_sync_at: float | None = None
        self._last_server = ""
        self._last_error = ""
        self.sync_count = 0
        self.drift_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._servers = [str(s).strip() for s in cfg["reference_servers"] if str(s).strip()]
        self._sync_interval_s = float(cfg["sync_interval_s"])
        self._query_timeout_s = float(cfg["query_timeout_s"])
        self._drift_alert_s = float(cfg["drift_alert_s"])
        self._stale_after_s = float(cfg["stale_after_s"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._sync_loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""

    async def shutdown(self) -> None:
        await self.stop()

    def _query(self, host: str) -> tuple[float, float]:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(self._query_timeout_s)
        try:
            sent_at = time.time()
            sock.sendto(_NTP_REQUEST, (host, _NTP_PORT))
            data, _ = sock.recvfrom(_NTP_PACKET_BYTES)
            received_at = time.time()
        finally:
            sock.close()
        if len(data) < _NTP_PACKET_BYTES:
            raise ValueError("NTP reply shorter than expected")
        seconds, fraction = struct.unpack("!II", data[_NTP_TX_START:_NTP_TX_END])
        server_time = seconds + fraction / _NTP_FRACTION_DIVISOR - _NTP_EPOCH_OFFSET
        round_trip = received_at - sent_at
        offset = server_time - (received_at - round_trip / _HALF_ROUND_TRIP)
        return offset, round_trip

    async def _sync_once(self) -> bool:
        if self._context is None:
            return False
        for host in self._servers:
            try:
                offset, round_trip = await asyncio.to_thread(self._query, host)
            except Exception as exc:
                self._last_error = f"{host}: {exc}"
                self._context.logger.warning("608 reference %s failed: %s", host, exc)
                continue
            previous = self._last_offset_s
            measured_at = time.time()
            self._last_offset_s = offset
            self._last_sync_at = measured_at
            self._last_server = host
            self._last_error = ""
            self.sync_count += 1
            body: dict[str, Any] = {
                "server": host,
                "offset_s": round(offset, _ROUND_DP),
                "round_trip_s": round(round_trip, _ROUND_DP),
                "measured_at": measured_at,
                "sync_count": self.sync_count,
            }
            await self._context.publish(EVENT_SYNCED, dict(body))
            if abs(offset) >= self._drift_alert_s:
                self.drift_count += 1
                await self._context.publish(EVENT_DRIFT, {
                    **body,
                    "threshold_s": self._drift_alert_s,
                    "previous_offset_s": previous,
                    "drift_count": self.drift_count,
                })
            return True
        self.failure_count += 1
        return False

    async def _sync_loop(self) -> None:
        try:
            while self._running:
                await self._sync_once()
                await asyncio.sleep(self._sync_interval_s)
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {
            "sync_count": self.sync_count,
            "drift_count": self.drift_count,
            "failure_count": self.failure_count,
            "last_offset_s": self._last_offset_s,
            "last_server": self._last_server,
        }
        if self._last_sync_at is None:
            state = HealthState.DEGRADED
            message = REASON_NEVER_SYNCED if not self._last_error else REASON_UNREACHABLE
        elif time.time() - self._last_sync_at > self._stale_after_s:
            state = HealthState.DEGRADED
            message = REASON_STALE
        else:
            state = HealthState.HEALTHY
            message = f"offset={self._last_offset_s or 0.0:.6f}s via {self._last_server}"
        return HealthStatus(state=state, message=message, details=details)
