from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "structure.cycle.validated"
EVENT_OUT = "market.structure.updated"

ID_STRUCTURE = "structure"

UID_TREND = "structure_trend"
UID_PHASE = "phase"
UID_SWING = "swing"
UID_EXTERNAL = "external"
UID_INTERNAL = "internal"
UID_MSS = "mss"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

DEFAULT_TREND = "range"
DEFAULT_PHASE = "neutral"
DEFAULT_NONE = "none"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NOTHING = "NOTHING_PUBLISHED_YET"


def _signal(results: dict[str, Any], uid: str, default: str) -> Any:
    state = results.get(uid)
    return state.get("signal", default) if isinstance(state, dict) else default


def _meta(results: dict[str, Any], uid: str, field: str) -> Any:
    state = results.get(uid)
    if isinstance(state, dict):
        meta = state.get("metadata") or {}
        return meta.get(field)
    return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_validated)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_validated(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        cycle_id = str(payload.get("cycle_id", ""))
        timeframe = str(payload.get("timeframe", ""))
        results = payload.get("results") or {}
        trend_state = results.get(UID_TREND) if isinstance(results.get(UID_TREND), dict) else {}
        valid = [s for s in results.values()
                 if isinstance(s, dict) and s.get("status") == STATUS_OK]
        status = STATUS_OK if valid else STATUS_INSUFFICIENT
        quality = QUALITY_GOOD if valid else QUALITY_LOW
        structure = {
            "trend": _signal(results, UID_TREND, DEFAULT_TREND),
            "phase": _signal(results, UID_PHASE, DEFAULT_PHASE),
            "swing": _signal(results, UID_SWING, DEFAULT_NONE),
            "swing_price": _meta(results, UID_SWING, "price"),
            "external_high": _meta(results, UID_EXTERNAL, "swing_high"),
            "external_low": _meta(results, UID_EXTERNAL, "swing_low"),
            "internal": _signal(results, UID_INTERNAL, DEFAULT_NONE),
            "last_shift": {"type": _meta(results, UID_MSS, "shift_type"),
                           "direction": _meta(results, UID_MSS, "direction")}}
        meta = {"timeframe": timeframe, "present": payload.get("present", 0),
                "expected": payload.get("expected", 0)}
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_STRUCTURE, "cycle_id": cycle_id,
            "status": status, "signal": structure["trend"],
            "score": int(trend_state.get("score", 0)),
            "confidence": float(trend_state.get("confidence", 0.0)),
            "quality": quality, "warnings": [],
            "structure": structure, "metadata": meta})
        self._published += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._published == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NOTHING)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d published=%d" % (self._seen, self._published),
            details={"seen": self._seen, "published": self._published})
