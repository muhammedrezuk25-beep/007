from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_OUT = "strategy.merged.state"

_STRATEGY_EVENTS = (
    "strategy.trend.state",
    "strategy.reversal.state",
    "strategy.breakout.state",
    "strategy.pullback.state",
    "strategy.momentum.state",
    "strategy.range.state",
    "strategy.liquidity.state",
    "strategy.session.state",
    "strategy.news.state",
)

_DIRECTIONAL_IDS = ("trend_strategy", "breakout_strategy", "pullback_strategy",
                    "momentum_strategy", "liquidity_strategy")

METHOD = "directional_vote"
ID_MERGER = "signals_merged"

SIGNAL_BUY = "buy"
SIGNAL_SELL = "sell"
SIGNAL_NEUTRAL = "neutral"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_PERCENT = 100.0
_DIR_TOTAL = len(_DIRECTIONAL_IDS)


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._sigs: dict[str, dict[str, str]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_CANDLE, self._on_candle)
        for event in _STRATEGY_EVENTS:
            context.subscribe(event, self._on_strategy)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_strategy(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        strategy_id = str(payload.get("id", ""))
        if not strategy_id:
            return
        key = str(payload.get("symbol", ""))
        self._sigs.setdefault(key, {})[strategy_id] = str(payload.get("signal", ""))

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = symbol
        self._candles_seen += 1
        sigs = self._sigs.get(key, {})
        buy = sum(1 for sid in _DIRECTIONAL_IDS if sigs.get(sid) == SIGNAL_BUY)
        sell = sum(1 for sid in _DIRECTIONAL_IDS if sigs.get(sid) == SIGNAL_SELL)
        present = sum(1 for sid in _DIRECTIONAL_IDS if sid in sigs)
        if buy > sell:
            net = SIGNAL_BUY
        elif sell > buy:
            net = SIGNAL_SELL
        else:
            net = SIGNAL_NEUTRAL
        winning = buy if net == SIGNAL_BUY else sell if net == SIGNAL_SELL else 0
        score = int(round(winning / _DIR_TOTAL * _PERCENT)) if _DIR_TOTAL > 0 else 0
        confidence = round(present / _DIR_TOTAL, 2) if _DIR_TOTAL > 0 else 0.0
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MERGER, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": net, "score": score, "confidence": confidence,
            "quality": QUALITY_GOOD if net != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "buy_votes": buy, "sell_votes": sell,
                                         "directional_present": present,
                                         "signals": dict(sigs)}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._sigs)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._sigs)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._sigs)})
