from __future__ import annotations

import asyncio
import re
import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_DB_TIMEOUT_S = 5.0
_BUSY_TIMEOUT_MS = 3000

EVENT_IN = "storage.archived"
EVENT_OUT = "storage.trading_data_cleaned"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NEVER_RAN"

_IDENT = re.compile(r"^[A-Za-z0-9_]+$")


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._stores: list[dict[str, Any]] = []
        self._vacuum = False
        self._runs = 0
        self._removed_total = 0
        self._reclaimed_bytes = 0
        self._last_error = ""
        self._last_report: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._stores = [dict(s) for s in cfg["stores"]]
        self._vacuum = bool(cfg["vacuum_after_cleanup"])
        context.subscribe(EVENT_IN, self._on_archived)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _clean_one(self, store: dict[str, Any]) -> tuple[int, int]:
        source = str(store.get("db_path", ""))
        table = str(store.get("table", ""))
        columns = [str(c) for c in store.get("dedup_columns", [])]
        if not source or not _IDENT.match(table) or not columns:
            self._last_error = "bad store spec: %s" % store
            return 0, 0
        if not all(_IDENT.match(c) for c in columns):
            self._last_error = "bad column in: %s" % store
            return 0, 0
        if not Path(source).is_file():
            return 0, 0
        try:
            before = Path(source).stat().st_size
            connection = sqlite3.connect(source, timeout=_DB_TIMEOUT_S)
            connection.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
            try:
                cursor = connection.execute(
                    "DELETE FROM %s WHERE id NOT IN ("
                    " SELECT MIN(id) FROM %s GROUP BY %s)"
                    % (table, table, ", ".join(columns)))
                removed = cursor.rowcount or 0
                connection.commit()
                if removed and self._vacuum:
                    connection.execute("VACUUM")
            finally:
                connection.close()
            after = Path(source).stat().st_size
            return removed, max(0, before - after)
        except (sqlite3.Error, OSError) as exc:
            self._last_error = "%s: %s" % (table, exc)
            return 0, 0

    def _run(self) -> tuple[dict[str, int], int]:
        report: dict[str, int] = {}
        reclaimed = 0
        for store in self._stores:
            removed, freed = self._clean_one(store)
            reclaimed += freed
            if removed:
                report[str(store.get("table", "?"))] = removed
        return report, reclaimed

    async def _on_archived(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        report, reclaimed = await asyncio.to_thread(self._run)
        removed = sum(report.values())
        self._runs += 1
        self._removed_total += removed
        self._reclaimed_bytes += reclaimed
        self._last_report = report
        body: dict[str, Any] = {"removed": removed, "total": self._removed_total,
                                "per_table": dict(report), "reclaimed_bytes": reclaimed}
        now = _to_float(payload.get("timestamp") if isinstance(payload, dict) else None)
        if now is not None:
            body["timestamp"] = now
        await self._context.publish(EVENT_OUT, body)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"runs": self._runs, "removed": self._removed_total,
                   "reclaimed_bytes": self._reclaimed_bytes, "stores": len(self._stores),
                   "last_report": dict(self._last_report), "last_error": self._last_error}
        if self._runs == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NEVER_RAN, details=details)
        if self._last_error:
            return HealthStatus(
                state=HealthState.DEGRADED, message=self._last_error, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="runs=%d removed=%d" % (self._runs, self._removed_total),
            details=details)
