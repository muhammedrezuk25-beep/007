from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "platform.positions.state"
EVENT_OUT = "decision.filter.position.state"

METHOD = "one_position_per_symbol"
ID_FILTER = "position_filter"

SIGNAL_PASS = "pass"
SIGNAL_BLOCK = "block"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._max_per_symbol = 1
        self._blocked: set[str] = set()
        self._seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_per_symbol = int(context.config["max_per_symbol"])
        context.subscribe(EVENT_IN, self._on_positions)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_positions(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        by_symbol = payload.get("by_symbol")
        if not isinstance(by_symbol, dict):
            return
        self._seen += 1
        held = {str(s) for s, c in by_symbol.items()
                if isinstance(c, (int, float)) and c >= self._max_per_symbol}
        freed = self._blocked - held
        for symbol in sorted(held):
            await self._emit(symbol, False)
        for symbol in sorted(freed):
            await self._emit(symbol, True)
        self._blocked = held

    async def _emit(self, symbol: str, passed: bool) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_FILTER, "cycle_id": "",
            "status": STATUS_OK, "signal": SIGNAL_PASS if passed else SIGNAL_BLOCK,
            "score": 0, "confidence": 1.0 if passed else 0.0,
            "quality": QUALITY_GOOD if passed else QUALITY_LOW, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": "", "passed": passed,
                         "max_per_symbol": self._max_per_symbol}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d blocked=%d emitted=%d" % (
                self._seen, len(self._blocked), self._emitted),
            details={"seen": self._seen, "blocked": sorted(self._blocked),
                     "emitted": self._emitted})
