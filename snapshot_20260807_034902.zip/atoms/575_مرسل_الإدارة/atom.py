from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_COMMAND = "execution.manage.command"
EVENT_WRITTEN = "execution.manage.written"

ACTION_MODIFY = "MODIFY_SL"
ACTION_PARTIAL = "CLOSE_PARTIAL"
ACTION_CLOSE = "CLOSE"

_ACTIONS = (ACTION_MODIFY, ACTION_PARTIAL, ACTION_CLOSE)

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0

_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS commands ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, request_id TEXT NOT NULL,"
    "action TEXT NOT NULL, symbol TEXT NOT NULL, side TEXT, volume REAL,"
    "price REAL, stop_loss REAL, take_profit REAL, ticket INTEGER,"
    "trail_dist REAL, trail_step REAL, params_json TEXT,"
    "status TEXT NOT NULL DEFAULT 'PENDING', result TEXT,"
    "created_at REAL NOT NULL, taken_at REAL, done_at REAL)")
_INDEX = "CREATE INDEX IF NOT EXISTS idx_cmd_status ON commands(status, id)"
_INSERT_SQL = (
    "INSERT INTO commands (request_id, action, symbol, side, volume,"
    " ticket, stop_loss, take_profit, status, created_at)"
    " VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)")

REASON_NOT_STARTED = "NOT_STARTED"
REASON_DISABLED = "DISABLED"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _to_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._enabled = False
        self._db_path = "nq_brain.db"
        self._counter = 0
        self._seen = 0
        self._written = 0
        self._skipped = 0
        self._failed = 0
        self._last_error = ""

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._enabled = bool(context.config["enabled"])
        self._db_path = _resolve_db(str(context.config["db_path"]))
        context.subscribe(EVENT_COMMAND, self._on_command)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _insert(self, row: tuple) -> None:
        conn = _connect(self._db_path)
        try:
            conn.execute(_SCHEMA)
            conn.execute(_INDEX)
            conn.execute(_INSERT_SQL, row)
            conn.commit()
        finally:
            conn.close()

    async def _on_command(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        action = str(payload.get("action", ""))
        ticket = _to_int(payload.get("ticket"))
        if action not in _ACTIONS or ticket is None:
            return
        self._seen += 1
        if not self._enabled:
            self._skipped += 1
            return
        symbol = str(payload.get("symbol", ""))
        side = str(payload.get("side", ""))
        volume = _to_float(payload.get("volume"))
        stop_loss = _to_float(payload.get("stop_loss"))
        self._counter += 1
        request_id = "mgmt-%s-%d-%d" % (action, ticket, self._counter)
        row = (request_id, action, symbol, side, volume, ticket, stop_loss,
               None, time.time())
        try:
            await asyncio.to_thread(self._insert, row)
            self._written += 1
            self._last_error = ""
            await self._context.publish(EVENT_WRITTEN, {
                "request_id": request_id, "action": action, "ticket": ticket,
                "symbol": symbol})
        except sqlite3.Error as exc:
            self._failed += 1
            self._last_error = str(exc)
            self._context.logger.error("575 manage write failed: %s", exc)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"enabled": self._enabled, "seen": self._seen, "written": self._written,
                   "skipped": self._skipped, "failed": self._failed,
                   "last_error": self._last_error}
        if not self._enabled:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_DISABLED,
                                details=details)
        if self._failed > 0 and self._written == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="written=%d skipped=%d" % (self._written, self._skipped),
                            details=details)
