import asyncio
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom150", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom150"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_OUT = _mod.EVENT_OUT


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []

    def subscribe(self, name, handler):
        pass

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def make_context(self, config):
        return AtomContext(atom_id=150, config=config, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


def _candle(symbol="NQ100", tf="60s", ps=100.0):
    return {"symbol": symbol, "timeframe": tf, "period_start": ps, "timestamp": ps}


def _state(unit_id, cycle_id, symbol="NQ100", signal="up"):
    return {"id": unit_id, "cycle_id": cycle_id, "symbol": symbol,
            "status": "ok", "signal": signal, "score": 70, "confidence": 0.8}


async def _make(cfg=None):
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context(cfg or {"timeout_seconds": 5.0}))
    await atom.start()
    return atom, bus


def _collected(bus):
    return [p for n, p in bus.published if n == EVENT_OUT]


async def test_forward_when_all_present():
    print("\n--- test_forward_when_all_present ---")
    atom, bus = await _make()
    cid = "NQ100|60s|100.0"
    await atom._on_candle(_candle())
    await atom._on_unit_state(_state("trend", cid))
    assert not _collected(bus), "لسا وحدة وحدة — ما يرسل"
    await atom._on_unit_state(_state("momentum", cid))
    out = _collected(bus)
    assert out, "لمّا يكملوا الاثنين لازم يرسل"
    body = out[-1]
    assert body["complete"] is True and body["present"] == 2
    assert set(body["results"].keys()) == {"trend", "momentum"}
    print("OK — اكتمال الوحدتين → إرسال cycle.collected")


async def test_timeout_forwards_partial():
    print("\n--- test_timeout_forwards_partial ---")
    atom, bus = await _make({"timeout_seconds": 5.0})
    await atom._on_time({"official_time": 1000.0})  # نبضة تضبط الساعة
    cid = "NQ100|60s|100.0"
    await atom._on_candle(_candle())          # open_time = 1000
    await atom._on_unit_state(_state("trend", cid))   # وحدة وحدة بس
    assert not _collected(bus)
    await atom._on_time({"official_time": 1006.0})     # مرّ 6s > 5s → مهلة
    out = _collected(bus)
    assert out, "المهلة لازم ترسل الناقص"
    assert out[-1]["present"] == 1 and out[-1]["complete"] is False
    print("OK — المهلة (نبضة) → إرسال جزئي")


async def test_next_candle_flushes_previous():
    print("\n--- test_next_candle_flushes_previous ---")
    atom, bus = await _make()
    await atom._on_candle(_candle(ps=100.0))
    await atom._on_unit_state(_state("trend", "NQ100|60s|100.0"))
    await atom._on_candle(_candle(ps=160.0))  # شمعة جديدة نفس الرمز → تفرّغ القديمة
    out = _collected(bus)
    assert out and out[-1]["cycle_id"] == "NQ100|60s|100.0"
    print("OK — الشمعة الجديدة تفرّغ الدورة السابقة")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({"timeout_seconds": 5.0}))
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.DEGRADED
    await atom._on_candle(_candle())
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY→DEGRADED→HEALTHY")


async def main():
    tests = [test_forward_when_all_present, test_timeout_forwards_partial,
             test_next_candle_flushes_previous, test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
