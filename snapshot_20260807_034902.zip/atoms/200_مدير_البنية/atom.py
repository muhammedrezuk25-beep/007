from __future__ import annotations

from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_TIME = "SYS_SECOND"
EVENT_OUT = "structure.cycle.collected"

_UNIT_EVENTS = (
    "structure.swing.state",
    "structure.external.state",
    "structure.internal.state",
    "structure.bos.state",
    "structure.choch.state",
    "structure.mss.state",
    "structure.trend.state",
    "structure.phase.state",
)

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CYCLES = "NO_CYCLES_YET"

_RECENT_CAP = 128


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._expected = len(_UNIT_EVENTS)
        self._timeout_s = 5.0
        self._now = 0.0
        self._cycles: dict[str, dict[str, Any]] = {}
        self._key_open: dict[tuple, str] = {}
        self._opened = 0
        self._forwarded = 0
        self._recent: deque = deque(maxlen=_RECENT_CAP)

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._timeout_s = float(context.config["timeout_seconds"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_TIME, self._on_time)
        for event in _UNIT_EVENTS:
            context.subscribe(event, self._on_unit_state)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        prev = self._key_open.get(key)
        if prev is not None and prev != cycle_id and prev in self._cycles:
            await self._forward(prev)
        if cycle_id in self._recent:
            return
        cycle = self._cycles.get(cycle_id)
        if cycle is None:
            self._cycles[cycle_id] = {"symbol": symbol, "timeframe": timeframe,
                                      "open_time": self._now, "results": {}}
            self._opened += 1
        else:
            cycle["symbol"] = symbol
            cycle["timeframe"] = timeframe
        self._key_open[key] = cycle_id

    async def _on_unit_state(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        cycle_id = payload.get("cycle_id")
        unit_id = payload.get("id")
        if not cycle_id or not unit_id:
            return
        cycle_id = str(cycle_id)
        cycle = self._cycles.get(cycle_id)
        if cycle is None:
            if cycle_id in self._recent:
                return
            cycle = {"symbol": str(payload.get("symbol", "")), "timeframe": "",
                     "open_time": self._now, "results": {}}
            self._cycles[cycle_id] = cycle
            self._opened += 1
        cycle["results"][str(unit_id)] = payload
        if len(cycle["results"]) >= self._expected:
            await self._forward(cycle_id)

    async def _on_time(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        now = _to_float(payload.get("official_time"))
        if now is None:
            return
        self._now = now
        expired = [cid for cid, c in self._cycles.items()
                   if c["open_time"] > 0.0 and (now - c["open_time"]) > self._timeout_s]
        for cid in expired:
            await self._forward(cid)

    async def _forward(self, cycle_id: str) -> None:
        cycle = self._cycles.pop(cycle_id, None)
        if cycle is None or self._context is None:
            return
        self._recent.append(cycle_id)
        key = (cycle["symbol"], cycle["timeframe"])
        if self._key_open.get(key) == cycle_id:
            del self._key_open[key]
        present = len(cycle["results"])
        await self._context.publish(EVENT_OUT, {
            "cycle_id": cycle_id, "symbol": cycle["symbol"], "timeframe": cycle["timeframe"],
            "results": cycle["results"], "expected": self._expected, "present": present,
            "complete": present >= self._expected})
        self._forwarded += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._opened == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CYCLES,
                                details={"open": len(self._cycles)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="opened=%d forwarded=%d open=%d" % (
                self._opened, self._forwarded, len(self._cycles)),
            details={"opened": self._opened, "forwarded": self._forwarded,
                     "open": len(self._cycles), "expected": self._expected})
