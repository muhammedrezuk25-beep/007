from __future__ import annotations

from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_OUT = "market_data.trade_tape_updated"

SIDE_BUY = "BUY"
SIDE_SELL = "SELL"
SIDE_UNKNOWN = "UNKNOWN"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_SOURCE = "UNAVAILABLE_NO_TRADE_SOURCE"

BAD_SHAPE = "shape"
BAD_PRICE = "bad_price"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _side(value: Any) -> str:
    if not isinstance(value, str):
        return SIDE_UNKNOWN
    upper = value.strip().upper()
    if upper in (SIDE_BUY, "B", "BID"):
        return SIDE_BUY
    if upper in (SIDE_SELL, "S", "ASK"):
        return SIDE_SELL
    return SIDE_UNKNOWN


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._source_event = ""
        self._window_size = 0
        self._publish_every = 0
        self._tape: dict[str, deque] = {}
        self._since_publish: dict[str, int] = {}
        self._received = 0
        self._published = 0
        self._rejected: dict[str, int] = {}

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._source_event = str(cfg["source_event"])
        self._window_size = int(cfg["window_size"])
        self._publish_every = int(cfg["publish_every_n_trades"])
        context.subscribe(self._source_event, self._on_trade)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _reject(self, reason: str) -> None:
        self._rejected[reason] = self._rejected.get(reason, 0) + 1

    async def _on_trade(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        self._received += 1
        symbol = str(payload.get("symbol") or "")
        price = _to_float(payload.get("price"))
        size = _to_float(payload.get("size", payload.get("volume")))
        if not symbol or price is None or size is None:
            self._reject(BAD_SHAPE)
            return
        if price <= 0 or size < 0:
            self._reject(BAD_PRICE)
            return
        tape = self._tape.setdefault(symbol, deque(maxlen=self._window_size))
        tape.append({"price": price, "size": size, "side": _side(payload.get("side")),
                     "timestamp": payload.get("timestamp")})
        self._since_publish[symbol] = self._since_publish.get(symbol, 0) + 1
        if self._since_publish[symbol] >= self._publish_every:
            self._since_publish[symbol] = 0
            self._published += 1
            await self._context.publish(EVENT_OUT, self._build_state(symbol))

    def _build_state(self, symbol: str) -> dict[str, Any]:
        trades = list(self._tape.get(symbol) or deque())
        buy_volume = sum(t["size"] for t in trades if t["side"] == SIDE_BUY)
        sell_volume = sum(t["size"] for t in trades if t["side"] == SIDE_SELL)
        unknown_volume = sum(t["size"] for t in trades if t["side"] == SIDE_UNKNOWN)
        known = buy_volume + sell_volume
        return {
            "symbol": symbol,
            "trades_in_window": len(trades),
            "last_price": trades[-1]["price"] if trades else None,
            "last_size": trades[-1]["size"] if trades else None,
            "total_volume": buy_volume + sell_volume + unknown_volume,
            "buy_volume": buy_volume, "sell_volume": sell_volume,
            "unknown_volume": unknown_volume,
            "buy_ratio": round(buy_volume / known, 6) if known else None,
            "recent": trades[-10:],
        }

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"received": self._received, "published": self._published,
                   "rejected": {k: v for k, v in self._rejected.items() if v},
                   "symbols": len(self._tape)}
        if self._received == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_SOURCE, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="symbols=%d published=%d" % (len(self._tape), self._published),
            details=details)
