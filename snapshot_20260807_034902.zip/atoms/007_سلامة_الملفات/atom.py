from __future__ import annotations

import hashlib
import os

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_VIOLATION = "tools.integrity.violation"

_CHUNK_BYTES = 65536
_MAX_SUMMARY_ITEMS = 6
_MISSING = "\x00missing"
_ERROR_PREFIX = "\x00error:"
_DEFAULT_IGNORED_DIRS = ("__pycache__", ".git", ".pytest_cache", ".mypy_cache")
_DEFAULT_IGNORED_SUFFIXES = (".pyc", ".pyo", ".pyd", ".tmp", ".log")


def _sha256_of_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(_CHUNK_BYTES), b""):
            h.update(chunk)
    return h.hexdigest()


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._watched_files: list[str] = []
        self._watched_dirs: list[str] = []
        self._ignored_dirs: set[str] = set(_DEFAULT_IGNORED_DIRS)
        self._ignored_suffixes: tuple[str, ...] = _DEFAULT_IGNORED_SUFFIXES
        self._baseline: dict[str, str] = {}
        self._established: bool = False

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._watched_files = list(context.config.get("watched_files", []))
        self._watched_dirs = list(context.config.get("watched_dirs", []))
        extra_dirs = context.config.get("ignored_dir_names")
        if extra_dirs:
            self._ignored_dirs = set(_DEFAULT_IGNORED_DIRS) | set(extra_dirs)
        extra_suffixes = context.config.get("ignored_suffixes")
        if extra_suffixes:
            self._ignored_suffixes = _DEFAULT_IGNORED_SUFFIXES + tuple(extra_suffixes)

    async def start(self) -> None:
        pass

    async def stop(self) -> None:
        pass

    async def shutdown(self) -> None:
        pass

    def _checksum(self, path: str) -> str:
        try:
            return _sha256_of_file(path)
        except FileNotFoundError:
            return _MISSING
        except OSError as exc:
            return _ERROR_PREFIX + str(exc)

    def _walk_source(self, dir_path: str) -> list[tuple[str, str]]:
        collected: list[tuple[str, str]] = []
        for root, dirs, files in os.walk(dir_path):
            dirs[:] = [d for d in dirs if d not in self._ignored_dirs]
            for name in files:
                if name.endswith(self._ignored_suffixes):
                    continue
                full = os.path.join(root, name)
                rel = os.path.relpath(full, dir_path)
                collected.append((rel, self._checksum(full)))
        return collected

    def _collect(self) -> dict[str, str]:
        current: dict[str, str] = {}
        for path in self._watched_files:
            current["file:" + path] = self._checksum(path)
        for dir_path in self._watched_dirs:
            for rel, checksum in self._walk_source(dir_path):
                current["dir:" + dir_path + "::" + rel] = checksum
        return current

    def _diff(self, current: dict[str, str]) -> list[dict]:
        violations: list[dict] = []
        for key, value in current.items():
            base = self._baseline.get(key)
            if base is None:
                violations.append({"key": key, "diff_type": "added"})
            elif value != base:
                if value == _MISSING:
                    violations.append({"key": key, "diff_type": "missing"})
                elif value.startswith(_ERROR_PREFIX):
                    violations.append({"key": key, "diff_type": "read_error",
                                       "detail": value[len(_ERROR_PREFIX):]})
                else:
                    violations.append({"key": key, "diff_type": "modified"})
        for key in self._baseline:
            if key not in current:
                violations.append({"key": key, "diff_type": "removed"})
        return violations

    @staticmethod
    def _summarize(violations: list[dict]) -> str:
        shown = violations[:_MAX_SUMMARY_ITEMS]
        text = "; ".join(f"{v['diff_type']}: {v['key']}" for v in shown)
        if len(violations) > _MAX_SUMMARY_ITEMS:
            text += f"; +{len(violations) - _MAX_SUMMARY_ITEMS} more"
        return text

    async def health_check(self) -> HealthStatus:
        if not self._watched_files and not self._watched_dirs:
            return HealthStatus(state=HealthState.UNKNOWN, message="no watched files or dirs configured")
        current = self._collect()
        if not self._established:
            self._baseline = current
            self._established = True
            return HealthStatus(state=HealthState.HEALTHY,
                                message=f"{len(current)} source items baselined now")
        violations = self._diff(current)
        if violations:
            if self._context is not None:
                await self._context.publish(EVENT_VIOLATION, {"violations": violations})
            return HealthStatus(state=HealthState.UNHEALTHY, message=self._summarize(violations))
        return HealthStatus(state=HealthState.HEALTHY, message=f"{len(current)} source items match baseline")

    async def snapshot(self) -> dict:
        return {"baseline": dict(self._baseline)}

    async def restore(self, state: dict) -> None:
        self._baseline = dict(state.get("baseline", {}))
        self._established = bool(self._baseline)
