import asyncio
import inspect
import os
import sys
import tempfile

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom007", _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom007"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_VIOLATION = _mod.EVENT_VIOLATION


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))

    def make_context(self, config):
        return AtomContext(atom_id=7, config=config, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


def _write(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def _last_violation(bus):
    return [p for n, p in bus.published if n == EVENT_VIOLATION][-1]


async def test_baseline_then_detect_modification():
    print("\n--- test_baseline_then_detect_modification ---")
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "watched.txt")
        _write(target, "original")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [target], "watched_dirs": []}))
        h1 = await atom.health_check()
        assert h1.state == HealthState.HEALTHY, "أول فحص يؤسّس الأساس"
        _write(target, "TAMPERED CONTENT longer")
        h2 = await atom.health_check()
        assert h2.state == HealthState.UNHEALTHY, "لازم يكشف التعديل"
        assert [p for n, p in bus.published if n == EVENT_VIOLATION], "لازم ينشر violation"
        print(f"OK — كشف التعديل: {h2.message[:50]}")


async def test_detect_missing_file():
    print("\n--- test_detect_missing_file ---")
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "watched.txt")
        _write(target, "x")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [target], "watched_dirs": []}))
        await atom.health_check()  # baseline
        os.remove(target)
        h = await atom.health_check()
        assert h.state == HealthState.UNHEALTHY
        viol = _last_violation(bus)
        assert any(v["diff_type"] == "missing" for v in viol["violations"])
        print("OK — كشف اختفاء الملف (missing)")


async def test_dir_content_modification_detected():
    """الجديد: تعديل محتوى ملف مصدر داخل مجلد مراقَب (نفس المسار) لازم يُكشف — الخلل القديم."""
    print("\n--- test_dir_content_modification_detected ---")
    with tempfile.TemporaryDirectory() as tmp:
        d = os.path.join(tmp, "sealed")
        os.makedirs(d)
        _write(os.path.join(d, "mod.py"), "x = 1")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [], "watched_dirs": [d]}))
        h1 = await atom.health_check()
        assert h1.state == HealthState.HEALTHY
        _write(os.path.join(d, "mod.py"), "x = 999  # tampered in place")
        h2 = await atom.health_check()
        assert h2.state == HealthState.UNHEALTHY, "تعديل محتوى داخل مجلد لازم يُكشف"
        viol = _last_violation(bus)
        assert any(v["diff_type"] == "modified" for v in viol["violations"])
        print("OK — كشف تعديل محتوى داخل مجلد (اللي القديم كان يفوته)")


async def test_pycache_and_pyc_ignored():
    """الجديد: __pycache__/*.pyc ضجيج بايتكود — لا إنذار كاذب."""
    print("\n--- test_pycache_and_pyc_ignored ---")
    with tempfile.TemporaryDirectory() as tmp:
        d = os.path.join(tmp, "sealed")
        cache = os.path.join(d, "__pycache__")
        os.makedirs(cache)
        _write(os.path.join(d, "real.py"), "ok = True")
        _write(os.path.join(cache, "real.cpython-312.pyc"), "BYTECODE-A")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [], "watched_dirs": [d]}))
        h1 = await atom.health_check()  # baseline excludes pyc
        assert h1.state == HealthState.HEALTHY
        # churn the bytecode + add a brand-new pyc: must stay HEALTHY
        _write(os.path.join(cache, "real.cpython-312.pyc"), "BYTECODE-CHANGED-AND-LONGER")
        _write(os.path.join(cache, "other.cpython-312.pyc"), "NEW-BYTECODE")
        h2 = await atom.health_check()
        assert h2.state == HealthState.HEALTHY, "بايتكود __pycache__ لازم يُتجاهل"
        # but touching the real source must trip
        _write(os.path.join(d, "real.py"), "ok = False  # tampered")
        h3 = await atom.health_check()
        assert h3.state == HealthState.UNHEALTHY, "تعديل مصدر حقيقي لازم يُكشف رغم تجاهل البايتكود"
        print("OK — تجاهل __pycache__/*.pyc، وكشف المصدر الحقيقي")


async def test_dir_added_and_removed_source():
    print("\n--- test_dir_added_and_removed_source ---")
    with tempfile.TemporaryDirectory() as tmp:
        d = os.path.join(tmp, "sealed")
        os.makedirs(d)
        _write(os.path.join(d, "a.py"), "a")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [], "watched_dirs": [d]}))
        await atom.health_check()  # baseline
        _write(os.path.join(d, "b.py"), "b")  # added
        h = await atom.health_check()
        assert h.state == HealthState.UNHEALTHY
        assert any(v["diff_type"] == "added" for v in _last_violation(bus)["violations"])
        os.remove(os.path.join(d, "b.py"))
        os.remove(os.path.join(d, "a.py"))
        h2 = await atom.health_check()
        assert h2.state == HealthState.UNHEALTHY
        assert any(v["diff_type"] == "removed" for v in _last_violation(bus)["violations"])
        print("OK — كشف إضافة/حذف ملف مصدر داخل مجلد")


async def test_snapshot_restore_preserves_security_baseline():
    """قاعدة الطزاجة الاستثناء — snapshot أساس أمني: يكشف تلاعبًا صار وقت التوقف."""
    print("\n--- test_snapshot_restore_preserves_security_baseline ---")
    with tempfile.TemporaryDirectory() as tmp:
        target = os.path.join(tmp, "watched.txt")
        _write(target, "before downtime")
        bus = FakeEventBus()
        atom = Atom()
        await atom.initialize(bus.make_context({"watched_files": [target], "watched_dirs": []}))
        await atom.health_check()  # baseline established
        snap = await atom.snapshot()
        _write(target, "changed while stopped")  # tampering while stopped
        atom2 = Atom()
        await atom2.initialize(bus.make_context({"watched_files": [target], "watched_dirs": []}))
        await atom2.restore(snap)
        h = await atom2.health_check()
        assert h.state == HealthState.UNHEALTHY, "الأساس المستعاد لازم يكشف تلاعب وقت التوقف"
        print("OK — snapshot أمني: كشف تلاعبًا صار والنظام مطفّي")


async def test_no_config_reports_unknown():
    print("\n--- test_no_config_reports_unknown ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({"watched_files": [], "watched_dirs": []}))
    h = await atom.health_check()
    assert h.state == HealthState.UNKNOWN
    print("OK — بلا عناصر مراقَبة: UNKNOWN")


async def main():
    tests = [
        test_baseline_then_detect_modification,
        test_detect_missing_file,
        test_dir_content_modification_detected,
        test_pycache_and_pyc_ignored,
        test_dir_added_and_removed_source,
        test_snapshot_restore_preserves_security_baseline,
        test_no_config_reports_unknown,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
