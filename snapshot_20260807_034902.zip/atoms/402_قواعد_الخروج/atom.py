from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "strategy.merged.state"
EVENT_OUT = "strategy.exit.state"

METHOD = "majority_flip"
ID_EXIT = "exit_rules"

SIGNAL_EXIT = "exit"
SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"

NET_BUY = "buy"
NET_SELL = "sell"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._last: dict[tuple, str] = {}
        self._seen = 0
        self._exits = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_merged)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_merged(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        key = (symbol, timeframe)
        self._seen += 1
        net = str(payload.get("signal", ""))
        signal = SIGNAL_NONE
        prev = self._last.get(key)
        from_dir = prev if prev is not None else ""
        if net in (NET_BUY, NET_SELL):
            if prev is not None and prev != net:
                signal = SIGNAL_EXIT
                self._exits += 1
            self._last[key] = net
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_EXIT, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal,
            "score": 0, "confidence": 1.0 if signal == SIGNAL_EXIT else 0.0,
            "quality": QUALITY_GOOD if signal == SIGNAL_EXIT else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "from": from_dir, "to": net}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d exits=%d emitted=%d" % (
                self._seen, self._exits, self._emitted),
            details={"seen": self._seen, "exits": self._exits,
                     "emitted": self._emitted, "tracked": len(self._last)})
