from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.1.0"

EVENT_IN = "strategy.merged.state"
EVENT_OUT = "strategy.entry.state"

METHOD = "min_agreement"
ID_ENTRY = "entry_rules"

SIGNAL_BUY = "buy"
SIGNAL_SELL = "sell"
SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._min_agreement = 2
        self._seen = 0
        self._entries = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._min_agreement = int(context.config["min_agreement"])
        context.subscribe(EVENT_IN, self._on_merged)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_merged(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        meta = payload.get("metadata")
        buy = _to_int(meta.get("buy_votes")) if isinstance(meta, dict) else 0
        sell = _to_int(meta.get("sell_votes")) if isinstance(meta, dict) else 0
        if buy >= self._min_agreement and buy > sell:
            signal = SIGNAL_BUY
        elif sell >= self._min_agreement and sell > buy:
            signal = SIGNAL_SELL
        else:
            signal = SIGNAL_NONE
        if signal != SIGNAL_NONE:
            self._entries += 1
        timeframe = str(payload.get("timeframe", ""))
        cycle_id = str(payload.get("cycle_id", ""))
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_ENTRY, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal,
            "score": buy if signal == SIGNAL_BUY else sell if signal == SIGNAL_SELL else 0,
            "confidence": 1.0 if signal != SIGNAL_NONE else 0.0,
            "quality": QUALITY_GOOD if signal != SIGNAL_NONE else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "buy_votes": buy, "sell_votes": sell,
                                         "min_agreement": self._min_agreement}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d entries=%d emitted=%d" % (
                self._seen, self._entries, self._emitted),
            details={"seen": self._seen, "entries": self._entries,
                     "emitted": self._emitted})
