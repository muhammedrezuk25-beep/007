from __future__ import annotations

import asyncio
import os
import tarfile
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

_SECONDS_PER_DAY = 86400.0

EVENT_DAY = "SYS_DAY"
EVENT_DONE = "tools.backup.completed"
EVENT_FAILED = "tools.backup.failed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NEVER_RAN = "NO_BACKUP_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._backup_dir = ""
        self._source_dirs: list[str] = []
        self._keep_last_n = 1
        self._interval_days = 1
        self._last_run: float | None = None
        self._last_error = ""
        self.backup_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._backup_dir = str(cfg["backup_dir"])
        self._source_dirs = [str(s) for s in cfg["source_dirs"]]
        self._keep_last_n = int(cfg["keep_last_n"])
        self._interval_days = int(cfg["interval_days"])
        context.subscribe(EVENT_DAY, self._on_day)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _run_backup(self, now: float) -> tuple[str, int, int]:
        os.makedirs(self._backup_dir, exist_ok=True)
        backup_abs = os.path.abspath(self._backup_dir)
        archive_path = os.path.join(self._backup_dir, "backup_%d.tar.gz" % int(now))
        file_count = 0
        with tarfile.open(archive_path, "w:gz") as tar:
            for src in self._source_dirs:
                if not os.path.isdir(src):
                    continue
                arcname_root = os.path.basename(os.path.normpath(src))
                for root, _dirs, files in os.walk(src):
                    if os.path.abspath(root).startswith(backup_abs):
                        continue
                    for name in files:
                        full = os.path.join(root, name)
                        if os.path.abspath(full).startswith(backup_abs):
                            continue
                        rel = os.path.relpath(full, src)
                        arcname = (arcname_root + "/" + rel).replace(os.sep, "/")
                        tar.add(full, arcname=arcname)
                        file_count += 1
        size = os.path.getsize(archive_path)
        self._enforce_retention()
        return archive_path, size, file_count

    def _enforce_retention(self) -> None:
        try:
            backups = sorted(
                (f for f in os.listdir(self._backup_dir)
                 if f.startswith("backup_") and f.endswith(".tar.gz")), reverse=True)
        except OSError:
            return
        for old in backups[self._keep_last_n:]:
            try:
                os.remove(os.path.join(self._backup_dir, old))
            except OSError:
                pass

    async def _on_day(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        now = _to_float(payload.get("official_time", payload.get("timestamp")))
        if now is None:
            return
        if self._last_run is not None:
            if now - self._last_run < self._interval_days * _SECONDS_PER_DAY:
                return
        try:
            path, size, count = await asyncio.to_thread(self._run_backup, now)
        except (OSError, tarfile.TarError) as exc:
            self._last_error = str(exc)
            await self._context.publish(EVENT_FAILED, {"reason": str(exc),
                                                       "timestamp": now})
            return
        self._last_run = now
        self._last_error = ""
        self.backup_count += 1
        await self._context.publish(EVENT_DONE, {
            "path": path, "size_bytes": size, "file_count": count, "timestamp": now})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"backups": self.backup_count, "last_run": self._last_run,
                   "backup_dir": self._backup_dir, "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(
                state=HealthState.DEGRADED, message=self._last_error, details=details)
        if self.backup_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NEVER_RAN, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="backups=%d" % self.backup_count, details=details)
