from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_PULSE = "SYS_SECOND"
EVENT_HALT = "emergency.halt"
EVENT_RESET = "risk.kill_switch.reset_requested"
EVENT_STATE = "system.commands.state"

ACTION_HALT = "halt"
ACTION_RESET = "kill_switch_reset"
ACTIONS = {ACTION_HALT: EVENT_HALT, ACTION_RESET: EVENT_RESET}

STATUS_PENDING = "PENDING"
STATUS_DONE = "DONE"
STATUS_EXPIRED = "EXPIRED"
STATUS_REJECTED = "REJECTED"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_COMMANDS = "NO_COMMANDS_YET"
REASON_UNREADABLE = "BRIDGE_UNREADABLE"

ID_GATEWAY = "command_gateway"
REASON_OWNER = "OWNER_COMMAND"

_BUSY_TIMEOUT_MS = 3000

_SCHEMA = (
    "CREATE TABLE IF NOT EXISTS commands ("
    "id INTEGER PRIMARY KEY AUTOINCREMENT, "
    "action TEXT NOT NULL, "
    "operator TEXT NOT NULL, "
    "requested_at REAL NOT NULL, "
    "status TEXT NOT NULL DEFAULT 'PENDING', "
    "executed_at REAL)")


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._db_path = Path()
        self._max_age_s = 0.0
        self._batch_limit = 0
        self._conn: sqlite3.Connection | None = None
        self._last_error = ""
        self._seen = 0
        self._executed = {ACTION_HALT: 0, ACTION_RESET: 0}
        self._expired = 0
        self._rejected = 0
        self._state_dirty = True

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        raw = Path(str(cfg["db_path"]))
        self._db_path = raw if raw.is_absolute() else Path.cwd() / raw
        self._max_age_s = float(cfg["max_age_s"])
        self._batch_limit = int(cfg["batch_limit"])
        context.subscribe(EVENT_PULSE, self._on_pulse)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False
        if self._conn is not None:
            try:
                self._conn.close()
            except sqlite3.Error:
                pass
            self._conn = None

    async def shutdown(self) -> None:
        await self.stop()

    def _connect(self) -> sqlite3.Connection:
        if self._conn is not None:
            return self._conn
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(self._db_path))
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=%d" % _BUSY_TIMEOUT_MS)
        conn.execute(_SCHEMA)
        conn.commit()
        conn.row_factory = sqlite3.Row
        self._conn = conn
        return conn

    async def _on_pulse(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        now = _to_float(payload.get("official_time"))
        if now is None:
            return
        try:
            conn = self._connect()
            rows = conn.execute(
                "SELECT id, action, operator, requested_at FROM commands "
                "WHERE status = ? ORDER BY id LIMIT ?",
                (STATUS_PENDING, self._batch_limit)).fetchall()
            for row in rows:
                await self._handle(conn, row, now)
            if rows:
                conn.commit()
                self._state_dirty = True
        except sqlite3.Error as exc:
            self._last_error = str(exc)
            self._conn = None
            return
        self._last_error = ""
        if self._state_dirty:
            self._state_dirty = False
            await self._publish_state()

    async def _handle(self, conn: sqlite3.Connection, row: sqlite3.Row,
                      now: float) -> None:
        if self._context is None:
            return
        self._seen += 1
        action = str(row["action"])
        event = ACTIONS.get(action)
        requested = _to_float(row["requested_at"]) or 0.0
        if event is None:
            status = STATUS_REJECTED
            self._rejected += 1
        elif now - requested > self._max_age_s:
            status = STATUS_EXPIRED
            self._expired += 1
        else:
            await self._context.publish(event, {
                "operator": str(row["operator"]),
                "reason": REASON_OWNER,
                "command_id": int(row["id"])})
            status = STATUS_DONE
            self._executed[action] += 1
        conn.execute(
            "UPDATE commands SET status = ?, executed_at = ? WHERE id = ?",
            (status, now, int(row["id"])))

    async def _publish_state(self) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_STATE, {
            "id": ID_GATEWAY,
            "seen": self._seen,
            "executed_halt": self._executed[ACTION_HALT],
            "executed_reset": self._executed[ACTION_RESET],
            "expired": self._expired,
            "rejected": self._rejected,
            "last_error": self._last_error})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=REASON_NOT_STARTED)
        details = {
            "seen": self._seen,
            "executed_halt": self._executed[ACTION_HALT],
            "executed_reset": self._executed[ACTION_RESET],
            "expired": self._expired,
            "rejected": self._rejected,
            "db": str(self._db_path)}
        if self._last_error:
            details["last_error"] = self._last_error
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_UNREADABLE, details=details)
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=REASON_NO_COMMANDS, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="halt=%d reset=%d expired=%d rejected=%d" % (
                self._executed[ACTION_HALT], self._executed[ACTION_RESET],
                self._expired, self._rejected),
            details=details)
