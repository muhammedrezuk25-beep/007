from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_OUT = "market_data.cleaned"

REASON_NOT_STARTED = "NOT_STARTED"

_WATCHED_EVENTS = [
    "market_data.price_received", "market_data.spread_updated",
    "market_data.candle_closed", "market_data.volume_received",
    "market_data.depth_updated", "market_data.trade_tape_updated",
    "market_data.news_received", "market_data.calendar_event",
    "market_data.reference_index_updated",
]


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._last_seen: dict[tuple, dict] = {}
        self.processed_count = 0
        self.duplicates_dropped = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        for event_name in _WATCHED_EVENTS:
            context.subscribe(event_name, self._make_cleaner(event_name))

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _make_cleaner(self, event_name: str):
        async def handler(payload: dict[str, Any]) -> None:
            if not self._running or self._context is None:
                return
            if not isinstance(payload, dict):
                return
            self.processed_count += 1
            key = (event_name, str(payload.get("symbol", "")))
            if self._last_seen.get(key) == payload:
                self.duplicates_dropped += 1
                return
            self._last_seen[key] = dict(payload)
            await self._context.publish(EVENT_OUT, {
                "source_event": event_name, "payload": payload})

        return handler

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="processed=%d dropped=%d" % (
                self.processed_count, self.duplicates_dropped),
            details={"processed": self.processed_count,
                     "duplicates_dropped": self.duplicates_dropped})
