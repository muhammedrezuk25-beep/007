import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom113", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom113"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_OUT = _mod.EVENT_OUT


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for h in self._handlers.get(name, []):
            r = h(payload)
            if inspect.isawaitable(r):
                await r

    def make_context(self):
        return AtomContext(atom_id=113, config={}, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def _make(bus):
    atom = Atom()
    await atom.initialize(bus.make_context())
    await atom.start()
    return atom


def _cleaned(bus):
    return [p for n, p in bus.published if n == EVENT_OUT]


async def test_passes_and_wraps():
    print("\n--- test_passes_and_wraps ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 1, "ask": 2})
    c = _cleaned(bus)
    assert len(c) == 1 and c[0]["source_event"] == "market_data.price_received"
    assert c[0]["payload"] == {"symbol": "NQ", "bid": 1, "ask": 2}
    print(f"OK — مرّر ولفّ: {c[0]['source_event']}")


async def test_drops_exact_duplicate():
    print("\n--- test_drops_exact_duplicate ---")
    bus = FakeEventBus()
    atom = await _make(bus)
    ev = {"symbol": "NQ", "bid": 1, "ask": 2}
    await bus.publish("market_data.price_received", dict(ev))
    await bus.publish("market_data.price_received", dict(ev))  # exact dup
    assert len(_cleaned(bus)) == 1 and atom.duplicates_dropped == 1
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 1, "ask": 3})
    assert len(_cleaned(bus)) == 2, "changed value passes"
    print("OK — تكرار حرفي اتشال، والمختلف مرّ")


async def test_per_symbol_dedup():
    print("\n--- test_per_symbol_dedup ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("market_data.price_received", {"symbol": "NQ", "bid": 1, "ask": 2})
    await bus.publish("market_data.price_received", {"symbol": "ES", "bid": 1, "ask": 2})
    assert len(_cleaned(bus)) == 2, "same values, different symbol -> both pass"
    print("OK — إزالة التكرار لكل رمز على حدة")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY -> HEALTHY")


async def main():
    tests = [test_passes_and_wraps, test_drops_exact_duplicate, test_per_symbol_dedup,
             test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e))); print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e))); print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}"); sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
