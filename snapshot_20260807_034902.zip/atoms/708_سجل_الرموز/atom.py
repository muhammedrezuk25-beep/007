from __future__ import annotations

import re
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_RESOLVE_REQUESTED = "storage.symbol.resolve_requested"
EVENT_RESOLVED = "storage.symbol.resolved"
EVENT_UNMAPPED = "storage.symbol.unmapped"
EVENT_MAP = "storage.symbol.map.state"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_MAP = "NO_MAPPING_CONFIGURED"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._initialized = False
        self._running = False
        self._exact: dict[str, str] = {}
        self._patterns: list[tuple[re.Pattern, str]] = []
        self._min_stem_length = 0
        self._strip_suffixes: list[str] = []
        self._passthrough_unknown = True
        self._unmapped: dict[str, int] = {}
        self._cache: dict[str, str] = {}
        self.resolved_count = 0
        self.unmapped_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._strip_suffixes = [str(s) for s in cfg["strip_suffixes"]]
        self._min_stem_length = int(cfg["min_stem_length"])
        self._passthrough_unknown = bool(cfg["passthrough_unknown"])
        for canonical, aliases in dict(cfg["canonical_map"]).items():
            for alias in aliases:
                self._exact[str(alias).strip().upper()] = str(canonical)
            self._exact[str(canonical).strip().upper()] = str(canonical)
        for canonical, pattern in dict(cfg["canonical_patterns"]).items():
            try:
                self._patterns.append(
                    (re.compile(pattern, re.IGNORECASE), str(canonical)))
            except re.error:
                pass
        context.subscribe(EVENT_RESOLVE_REQUESTED, self._on_resolve_requested)
        self._initialized = True

    async def start(self) -> None:
        if not self._initialized or self._running or self._context is None:
            return
        self._running = True
        await self._context.publish(EVENT_MAP, {
            "aliases": dict(self._exact),
            "strip_suffixes": list(self._strip_suffixes),
            "passthrough_unknown": self._passthrough_unknown,
        })

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _strip(self, symbol: str) -> str:
        cleaned = symbol.strip().upper()
        for suffix in self._strip_suffixes:
            marker = suffix.upper()
            if not marker or not cleaned.endswith(marker):
                continue
            stem = cleaned[: -len(marker)]
            if len(stem) < self._min_stem_length:
                continue
            if len(marker) == 1 and marker.isalnum():
                if symbol.strip()[-1:].isupper():
                    continue
            cleaned = stem
            break
        return cleaned

    def resolve(self, symbol: Any) -> str | None:
        if not isinstance(symbol, str) or not symbol.strip():
            return None
        cached = self._cache.get(symbol)
        if cached is not None:
            return cached
        cleaned = self._strip(symbol)
        canonical = self._exact.get(cleaned)
        if canonical is None:
            for pattern, target in self._patterns:
                if pattern.fullmatch(cleaned):
                    canonical = target
                    break
        if canonical is None:
            self._unmapped[symbol] = self._unmapped.get(symbol, 0) + 1
            self.unmapped_count += 1
            if not self._passthrough_unknown:
                return None
            canonical = cleaned
        self._cache[symbol] = canonical
        self.resolved_count += 1
        return canonical

    def is_mapped(self, symbol: Any) -> bool:
        if not isinstance(symbol, str) or not symbol.strip():
            return False
        cleaned = self._strip(symbol)
        if cleaned in self._exact:
            return True
        return any(pattern.fullmatch(cleaned) for pattern, _ in self._patterns)

    async def _on_resolve_requested(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        if not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        canonical = self.resolve(symbol)
        mapped = self.is_mapped(symbol)
        body: dict[str, Any] = {
            "request_id": payload.get("request_id"),
            "account_id": payload.get("account_id"),
            "symbol": symbol,
            "canonical": canonical,
            "mapped": mapped,
        }
        stamp = payload.get("timestamp")
        if isinstance(stamp, (int, float)):
            body["timestamp"] = stamp
        await self._context.publish(EVENT_RESOLVED, body)
        if not mapped:
            await self._context.publish(EVENT_UNMAPPED, dict(body))

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {
            "aliases": len(self._exact), "patterns": len(self._patterns),
            "resolved": self.resolved_count, "unmapped": self.unmapped_count,
            "unmapped_symbols": dict(self._unmapped),
        }
        if not self._exact and not self._patterns:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_MAP, details=details)
        if self._unmapped:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message="unmapped: %s" % ",".join(sorted(self._unmapped)),
                details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="resolved=%d" % self.resolved_count, details=details)
