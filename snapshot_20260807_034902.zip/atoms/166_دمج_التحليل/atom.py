from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "analysis.cycle.collected"
EVENT_OUT = "analysis.raw.completed"

SIGNAL_UP = "up"
SIGNAL_DOWN = "down"
SIGNAL_SIDEWAYS = "sideways"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

WARN_NO_VALID = "no_valid_analysis"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CYCLES = "NO_CYCLES_YET"

_VOTE = {SIGNAL_UP: 1, SIGNAL_DOWN: -1, SIGNAL_SIDEWAYS: 0}
_DIRECTIONS = (SIGNAL_UP, SIGNAL_DOWN, SIGNAL_SIDEWAYS)


def _num(value: Any) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return 0.0
    return result if result == result else 0.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._agree_threshold = 0.2
        self._fused = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._agree_threshold = float(context.config["agree_threshold"])
        context.subscribe(EVENT_IN, self._on_collected)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_collected(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        results = payload.get("results") or {}
        base = {"symbol": str(payload.get("symbol", "")),
                "cycle_id": str(payload.get("cycle_id", "")), "id": "fusion"}
        meta = {"expected": payload.get("expected", 0),
                "present": payload.get("present", 0),
                "complete": payload.get("complete", False)}
        valid = [s for s in results.values()
                 if isinstance(s, dict) and s.get("status") == STATUS_OK]
        if not valid:
            meta["valid"] = 0
            await self._context.publish(EVENT_OUT, {
                **base, "status": STATUS_INSUFFICIENT, "signal": SIGNAL_SIDEWAYS,
                "score": 0, "confidence": 0.0, "quality": QUALITY_LOW,
                "warnings": [WARN_NO_VALID], "contributors": {}, "agreement": 0.0,
                "metadata": meta})
            self._fused += 1
            return
        signal, agreement, confidence, score, warnings = self._fuse(valid)
        contributors = {str(s.get("id")): {
            "signal": s.get("signal"), "score": s.get("score"),
            "confidence": s.get("confidence")} for s in valid}
        meta["valid"] = len(valid)
        await self._context.publish(EVENT_OUT, {
            **base, "status": STATUS_OK, "signal": signal, "score": score,
            "confidence": confidence, "quality": QUALITY_GOOD, "warnings": warnings,
            "contributors": contributors, "agreement": agreement, "metadata": meta})
        self._fused += 1

    def _fuse(self, valid: list[dict]) -> tuple:
        directional = [s for s in valid if s.get("signal") in _DIRECTIONS]
        if not directional:
            return SIGNAL_SIDEWAYS, 0.0, 0.0, 0, []
        conf_sum = sum(_num(s.get("confidence")) for s in directional)
        weighted = sum(_VOTE.get(s.get("signal"), 0) * _num(s.get("confidence"))
                       for s in directional)
        net = weighted / conf_sum if conf_sum > 0 else 0.0
        if net > self._agree_threshold:
            signal = SIGNAL_UP
        elif net < -self._agree_threshold:
            signal = SIGNAL_DOWN
        else:
            signal = SIGNAL_SIDEWAYS
        target = _VOTE[signal]
        agreeing = [s for s in directional if _VOTE.get(s.get("signal"), 0) == target]
        chosen = agreeing if agreeing else directional
        score = int(round(sum(_num(s.get("score")) for s in chosen) / len(chosen)))
        agreement = round(len(agreeing) / len(directional), 2)
        confidence = round(
            agreement * (sum(_num(s.get("confidence")) for s in chosen) / len(chosen)), 2)
        warnings = ["conflict:" + str(s.get("id")) for s in directional
                    if signal != SIGNAL_SIDEWAYS and _VOTE.get(s.get("signal"), 0) == -target]
        return signal, agreement, confidence, score, warnings

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._fused == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CYCLES)
        return HealthStatus(state=HealthState.HEALTHY, message="fused=%d" % self._fused,
                            details={"fused": self._fused})
