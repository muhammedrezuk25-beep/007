from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

PROVIDER = "MT5"
EVENT_TICK = "feed.mt5.tick"
EVENT_SPECS = "market.symbol_specs"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TABLE = "TICKS_TABLE_MISSING"
REASON_NO_FILE = "BRIDGE_FILE_MISSING"
REASON_NO_DATA = "NO_TICKS_YET"

_COLUMNS = ("id", "symbol", "bid", "ask", "last", "volume", "tick_ms")
_SPEC_COLUMNS = ("symbol", "contract_size", "tick_value", "tick_size")

_MS_PER_SECOND = 1000.0
_MID_DIVISOR = 2.0
_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str, read_only: bool = True) -> sqlite3.Connection:
    uri = f"file:{db_path}?mode=ro" if read_only else db_path
    conn = sqlite3.connect(uri, uri=read_only, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    if not read_only:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._task: asyncio.Task | None = None
        self._db_path = ""
        self._table = "ticks"
        self._spec_table = "symbol_specs"
        self._spec_refresh_s = 0.0
        self._poll_interval_s = 0.0
        self._batch_limit = 0
        self._delete_consumed = True
        self._last_id = 0
        self._last_error = ""
        self._symbols: set[str] = set()
        self._announced: set[str] = set()
        self.published_count = 0
        self.spec_publishes = 0
        self.dropped_count = 0
        self.failure_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._db_path = _resolve_db(str(cfg["db_path"]))
        self._table = str(cfg["table_name"])
        self._spec_table = str(cfg["spec_table"])
        self._spec_refresh_s = float(cfg["spec_refresh_s"])
        self._poll_interval_s = float(cfg["poll_interval_s"])
        self._batch_limit = int(cfg["batch_limit"])
        self._delete_consumed = bool(cfg["delete_consumed"])

    async def start(self) -> None:
        if self._running or self._context is None:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())

    async def stop(self) -> None:
        self._running = False
        if self._task is not None and not self._task.done():
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
        self._task = None
        self.failure_count = 0
        self._last_error = ""

    async def shutdown(self) -> None:
        await self.stop()

    def _fetch(self) -> list[dict[str, Any]]:
        columns = ", ".join(_COLUMNS)
        conn = _connect(self._db_path, read_only=True)
        try:
            conn.row_factory = sqlite3.Row
            return [dict(r) for r in conn.execute(
                f"SELECT {columns} FROM {self._table} WHERE id > ? ORDER BY id LIMIT ?",
                (self._last_id, self._batch_limit)).fetchall()]
        finally:
            conn.close()

    def _purge(self, up_to_id: int) -> None:
        conn = _connect(self._db_path, read_only=False)
        try:
            conn.execute(f"DELETE FROM {self._table} WHERE id <= ?", (up_to_id,))
            conn.commit()
        finally:
            conn.close()

    def _read_specs(self) -> list[dict[str, Any]]:
        columns = ", ".join(_SPEC_COLUMNS)
        conn = _connect(self._db_path, read_only=True)
        try:
            conn.row_factory = sqlite3.Row
            return [dict(r) for r in conn.execute(f"SELECT {columns} FROM {self._spec_table}").fetchall()]
        finally:
            conn.close()

    async def _refresh_specs(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._read_specs)
        except sqlite3.Error as exc:
            self._context.logger.warning("618 spec read failed: %s", exc)
            return
        usable = []
        for row in rows:
            size = _to_float(row.get("contract_size"))
            if size is None or size <= 0:
                continue
            usable.append({"symbol": row.get("symbol"), "contract_size": size,
                           "tick_value": _to_float(row.get("tick_value")),
                           "tick_size": _to_float(row.get("tick_size"))})
        if not usable:
            return
        self._announced = {r["symbol"] for r in usable}
        self.spec_publishes += 1
        await self._context.publish(EVENT_SPECS, {"provider": PROVIDER, "symbols": usable})

    async def _announce_if_new(self, symbols: set[str]) -> None:
        if symbols - self._announced:
            await self._refresh_specs()

    async def _drain_once(self) -> None:
        if self._context is None:
            return
        try:
            rows = await asyncio.to_thread(self._fetch)
        except sqlite3.Error as exc:
            self.failure_count += 1
            message = str(exc).lower()
            self._last_error = (REASON_NO_TABLE if "no such table" in message
                                else REASON_NO_FILE if "unable to open" in message else str(exc))
            self._context.logger.warning("618 read failed: %s", exc)
            return
        self._last_error = ""
        if not rows:
            return
        seen = {str(r["symbol"]) for r in rows if r.get("symbol")}
        await self._announce_if_new(seen)
        highest = self._last_id
        for row in rows:
            row_id = int(row["id"])
            highest = max(highest, row_id)
            symbol = row.get("symbol")
            bid = _to_float(row.get("bid"))
            ask = _to_float(row.get("ask"))
            tick_ms = _to_float(row.get("tick_ms"))
            if not symbol or bid is None or ask is None or tick_ms is None:
                self.dropped_count += 1
                continue
            self._symbols.add(str(symbol))
            await self._context.publish(EVENT_TICK, {
                "provider": PROVIDER,
                "symbol": symbol,
                "bid": bid,
                "ask": ask,
                "price": (bid + ask) / _MID_DIVISOR,
                "volume": _to_float(row.get("volume")),
                "last_trade": _to_float(row.get("last")),
                "exchange_timestamp": tick_ms / _MS_PER_SECOND,
                "received_at": time.time(),
                "source_row_id": row_id,
            })
            self.published_count += 1
        self._last_id = highest
        if self._delete_consumed and highest > 0:
            try:
                await asyncio.to_thread(self._purge, highest)
            except sqlite3.Error as exc:
                self._context.logger.warning("618 purge failed: %s", exc)

    async def _loop(self) -> None:
        try:
            await self._refresh_specs()
            loop = asyncio.get_running_loop()
            last_specs = loop.time()
            while self._running:
                await self._drain_once()
                if loop.time() - last_specs >= self._spec_refresh_s:
                    await self._refresh_specs()
                    last_specs = loop.time()
                await asyncio.sleep(self._poll_interval_s)
        except asyncio.CancelledError:
            pass

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"published": self.published_count, "dropped": self.dropped_count,
                   "failures": self.failure_count, "last_id": self._last_id,
                   "symbols": len(self._symbols), "last_error": self._last_error}
        if self._last_error:
            return HealthStatus(state=HealthState.DEGRADED, message=self._last_error, details=details)
        if self.published_count == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_DATA, details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message=f"published={self.published_count} symbols={len(self._symbols)}",
                            details=details)

    async def snapshot(self) -> dict:
        return {"last_id": self._last_id, "published": self.published_count, "dropped": self.dropped_count}

    async def restore(self, state: dict) -> None:
        self._last_id = int(state.get("last_id", 0))
        self.published_count = int(state.get("published", 0))
        self.dropped_count = int(state.get("dropped", 0))
