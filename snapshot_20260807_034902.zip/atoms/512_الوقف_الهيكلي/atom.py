from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "structure.swing.state"
EVENT_OUT = "risk.structure_stop.state"

METHOD = "swing_structure_stop"
ID_STOP = "structure_stop"

SIGNAL_STOP = "structure_stop"
SIGNAL_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"

SWING_HIGH = "swing_high"
SWING_LOW = "swing_low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_SWINGS = "NO_SWINGS_YET"

_PERCENT = 100.0
_PRICE_DP = 6


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._buffer_pct = 0.05
        self._last: dict[str, dict[str, Any]] = {}
        self._seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._buffer_pct = float(context.config["stop_buffer_pct"])
        context.subscribe(EVENT_IN, self._on_swing)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_swing(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        signal = str(payload.get("signal", ""))
        if signal not in (SWING_HIGH, SWING_LOW):
            return
        symbol = payload.get("symbol")
        meta = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}
        price = _to_float(meta.get("price"))
        if not symbol or price is None or price <= 0.0:
            return
        symbol = str(symbol)
        self._seen += 1
        st = self._last.get(symbol)
        if st is None:
            st = {"low": None, "high": None, "timeframe": ""}
            self._last[symbol] = st
        st["timeframe"] = str(meta.get("timeframe", ""))
        if signal == SWING_LOW:
            st["low"] = price
        else:
            st["high"] = price
        await self._emit(symbol, st, payload)

    async def _emit(self, symbol: str, st: dict[str, Any], payload: dict[str, Any]) -> None:
        if self._context is None:
            return
        low = st["low"]
        high = st["high"]
        buy_stop = None
        sell_stop = None
        if low is not None:
            buy_stop = round(low - low * self._buffer_pct / _PERCENT, _PRICE_DP)
        if high is not None:
            sell_stop = round(high + high * self._buffer_pct / _PERCENT, _PRICE_DP)
        signal = SIGNAL_STOP if (low is not None or high is not None) else SIGNAL_NONE
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_STOP, "cycle_id": str(payload.get("cycle_id", "")),
            "status": STATUS_OK, "signal": signal, "score": 0, "confidence": 1.0,
            "quality": QUALITY_GOOD, "warnings": [],
            "metadata": {"method": METHOD, "timeframe": st["timeframe"],
                         "buy_stop": buy_stop, "sell_stop": sell_stop,
                         "swing_low": low, "swing_high": high,
                         "buffer_pct": self._buffer_pct}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"tracked": len(self._last), "seen": self._seen, "emitted": self._emitted}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_SWINGS,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="seen=%d emitted=%d tracked=%d" % (
                                self._seen, self._emitted, len(self._last)),
                            details=details)
