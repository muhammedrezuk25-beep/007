from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_BUILT = "execution.order.built"
EVENT_FINAL = "trading.final_decision"
EVENT_PREVIEW = "execution.order.preview"
EVENT_REJECTED = "execution.order.rejected"
EVENT_MANAGE_CMD = "execution.manage.command"
EVENT_MANAGE_WRITTEN = "execution.manage.written"
EVENT_OUTCOME = "market.outcome.realized"
EVENT_HALT = "emergency.halt"

EVENT_OUT = "execution.unified.state"

ID_MANAGER = "execution_manager"
STATUS_OK = "ok"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_INPUT = "NO_INPUT_YET"


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._counts: dict[str, int] = {
            "built": 0, "sent": 0, "preview": 0, "rejected": 0,
            "manage_commands": 0, "manage_written": 0, "outcomes": 0, "halts": 0}
        self._last_order: dict[str, Any] | None = None
        self._last_outcome: dict[str, Any] | None = None
        self._halted = False
        self._seen = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_BUILT, self._on_built)
        context.subscribe(EVENT_FINAL, self._on_final)
        context.subscribe(EVENT_PREVIEW, self._on_preview)
        context.subscribe(EVENT_REJECTED, self._on_rejected)
        context.subscribe(EVENT_MANAGE_CMD, self._on_manage_cmd)
        context.subscribe(EVENT_MANAGE_WRITTEN, self._on_manage_written)
        context.subscribe(EVENT_OUTCOME, self._on_outcome)
        context.subscribe(EVENT_HALT, self._on_halt)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _order_summary(self, payload: dict[str, Any], stage: str) -> dict[str, Any]:
        return {"stage": stage, "symbol": str(payload.get("symbol", "")),
                "side": str(payload.get("side", "")),
                "volume": _to_float(payload.get("volume")),
                "stop_loss": _to_float(payload.get("stop_loss")),
                "take_profit": _to_float(payload.get("take_profit"))}

    async def _emit(self) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "id": ID_MANAGER, "status": STATUS_OK, "counts": dict(self._counts),
            "halted": self._halted, "last_order": self._last_order,
            "last_outcome": self._last_outcome})

    async def _bump(self, key: str) -> None:
        if not self._running or self._context is None:
            return
        self._seen += 1
        self._counts[key] += 1
        await self._emit()

    async def _on_built(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        self._last_order = self._order_summary(payload, "built")
        await self._bump("built")

    async def _on_final(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        self._last_order = self._order_summary(payload, "sent")
        await self._bump("sent")

    async def _on_preview(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        self._last_order = self._order_summary(payload, "preview")
        await self._bump("preview")

    async def _on_rejected(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        await self._bump("rejected")

    async def _on_manage_cmd(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        await self._bump("manage_commands")

    async def _on_manage_written(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        await self._bump("manage_written")

    async def _on_outcome(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        self._last_outcome = {"symbol": str(payload.get("symbol", "")),
                              "profit": _to_float(payload.get("profit"))}
        await self._bump("outcomes")

    async def _on_halt(self, payload: dict[str, Any]) -> None:
        if not isinstance(payload, dict):
            return
        self._halted = True
        await self._bump("halts")

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"counts": dict(self._counts), "halted": self._halted}
        if self._seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_INPUT,
                                details=details)
        return HealthStatus(state=HealthState.HEALTHY,
                            message="built=%d sent=%d preview=%d outcomes=%d" % (
                                self._counts["built"], self._counts["sent"],
                                self._counts["preview"], self._counts["outcomes"]),
                            details=details)
