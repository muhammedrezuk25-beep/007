from __future__ import annotations

import asyncio
import time
from typing import Awaitable, Callable

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_SYNCED = "time.utc.synced"
EVENT_SYS_TICK = "kernel.clock.sys_tick"
EVENT_HEARTBEAT = "kernel.clock.heartbeat"
EVENT_MINUTE = "kernel.clock.minute_elapsed"

SOURCE_LOCAL = "LOCAL_CLOCK"
SOURCE_NTP = "NTP_SYNCED"

_MINUTE_S = 60.0
_DRIFT_WARNING_THRESHOLD_S = 1.0
_DEFAULT_SYS_TICK_S = 0.1
_DEFAULT_HEARTBEAT_S = 1.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._sys_tick_task: asyncio.Task | None = None
        self._heartbeat_task: asyncio.Task | None = None
        self._minute_task: asyncio.Task | None = None
        self._sys_tick_interval_s = _DEFAULT_SYS_TICK_S
        self._heartbeat_interval_s = _DEFAULT_HEARTBEAT_S
        self._offset_s = 0.0
        self._time_source = SOURCE_LOCAL
        self.sys_tick_count = 0
        self.heartbeat_count = 0
        self.minute_count = 0
        self._max_observed_drift_s = 0.0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_SYNCED, self._on_synced)
        self._sys_tick_interval_s = float(context.config.get("sys_tick_interval_s", _DEFAULT_SYS_TICK_S))
        self._heartbeat_interval_s = float(context.config.get("heartbeat_interval_s", _DEFAULT_HEARTBEAT_S))

    async def start(self) -> None:
        self._sys_tick_task = asyncio.create_task(
            self._scheduled_loop(self._sys_tick_interval_s, self._on_sys_tick))
        self._heartbeat_task = asyncio.create_task(
            self._scheduled_loop(self._heartbeat_interval_s, self._on_heartbeat))
        self._minute_task = asyncio.create_task(
            self._scheduled_loop(_MINUTE_S, self._on_minute_elapsed, align_to_wall_clock=True))

    async def stop(self) -> None:
        tasks = (self._sys_tick_task, self._heartbeat_task, self._minute_task)
        for task in tasks:
            if task is not None:
                task.cancel()
        for task in tasks:
            if task is not None:
                try:
                    await task
                except asyncio.CancelledError:
                    pass
        self._sys_tick_task = self._heartbeat_task = self._minute_task = None

    async def shutdown(self) -> None:
        await self.stop()

    async def health_check(self) -> HealthStatus:
        if self._sys_tick_task is None or self._sys_tick_task.done():
            return HealthStatus(state=HealthState.UNHEALTHY, message="sys_tick loop stopped")
        if self._max_observed_drift_s > _DRIFT_WARNING_THRESHOLD_S:
            return HealthStatus(
                state=HealthState.DEGRADED,
                message=f"drift={self._max_observed_drift_s:.3f}s")
        return HealthStatus(
            state=HealthState.HEALTHY,
            message=(f"sys_tick={self.sys_tick_count} heartbeat={self.heartbeat_count} "
                     f"minute={self.minute_count} max_drift={self._max_observed_drift_s:.4f}s"))

    async def _on_synced(self, payload: dict) -> None:
        offset = payload.get("offset_s")
        if isinstance(offset, (int, float)):
            self._offset_s = float(offset)
            self._time_source = SOURCE_NTP

    def _official_now(self) -> float:
        return time.time() + self._offset_s

    async def _scheduled_loop(self, interval_s: float,
                              on_tick: Callable[[], Awaitable[None]],
                              align_to_wall_clock: bool = False) -> None:
        loop = asyncio.get_running_loop()
        if align_to_wall_clock:
            next_deadline = loop.time() + (interval_s - time.time() % interval_s)
        else:
            next_deadline = loop.time() + interval_s
        try:
            while True:
                sleep_for = next_deadline - loop.time()
                if sleep_for > 0:
                    await asyncio.sleep(sleep_for)
                else:
                    self._max_observed_drift_s = max(self._max_observed_drift_s, -sleep_for)
                    next_deadline = loop.time()
                try:
                    await on_tick()
                except Exception as exc:
                    if self._context is not None:
                        self._context.logger.error("clock tick failed: %s", exc)
                next_deadline += interval_s
                if next_deadline <= loop.time():
                    next_deadline = loop.time() + interval_s
        except asyncio.CancelledError:
            pass

    async def _on_sys_tick(self) -> None:
        self.sys_tick_count += 1
        await self._context.publish(EVENT_SYS_TICK, {
            "tick": self.sys_tick_count,
            "official_time": self._official_now(),
            "time_source": self._time_source})

    async def _on_heartbeat(self) -> None:
        self.heartbeat_count += 1
        await self._context.publish(EVENT_HEARTBEAT, {
            "beat": self.heartbeat_count,
            "official_time": self._official_now(),
            "time_source": self._time_source})

    async def _on_minute_elapsed(self) -> None:
        self.minute_count += 1
        await self._context.publish(EVENT_MINUTE, {
            "minute": self.minute_count,
            "official_time": self._official_now(),
            "time_source": self._time_source})
