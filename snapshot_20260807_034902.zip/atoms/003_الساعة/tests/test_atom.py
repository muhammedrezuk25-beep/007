import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext  # noqa: E402
import importlib.util as _ilu  # noqa: E402
from pathlib import Path as _AtomPath  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom003", _AtomPath(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom003"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
SYS_TICK = _mod.EVENT_SYS_TICK
SYNCED = _mod.EVENT_SYNCED
SOURCE_LOCAL = _mod.SOURCE_LOCAL
SOURCE_NTP = _mod.SOURCE_NTP


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for handler in self._handlers.get(name, []):
            result = handler(payload)
            if inspect.isawaitable(result):
                await result

    def make_context(self):
        return AtomContext(atom_id=3, config={}, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def test_sys_tick_publishes_official_time():
    print("\n--- test_sys_tick_publishes_official_time ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await atom._on_sys_tick()
    ticks = [p for n, p in bus.published if n == SYS_TICK]
    assert len(ticks) == 1
    assert ticks[0]["tick"] == 1
    assert isinstance(ticks[0]["official_time"], float)
    assert ticks[0]["time_source"] == SOURCE_LOCAL
    print(f"OK — نشر sys_tick: {ticks[0]}")


async def test_synced_updates_offset_and_source():
    print("\n--- test_synced_updates_offset_and_source ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    before = atom._official_now()
    await bus.publish(SYNCED, {"offset_s": 100.0})
    after = atom._official_now()
    assert atom._time_source == SOURCE_NTP, "المصدر لازم يصير NTP بعد المزامنة"
    assert after - before >= 99.0, "official_time لازم يقفز بمقدار الإزاحة"
    print(f"OK — الإزاحة طُبّقت: قفزة ~{after - before:.1f}s، المصدر {atom._time_source}")


async def test_bad_offset_ignored():
    """حالة فشل/حافة (قاعدة 9) — إزاحة غير رقمية تُتجاهَل بلا انهيار ولا تغيير."""
    print("\n--- test_bad_offset_ignored ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    await bus.publish(SYNCED, {"offset_s": "غير رقم"})
    assert atom._offset_s == 0.0, "الإزاحة الغلط ما لازم تتطبّق"
    assert atom._time_source == SOURCE_LOCAL, "المصدر يبقى محلي"
    await bus.publish(SYNCED, {})  # بلا مفتاح إطلاقًا
    assert atom._offset_s == 0.0
    print("OK — الإزاحة الغلط/الناقصة اتجاهلت بلا انهيار")


async def test_counts_increment_across_pulses():
    print("\n--- test_counts_increment_across_pulses ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    for _ in range(3):
        await atom._on_sys_tick()
    await atom._on_heartbeat()
    await atom._on_minute_elapsed()
    assert atom.sys_tick_count == 3
    assert atom.heartbeat_count == 1
    assert atom.minute_count == 1
    print(f"OK — العدّادات: sys_tick={atom.sys_tick_count} heartbeat={atom.heartbeat_count} minute={atom.minute_count}")


async def main():
    tests = [
        test_sys_tick_publishes_official_time,
        test_synced_updates_offset_and_source,
        test_bad_offset_ignored,
        test_counts_increment_across_pulses,
    ]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e)))
            print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e)))
            print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}")
        sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
