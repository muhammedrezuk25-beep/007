from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_CANDLE = "market_data.candle_closed"
EVENT_SWEEP = "liquidity.sweep.state"
EVENT_OUT = "probability.pullback.state"

METHOD = "pullback_after_sweep_decay"
ID_MODEL = "pullback_model"

SIGNAL_PULLBACK = "pullback"
SIGNAL_NEUTRAL = "neutral"

DIR_UP = "up"
DIR_DOWN = "down"
DIR_NONE = "none"

STATUS_OK = "ok"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

BUYSIDE = "buyside"
SELLSIDE = "sellside"
SWEEP = "sweep"
NONE = "none"

_PERCENT = 100.0
_NEUTRAL_PROB = 0.5
_FULL = 1.0
_LOW = 0.3
_DP = 4


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._sweep_prob = 0.7
        self._decay = 0.05
        self._horizon = 5
        self._state: dict[tuple, dict[str, Any]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._sweep_prob = float(cfg["sweep_prob"])
        self._decay = float(cfg["decay_per_candle"])
        self._horizon = int(cfg["horizon_candles"])
        context.subscribe(EVENT_CANDLE, self._on_candle)
        context.subscribe(EVENT_SWEEP, self._on_sweep)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    @staticmethod
    def _key(payload: dict[str, Any]) -> tuple:
        return (str(payload.get("symbol", "")), str(payload.get("timeframe", "")))

    async def _on_sweep(self, payload: dict[str, Any]) -> None:
        if not self._running or not isinstance(payload, dict):
            return
        signal = str(payload.get("signal", NONE))
        if signal in (BUYSIDE, SELLSIDE, SWEEP):
            self._state[self._key(payload)] = {"active": True, "age": 0, "side": signal}

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        self._candles_seen += 1
        st = self._state.get(key)
        if st is not None and st["active"]:
            age = st["age"]
            prob = max(_NEUTRAL_PROB, self._sweep_prob - self._decay * age)
            side = st["side"]
            direction = DIR_DOWN if side == BUYSIDE else DIR_UP if side == SELLSIDE else DIR_NONE
            st["age"] = age + 1
            if st["age"] > self._horizon:
                st["active"] = False
            await self._emit(symbol, timeframe, cycle_id, SIGNAL_PULLBACK, direction,
                             prob, _FULL, side, age)
            return
        await self._emit(symbol, timeframe, cycle_id, SIGNAL_NEUTRAL, DIR_NONE,
                         _NEUTRAL_PROB, _LOW, NONE, 0)

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, signal: str,
                    direction: str, prob: float, confidence: float, side: str,
                    age: int) -> None:
        if self._context is None:
            return
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_MODEL, "cycle_id": cycle_id,
            "status": STATUS_OK, "signal": signal,
            "score": int(round(min(_PERCENT, prob * _PERCENT))),
            "confidence": confidence,
            "quality": QUALITY_GOOD if signal != SIGNAL_NEUTRAL else QUALITY_LOW,
            "warnings": [], "metadata": {"method": METHOD, "timeframe": timeframe,
                                         "direction": direction, "probability": round(prob, _DP),
                                         "sweep_side": side, "candles_since": age}})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._state)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._state)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._state)})
