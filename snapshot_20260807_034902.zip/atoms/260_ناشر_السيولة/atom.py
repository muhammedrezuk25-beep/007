from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "liquidity.cycle.validated"
EVENT_OUT = "market.liquidity.updated"

ID_LIQUIDITY = "liquidity"

UID_POOL = "pool"
UID_BUY = "buyside"
UID_SELL = "sellside"
UID_SWEEP = "sweep"
UID_FVG = "fvg"

SIGNAL_SWEEP = "sweep"
DEFAULT_NONE = "none"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NOTHING = "NOTHING_PUBLISHED_YET"


def _signal(results: dict[str, Any], uid: str, default: str) -> Any:
    state = results.get(uid)
    return state.get("signal", default) if isinstance(state, dict) else default


def _meta(results: dict[str, Any], uid: str, field: str) -> Any:
    state = results.get(uid)
    if isinstance(state, dict):
        meta = state.get("metadata") or {}
        return meta.get(field)
    return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._seen = 0
        self._published = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN, self._on_validated)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_validated(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        if not symbol:
            return
        symbol = str(symbol)
        self._seen += 1
        cycle_id = str(payload.get("cycle_id", ""))
        timeframe = str(payload.get("timeframe", ""))
        results = payload.get("results") or {}
        sweep_sig = _signal(results, UID_SWEEP, DEFAULT_NONE)
        fvg_sig = _signal(results, UID_FVG, DEFAULT_NONE)
        if sweep_sig == SIGNAL_SWEEP:
            headline = SIGNAL_SWEEP
        elif fvg_sig != DEFAULT_NONE:
            headline = fvg_sig
        else:
            headline = DEFAULT_NONE
        valid = [s for s in results.values()
                 if isinstance(s, dict) and s.get("status") == STATUS_OK]
        status = STATUS_OK if valid else STATUS_INSUFFICIENT
        quality = QUALITY_GOOD if valid else QUALITY_LOW
        liquidity = {
            "pool": _signal(results, UID_POOL, DEFAULT_NONE),
            "buyside_level": _meta(results, UID_BUY, "price"),
            "sellside_level": _meta(results, UID_SELL, "price"),
            "sweep": {"signal": sweep_sig, "direction": _meta(results, UID_SWEEP, "direction"),
                      "price": _meta(results, UID_SWEEP, "price")},
            "fvg": {"signal": fvg_sig, "gap_top": _meta(results, UID_FVG, "gap_top"),
                    "gap_bottom": _meta(results, UID_FVG, "gap_bottom")}}
        meta = {"timeframe": timeframe, "present": payload.get("present", 0),
                "expected": payload.get("expected", 0)}
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "id": ID_LIQUIDITY, "cycle_id": cycle_id,
            "status": status, "signal": headline, "score": 0,
            "confidence": 1.0 if headline != DEFAULT_NONE else 0.0,
            "quality": quality, "warnings": [],
            "liquidity": liquidity, "metadata": meta})
        self._published += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._published == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NOTHING)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="seen=%d published=%d" % (self._seen, self._published),
            details={"seen": self._seen, "published": self._published})
