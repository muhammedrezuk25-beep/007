from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_IN_DRIFT = "time.utc.drift"
EVENT_IN_SYNCED = "time.utc.synced"
EVENT_OUT_DRIFT = "market.time.drift"
EVENT_OUT_SYNCED = "market.time.synced"

REASON_NOT_STARTED = "NOT_STARTED"


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self.drift_count = 0
        self.synced_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        context.subscribe(EVENT_IN_DRIFT, self._on_drift)
        context.subscribe(EVENT_IN_SYNCED, self._on_synced)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_drift(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.drift_count += 1
        await self._context.publish(EVENT_OUT_DRIFT, payload)

    async def _on_synced(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None:
            return
        self.synced_count += 1
        await self._context.publish(EVENT_OUT_SYNCED, payload)

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="drift=%d synced=%d" % (self.drift_count, self.synced_count))
