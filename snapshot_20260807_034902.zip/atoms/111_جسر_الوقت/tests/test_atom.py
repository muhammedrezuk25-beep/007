import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom111", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom111"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for h in self._handlers.get(name, []):
            r = h(payload)
            if inspect.isawaitable(r):
                await r

    def make_context(self):
        return AtomContext(atom_id=111, config={}, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def _make(bus):
    atom = Atom()
    await atom.initialize(bus.make_context())
    await atom.start()
    return atom


async def test_relays_drift_and_synced():
    print("\n--- test_relays_drift_and_synced ---")
    bus = FakeEventBus()
    await _make(bus)
    await bus.publish("time.utc.drift", {"drift_ms": 12})
    await bus.publish("time.utc.synced", {"offset_ms": 3})
    drift = [p for n, p in bus.published if n == "market.time.drift"]
    synced = [p for n, p in bus.published if n == "market.time.synced"]
    assert drift == [{"drift_ms": 12}] and synced == [{"offset_ms": 3}]
    print("OK — مرّر time.utc.* → market.time.* (نقطة وصول موحّدة)")


async def test_ignores_before_start():
    print("\n--- test_ignores_before_start ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())  # not started
    await bus.publish("time.utc.drift", {"drift_ms": 1})
    assert not [p for n, p in bus.published if n == "market.time.drift"]
    print("OK — ما يمرّر قبل التشغيل")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context())
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY -> HEALTHY")


async def main():
    tests = [test_relays_drift_and_synced, test_ignores_before_start, test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e))); print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e))); print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}"); sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
