from __future__ import annotations

import asyncio
import os
import sqlite3
import time
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

EVENT_FINAL_DECISION = "trading.final_decision"
EVENT_HALT = "emergency.halt"
EVENT_WRITTEN = "platform.brain_signal.written"
EVENT_WRITE_FAILED = "platform.brain_signal.write_failed"
EVENT_HALTED = "platform.brain_signal.halted"

_BUSY_TIMEOUT_MS = 3000
_CONNECT_TIMEOUT_S = 5.0
_BEAT_FAILURES_BEFORE_FAULT = 3

_SCHEMA = """
CREATE TABLE IF NOT EXISTS commands (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    request_id   TEXT    NOT NULL,
    action       TEXT    NOT NULL,
    symbol       TEXT    NOT NULL,
    side         TEXT,
    volume       REAL,
    price        REAL,
    stop_loss    REAL,
    take_profit  REAL,
    ticket       INTEGER,
    trail_dist   REAL,
    trail_step   REAL,
    params_json  TEXT,
    status       TEXT    NOT NULL DEFAULT 'PENDING',
    result       TEXT,
    created_at   REAL    NOT NULL,
    taken_at     REAL,
    done_at      REAL
)
"""
_INDEX = "CREATE INDEX IF NOT EXISTS idx_cmd_status ON commands(status, id)"
_DISPLAY_SCHEMA = """
CREATE TABLE IF NOT EXISTS display (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    daily_pct REAL, wins INTEGER, losses INTEGER, trades INTEGER,
    open_trades INTEGER, kill_switch TEXT, updated_at REAL
)
"""
_DISPLAY_SEED = "INSERT OR IGNORE INTO display (id) VALUES (1)"
_HEARTBEAT_SQL = "UPDATE display SET updated_at = ? WHERE id = 1"
_INSERT_SQL = ("INSERT INTO commands (request_id, action, symbol, side, volume,"
               " price, stop_loss, take_profit, status, created_at)"
               " VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)")
_CANCEL_SQL = ("UPDATE commands SET status='CANCELLED', result='EMERGENCY_HALT',"
               " done_at=? WHERE status='PENDING'")


def _resolve_db(configured: str) -> str:
    override = os.environ.get("NQ_BRIDGE_DB", "").strip()
    return override or configured


def _connect(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path, timeout=_CONNECT_TIMEOUT_S)
    conn.execute(f"PRAGMA busy_timeout={_BUSY_TIMEOUT_MS}")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._account_id = ""
        self._db_path = "nq_brain.db"
        self._beat_interval_s = 0.0
        self._beat_task: asyncio.Task | None = None
        self.heartbeat_written = 0
        self.heartbeat_failed = 0
        self._beats_failing = 0
        self.written_count = 0
        self.halted_count = 0
        self.last_write_success: bool | None = None
        self.last_write_at: float | None = None
        self.last_write_error: str | None = None

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._account_id = str(context.config["account_id"])
        self._db_path = _resolve_db(str(context.config["db_path"]))
        self._beat_interval_s = float(context.config["heartbeat_interval_s"])
        context.subscribe(EVENT_FINAL_DECISION, self._on_final_decision)
        context.subscribe(EVENT_HALT, self._on_emergency_halt)
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        try:
            conn = _connect(self._db_path)
            try:
                conn.execute(_SCHEMA)
                conn.execute(_INDEX)
                conn.execute(_DISPLAY_SCHEMA)
                conn.execute(_DISPLAY_SEED)
                conn.commit()
            finally:
                conn.close()
        except sqlite3.Error as exc:
            self.last_write_success = False
            self.last_write_error = str(exc)

    async def start(self) -> None:
        self._beat_task = asyncio.create_task(self._beat_loop())

    async def stop(self) -> None:
        if self._beat_task is not None:
            self._beat_task.cancel()
            try:
                await self._beat_task
            except asyncio.CancelledError:
                pass
            self._beat_task = None

    async def shutdown(self) -> None:
        await self.stop()

    def _is_mine(self, account_id: Any) -> bool:
        return account_id is not None and str(account_id) == self._account_id

    async def _on_final_decision(self, payload: dict) -> None:
        if self._context is None:
            return
        if not self._is_mine(payload.get("account_id")):
            return
        symbol = payload.get("symbol")
        side = payload.get("side") or payload.get("bias")
        if not symbol or side not in ("BUY", "SELL"):
            await self._record_failure(f"bad symbol/side: symbol={symbol!r} side={side!r}", payload)
            return
        if payload.get("volume") in (None, 0):
            await self._record_failure(f"missing volume request_id={payload.get('request_id')!r}", payload)
            return
        row = (
            str(payload.get("request_id") or ""),
            str(payload.get("action") or "OPEN"),
            str(symbol),
            side,
            payload.get("volume"),
            payload.get("reference_price"),
            payload.get("stop_loss"),
            payload.get("take_profit"),
            time.time(),
        )
        try:
            await asyncio.to_thread(self._insert_command, row)
            self.written_count += 1
            self.last_write_success = True
            self.last_write_at = time.time()
            self.last_write_error = None
            await self._context.publish(EVENT_WRITTEN, {**payload, "side": side, "account_id": self._account_id})
        except sqlite3.Error as exc:
            await self._record_failure(str(exc), payload)

    def _insert_command(self, row: tuple) -> None:
        conn = _connect(self._db_path)
        try:
            conn.execute(_INSERT_SQL, row)
            conn.commit()
        finally:
            conn.close()

    async def _on_emergency_halt(self, payload: dict) -> None:
        if self._context is None:
            return
        target = payload.get("account_id")
        if target is not None and str(target) != self._account_id:
            return
        self.halted_count += 1
        cancelled = 0
        try:
            cancelled = await asyncio.to_thread(self._cancel_pending)
            self.last_write_at = time.time()
        except sqlite3.Error as exc:
            await self._record_failure(str(exc))
        await self._context.publish(EVENT_HALTED, {
            "account_id": self._account_id,
            "reason": payload.get("reason"),
            "cancelled_commands": cancelled,
        })

    def _cancel_pending(self) -> int:
        conn = _connect(self._db_path)
        try:
            cursor = conn.execute(_CANCEL_SQL, (time.time(),))
            conn.commit()
            return cursor.rowcount
        finally:
            conn.close()

    def _write_heartbeat(self, stamp: float) -> None:
        try:
            conn = _connect(self._db_path)
            try:
                conn.execute(_DISPLAY_SCHEMA)
                conn.execute(_DISPLAY_SEED)
                conn.execute(_HEARTBEAT_SQL, (float(stamp),))
                conn.commit()
            finally:
                conn.close()
            self.heartbeat_written += 1
            self._beats_failing = 0
        except sqlite3.Error:
            self.heartbeat_failed += 1
            self._beats_failing += 1

    async def _beat_loop(self) -> None:
        loop = asyncio.get_running_loop()
        deadline = loop.time()
        try:
            while True:
                deadline += self._beat_interval_s
                if deadline <= loop.time():
                    deadline = loop.time() + self._beat_interval_s
                await asyncio.sleep(max(deadline - loop.time(), 0.0))
                await asyncio.to_thread(self._write_heartbeat, time.time())
        except asyncio.CancelledError:
            pass

    async def _record_failure(self, reason: str, order: dict | None = None) -> None:
        self.last_write_success = False
        self.last_write_error = reason
        if self._context is None:
            return
        body: dict[str, Any] = {"account_id": self._account_id, "reason": reason}
        if order:
            for field in ("request_id", "symbol", "side", "action", "volume"):
                if order.get(field) is not None:
                    body[field] = order[field]
        await self._context.publish(EVENT_WRITE_FAILED, body)
        self._context.logger.error("601 failed to write %s on %s: %s",
                                   body.get("request_id"), body.get("symbol"), reason)

    async def health_check(self) -> HealthStatus:
        details = {"account_id": self._account_id, "written": self.written_count,
                   "heartbeats": self.heartbeat_written, "heartbeat_failures": self.heartbeat_failed,
                   "beats_failing_in_a_row": self._beats_failing}
        if self._beats_failing >= _BEAT_FAILURES_BEFORE_FAULT:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=f"heartbeat not reaching bridge for {self._beats_failing} tries",
                                details=details)
        if self.last_write_success is False and not self.heartbeat_written:
            return HealthStatus(state=HealthState.UNHEALTHY,
                                message=f"last write failed: {self.last_write_error}", details=details)
        if self.last_write_success is False:
            return HealthStatus(state=HealthState.DEGRADED,
                                message=f"command not written: {self.last_write_error}", details=details)
        if self.heartbeat_written or self.last_write_success:
            return HealthStatus(state=HealthState.HEALTHY,
                                message=f"bridge writable, written={self.written_count}", details=details)
        return HealthStatus(state=HealthState.DEGRADED, message="no heartbeat yet", details=details)
