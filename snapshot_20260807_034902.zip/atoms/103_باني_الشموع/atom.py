from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_IN = "market.tick"
EVENT_OUT = "market_data.candle_closed"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"


def _to_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._period_s = 60.0
        self._candles: dict[str, dict[str, Any]] = {}
        self.candles_closed_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._period_s = float(context.config["period_s"])
        context.subscribe(EVENT_IN, self._on_tick)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    def _period_start(self, timestamp: float) -> float:
        return timestamp - (timestamp % self._period_s)

    async def _on_tick(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        bid = _to_float(payload.get("bid"))
        ask = _to_float(payload.get("ask"))
        timestamp = _to_float(payload.get("timestamp"))
        if not symbol or bid is None or ask is None or timestamp is None:
            return
        mid = (bid + ask) / 2.0
        period_start = self._period_start(timestamp)
        current = self._candles.get(symbol)
        if current is not None and current["period_start"] != period_start:
            await self._close_candle(symbol, current)
            current = None
        if current is None:
            self._candles[symbol] = {
                "period_start": period_start, "open": mid, "high": mid,
                "low": mid, "close": mid, "tick_count": 1}
        else:
            current["high"] = max(current["high"], mid)
            current["low"] = min(current["low"], mid)
            current["close"] = mid
            current["tick_count"] += 1

    async def _close_candle(self, symbol: str, candle: dict[str, Any]) -> None:
        if self._context is None:
            return
        self.candles_closed_count += 1
        await self._context.publish(EVENT_OUT, {
            "symbol": symbol, "open": candle["open"], "high": candle["high"],
            "low": candle["low"], "close": candle["close"],
            "volume": candle["tick_count"], "timeframe": "%ds" % int(self._period_s),
            "period_start": candle["period_start"], "timestamp": candle["period_start"]})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"closed": self.candles_closed_count,
                   "active_symbols": list(self._candles.keys())}
        if self.candles_closed_count == 0:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_CANDLES, details=details)
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="closed=%d" % self.candles_closed_count, details=details)
