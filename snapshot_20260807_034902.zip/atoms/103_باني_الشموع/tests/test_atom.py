import asyncio
import inspect
import os
import sys

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[3]))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.contracts.atom import AtomContext, HealthState  # noqa: E402
import importlib.util as _ilu  # noqa: E402

_spec = _ilu.spec_from_file_location(
    "_atom103", _Path(__file__).resolve().parents[1] / "atom.py")
_mod = _ilu.module_from_spec(_spec)
sys.modules["_atom103"] = _mod
_spec.loader.exec_module(_mod)
Atom = _mod.Atom
EVENT_IN = _mod.EVENT_IN
EVENT_OUT = _mod.EVENT_OUT


class _NullLogger:
    def debug(self, *a): pass
    def info(self, *a): pass
    def warning(self, *a): pass
    def error(self, *a): pass
    def critical(self, *a): pass


class FakeEventBus:
    def __init__(self):
        self.published = []
        self._handlers = {}

    def subscribe(self, name, handler):
        self._handlers.setdefault(name, []).append(handler)

    async def publish(self, name, payload):
        self.published.append((name, payload))
        for h in self._handlers.get(name, []):
            r = h(payload)
            if inspect.isawaitable(r):
                await r

    def make_context(self, cfg):
        return AtomContext(atom_id=103, config=cfg, logger=_NullLogger(),
                           publish=self.publish, subscribe=self.subscribe)


async def _make(bus, period=60.0):
    atom = Atom()
    await atom.initialize(bus.make_context({"period_s": period}))
    await atom.start()
    return atom


def _candles(bus):
    return [p for n, p in bus.published if n == EVENT_OUT]


async def test_builds_ohlc_and_closes_on_new_period():
    print("\n--- test_builds_ohlc_and_closes_on_new_period ---")
    bus = FakeEventBus()
    await _make(bus, period=60.0)
    # bar [0,60): mids 100, 102, 99 -> O=100 H=102 L=99 C=99, vol=3
    for bid, ask, ts in [(99.5, 100.5, 10.0), (101.5, 102.5, 20.0), (98.5, 99.5, 50.0)]:
        await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": bid, "ask": ask, "timestamp": ts})
    assert _candles(bus) == [], "bar not closed until a tick in next period"
    # tick at t=61 -> new period -> closes previous bar
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 100.0, "ask": 101.0, "timestamp": 61.0})
    c = _candles(bus)
    assert len(c) == 1, c
    bar = c[0]
    assert (bar["open"], bar["high"], bar["low"], bar["close"]) == (100.0, 102.0, 99.0, 99.0), bar
    assert bar["volume"] == 3 and bar["period_start"] == 0.0 and bar["timestamp"] == 0.0, bar
    assert bar["timeframe"] == "60s", bar
    print(f"OK — شمعة OHLC من التكات، تُغلق عند فترة جديدة: {bar}")


async def test_skips_tick_without_timestamp():
    print("\n--- test_skips_tick_without_timestamp ---")
    bus = FakeEventBus()
    atom = await _make(bus, period=60.0)
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 1, "ask": 2})  # no timestamp
    assert atom._candles == {}, "no timestamp -> tick skipped (Rule 13, no time.time)"
    print("OK — تكّة بلا timestamp تُتجاهل (قاعدة ١٣ — بلا time.time)")


async def test_per_symbol_independent():
    print("\n--- test_per_symbol_independent ---")
    bus = FakeEventBus()
    await _make(bus, period=60.0)
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 1, "ask": 1, "timestamp": 10.0})
    await bus.publish(EVENT_IN, {"symbol": "ES", "bid": 5, "ask": 5, "timestamp": 10.0})
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 2, "ask": 2, "timestamp": 70.0})
    c = _candles(bus)
    assert len(c) == 1 and c[0]["symbol"] == "NQ", c
    print("OK — كل رمز شمعته المستقلّة")


async def test_health_states():
    print("\n--- test_health_states ---")
    bus = FakeEventBus()
    atom = Atom()
    await atom.initialize(bus.make_context({"period_s": 60.0}))
    assert (await atom.health_check()).state == HealthState.UNHEALTHY
    await atom.start()
    assert (await atom.health_check()).state == HealthState.DEGRADED
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 1, "ask": 1, "timestamp": 10.0})
    await bus.publish(EVENT_IN, {"symbol": "NQ", "bid": 2, "ask": 2, "timestamp": 70.0})
    assert (await atom.health_check()).state == HealthState.HEALTHY
    print("OK — الصحة: UNHEALTHY -> DEGRADED(NO_CANDLES_YET) -> HEALTHY")


async def main():
    tests = [test_builds_ohlc_and_closes_on_new_period, test_skips_tick_without_timestamp,
             test_per_symbol_independent, test_health_states]
    failed = []
    for t in tests:
        try:
            await t()
        except AssertionError as e:
            failed.append((t.__name__, str(e))); print(f"FAILED: {t.__name__}: {e}")
        except Exception as e:
            failed.append((t.__name__, repr(e))); print(f"ERROR: {t.__name__}: {e!r}")
    print("\n" + "=" * 60)
    if failed:
        print(f"فشل {len(failed)} من أصل {len(tests)}"); sys.exit(1)
    print(f"نجح كل الاختبارات ({len(tests)}/{len(tests)})")


if __name__ == "__main__":
    asyncio.run(main())
