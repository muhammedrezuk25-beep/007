from __future__ import annotations

from collections import deque
from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "1.0.0"

EVENT_IN = "market_data.candle_closed"
EVENT_OUT = "analysis.volume.state"

METHOD = "relative_volume"
SOURCE_TICK = "tick"

SIGNAL_ACCUM = "accumulation"
SIGNAL_DISTRIB = "distribution"
SIGNAL_NORMAL = "normal"

TREND_RISING = "rising"
TREND_FALLING = "falling"
TREND_FLAT = "flat"

STATUS_OK = "ok"
STATUS_INSUFFICIENT = "insufficient_data"

QUALITY_GOOD = "good"
QUALITY_LOW = "low"

WARN_INSUFFICIENT = "insufficient_candles"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_CANDLES = "NO_CANDLES_YET"

_SCORE_MAX = 100.0
_RATIO_SCALE = 33.0


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._baseline_window = 50
        self._trend_short = 5
        self._trend_long = 20
        self._high_mult = 1.5
        self._spike_mult = 2.5
        self._min_candles = 20
        self._state: dict[tuple, dict[str, Any]] = {}
        self._candles_seen = 0
        self._emitted = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        cfg = context.config
        self._baseline_window = int(cfg["baseline_window"])
        self._trend_short = int(cfg["trend_short"])
        self._trend_long = int(cfg["trend_long"])
        self._high_mult = float(cfg["high_mult"])
        self._spike_mult = float(cfg["spike_mult"])
        self._min_candles = int(cfg["min_candles"])
        context.subscribe(EVENT_IN, self._on_candle)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_candle(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        symbol = payload.get("symbol")
        volume = _to_float(payload.get("volume"))
        close = _to_float(payload.get("close"))
        if not symbol or volume is None or close is None:
            return
        symbol = str(symbol)
        timeframe = str(payload.get("timeframe", ""))
        period_start = payload.get("period_start", payload.get("timestamp", ""))
        cycle_id = "%s|%s|%s" % (symbol, timeframe, period_start)
        key = (symbol, timeframe)
        st = self._state.get(key)
        if st is None:
            st = {"vol": deque(maxlen=self._baseline_window), "prev_close": None}
            self._state[key] = st
        prev_close = st["prev_close"]
        st["vol"].append(volume)
        st["prev_close"] = close
        self._candles_seen += 1
        await self._emit(symbol, timeframe, cycle_id, volume, close, prev_close, st)

    def _trend(self, vols: list[float]) -> str:
        if len(vols) < self._trend_long:
            return TREND_FLAT
        short = _mean(vols[-self._trend_short:])
        long = _mean(vols[-self._trend_long:])
        if long <= 0:
            return TREND_FLAT
        if short > long * self._high_mult:
            return TREND_RISING
        if short < long / self._high_mult:
            return TREND_FALLING
        return TREND_FLAT

    async def _emit(self, symbol: str, timeframe: str, cycle_id: str, volume: float,
                    close: float, prev_close: float | None, st: dict[str, Any]) -> None:
        if self._context is None:
            return
        base = {"symbol": symbol, "id": "volume", "cycle_id": cycle_id}
        meta = {"method": METHOD, "timeframe": timeframe, "source": SOURCE_TICK}
        vols = list(st["vol"])
        if len(vols) < self._min_candles:
            await self._context.publish(EVENT_OUT, {
                **base, "status": STATUS_INSUFFICIENT, "signal": SIGNAL_NORMAL,
                "score": 0, "confidence": 0.0, "quality": QUALITY_LOW,
                "warnings": [WARN_INSUFFICIENT], "metadata": meta})
            self._emitted += 1
            return
        avg_volume = _mean(vols)
        ratio = volume / avg_volume if avg_volume > 0 else 1.0
        spike = ratio >= self._spike_mult
        rising_price = prev_close is not None and close > prev_close
        falling_price = prev_close is not None and close < prev_close
        if ratio >= self._high_mult and rising_price:
            signal = SIGNAL_ACCUM
        elif ratio >= self._high_mult and falling_price:
            signal = SIGNAL_DISTRIB
        else:
            signal = SIGNAL_NORMAL
        score = int(round(min(_SCORE_MAX, ratio * _RATIO_SCALE)))
        confidence = round(min(1.0, len(vols) / self._baseline_window), 2)
        meta.update({"volume": round(volume, 2), "avg_volume": round(avg_volume, 2),
                     "ratio": round(ratio, 2), "spike": spike,
                     "volume_trend": self._trend(vols)})
        await self._context.publish(EVENT_OUT, {
            **base, "status": STATUS_OK, "signal": signal, "score": score,
            "confidence": confidence, "quality": QUALITY_GOOD, "warnings": [],
            "metadata": meta})
        self._emitted += 1

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        if self._candles_seen == 0:
            return HealthStatus(state=HealthState.DEGRADED, message=REASON_NO_CANDLES,
                                details={"tracked": len(self._state)})
        return HealthStatus(
            state=HealthState.HEALTHY,
            message="candles=%d emitted=%d tracked=%d" % (
                self._candles_seen, self._emitted, len(self._state)),
            details={"candles": self._candles_seen, "emitted": self._emitted,
                     "tracked": len(self._state)})
