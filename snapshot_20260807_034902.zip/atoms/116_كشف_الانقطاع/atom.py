from __future__ import annotations

from typing import Any

from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus

ATOM_VERSION = "2.0.0"

EVENT_TIME = "SYS_SECOND"
EVENT_INTERRUPTED = "market_data.feed_interrupted"
EVENT_RECOVERED = "market_data.feed_recovered"

REASON_NOT_STARTED = "NOT_STARTED"
REASON_NO_TIME = "NO_TIME_INPUT"

_FEED_EVENTS = (
    "feed.binance.tick",
    "feed.yahoo.tick",
    "feed.mt5.tick",
    "feed.rithmic.tick",
)


def _to_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


class Atom(AtomBase):
    def __init__(self) -> None:
        self._context: AtomContext | None = None
        self._running = False
        self._max_silence_s = 0.0
        self._now = 0.0
        self._last_activity: float | None = None
        self._interrupted = False
        self._interruption_count = 0

    async def initialize(self, context: AtomContext) -> None:
        self._context = context
        self._max_silence_s = float(context.config["max_silence_seconds"])
        for feed_event in _FEED_EVENTS:
            context.subscribe(feed_event, self._on_feed)
        context.subscribe(EVENT_TIME, self._on_time)

    async def start(self) -> None:
        self._running = True

    async def stop(self) -> None:
        self._running = False

    async def shutdown(self) -> None:
        await self.stop()

    async def _on_feed(self, payload: dict[str, Any]) -> None:
        if not self._running:
            return
        if self._now > 0.0:
            self._last_activity = self._now

    async def _on_time(self, payload: dict[str, Any]) -> None:
        if not self._running or self._context is None or not isinstance(payload, dict):
            return
        now = _to_float(payload.get("official_time"))
        if now is None:
            return
        self._now = now
        if self._last_activity is None:
            self._last_activity = now
            return
        elapsed = now - self._last_activity
        if elapsed > self._max_silence_s:
            if not self._interrupted:
                self._interrupted = True
                self._interruption_count += 1
                await self._context.publish(EVENT_INTERRUPTED, {
                    "elapsed_seconds": round(elapsed, 1),
                    "threshold_seconds": self._max_silence_s,
                    "interruption_count": self._interruption_count,
                    "timestamp": now})
        elif self._interrupted:
            self._interrupted = False
            await self._context.publish(EVENT_RECOVERED, {
                "interruption_count": self._interruption_count, "timestamp": now})

    async def health_check(self) -> HealthStatus:
        if not self._running:
            return HealthStatus(state=HealthState.UNHEALTHY, message=REASON_NOT_STARTED)
        details = {"interrupted": self._interrupted,
                   "interruption_count": self._interruption_count}
        if self._last_activity is None:
            return HealthStatus(
                state=HealthState.DEGRADED, message=REASON_NO_TIME, details=details)
        if self._interrupted:
            return HealthStatus(
                state=HealthState.DEGRADED, message="FEED_INTERRUPTED", details=details)
        return HealthStatus(
            state=HealthState.HEALTHY, message="feed_live", details=details)
