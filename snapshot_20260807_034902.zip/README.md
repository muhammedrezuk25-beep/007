# QUANT_NQ — Core Infrastructure

منصة تداول كمية معيارية قائمة على الذرات (Atoms). هذا المستودع يحتوي
**نواة التشغيل فقط** — بلا أي منطق تداول أو استراتيجية أو Broker.
الوثيقة الحاكمة: [`ATOM_CONSTITUTION_V2.0.md`](ATOM_CONSTITUTION_V2.0.md).

**الإصدار الحالي: Core V1.4.0 — مختوم ومجمّد.**

> **قبل أي تعديل داخل `core/`** اقرأ [`docs/core/ARCHITECTURE.md`](docs/core/ARCHITECTURE.md)
> والقاعدة الذهبية فيه. الحاجة لفتح ملف داخل `core/` بسبب إضافة أو حذف
> أو نقل ذرة تعني أن **تصميم الذرة خاطئ** — لا أن النواة ناقصة
> (المادة 41).

---

## التشغيل السريع

```bash
pip install -e ".[dev,api]"

PYTHONPATH=. pytest tests/ -q          # 95 اختبارًا
python3 scripts/freeze_core.py verify  # التحقق من ختم التجميد
bash scripts/verify_core.sh            # الاثنان معًا + فحص الجودة

python3 scripts/run_core.py                   # تشغيل فعلي + Dashboard على :8000
python3 scripts/run_core.py --demo-seconds 5  # يوقف نفسه تلقائيًا
python3 scripts/run_core.py --no-api          # بدون REST/WebSocket/Dashboard
```

بعد التشغيل: `http://localhost:8000` للوحة المراقبة الحية، أو
`http://localhost:8000/api/atoms` للحالة الخام بصيغة JSON.

**مرّة واحدة، لتفعيل حارس التجميد على جهازك:**

```bash
bash scripts/install_guard.sh   # يمنع أي commit يلمس core/
```

---

## وحدات النواة

| الوحدة | الملف | المسؤولية |
|---|---|---|
| Errors | `core/errors.py` | شجرة الاستثناءات الموحّدة برموز رقمية |
| Atom Contract | `core/contracts/atom.py` | العقد الوحيد الذي تلتزم به كل ذرة |
| Manifest Schema | `core/contracts/manifest.py` | مخطط `manifest.yaml` والتحقق منه |
| **Service Protocols** | `core/contracts/services.py` | واجهات مجردة لكل خدمة عامة (المادة 63) |
| Manifest Loader | `core/manifest_loader.py` | الاكتشاف التلقائي بأي عمق وأي تسمية |
| Logger | `core/logger.py` | لوغر موسوم بـ Atom ID + تتبّع سياقي |
| Config Loader | `core/config.py` | إعداد Core العام فقط (`config/core.yaml`) |
| Event Bus | `core/event_bus.py` | pub/sub معزول بمهلة لكل معالج |
| Version Manager | `core/version_manager.py` | توافق الإصدارات (PEP 440) |
| Dependency Resolver | `core/dependency_resolver.py` | ترتيب الإقلاع (Kahn) + كشف الحلقات |
| Registry | `core/registry.py` | حالة كل ذرة، مفهرسة بـ Atom ID فقط |
| Journal | `core/journal.py` | سجل append-only محدود الذاكرة |
| Metrics | `core/metrics.py` | مقاييس بمفتاح (Atom ID + اسم) |
| **Bootloader** | `core/bootloader.py` | ينسّق الدورة الكاملة |
| **Health Manager** | `core/health_manager.py` | مراقبة دورية + إعادة تشغيل معزولة |
| **Snapshot Engine** | `core/snapshot_engine.py` | التقاط/استعادة ذرّي للذرات الداعمة |
| **Hot Reload** | `core/hot_reload_service.py` | Runtime Discovery Engine |
| **API + Dashboard** | `core/api/` | REST + WebSocket + لوحة مراقبة |

---

## هيكل المشروع

```
QUANT_NQ/
├── core/              ← مجمَّد ومختوم بـ CORE.lock (المادة 1)
│   ├── contracts/      ← العقود والواجهات
│   ├── api/            ← REST + WebSocket + Dashboard
│   └── CORE.lock       ← بصمة التجميد — لا يُعدَّل يدويًا
├── atoms/             ← كل ذراتك، بأي عمق وأي تسمية
├── config/core.yaml   ← إعداد Core العام فقط
├── scripts/           ← run_core.py + أدوات الختم والتحقق
├── tests/core/        ← 95 اختبارًا، منها طرف-إلى-طرف كعملية حقيقية
├── docs/core/         ← ARCHITECTURE.md
└── var/               ← بيانات وقت التشغيل (لا تُدفع للمستودع)
```

---

## كتابة ذرة جديدة

كل ذرة مجلد يحتوي — كحدٍّ أدنى — `manifest.yaml` وملف الكود:

```yaml
# atoms/<أي مسار تريده>/manifest.yaml
id: 101                    # هوية رقمية فريدة، لا تتغيّر أبدًا (المادة 9)
name: my-atom
version: 1.0.0             # إصدار الذرة، مستقل عن النواة (المادة 19)
core_version: ">=1.4.0"    # قيد التوافق مع النواة (المادة 20)
critical: false
startup_mode: auto         # auto | manual | lazy
dependencies: []
health:
  interval_ms: 5000
  timeout_ms: 2000
  restart_on_failure: true
config:                    # إعداد الذرة يعيش هنا، لا في ملف منفصل
  window: 20
config_schema:             # ويُتحقق منه فور التحميل
  type: object
  properties: { window: { type: integer } }
metadata: { family: risk } # تصنيف حر تتجاهله النواة تمامًا (المادة 22)
```

```python
# atoms/<نفس المجلد>/atom.py
from core.contracts.atom import AtomBase, AtomContext, HealthState, HealthStatus


class Atom(AtomBase):
    async def initialize(self, context: AtomContext) -> None:
        self.log = context.logger          # موسوم بـ Atom ID تلقائيًا
        self.window = context.config["window"]
        context.subscribe("some.event", self._on_event)

    async def start(self) -> None: ...
    async def stop(self) -> None: ...      # قابل للعكس (Restart)
    async def shutdown(self) -> None: ...  # نهائي، غير قابل للعكس

    async def health_check(self) -> HealthStatus:
        return HealthStatus(state=HealthState.HEALTHY)

    async def _on_event(self, payload: dict) -> None:
        ...  # payload يحمل source و trace_id و timestamp تلقائيًا
```

ضعها في `atoms/` وهي تُكتشف وتُشغَّل خلال ثوانٍ **دون إعادة تشغيل
النواة**. احذف المجلد فتُزال حياً وتُطهَّر من Registry و Health Manager
و Event Bus معًا.

---

## القاعدة الذهبية

النواة ثابتة، والذرات متحركة (المادة 100). كل ما تريد تغييره أو ترقيته
مستقبلاً يعيش داخل ذرة — لا داخل `core/`.

الختم في `core/CORE.lock` لا يمنعك من شيء تقرره أنت؛ يمنع فقط أن يحدث
التعديل **دون أن تنتبه**.
